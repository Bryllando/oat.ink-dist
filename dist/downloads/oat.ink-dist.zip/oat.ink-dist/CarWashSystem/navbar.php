<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Car Wash & Auto Detailing Service System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'customers') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>customers/index.php">Car Owners</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'wash_packages') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>wash_packages/index.php">Detailing Packages</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'wash_orders') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>wash_orders/index.php">Service Jobs</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
