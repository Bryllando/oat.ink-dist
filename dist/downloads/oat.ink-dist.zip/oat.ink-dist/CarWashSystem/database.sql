CREATE DATABASE IF NOT EXISTS `car_wash_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `car_wash_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `customers` (
  `customerID` INT AUTO_INCREMENT PRIMARY KEY,
  `ownerName` VARCHAR(100) NOT NULL,
  `plateNumber` VARCHAR(50) NOT NULL,
  `vehicleModel` VARCHAR(100) NOT NULL,
  `contactNumber` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `wash_packages` (
  `packageID` INT AUTO_INCREMENT PRIMARY KEY,
  `packageName` VARCHAR(100) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `durationMinutes` INT NOT NULL,
  `inclusions` VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `wash_orders` (
  `orderID` INT AUTO_INCREMENT PRIMARY KEY,
  `customerID` INT NOT NULL,
  `packageID` INT NOT NULL,
  `serviceDate` DATE NOT NULL,
  `attendantName` VARCHAR(100) NOT NULL,
  `totalCost` DECIMAL(10,2) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Completed',
  FOREIGN KEY (`customerID`) REFERENCES `customers`(`customerID`) ON DELETE CASCADE,
  FOREIGN KEY (`packageID`) REFERENCES `wash_packages`(`packageID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `customers` (`ownerName`, `plateNumber`, `vehicleModel`, `contactNumber`) VALUES
('Atty. Francis Yap', 'GAF-4821', 'Toyota Fortuner White', '09171239876'),
('Corazon Dizon', 'JAN-3042', 'Honda Civic RS Red', '09182348765'),
('Guillermo Beltran', 'YAA-9122', 'Ford Ranger Wildtrak', '09223457654');

INSERT INTO `wash_packages` (`packageName`, `price`, `durationMinutes`, `inclusions`) VALUES
('Express Foam Wash & Vacuum', 250.0, 30, 'Body wash, tire black, interior vacuum'),
('Interior Deep Disinfection & Wax', 850.0, 60, 'Buffing wax, steam sanitization, engine wipe'),
('Ceramic Glass Coating Treatment', 2800.0, 120, 'Hydrophobic paint shield, leather conditioning');

INSERT INTO `wash_orders` (`customerID`, `packageID`, `serviceDate`, `attendantName`, `totalCost`, `status`) VALUES
(1, 1, '2026-11-01', 'Kuya Jojo', 250.0, 'Completed'),
(2, 2, '2026-11-02', 'Kuya Ruel', 850.0, 'Completed'),
(3, 3, '2026-11-03', 'Kuya Elmer', 2800.0, 'In Progress');

SET FOREIGN_KEY_CHECKS=1;
