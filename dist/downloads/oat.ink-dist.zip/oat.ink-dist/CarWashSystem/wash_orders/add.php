<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `customerID`, `ownerName` FROM `customers` ORDER BY `ownerName` ASC");
$e2List = $conn->query("SELECT `packageID`, `packageName` FROM `wash_packages` ORDER BY `packageName` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['customerID'] ?? 0);
    $id2 = (int)($_POST['packageID'] ?? 0);
    $serviceDate = is_string($_POST['serviceDate'] ?? null) ? trim($_POST['serviceDate']) : '';
    $attendantName = is_string($_POST['attendantName'] ?? null) ? trim($_POST['attendantName']) : '';
    $totalCost = is_string($_POST['totalCost'] ?? null) ? trim($_POST['totalCost']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($serviceDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $serviceDate) ||
        date('Y-m-d', strtotime($serviceDate) ?: 0) !== $serviceDate ||
        $attendantName === '' ||
        $totalCost === '' ||
        !is_numeric($totalCost) ||
        !is_finite((float)$totalCost) ||
        (float)$totalCost < 0 ||
        $status === '' ||
        $id1 <= 0 ||
        $id2 <= 0) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `wash_orders` (`customerID`, `packageID`, `serviceDate`, `attendantName`, `totalCost`, `status`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($serviceDate) . "', '" . $conn->real_escape_string($attendantName) . "', '" . $conn->real_escape_string($totalCost) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Service Job - Car Wash & Auto Detailing Service System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Service Job</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="customerID" class="weight-semibold">Select Car Owner</label>
                        <select id="customerID" name="customerID" class="" required>
                            <option value="">-- Choose Car Owner --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['customerID'] ?>" <?= ((int)($_POST['customerID'] ?? 0) === (int)$r['customerID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['ownerName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="packageID" class="weight-semibold">Select Package</label>
                        <select id="packageID" name="packageID" class="" required>
                            <option value="">-- Choose Package --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['packageID'] ?>" <?= ((int)($_POST['packageID'] ?? 0) === (int)$r['packageID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['packageName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="serviceDate" class="weight-semibold">Service Date</label>
                <input type="date" id="serviceDate" name="serviceDate" class=""  required value="<?= htmlspecialchars($serviceDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="attendantName" class="weight-semibold">Lead Detailer</label>
                <input type="text" id="attendantName" name="attendantName" class=""  required value="<?= htmlspecialchars($attendantName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="totalCost" class="weight-semibold">Total Amount Paid</label>
                <input type="number" id="totalCost" name="totalCost" min="0" class="" step="0.01" required value="<?= htmlspecialchars($totalCost ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="status" class="weight-semibold">Job Status</label>
                <input type="text" id="status" name="status" class=""  required value="<?= htmlspecialchars($status ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Service Job</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
