<?php
require_once __DIR__ . '/../database.php';

$sql = "SELECT t.*, e1.ownerName AS e1_title, e2.packageName AS e2_title 
        FROM `wash_orders` t 
        JOIN `customers` e1 ON t.customerID = e1.customerID 
        JOIN `wash_packages` e2 ON t.packageID = e2.packageID 
        ORDER BY t.orderID DESC";
$records = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Service Jobs - Car Wash & Auto Detailing Service System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Manage Service Jobs</h3>
            <a href="add.php" class="button">+ Record New Service Job</a>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="mb-0">
                    <thead class="">
                        <tr>
                            <th>#</th>
                            <th>Car Owner</th>
                            <th>Package</th>
                            <th>Service Date</th>
<th>Lead Detailer</th>
<th>Total Amount Paid</th>
<th>Job Status</th>

                            <th class="align-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['orderID'] ?></td>
                                    <td class="weight-bold"><?= htmlspecialchars($r['e1_title']) ?></td>
                                    <td><?= htmlspecialchars($r['e2_title']) ?></td>
                                    <td><?= htmlspecialchars($r['serviceDate']) ?></td>
<td><?= htmlspecialchars($r['attendantName']) ?></td>
<td><?= htmlspecialchars($r['totalCost']) ?></td>
<td><?= htmlspecialchars($r['status']) ?></td>

                                    <td class="align-right">
                                        <form method="POST" action="delete.php" class="inline-block" onsubmit="return confirm('Delete this record and any linked transactions?');">
                                            <input type="hidden" name="id" value="<?= $r['orderID'] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                                            <button type="submit" class="button small outline danger-action">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="align-center py-4 text-light">No transaction records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
</body>
</html>
