<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $packageName = is_string($_POST['packageName'] ?? null) ? trim($_POST['packageName']) : '';
    $price = is_string($_POST['price'] ?? null) ? trim($_POST['price']) : '';
    $durationMinutes = is_string($_POST['durationMinutes'] ?? null) ? trim($_POST['durationMinutes']) : '';
    $inclusions = is_string($_POST['inclusions'] ?? null) ? trim($_POST['inclusions']) : '';

    if ($packageName === '' ||
        $price === '' ||
        !is_numeric($price) ||
        !is_finite((float)$price) ||
        (float)$price < 0 ||
        $durationMinutes === '' ||
        !is_numeric($durationMinutes) ||
        !is_finite((float)$durationMinutes) ||
        (float)$durationMinutes < 0 ||
        filter_var($durationMinutes, FILTER_VALIDATE_INT) === false ||
        $inclusions === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `wash_packages` (`packageName`, `price`, `durationMinutes`, `inclusions`) VALUES ('" . $conn->real_escape_string($packageName) . "', '" . $conn->real_escape_string($price) . "', '" . $conn->real_escape_string($durationMinutes) . "', '" . $conn->real_escape_string($inclusions) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Package - Car Wash & Auto Detailing Service System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Add New Package</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="packageName" class="weight-semibold">Service Package</label>
                <input type="text" id="packageName" name="packageName" class=""  required value="<?= htmlspecialchars($packageName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="price" class="weight-semibold">Package Price</label>
                <input type="number" id="price" name="price" min="0" class="" step="0.01" required value="<?= htmlspecialchars($price ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="durationMinutes" class="weight-semibold">Duration (Minutes)</label>
                <input type="number" id="durationMinutes" name="durationMinutes" min="0" class="" step="1" required value="<?= htmlspecialchars($durationMinutes ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="inclusions" class="weight-semibold">Inclusions</label>
                <input type="text" id="inclusions" name="inclusions" class=""  required value="<?= htmlspecialchars($inclusions ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Save Package</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
