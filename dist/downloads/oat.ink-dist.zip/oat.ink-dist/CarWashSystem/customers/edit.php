<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `customers` WHERE `customerID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ownerName = is_string($_POST['ownerName'] ?? null) ? trim($_POST['ownerName']) : '';
    $plateNumber = is_string($_POST['plateNumber'] ?? null) ? trim($_POST['plateNumber']) : '';
    $vehicleModel = is_string($_POST['vehicleModel'] ?? null) ? trim($_POST['vehicleModel']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($ownerName === '' ||
        $plateNumber === '' ||
        $vehicleModel === '' ||
        $contactNumber === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `customers` SET `ownerName` = '" . $conn->real_escape_string($ownerName) . "', `plateNumber` = '" . $conn->real_escape_string($plateNumber) . "', `vehicleModel` = '" . $conn->real_escape_string($vehicleModel) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE `customerID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Car Owner - Car Wash & Auto Detailing Service System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Car Owner</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="ownerName" class="weight-semibold">Customer Name</label>
                <input type="text" id="ownerName" name="ownerName" class=""  required value="<?= htmlspecialchars($record['ownerName'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="plateNumber" class="weight-semibold">Plate Number</label>
                <input type="text" id="plateNumber" name="plateNumber" class=""  required value="<?= htmlspecialchars($record['plateNumber'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="vehicleModel" class="weight-semibold">Make & Model</label>
                <input type="text" id="vehicleModel" name="vehicleModel" class=""  required value="<?= htmlspecialchars($record['vehicleModel'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactNumber" class="weight-semibold">Phone Number</label>
                <input type="text" id="contactNumber" name="contactNumber" class=""  required value="<?= htmlspecialchars($record['contactNumber'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Car Owner</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
