<?php
$pageTitle = 'Dashboard';
$cssRoot   = '';
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/navbar.php';

$totalClients      = $pdo->query("SELECT COUNT(*) FROM clients")->fetchColumn();
$totalServices     = $pdo->query("SELECT COUNT(*) FROM services")->fetchColumn();
$totalAppointments = $pdo->query("SELECT COUNT(*) FROM appointments")->fetchColumn();
$scheduled         = $pdo->query("SELECT COUNT(*) FROM appointments WHERE status='Scheduled'")->fetchColumn();
?>
<div class="page-wrapper">
    <div class="topbar">
        <div>
            <h1 class="page-title">Dashboard</h1>
            <p><?= date('l, F j, Y') ?></p>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <h4><?= $totalClients ?></h4>
            <p>Total Clients</p>
        </div>
        <div class="stat-card">
            <h4><?= $totalServices ?></h4>
            <p>Total Services</p>
        </div>
        <div class="stat-card">
            <h4><?= $totalAppointments ?></h4>
            <p>Total Appointments</p>
        </div>
        <div class="stat-card">
            <h4><?= $scheduled ?></h4>
            <p>Scheduled</p>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3>Recent Appointments</h3>
            <a href="appointments/add.php" id="addNewApptBtn" class="button small">New Appointment</a>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Client</th>
                        <th>Service</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Fee</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $rows = $pdo->query("
                    SELECT a.appointmentID, CONCAT(c.fName,' ',c.lName) AS client,
                           s.serviceName, a.appointmentDate, a.appointmentTime, a.fee, a.status
                    FROM appointments a
                    JOIN clients  c ON a.clientID  = c.clientID
                    JOIN services s ON a.serviceID = s.serviceID
                    ORDER BY a.appointmentID DESC LIMIT 10
                ")->fetchAll();
                if ($rows): foreach ($rows as $r): ?>
                    <tr>
                        <td><?= $r['appointmentID'] ?></td>
                        <td><?= htmlspecialchars($r['client']) ?></td>
                        <td><?= htmlspecialchars($r['serviceName']) ?></td>
                        <td><?= $r['appointmentDate'] ?></td>
                        <td><?= date('h:i A', strtotime($r['appointmentTime'])) ?></td>
                        <td>&#8369;<?= number_format($r['fee'],2) ?></td>
                        <td><span class="badge badge-<?= strtolower($r['status']) ?>"><?= $r['status'] ?></span></td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="7" style="text-align:center;color:#555555;padding:20px;">No appointments yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once 'includes/footer.php'; ?>
