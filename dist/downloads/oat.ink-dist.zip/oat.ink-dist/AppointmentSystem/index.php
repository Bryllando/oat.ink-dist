<?php
// No login required — redirect directly to dashboard
header('Location: dashboard.php');
exit;
?>
