<?php
$host = '127.0.0.1';
$dbname = 'appointment_system';
$username = 'root';
$password = '';

try {
    // Connect to MySQL server first without dbname
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Auto-create database if not exists
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$dbname}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci");
    $pdo->exec("USE `{$dbname}`");

    // Auto-create tables and sample data if not present
    if ($pdo->query('SHOW TABLES')->fetch() === false) {
        $sql = @file_get_contents(__DIR__ . '/../database/appointment_system.sql');
        if ($sql === false) die('Database setup failed: cannot read the SQL file.');
        $pdo->exec("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;");
    }
} catch (PDOException $e) {
    die('Database setup failed: ' . htmlspecialchars($e->getMessage()));
}
?>
