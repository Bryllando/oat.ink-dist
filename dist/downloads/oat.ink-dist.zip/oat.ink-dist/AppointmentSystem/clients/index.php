<?php
$pageTitle = 'Clients';
$cssRoot   = '../';
require_once '../config/database.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM clients WHERE clientID = ?")->execute([$id]);
    header('Location: index.php?msg=deleted');
    exit;
}

$search = trim($_GET['search'] ?? '');
if ($search) {
    $stmt = $pdo->prepare("SELECT * FROM clients WHERE fName LIKE ? OR lName LIKE ? OR email LIKE ? OR contactNo LIKE ? ORDER BY clientID DESC");
    $like = "%$search%";
    $stmt->execute([$like, $like, $like, $like]);
} else {
    $stmt = $pdo->query("SELECT * FROM clients ORDER BY clientID DESC");
}
$clients = $stmt->fetchAll();
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper">
    <div class="topbar">
        <div>
            <h1 class="page-title">Clients / Customers</h1>
            <p>Manage all client records</p>
        </div>
        <a href="add.php" class="button" id="addClientBtn">Add Client</a>
    </div>

    <?php if (isset($_GET['msg'])): ?>
    <div role="alert" class="notice notice-<?= $_GET['msg'] === 'deleted' ? 'danger' : 'success' ?>">
        <?= $_GET['msg'] === 'deleted' ? 'Client deleted successfully.' : 'Client saved successfully.' ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <form class="search-form filter-form" method="GET" action="index.php">
            <input type="text" id="clientSearch" name="search" placeholder="Search by name, email, or contact..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="button">Search</button>
            <?php if ($search): ?>
            <a href="index.php" class="button outline">Clear</a>
            <?php endif; ?>
        </form>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Contact No.</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($clients): foreach ($clients as $c): ?>
                    <tr>
                        <td><?= $c['clientID'] ?></td>
                        <td><?= htmlspecialchars($c['fName']) ?></td>
                        <td><?= htmlspecialchars($c['lName']) ?></td>
                        <td><?= htmlspecialchars($c['contactNo']) ?></td>
                        <td><?= htmlspecialchars($c['email']) ?></td>
                        <td>
                            <a href="edit.php?id=<?= $c['clientID'] ?>" class="button outline small" id="editClient<?= $c['clientID'] ?>">Edit</a>
                            <a href="index.php?delete=<?= $c['clientID'] ?>" class="button danger-action small" id="delClient<?= $c['clientID'] ?>"
                           onclick="return confirm('Delete this client?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="6" style="text-align:center;color:#555555;padding:20px;">No clients found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
