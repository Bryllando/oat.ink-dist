<?php
$pageTitle = 'Edit Client';
$cssRoot   = '../';
require_once '../config/database.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$client = $pdo->prepare("SELECT * FROM clients WHERE clientID = ?");
$client->execute([$id]);
$data = $client->fetch();
if (!$data) { header('Location: index.php'); exit; }

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['fName']     = trim($_POST['fName'] ?? '');
    $data['lName']     = trim($_POST['lName'] ?? '');
    $data['contactNo'] = trim($_POST['contactNo'] ?? '');
    $data['email']     = trim($_POST['email'] ?? '');

    if (!$data['fName'])     $errors[] = 'First name is required.';
    if (!$data['lName'])     $errors[] = 'Last name is required.';
    if (!$data['contactNo']) $errors[] = 'Contact number is required.';
    if (!$data['email'])     $errors[] = 'Email is required.';

    if (!$errors) {
        $stmt = $pdo->prepare("UPDATE clients SET fName=?, lName=?, contactNo=?, email=? WHERE clientID=?");
        $stmt->execute([$data['fName'], $data['lName'], $data['contactNo'], $data['email'], $id]);
        header('Location: index.php?msg=saved');
        exit;
    }
}
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper form-page">
    <div class="topbar">
        <div>
            <h1 class="page-title">Edit Client</h1>
            <p>Update information for: <?= htmlspecialchars($data['fName'].' '.$data['lName']) ?></p>
        </div>
        <a href="index.php" class="button outline">Back to Clients</a>
    </div>

    <?php if ($errors): ?>
    <div role="alert" class="notice notice-danger"><?= implode('<br>', $errors) ?></div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="edit.php?id=<?= $id ?>" class="entry-form">
            <div class="form-grid">
                <div class="form-group">
                    <label for="fName">First Name</label>
                    <input id="fName" type="text" name="fName" value="<?= htmlspecialchars($data['fName']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="lName">Last Name</label>
                    <input id="lName" type="text" name="lName" value="<?= htmlspecialchars($data['lName']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="contactNo">Contact Number</label>
                    <input id="contactNo" type="text" name="contactNo" value="<?= htmlspecialchars($data['contactNo']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input id="email" type="email" name="email" value="<?= htmlspecialchars($data['email']) ?>" required>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" id="updateClientBtn" class="button">Update Client</button>
                <a href="index.php" class="button outline">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
