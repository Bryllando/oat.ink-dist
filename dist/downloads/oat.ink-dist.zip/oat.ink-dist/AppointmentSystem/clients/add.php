<?php
$pageTitle = 'Add Client';
$cssRoot   = '../';
require_once '../config/database.php';

$errors = [];
$data   = ['fName'=>'','lName'=>'','contactNo'=>'','email'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['fName']     = trim($_POST['fName'] ?? '');
    $data['lName']     = trim($_POST['lName'] ?? '');
    $data['contactNo'] = trim($_POST['contactNo'] ?? '');
    $data['email']     = trim($_POST['email'] ?? '');

    if (!$data['fName'])     $errors[] = 'First name is required.';
    if (!$data['lName'])     $errors[] = 'Last name is required.';
    if (!$data['contactNo']) $errors[] = 'Contact number is required.';
    if (!$data['email'])     $errors[] = 'Email is required.';

    if (!$errors) {
        $stmt = $pdo->prepare("INSERT INTO clients (fName, lName, contactNo, email) VALUES (?,?,?,?)");
        $stmt->execute([$data['fName'], $data['lName'], $data['contactNo'], $data['email']]);
        header('Location: index.php?msg=saved');
        exit;
    }
}
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper form-page">
    <div class="topbar">
        <div>
            <h1 class="page-title">Add New Client</h1>
            <p>Fill in the form to register a new client</p>
        </div>
        <a href="index.php" class="button outline">Back to Clients</a>
    </div>

    <?php if ($errors): ?>
    <div role="alert" class="notice notice-danger"><?= implode('<br>', $errors) ?></div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="add.php" class="entry-form">
            <div class="form-grid">
                <div class="form-group">
                    <label for="fName">First Name</label>
                    <input id="fName" type="text" name="fName" value="<?= htmlspecialchars($data['fName']) ?>" placeholder="e.g. Juan" required>
                </div>
                <div class="form-group">
                    <label for="lName">Last Name</label>
                    <input id="lName" type="text" name="lName" value="<?= htmlspecialchars($data['lName']) ?>" placeholder="e.g. Dela Cruz" required>
                </div>
                <div class="form-group">
                    <label for="contactNo">Contact Number</label>
                    <input id="contactNo" type="text" name="contactNo" value="<?= htmlspecialchars($data['contactNo']) ?>" placeholder="e.g. 09XX-XXX-XXXX" required>
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input id="email" type="email" name="email" value="<?= htmlspecialchars($data['email']) ?>" placeholder="e.g. juan@email.com" required>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" id="saveClientBtn" class="button">Save Client</button>
                <a href="index.php" class="button outline">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
