<?php
$pageTitle = 'New Appointment';
$cssRoot   = '../';
require_once '../config/database.php';

$clients  = $pdo->query("SELECT clientID, fName, lName FROM clients ORDER BY lName, fName")->fetchAll();
$services = $pdo->query("SELECT serviceID, serviceName, fee FROM services ORDER BY serviceName")->fetchAll();

$errors = [];
$data   = [
    'clientID'        => '',
    'serviceID'       => '',
    'appointmentDate' => date('Y-m-d'),
    'appointmentTime' => '08:00',
    'fee'             => '',
    'paymentMode'     => 'Cash',
    'status'          => 'Scheduled',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['clientID']        = (int)($_POST['clientID'] ?? 0);
    $data['serviceID']       = (int)($_POST['serviceID'] ?? 0);
    $data['appointmentDate'] = trim($_POST['appointmentDate'] ?? '');
    $data['appointmentTime'] = trim($_POST['appointmentTime'] ?? '');
    $data['fee']             = trim($_POST['fee'] ?? '');
    $data['paymentMode']     = trim($_POST['paymentMode'] ?? '');
    $data['status']          = trim($_POST['status'] ?? 'Scheduled');

    if (!$data['clientID'])        $errors[] = 'Please select a client.';
    if (!$data['serviceID'])       $errors[] = 'Please select a service.';
    if (!$data['appointmentDate']) $errors[] = 'Appointment date is required.';
    if (!$data['appointmentTime']) $errors[] = 'Appointment time is required.';
    if (!$data['paymentMode'])     $errors[] = 'Payment mode is required.';

    if (!$errors) {
        $svc = $pdo->prepare("SELECT fee FROM services WHERE serviceID=?");
        $svc->execute([$data['serviceID']]);
        $data['fee'] = $svc->fetchColumn();

        $stmt = $pdo->prepare("
            INSERT INTO appointments (clientID, serviceID, appointmentDate, appointmentTime, fee, paymentMode, status)
            VALUES (?,?,?,?,?,?,?)
        ");
        $stmt->execute([
            $data['clientID'], $data['serviceID'], $data['appointmentDate'],
            $data['appointmentTime'], $data['fee'], $data['paymentMode'], $data['status']
        ]);
        header('Location: index.php?msg=saved');
        exit;
    }
}
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper form-page">
    <div class="topbar">
        <div>
            <h1 class="page-title">New Appointment</h1>
            <p>Book a new appointment or reservation</p>
        </div>
        <a href="index.php" class="button outline">Back to Appointments</a>
    </div>

    <?php if ($errors): ?>
    <div role="alert" class="notice notice-danger"><?= implode('<br>', $errors) ?></div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="add.php" id="appointmentForm" class="entry-form">
            <div class="form-grid">
                <div class="form-group">
                    <label for="clientID">Client / Customer</label>
                    <select id="clientID" name="clientID" required>
                        <option value="">-- Select Client --</option>
                        <?php foreach ($clients as $c): ?>
                        <option value="<?= $c['clientID'] ?>" <?= $data['clientID']==$c['clientID'] ? 'selected':'' ?>>
                            <?= htmlspecialchars($c['lName'].', '.$c['fName']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="serviceID">Service / Room</label>
                    <select id="serviceID" name="serviceID" required onchange="computeFee()">
                        <option value="">-- Select Service --</option>
                        <?php foreach ($services as $s): ?>
                        <option value="<?= $s['serviceID'] ?>" data-fee="<?= $s['fee'] ?>" <?= $data['serviceID']==$s['serviceID'] ? 'selected':'' ?>>
                            <?= htmlspecialchars($s['serviceName']) ?> (&#8369;<?= number_format($s['fee'],2) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="appointmentDate">Appointment Date</label>
                    <input id="appointmentDate" type="date" name="appointmentDate"
                           value="<?= htmlspecialchars($data['appointmentDate']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="appointmentTime">Appointment Time</label>
                    <input id="appointmentTime" type="time" name="appointmentTime"
                           value="<?= htmlspecialchars($data['appointmentTime']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="fee">Calculated Fee (&#8369;)</label>
                    <input id="fee" type="text" name="fee" readonly
                           value="<?= $data['fee'] ? number_format($data['fee'],2) : '' ?>"
                           placeholder="Auto-computed from service">
                </div>

                <div class="form-group">
                    <label for="paymentMode">Payment Mode</label>
                    <select id="paymentMode" name="paymentMode" required>
                        <option value="Cash"  <?= $data['paymentMode']==='Cash'  ? 'selected':'' ?>>Cash</option>
                        <option value="Card"  <?= $data['paymentMode']==='Card'  ? 'selected':'' ?>>Card</option>
                        <option value="Other" <?= $data['paymentMode']==='Other' ? 'selected':'' ?>>Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <option value="Scheduled" <?= $data['status']==='Scheduled' ? 'selected':'' ?>>Scheduled</option>
                        <option value="Completed" <?= $data['status']==='Completed' ? 'selected':'' ?>>Completed</option>
                        <option value="Cancelled" <?= $data['status']==='Cancelled' ? 'selected':'' ?>>Cancelled</option>
                    </select>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" id="saveAppointmentBtn" class="button">Save Appointment</button>
                <a href="index.php" class="button outline">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
function computeFee() {
    var sel = document.getElementById('serviceID');
    var opt = sel.options[sel.selectedIndex];
    var fee = opt ? (opt.getAttribute('data-fee') || '') : '';
    document.getElementById('fee').value = fee ? parseFloat(fee).toFixed(2) : '';
}
window.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('serviceID').value) computeFee();
});
</script>

<?php require_once '../includes/footer.php'; ?>
