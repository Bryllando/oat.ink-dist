<?php
$pageTitle = 'Appointments';
$cssRoot   = '../';
require_once '../config/database.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM appointments WHERE appointmentID = ?")->execute([$id]);
    header('Location: index.php?msg=deleted');
    exit;
}

if (isset($_POST['update_status'])) {
    $id     = (int)$_POST['appointmentID'];
    $status = $_POST['status'];
    if (in_array($status, ['Scheduled','Completed','Cancelled'])) {
        $pdo->prepare("UPDATE appointments SET status=? WHERE appointmentID=?")->execute([$status, $id]);
    }
    header('Location: index.php?msg=updated');
    exit;
}

$search = trim($_GET['search'] ?? '');
$sql = "
    SELECT a.*, CONCAT(c.fName,' ',c.lName) AS clientName, s.serviceName
    FROM appointments a
    JOIN clients  c ON a.clientID  = c.clientID
    JOIN services s ON a.serviceID = s.serviceID
";
if ($search) {
    $sql .= " WHERE c.fName LIKE :s OR c.lName LIKE :s OR s.serviceName LIKE :s";
    $stmt = $pdo->prepare($sql . " ORDER BY a.appointmentID DESC");
    $stmt->execute([':s' => "%$search%"]);
} else {
    $stmt = $pdo->query($sql . " ORDER BY a.appointmentID DESC");
}
$appointments = $stmt->fetchAll();
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper">
    <div class="topbar">
        <div>
            <h1 class="page-title">Appointments / Reservations</h1>
            <p>Manage all appointment records</p>
        </div>
        <a href="add.php" class="button" id="addAppointmentBtn">New Appointment</a>
    </div>

    <?php if (isset($_GET['msg'])): ?>
    <div role="alert" class="notice notice-<?= $_GET['msg'] === 'deleted' ? 'danger' : 'success' ?>">
        <?php
        $msgs = [
            'deleted' => 'Appointment deleted successfully.',
            'saved'   => 'Appointment saved successfully.',
            'updated' => 'Status updated successfully.',
        ];
        echo $msgs[$_GET['msg']] ?? 'Done.';
        ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <form class="search-form filter-form" method="GET" action="index.php">
            <input type="text" id="appointmentSearch" name="search" placeholder="Search by client name or service..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="button">Search</button>
            <?php if ($search): ?>
            <a href="index.php" class="button outline">Clear</a>
            <?php endif; ?>
        </form>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Client</th>
                        <th>Service</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Fee</th>
                        <th>Payment</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($appointments): foreach ($appointments as $a): ?>
                    <tr>
                        <td><?= $a['appointmentID'] ?></td>
                        <td><?= htmlspecialchars($a['clientName']) ?></td>
                        <td><?= htmlspecialchars($a['serviceName']) ?></td>
                        <td><?= $a['appointmentDate'] ?></td>
                        <td><?= date('h:i A', strtotime($a['appointmentTime'])) ?></td>
                        <td>&#8369;<?= number_format($a['fee'],2) ?></td>
                        <td><?= htmlspecialchars($a['paymentMode']) ?></td>
                        <td>
                            <form method="POST" action="index.php" style="display:inline-flex;gap:4px;align-items:center;" class="entry-form">
                                <input type="hidden" name="appointmentID" value="<?= $a['appointmentID'] ?>">
                                <div class="form-group"><label for="statusSel                          ">Status</label>
                                    <select name="status" id="statusSel<?= $a['appointmentID'] ?>" class="status-select">
                                        <option value="Scheduled" <?= $a['status']==='Scheduled' ? 'selected':'' ?>>Scheduled</option>
                                        <option value="Completed" <?= $a['status']==='Completed' ? 'selected':'' ?>>Completed</option>
                                        <option value="Cancelled" <?= $a['status']==='Cancelled' ? 'selected':'' ?>>Cancelled</option>
                                    </select></div>
                                <div class="form-actions">
                                    <button type="submit" name="update_status" class="button small" id="updStatus<?= $a['appointmentID'] ?>">Save</button>
                                </div>
                            </form>
                        </td>
                        <td>
                            <a href="index.php?delete=<?= $a['appointmentID'] ?>" class="button danger-action small" id="delAppt<?= $a['appointmentID'] ?>"
                           onclick="return confirm('Delete this appointment?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="9" style="text-align:center;color:#555555;padding:20px;">No appointments found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
