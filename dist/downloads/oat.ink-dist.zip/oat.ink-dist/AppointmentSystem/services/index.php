<?php
$pageTitle = 'Services / Rooms';
$cssRoot   = '../';
require_once '../config/database.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM services WHERE serviceID = ?")->execute([$id]);
    header('Location: index.php?msg=deleted');
    exit;
}

$search = trim($_GET['search'] ?? '');
if ($search) {
    $stmt = $pdo->prepare("SELECT * FROM services WHERE serviceName LIKE ? OR description LIKE ? ORDER BY serviceID DESC");
    $like = "%$search%";
    $stmt->execute([$like, $like]);
} else {
    $stmt = $pdo->query("SELECT * FROM services ORDER BY serviceID DESC");
}
$services = $stmt->fetchAll();
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper">
    <div class="topbar">
        <div>
            <h1 class="page-title">Services / Rooms</h1>
            <p>Manage all service and room records</p>
        </div>
        <a href="add.php" class="button" id="addServiceBtn">Add Service</a>
    </div>

    <?php if (isset($_GET['msg'])): ?>
    <div role="alert" class="notice notice-<?= $_GET['msg'] === 'deleted' ? 'danger' : 'success' ?>">
        <?= $_GET['msg'] === 'deleted' ? 'Service deleted successfully.' : 'Service saved successfully.' ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <form class="search-form filter-form" method="GET" action="index.php">
            <input type="text" id="serviceSearch" name="search" placeholder="Search by service name or description..." value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="button">Search</button>
            <?php if ($search): ?>
            <a href="index.php" class="button outline">Clear</a>
            <?php endif; ?>
        </form>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Service / Room Name</th>
                        <th>Description</th>
                        <th>Fee (&#8369;)</th>
                        <th>Duration (min)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($services): foreach ($services as $s): ?>
                    <tr>
                        <td><?= $s['serviceID'] ?></td>
                        <td><?= htmlspecialchars($s['serviceName']) ?></td>
                        <td><?= htmlspecialchars($s['description']) ?></td>
                        <td>&#8369;<?= number_format($s['fee'],2) ?></td>
                        <td><?= $s['duration'] ?></td>
                        <td>
                            <a href="edit.php?id=<?= $s['serviceID'] ?>" class="button outline small" id="editService<?= $s['serviceID'] ?>">Edit</a>
                            <a href="index.php?delete=<?= $s['serviceID'] ?>" class="button danger-action small" id="delService<?= $s['serviceID'] ?>"
                           onclick="return confirm('Delete this service?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="6" style="text-align:center;color:#555555;padding:20px;">No services found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
