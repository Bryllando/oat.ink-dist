<?php
$pageTitle = 'Add Service';
$cssRoot   = '../';
require_once '../config/database.php';

$errors = [];
$data   = ['serviceName'=>'','description'=>'','fee'=>'','duration'=>''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['serviceName'] = trim($_POST['serviceName'] ?? '');
    $data['description'] = trim($_POST['description'] ?? '');
    $data['fee']         = trim($_POST['fee'] ?? '');
    $data['duration']    = trim($_POST['duration'] ?? '');

    if (!$data['serviceName']) $errors[] = 'Service name is required.';
    if (!$data['fee'])         $errors[] = 'Fee is required.';
    if (!$data['duration'])    $errors[] = 'Duration is required.';

    if (!$errors) {
        $stmt = $pdo->prepare("INSERT INTO services (serviceName, description, fee, duration) VALUES (?,?,?,?)");
        $stmt->execute([$data['serviceName'], $data['description'], $data['fee'], $data['duration']]);
        header('Location: index.php?msg=saved');
        exit;
    }
}
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper form-page">
    <div class="topbar">
        <div>
            <h1 class="page-title">Add New Service</h1>
            <p>Register a new service or room</p>
        </div>
        <a href="index.php" class="button outline">Back to Services</a>
    </div>

    <?php if ($errors): ?>
    <div role="alert" class="notice notice-danger"><?= implode('<br>', $errors) ?></div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="add.php" class="entry-form">
            <div class="form-grid">
                <div class="form-group">
                    <label for="serviceName">Service / Room Name</label>
                    <input id="serviceName" type="text" name="serviceName" value="<?= htmlspecialchars($data['serviceName']) ?>" placeholder="e.g. General Consultation" required>
                </div>
                <div class="form-group">
                    <label for="fee">Fee / Rate (&#8369;)</label>
                    <input id="fee" type="number" step="0.01" min="0" name="fee" value="<?= htmlspecialchars($data['fee']) ?>" placeholder="e.g. 500.00" required>
                </div>
                <div class="form-group">
                    <label for="duration">Duration (minutes)</label>
                    <input id="duration" type="number" min="1" name="duration" value="<?= htmlspecialchars($data['duration']) ?>" placeholder="e.g. 60" required>
                </div>
                <div class="form-group" style="grid-column:1/-1">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="3" placeholder="Brief description of the service..."><?= htmlspecialchars($data['description']) ?></textarea>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" id="saveServiceBtn" class="button">Save Service</button>
                <a href="index.php" class="button outline">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
