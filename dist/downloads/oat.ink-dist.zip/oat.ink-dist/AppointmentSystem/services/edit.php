<?php
$pageTitle = 'Edit Service';
$cssRoot   = '../';
require_once '../config/database.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$svc = $pdo->prepare("SELECT * FROM services WHERE serviceID = ?");
$svc->execute([$id]);
$data = $svc->fetch();
if (!$data) { header('Location: index.php'); exit; }

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data['serviceName'] = trim($_POST['serviceName'] ?? '');
    $data['description'] = trim($_POST['description'] ?? '');
    $data['fee']         = trim($_POST['fee'] ?? '');
    $data['duration']    = trim($_POST['duration'] ?? '');

    if (!$data['serviceName']) $errors[] = 'Service name is required.';
    if (!$data['fee'])         $errors[] = 'Fee is required.';
    if (!$data['duration'])    $errors[] = 'Duration is required.';

    if (!$errors) {
        $stmt = $pdo->prepare("UPDATE services SET serviceName=?, description=?, fee=?, duration=? WHERE serviceID=?");
        $stmt->execute([$data['serviceName'], $data['description'], $data['fee'], $data['duration'], $id]);
        header('Location: index.php?msg=saved');
        exit;
    }
}
require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>
<div class="page-wrapper form-page">
    <div class="topbar">
        <div>
            <h1 class="page-title">Edit Service</h1>
            <p>Update information for: <?= htmlspecialchars($data['serviceName']) ?></p>
        </div>
        <a href="index.php" class="button outline">Back to Services</a>
    </div>

    <?php if ($errors): ?>
    <div role="alert" class="notice notice-danger"><?= implode('<br>', $errors) ?></div>
    <?php endif; ?>

    <div class="card">
        <form method="POST" action="edit.php?id=<?= $id ?>" class="entry-form">
            <div class="form-grid">
                <div class="form-group">
                    <label for="serviceName">Service / Room Name</label>
                    <input id="serviceName" type="text" name="serviceName" value="<?= htmlspecialchars($data['serviceName']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="fee">Fee / Rate (&#8369;)</label>
                    <input id="fee" type="number" step="0.01" min="0" name="fee" value="<?= htmlspecialchars($data['fee']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="duration">Duration (minutes)</label>
                    <input id="duration" type="number" min="1" name="duration" value="<?= htmlspecialchars($data['duration']) ?>" required>
                </div>
                <div class="form-group" style="grid-column:1/-1">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="3"><?= htmlspecialchars($data['description']) ?></textarea>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" id="updateServiceBtn" class="button">Update Service</button>
                <a href="index.php" class="button outline">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
