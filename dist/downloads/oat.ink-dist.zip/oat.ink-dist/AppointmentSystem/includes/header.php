<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="<?= $cssRoot ?? '' ?>assets/css/oat.min.css">
        <link rel="stylesheet" href="<?= $cssRoot ?? '' ?>assets/css/app.css">
        <script src="<?= $cssRoot ?? '' ?>assets/js/oat.min.js" defer></script>
        <script src="<?= $cssRoot ?? '' ?>assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= $pageTitle ?? 'Appointment System' ?> | LibradillaAppointment</title>
        <meta name="description" content="Appointment Reservation System - University of Cebu Capstone Project">
    
    </head>
    <body>
