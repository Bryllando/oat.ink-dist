<?php
$current    = basename($_SERVER['PHP_SELF']);
$currentDir = basename(dirname($_SERVER['PHP_SELF']));

function nav_active($dir) {
    global $currentDir;
    return ($currentDir === $dir) ? 'active' : '';
}
function nav_active_file($file) {
    global $current, $currentDir;
    return ($current === $file && $currentDir === '.') ? 'active' : '';
}
?>
<nav class="app-nav">
    <a class="app-brand" href="<?= $cssRoot ?? '' ?>dashboard.php">AppointSys</a>
    <ul class="nav-links">
        <li><a href="<?= $cssRoot ?? '' ?>dashboard.php"
               class="nav-link <?= nav_active_file('dashboard.php') ?>">Dashboard</a></li>
        <li><a href="<?= $cssRoot ?? '' ?>clients/index.php"
               class="nav-link <?= nav_active('clients') ?>">Clients</a></li>
        <li><a href="<?= $cssRoot ?? '' ?>services/index.php"
               class="nav-link <?= nav_active('services') ?>">Services / Rooms</a></li>
        <li><a href="<?= $cssRoot ?? '' ?>appointments/index.php"
               class="nav-link <?= nav_active('appointments') ?>">Appointments</a></li>
    </ul>
</nav>
