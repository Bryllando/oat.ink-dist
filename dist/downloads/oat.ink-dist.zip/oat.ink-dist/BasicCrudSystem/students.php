<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';

// ====== CHANGE THESE TEXTS ======
$tableName            = 'students';
$pageTitle            = 'Students';
$pageHeading          = 'Students List';
$pageNote             = 'Manage student entries here. Use search to filter results.';
$searchPlaceholder    = 'Search Students';
$addButtonText        = 'Add Student';
$addPageTitle         = 'Add Student';
$editPageTitle        = 'Edit Student';
$deleteConfirmMessage = 'Are you sure you want to delete this student?';
// ================================

$activePage = 'students';
require __DIR__ . '/includes/crud.php';
