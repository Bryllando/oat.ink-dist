<?php
function render_layout($pageTitle, $pageHeading, $content, $activePage = 'home') {
    global $DB_CONFIG;
    $navItems = $DB_CONFIG['menu_items'] ?? [
        ['name' => 'Home', 'url' => 'home.php', 'key' => 'home'],
        ['name' => 'Records', 'url' => 'index.php', 'key' => 'records'],
        ['name' => 'Students', 'url' => 'students.php', 'key' => 'students'],
        ['name' => 'More Items', 'url' => 'about.php', 'key' => 'about'],
    ];
    ?>
    <!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
        
    </head>
    <body>
        <nav class="top-nav">
            <div class="nav-brand"><?= htmlspecialchars($DB_CONFIG['app_title'] ?? 'Management System', ENT_QUOTES, 'UTF-8') ?></div>
            <div class="nav-links">
                <?php foreach ($navItems as $item) : ?>
                <a href="<?= $item['url'] ?>" class="nav-link <?= $activePage === $item['key'] ? 'active' : '' ?>"><?= htmlspecialchars($item['name'], ENT_QUOTES, 'UTF-8') ?></a>
                <?php endforeach; ?>
            </div>
        </nav>
        <div class="container">
            <h1><?= htmlspecialchars($pageHeading, ENT_QUOTES, 'UTF-8') ?></h1>
            <?= $content ?>
        </div>
    </body>
</html>
    <?php
}
