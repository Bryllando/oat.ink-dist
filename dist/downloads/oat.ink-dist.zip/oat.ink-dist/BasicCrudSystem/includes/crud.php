<?php
if (!isset($tableName) || !in_array($tableName, ['records', 'students', 'more_items'], true)) {
    http_response_code(404);
    exit('Page not found.');
}
$pageFile = basename($_SERVER['SCRIPT_NAME']);
$fieldLabels = $fieldLabels ?? ['name' => 'Name', 'email' => 'Email', 'phone' => 'Phone', 'address' => 'Address'];
$values = ['name' => '', 'email' => '', 'phone' => '', 'address' => ''];
$errors = [];
$generalError = '';
$missing = false;
$id = null;
$action = is_string($_GET['action'] ?? null) ? $_GET['action'] : 'list';
if (isset($_GET['delete'])) $action = 'delete';
if (!in_array($action, ['list', 'add', 'edit', 'delete'], true)) $action = 'list';
$posting = $_SERVER['REQUEST_METHOD'] === 'POST';
if ($posting) {
    $submitted = array_intersect(['submit_add', 'submit_update', 'submit_delete'], array_keys($_POST));
    if (count($submitted) !== 1) {
        $generalError = 'Choose a valid form action.';
        http_response_code(400);
    } else $action = ['submit_add' => 'add', 'submit_update' => 'edit', 'submit_delete' => 'delete'][reset($submitted)];
    if (!is_string($_POST['csrf_token'] ?? null) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $generalError = 'Your form expired. Reload this page and try again.';
        http_response_code(403);
    }
}
if (in_array($action, ['edit', 'delete'], true)) {
    $id = filter_var($posting ? ($_POST['id'] ?? null) : ($_GET['delete'] ?? $_GET['id'] ?? null), FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2147483647]]);
    $item = null;
    if ($id) {
        $statement = mysqli_prepare($conn, "SELECT * FROM `$tableName` WHERE id = ?");
        mysqli_stmt_bind_param($statement, 'i', $id);
        mysqli_stmt_execute($statement);
        $item = mysqli_fetch_assoc(mysqli_stmt_get_result($statement));
    }
    if ($item) foreach ($values as $field => $unused) $values[$field] = $item[$field];
    else { $missing = true; if (!$generalError) http_response_code(404); }
}
if ($posting && !$missing && in_array($action, ['add', 'edit'], true)) {
    foreach ($values as $field => $unused) $values[$field] = is_string($_POST[$field] ?? null) ? trim($_POST[$field]) : '';
    if (!$generalError) {
        if (!preg_match('/^.{1,100}$/us', $values['name'])) $errors['name'] = 'Enter a name of 1 to 100 characters.';
        if (strlen($values['email']) > 100 || !filter_var($values['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Enter a valid email address, up to 100 characters.';
        if (!preg_match('/^[0-9+() .-]{1,20}$/', $values['phone'])) $errors['phone'] = 'Enter a phone of 1 to 20 digits, spaces, +, -, dots or parentheses.';
        if (!preg_match('/^.{1,1000}$/us', $values['address'])) $errors['address'] = 'Enter an address of 1 to 1,000 characters.';
        if ($errors) http_response_code(422);
    }
}
if ($posting && !$generalError && !$errors && !$missing) {
    try {
        if ($action === 'delete') {
            $statement = mysqli_prepare($conn, "DELETE FROM `$tableName` WHERE id = ?");
            mysqli_stmt_bind_param($statement, 'i', $id);
        } else {
            $sql = $action === 'add' ? "INSERT INTO `$tableName` (name, email, phone, address) VALUES (?, ?, ?, ?)" : "UPDATE `$tableName` SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?";
            $statement = mysqli_prepare($conn, $sql);
            if ($action === 'add') mysqli_stmt_bind_param($statement, 'ssss', $values['name'], $values['email'], $values['phone'], $values['address']);
            else mysqli_stmt_bind_param($statement, 'ssssi', $values['name'], $values['email'], $values['phone'], $values['address'], $id);
        }
        mysqli_stmt_execute($statement);
        $_SESSION['crud_flash'] = ['add' => 'Entry added successfully.', 'edit' => 'Entry updated successfully.', 'delete' => 'Entry deleted successfully.'][$action];
        header('Location: ' . $pageFile);
        exit;
    } catch (mysqli_sql_exception $error) {
        error_log($error->getMessage());
        http_response_code(503);
        $generalError = 'The change could not be saved. Your entries are kept below. Check the database and try again.';
    }
}
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
if ($action === 'list') {
    $statement = mysqli_prepare($conn, "SELECT * FROM `$tableName` WHERE name LIKE ? OR email LIKE ? OR phone LIKE ? OR address LIKE ? ORDER BY id DESC");
    $like = '%' . $search . '%';
    mysqli_stmt_bind_param($statement, 'ssss', $like, $like, $like, $like);
    mysqli_stmt_execute($statement);
    $rows = mysqli_stmt_get_result($statement);
}
ob_start();
?>
<?php if (!empty($_SESSION['crud_flash'])): ?><div class="notice notice-success" role="status"><?= escape_value($_SESSION['crud_flash']) ?></div><?php unset($_SESSION['crud_flash']); endif; ?>
<?php if ($generalError): ?><div class="notice notice-danger" role="alert"><?= escape_value($generalError) ?></div><?php endif; ?>
<?php if ($missing): ?>
    <div class="notice notice-warning" role="alert">This entry does not exist or has already been deleted.</div>
    <a class="button outline" href="<?= escape_value($pageFile) ?>">Back to list</a>
<?php elseif ($action === 'delete'): ?>
    <section class="form-panel">
        <h2><?= escape_value($values['name']) ?></h2>
        <p><?= escape_value($values['email']) ?></p>
        <p><?= escape_value($deleteConfirmMessage) ?> This permanently removes the entry and cannot be undone.</p>
        <form method="post" action="<?= escape_value($pageFile) ?>" class="form-actions">
            <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['csrf_token']) ?>">
            <input type="hidden" name="id" value="<?= $id ?>">
            <button type="submit" name="submit_delete" value="1" class="danger-action">Yes, delete entry</button>
            <a class="button outline" href="<?= escape_value($pageFile) ?>">Keep entry</a>
        </form>
    </section>
<?php elseif (in_array($action, ['add', 'edit'], true)): ?>
    <?php if ($errors): ?><div class="notice notice-danger" role="alert"><strong>Review the form before saving.</strong><ul><?php foreach ($errors as $field => $message): ?><li><a href="#input-<?= $field ?>"><?= escape_value($message) ?></a></li><?php endforeach; ?></ul></div><?php endif; ?>
    <form method="post" action="<?= escape_value($pageFile) ?>" class="entry-form form-panel">
        <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['csrf_token']) ?>">
        <?php if ($action === 'edit'): ?><input type="hidden" name="id" value="<?= $id ?>"><?php endif; ?>
        <p class="page-note">All fields are required.</p>
        <div class="field-grid">
            <?php foreach ($fieldLabels as $field => $label): ?>
            <div>
                <label for="input-<?= $field ?>"><?= escape_value($label) ?></label>
                <?php if ($field === 'address'): ?>
                    <textarea id="input-address" name="address" maxlength="1000" rows="3" required <?= isset($errors[$field]) ? 'aria-invalid="true" aria-describedby="error-address"' : '' ?>><?= escape_value($values[$field]) ?></textarea>
                <?php else: ?>
                    <input id="input-<?= $field ?>" name="<?= $field ?>" type="<?= ['name' => 'text', 'email' => 'email', 'phone' => 'tel'][$field] ?>" maxlength="<?= $field === 'phone' ? 20 : 100 ?>" required value="<?= escape_value($values[$field]) ?>" <?= isset($errors[$field]) ? 'aria-invalid="true" aria-describedby="error-'.$field.'"' : '' ?>>
                <?php endif; ?>
                <?php if (isset($errors[$field])): ?><p id="error-<?= $field ?>" class="text-danger small"><?= escape_value($errors[$field]) ?></p><?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="form-actions"><button type="submit" name="<?= $action === 'add' ? 'submit_add' : 'submit_update' ?>" value="1"><?= $action === 'add' ? 'Save Entry' : 'Save Changes' ?></button><a class="button outline" href="<?= escape_value($pageFile) ?>">Cancel</a></div>
    </form>
<?php else: ?>
    <div class="actions-bar">
        <form method="get" action="<?= escape_value($pageFile) ?>" class="search-form filter-form filter-panel"><label for="search">Search <?= escape_value($pageTitle) ?></label><input id="search" name="search" type="search" value="<?= escape_value($search) ?>" placeholder="<?= escape_value($searchPlaceholder) ?>"><button type="submit">Search</button><a class="button outline" href="<?= escape_value($pageFile) ?>">Clear</a></form>
        <a class="button" href="<?= escape_value($pageFile) ?>?action=add"><?= escape_value($addButtonText) ?></a>
    </div>
    <p class="page-note"><?= escape_value($pageNote) ?></p>
    <div class="table-responsive" role="region" aria-label="<?= escape_value($pageTitle) ?> table" tabindex="0"><table>
        <thead><tr><th scope="col">No.</th><?php foreach ($fieldLabels as $label): ?><th scope="col"><?= escape_value($label) ?></th><?php endforeach; ?><th scope="col">Actions</th></tr></thead>
        <tbody>
        <?php $number = 1; while ($item = mysqli_fetch_assoc($rows)): ?>
            <tr><td><?= $number++ ?></td><?php foreach ($fieldLabels as $field => $label): ?><td><?= escape_value($item[$field]) ?></td><?php endforeach; ?><td class="actions-cell"><a class="button small outline" href="<?= escape_value($pageFile) ?>?action=edit&amp;id=<?= (int)$item['id'] ?>">Edit</a><a class="button small danger-action" href="<?= escape_value($pageFile) ?>?action=delete&amp;id=<?= (int)$item['id'] ?>">Delete</a></td></tr>
        <?php endwhile; ?>
        <?php if (mysqli_num_rows($rows) === 0): ?><tr><td colspan="6" class="empty-state"><?= $search === '' ? 'No entries yet. Add an entry to get started.' : 'No entries match this search. Try another search or clear it.' ?></td></tr><?php endif; ?>
        </tbody>
    </table></div>
<?php endif; ?>
<?php
$content = ob_get_clean();
$heading = ['add' => $addPageTitle, 'edit' => $editPageTitle, 'delete' => 'Delete entry?', 'list' => $pageHeading][$action];
render_layout($pageTitle, $heading, $content, $activePage);
