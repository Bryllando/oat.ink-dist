# Basic CRUD System - setup and copy-and-paste Oat example

Choose **43** in `deploy_exam.bat`. This guide matches the existing Basic CRUD schema. For more components and full add/edit/delete handler examples, open [the option 44 Oat cookbook](../CompleteCrudSystem/readme.md#4-reuse-the-complete-oat-design) in your original Skilltest folder. That guide is also included with option 44 deployments.

## Setup and files

1. Start Apache and MySQL in XAMPP.
2. Choose 43 in the deployer and enter a new folder such as `BasicPractice`, or copy this whole folder to `C:\xampp\htdocs\BasicPractice`.
3. Open `http://localhost/BasicPractice/`. The connector prepares its tables on a fresh installation.
4. For the copyable example below, save its whole PHP block as `practice.php` beside `config.php`, then open `http://localhost/BasicPractice/practice.php`.

```text
BasicPractice/
|-- config.php                 Connection and escape_value()
|-- database.sql               Schema reference
|-- skillstestdb.sql           File used by first-run setup
|-- index.php                  Existing Records CRUD
|-- students.php               Existing Students CRUD
|-- about.php                  Existing More Items / Market CRUD
|-- home.php                   Existing dashboard
|-- includes/layout.php        render_layout(): document, Oat assets and navigation
|-- includes/crud.php          Shared validation, forms, search and POST deletion
|-- assets/css/oat.min.css
|-- assets/css/app.css
|-- assets/js/oat.min.js
|-- assets/js/app.js
|-- practice.php               Paste the example below here
`-- readme.md                  This guide
```

The connection is configured in `config.php` through `$DB_CONFIG`. It defaults to host `127.0.0.1`, username `root`, blank password and database `skillstestdb`. Add/change its `host`, `username` and `password` entries when needed. MySQLi supplies the configured port, normally 3306. The connector supplies `$conn`; `includes/layout.php` supplies the Oat document and navigation.

**A renamed folder still uses the same database.** For an independent copy, change `skillstestdb` in `config.php`, `database.sql` and `skillstestdb.sql` before its first visit. To import manually, select/create that database in phpMyAdmin and import `skillstestdb.sql` once. Do not reimport to reset data: sample rows have fixed IDs and may conflict with existing records. Use a new database for a new exercise.

## Match the correct schema

| Option | Include for connection | Table columns |
| --- | --- | --- |
| **43 Basic** | `config.php` | `id`, `name`, `email`, `phone`, `address` |
| **44 Complete** | `database.php` | `id`, `name`, `email`, `phone`, `status`, `notes`, timestamps |

The Basic tables `records`, `students` and `more_items` each use the first schema. The example below works on **records**. It does not add `status` or `notes`; do not paste option 44 SQL into this database. Name is a database column; `for="name"` and `id="name"` connect the visible label to its input, while `name="name"` sends `$_POST['name']` to PHP.

## Ready-to-copy connected example: save as `practice.php`

I-copy ang entire block into a new file. Keep your original files. This page includes an add form, retained entries on validation failure, success/error alerts, prepared SQL search, table, existing Edit links and Oat delete modals. It uses actual records; saving and confirming deletion change the database. PHP must run through Apache, not by opening a file directly.

```php
<?php
session_start();
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
if (empty($_SESSION['practice_token'])) $_SESSION['practice_token'] = bin2hex(random_bytes(32));
$values = ['name' => '', 'email' => '', 'phone' => '', 'address' => ''];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_string($_POST['csrf_token'] ?? null) || !hash_equals($_SESSION['practice_token'], $_POST['csrf_token'])) {
        http_response_code(403);
        exit('Form expired. Reload practice.php and try again.');
    }
    try {
        if (isset($_POST['delete_id'])) {
            $id = filter_var($_POST['delete_id'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
            if (!$id) {
                http_response_code(400);
                $error = 'Choose a valid record ID.';
            } else {
                $statement = mysqli_prepare($conn, 'DELETE FROM records WHERE id = ?');
                mysqli_stmt_bind_param($statement, 'i', $id);
                mysqli_stmt_execute($statement);
                $_SESSION['practice_message'] = mysqli_stmt_affected_rows($statement) ? 'Record deleted.' : 'The record was already removed.';
            }
        } else {
            foreach ($values as $field => $unused) $values[$field] = is_string($_POST[$field] ?? null) ? trim($_POST[$field]) : '';
            if (!preg_match('/^.{1,100}$/us', $values['name']) || strlen($values['email']) > 100 || !filter_var($values['email'], FILTER_VALIDATE_EMAIL) || !preg_match('/^[0-9+() .-]{1,20}$/', $values['phone']) || !preg_match('/^.{1,500}$/us', $values['address'])) {
                http_response_code(422);
                $error = 'Enter a name (up to 100 characters), valid email (up to 100), phone (up to 20 digits/spaces/+/-/parentheses/dots), and address (up to 500).';
            } else {
                $statement = mysqli_prepare($conn, 'INSERT INTO records (name, email, phone, address) VALUES (?, ?, ?, ?)');
                mysqli_stmt_bind_param($statement, 'ssss', $values['name'], $values['email'], $values['phone'], $values['address']);
                mysqli_stmt_execute($statement);
                $_SESSION['practice_message'] = 'Record added.';
            }
        }
        if (!$error) { header('Location: practice.php'); exit; }
    } catch (mysqli_sql_exception $exception) {
        error_log($exception->getMessage());
        http_response_code(503);
        $error = 'The change could not be saved. Your entries are kept below. Check MySQL and try again.';
    }
}

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$like = '%' . $search . '%';
$statement = mysqli_prepare($conn, 'SELECT * FROM records WHERE name LIKE ? OR email LIKE ? OR phone LIKE ? OR address LIKE ? ORDER BY id DESC');
mysqli_stmt_bind_param($statement, 'ssss', $like, $like, $like, $like);
mysqli_stmt_execute($statement);
// shortcut: this practice list is unpaginated; paginate for larger collections.
$records = mysqli_fetch_all(mysqli_stmt_get_result($statement), MYSQLI_ASSOC);
ob_start();
?>
<?php if (!empty($_SESSION['practice_message'])): ?><div class="notice notice-success" role="status"><?= escape_value($_SESSION['practice_message']) ?></div><?php unset($_SESSION['practice_message']); endif; ?>
<?php if ($error): ?><div class="notice notice-danger" role="alert"><?= escape_value($error) ?></div><?php endif; ?>

<section class="card-surface">
    <h2>Add a record</h2>
    <form method="post" action="practice.php" class="entry-form">
        <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['practice_token']) ?>">
        <div class="field-grid">
            <div><label for="name">Name</label><input id="name" name="name" maxlength="100" value="<?= escape_value($values['name']) ?>" autocomplete="name" required></div>
            <div><label for="email">Email</label><input id="email" name="email" type="email" maxlength="100" value="<?= escape_value($values['email']) ?>" autocomplete="email" required></div>
            <div><label for="phone">Phone</label><input id="phone" name="phone" type="tel" maxlength="20" value="<?= escape_value($values['phone']) ?>" autocomplete="tel" required></div>
            <div><label for="address">Address</label><textarea id="address" name="address" maxlength="500" rows="3" autocomplete="street-address" required><?= escape_value($values['address']) ?></textarea></div>
        </div>
        <div class="form-actions"><button type="submit">Save record</button><a class="button outline" href="practice.php">Clear form</a><a class="button outline" href="index.php">Original Records page</a></div>
    </form>
</section>

<h2>Saved records</h2>
<form method="get" action="practice.php" class="filter-form filter-panel">
    <label for="search">Search records</label><input id="search" name="search" type="search" value="<?= escape_value($search) ?>">
    <button type="submit">Search</button><a class="button outline" href="practice.php">Clear search</a>
</form>
<div class="table-responsive" role="region" aria-label="Saved records" tabindex="0">
    <table>
        <caption>Records with address details</caption>
        <thead><tr><th scope="col">Name</th><th scope="col">Email</th><th scope="col">Address</th><th scope="col">Actions</th></tr></thead>
        <tbody>
        <?php foreach ($records as $record): ?>
            <tr><th scope="row"><?= escape_value($record['name']) ?></th><td><?= escape_value($record['email']) ?></td><td><?= escape_value($record['address']) ?></td><td class="actions-cell">
                <a class="button small outline" href="index.php?action=edit&amp;id=<?= (int)$record['id'] ?>" aria-label="Edit <?= escape_value($record['name']) ?>">Edit</a>
                <button type="button" class="small danger-action" commandfor="remove-<?= (int)$record['id'] ?>" command="show-modal" aria-label="Delete <?= escape_value($record['name']) ?>">Delete</button>
            </td></tr>
        <?php endforeach; ?>
        <?php if (!$records): ?><tr><td colspan="4" class="empty-state">No matching records. Clear the search or add one above.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php foreach ($records as $record): ?>
<dialog id="remove-<?= (int)$record['id'] ?>" aria-labelledby="remove-title-<?= (int)$record['id'] ?>">
    <form method="post" action="practice.php">
        <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['practice_token']) ?>">
        <input type="hidden" name="delete_id" value="<?= (int)$record['id'] ?>">
        <header><h2 id="remove-title-<?= (int)$record['id'] ?>">Delete record?</h2></header>
        <div><p><?= escape_value($record['name']) ?></p><p>This permanently removes this record.</p></div>
        <footer><button type="button" class="outline" commandfor="remove-<?= (int)$record['id'] ?>" command="close" autofocus>Keep record</button><button type="submit" class="danger-action">Yes, delete</button></footer>
    </form>
</dialog>
<?php endforeach; ?>
<?php
$content = ob_get_clean();
render_layout('Oat CRUD practice', 'Oat CRUD practice', $content, 'records');
```

## How this example connects

```text
GET practice.php
  -> config.php connects MySQL and supplies $conn
  -> SELECT reads records
  -> ob_start() captures the form/table/modal markup
  -> render_layout() adds the complete local Oat page

Save form [POST practice.php]
  -> verify session CSRF token
  -> validate name/email/phone/address
  -> prepare + bind + execute INSERT
  -> set success message and redirect to practice.php

Delete button -> opens matching <dialog>
  -> Keep record / Escape closes it without changing data
  -> Yes, delete [POST practice.php with delete_id and token]
  -> prepared DELETE -> redirect to list

Edit link -> existing index.php?action=edit&id=...
  -> existing Basic edit form -> update -> original list
```

All POST handling happens before `ob_start()` and `render_layout()`, so redirects can send HTTP headers. The example's create/delete actions have their own token checks. The built-in Records, Students and Market pages also validate fields, retain invalid submissions, show inline errors, and require a session token for writes through includes/crud.php. Their Delete links open a confirmation page; only its POST form removes the entry. Old ?delete=ID bookmarks also open confirmation and never delete on GET. Oat's `commandfor` targets a unique dialog ID; the local `oat.min.js` supports the button commands. The browser handles dialog focus and Escape. Modal action forms use `method="post"`, not `method="dialog"`.

## Copy the look into another Basic page

1. Keep `require config.php` and `require includes/layout.php` before the content.
2. Put form/card/table/modal markup between `ob_start()` and `$content = ob_get_clean()`.
3. Finish with `render_layout($title, $heading, $content, 'records')`.
4. Keep the four local Oat/app asset files; the shared layout loads them for you.
5. Use `.card-surface`, `.entry-form`, `.field-grid`, `.form-actions`, `.button`, `.button.outline`, `.danger-action` and `.table-responsive` as shown. Change colours in the local `assets/css/app.css`.

The [Complete CRUD cookbook](../CompleteCrudSystem/readme.md#4-reuse-the-complete-oat-design) also has a complete designed gallery, add modal, badges, alerts and a small CSS block. Static components can be reused here; data forms must keep this Basic schema and connector. For fully connected option 44 examples, deploy 44 first.

## Check and troubleshoot

- Add a record, search its name, and refresh after saving; it should not create a duplicate.
- Submit an invalid email or an overlong field; the server should show feedback and keep your entries.
- Open Delete, then Keep record; the record should remain. Confirm only on a sample record.
- Check the narrow layout and keyboard focus. Oat's dialog opens with its command button; CSS/scripts must all load locally.
- If you see a headers/session warning, save UTF-8 without BOM and put no spaces before `<?php`.
- If a table/column is missing, confirm you used the Basic schema, not the Complete schema.

This is a local practice project without authentication. The example does not add login, uploads or pagination. Records, Students and Market share the same validation and safe delete flow in includes/crud.php. Option 44 adds record detail pages, status filters and summary cards.
