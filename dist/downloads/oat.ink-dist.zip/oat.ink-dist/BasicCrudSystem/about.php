<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';

// ====== CHANGE THESE TEXTS ======
// Reference examples:
// $pageTitle            = 'More Items';
// $pageHeading          = 'Item List';
// $pageNote             = 'Manage additional items here. Use search to filter results.';
// $searchPlaceholder    = 'Search Items';
// $addButtonText        = 'Add Item';
// $addPageTitle         = 'Add Item';
// $editPageTitle        = 'Edit Item';
// $deleteConfirmMessage = 'Are you sure you want to delete this item?';

$tableName            = 'more_items';
$pageTitle            = 'Market';
$pageHeading          = 'Market List';
$pageNote             = 'Manage market entries here. Use search to filter results.';
$searchPlaceholder    = 'Search Market';
$addButtonText        = 'Add Market';
$addPageTitle         = 'Add Market';
$editPageTitle        = 'Edit Market';
$deleteConfirmMessage = 'Are you sure you want to delete this market entry?';
// ================================

$fieldLabels = ['name' => 'Market Name', 'email' => 'Contact Email', 'phone' => 'Contact Phone', 'address' => 'Market Address'];
$activePage = 'about';
require __DIR__ . '/includes/crud.php';
