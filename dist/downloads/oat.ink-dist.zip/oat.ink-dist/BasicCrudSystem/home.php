<?php
include 'config.php';
include 'includes/layout.php';

$pageTitle = $DB_CONFIG['home_title'];
$pageHeading = $DB_CONFIG['home_heading'];
$pageDescription = $DB_CONFIG['home_description'];

$content = '<p>' . escape_value($pageDescription) . '</p><ul class="simple-menu"><li><a href="index.php">Records</a></li><li><a href="students.php">Students</a></li><li><a href="about.php">More Items</a></li></ul>';

render_layout($pageTitle, $pageHeading, $content, 'home');
