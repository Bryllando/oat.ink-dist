-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Database: `skillstestdb`
--

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `skillstestdb`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE `skillstestdb`;

CREATE TABLE IF NOT EXISTS `records` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `address` TEXT NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `records` (`id`, `name`, `email`, `phone`, `address`) VALUES
(1, 'John Cedrick Pogi', 'Amaycedrick68@gmail.com', '09560757817', 'Tisa, Cebu'),
(2, 'Justine T. Dupa', 'Justinedupa@gmail.com', '09238140248', 'Emall street, Cebu City');

CREATE TABLE IF NOT EXISTS `students` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `address` TEXT NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `students` (`id`, `name`, `email`, `phone`, `address`) VALUES
(1, 'Maria Lopez', 'maria.lopez@example.com', '09181234567', 'Ayala, Cebu'),
(2, 'Carlos Santos', 'carlos.santos@example.com', '09281234567', 'Mandaue City');

CREATE TABLE IF NOT EXISTS `more_items` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `address` TEXT NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data for the Market page (about.php)
INSERT INTO `more_items` (`id`, `name`, `email`, `phone`, `address`) VALUES
(1, 'Carbon Market', 'carbon@example.com', '09381234567', 'Carbon Market, Cebu City'),
(2, 'Mango Avenue Market', 'mango@example.com', '09481234567', 'Mango Avenue, Cebu City');

COMMIT;
