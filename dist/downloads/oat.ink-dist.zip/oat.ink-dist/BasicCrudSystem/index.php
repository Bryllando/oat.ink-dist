<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';

// ====== CHANGE THESE TEXTS ======
$tableName = 'records';
$pageTitle = 'Records';
$pageHeading = 'Record List';
$pageNote = 'Manage all records here. Use search to filter results.';
$searchPlaceholder = 'Search Records';
$addButtonText = 'Add Record';
$addPageTitle = 'Add Record';
$editPageTitle = 'Edit Record';
$deleteConfirmMessage = 'Are you sure you want to delete this record?';
// ================================

$activePage = 'records';
require __DIR__ . '/includes/crud.php';
