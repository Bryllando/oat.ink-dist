<?php

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

$DB_CONFIG = [
    'app_title' => 'Generic Management System',
    'database' => 'skillstestdb',
    'table' => 'records',
    'entity_label' => 'Record',
    'entity_label_plural' => 'Records',
    'home_title' => 'Home',
    'home_heading' => 'Dashboard',
    'home_description' => 'Select a module.',
// These are now handled in the individual files:
    // (index.php, students.php, about.php, add.php, edit.php)
    'menu_items' => [
        ['name' => 'Home', 'url' => 'home.php', 'key' => 'home'],
        ['name' => 'Records', 'url' => 'index.php', 'key' => 'records'],
        ['name' => 'Students', 'url' => 'students.php', 'key' => 'students'],
        ['name' => 'More Items', 'url' => 'about.php', 'key' => 'about'],
    ],
];

$dbHost = $DB_CONFIG['host'] ?? '127.0.0.1';
$dbUser = $DB_CONFIG['username'] ?? 'root';
$dbPass = $DB_CONFIG['password'] ?? '';
$dbName = $DB_CONFIG['database'];

$conn = @mysqli_connect($dbHost, $dbUser, $dbPass);
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}

mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS `{$dbName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci") or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));
mysqli_select_db($conn, $dbName) or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));
mysqli_set_charset($conn, 'utf8mb4') or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));

$tables = $conn->query("SHOW TABLES LIKE 'records'");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($conn->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/skillstestdb.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $conn->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($conn->error));
    do {
        if ($result = $conn->store_result()) $result->free();
    } while ($conn->more_results() && $conn->next_result());
    if ($conn->errno) die('Database setup failed: ' . htmlspecialchars($conn->error));
}

function escape_value($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
