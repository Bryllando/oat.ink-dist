<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
    $rental = $conn->query("SELECT vehicleID FROM rentals WHERE rentalID = $id")->fetch_assoc();
    if ($rental && $conn->query("DELETE FROM rentals WHERE rentalID = $id")) {
        $vehicle = (int)$rental['vehicleID'];
        $conn->query("UPDATE vehicles SET status='Available' WHERE vehicleID=$vehicle AND NOT EXISTS (SELECT 1 FROM rentals WHERE vehicleID=$vehicle)");
    }
}
header("Location: index.php");
exit;
