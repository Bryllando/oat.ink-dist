<?php
require_once '../database.php';

$query = "SELECT r.*, v.plateNumber, v.brandModel, v.dailyRate, c.custFName, c.custLName 
          FROM rentals r
          JOIN vehicles v ON r.vehicleID = v.vehicleID
          JOIN customers c ON r.customerID = c.customerID
          ORDER BY r.rentalID DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Rental Transactions</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Rental Transactions</h1>
                <a href="add.php" class="button">New Rental Booking</a>
            </div>
            <div class="card card-surface p-0">
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>Rental #</th>
                            <th>Vehicle</th>
                            <th>Customer</th>
                            <th>Rental Period</th>
                            <th>Days</th>
                            <th>Total Fee</th>
                            <th>Mode</th>
                            <th class="align-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $row['rentalID']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['brandModel']); ?></strong>
                                <small class="text-light block"><?php echo htmlspecialchars($row['plateNumber']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><?php echo $row['rentalDate']; ?> to <?php echo $row['returnDate']; ?></td>
                            <td><?php echo $row['totalDays']; ?> days</td>
                            <td><strong>₱<?php echo number_format($row['totalFee'], 2); ?></strong></td>
                            <td><span class="badge surface-muted text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                            <td class="align-right">
                                <a href="delete.php?id=<?php echo $row['rentalID']; ?>" class="button small danger-action" onclick="return confirm('Cancel/Delete this rental record?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="align-center py-4 text-light">No rental bookings yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>