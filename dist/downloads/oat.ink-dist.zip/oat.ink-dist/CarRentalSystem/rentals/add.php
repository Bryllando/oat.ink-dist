<?php
require_once '../database.php';
$msg = '';

$vehicles = $conn->query("SELECT * FROM vehicles ORDER BY brandModel ASC");
$customers = $conn->query("SELECT * FROM customers ORDER BY custLName ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vehID = intval($_POST['vehicleID']);
    $custID = intval($_POST['customerID']);
    $rDate = trim($_POST['rentalDate']);
    $retDate = trim($_POST['returnDate']);
    $mode = trim($_POST['paymentMode']);

    $d1 = DateTimeImmutable::createFromFormat('!Y-m-d', $rDate);
    $d2 = DateTimeImmutable::createFromFormat('!Y-m-d', $retDate);
    $validDates = $d1 && $d2 && $d1->format('Y-m-d') === $rDate && $d2->format('Y-m-d') === $retDate && $d2 >= $d1;
    $days = $validDates ? max(1, $d1->diff($d2)->days) : 0;

    // Fetch vehicle daily rate
    $vRow = $conn->query("SELECT dailyRate FROM vehicles WHERE vehicleID = $vehID")->fetch_assoc();
    $rate = $vRow ? floatval($vRow['dailyRate']) : 0;
    $totalFee = $days * $rate;

    if (!$validDates) {
        $msg = "<div role='alert' class='notice notice-danger'>Return date must be on or after the rental date.</div>";
    } elseif ($vehID && $custID && $vRow) {
        $stmt = $conn->prepare("INSERT INTO rentals (vehicleID, customerID, rentalDate, returnDate, totalDays, totalFee, paymentMode) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iissids", $vehID, $custID, $rDate, $retDate, $days, $totalFee, $mode);
        if ($stmt->execute()) {
            // Update vehicle status
            $conn->query("UPDATE vehicles SET status = 'Rented' WHERE vehicleID = $vehID");
            header("Location: index.php?msg=booked");
            exit;
        } else {
            $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>New Rental</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 650px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Book Vehicle Rental</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="mb-3">
                        <label for="input-vehicleID">Select Vehicle</label>
                        <select name="vehicleID" required id="input-vehicleID">
                            <option value="">-- Choose Vehicle --</option>
                        <?php while($v = $vehicles->fetch_assoc()): ?>
                            <option value="<?php echo $v['vehicleID']; ?>">
                            <?php echo htmlspecialchars($v['brandModel'] . ' (' . $v['plateNumber'] . ') - ₱' . number_format($v['dailyRate'], 2) . '/day'); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="input-customerID">Select Customer</label>
                        <select name="customerID" required id="input-customerID">
                            <option value="">-- Choose Customer --</option>
                        <?php while($c = $customers->fetch_assoc()): ?>
                            <option value="<?php echo $c['customerID']; ?>">
                            <?php echo htmlspecialchars($c['custLName'] . ', ' . $c['custFName'] . ' (' . $c['licenseNumber'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="input-rentalDate">Rental Date</label>
                            <input type="date" name="rentalDate" required value="<?php echo date('Y-m-d'); ?>" id="input-rentalDate">
                        </div>
                        <div class="col-6">
                            <label for="input-returnDate">Return Date</label>
                            <input type="date" name="returnDate" required value="<?php echo date('Y-m-d', strtotime('+2 days')); ?>" id="input-returnDate">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="input-paymentMode">Payment Mode</label>
                        <select name="paymentMode" id="input-paymentMode">
                            <option value="Cash">Cash</option>
                            <option value="GCash">GCash</option>
                            <option value="Credit Card">Credit Card</option>
                        </select>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button w-100">Confirm Rental Booking</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to Rentals</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>
