<?php
require_once '../database.php';

// Fetch distinct vehicle types for dropdown filter
$typeResult = $conn->query("SELECT DISTINCT vehicleType FROM vehicles ORDER BY vehicleType ASC");

$filterType = trim($_GET['vehicleType'] ?? '');

// Filtered query
if ($filterType !== '') {
    $stmt = $conn->prepare("SELECT r.*, v.plateNumber, v.brandModel, v.vehicleType, v.dailyRate, c.custFName, c.custLName 
                            FROM rentals r
                            JOIN vehicles v ON r.vehicleID = v.vehicleID
                            JOIN customers c ON r.customerID = c.customerID
                            WHERE v.vehicleType = ?
                            ORDER BY r.rentalID DESC");
    $stmt->bind_param("s", $filterType);
    $stmt->execute();
    $records = $stmt->get_result();

    // Aggregates for filter
    $aggStmt = $conn->prepare("SELECT COUNT(*) AS total_rentals, IFNULL(SUM(r.totalFee), 0) AS total_revenue, IFNULL(AVG(r.totalDays), 0) AS avg_days
                               FROM rentals r
                               JOIN vehicles v ON r.vehicleID = v.vehicleID
                               WHERE v.vehicleType = ?");
    $aggStmt->bind_param("s", $filterType);
    $aggStmt->execute();
    $agg = $aggStmt->get_result()->fetch_assoc();
} else {
    $records = $conn->query("SELECT r.*, v.plateNumber, v.brandModel, v.vehicleType, v.dailyRate, c.custFName, c.custLName 
                             FROM rentals r
                             JOIN vehicles v ON r.vehicleID = v.vehicleID
                             JOIN customers c ON r.customerID = c.customerID
                             ORDER BY r.rentalID DESC");
    $agg = $conn->query("SELECT COUNT(*) AS total_rentals, IFNULL(SUM(totalFee), 0) AS total_revenue, IFNULL(AVG(totalDays), 0) AS avg_days FROM rentals")->fetch_assoc();
}

$count = $agg['total_rentals'] ?? 0;
$sumRevenue = $agg['total_revenue'] ?? 0.00;
$avgDays = round($agg['avg_days'] ?? 0, 1);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Car Rental Monitoring Report</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <div>
                    <h1 class="mb-0 page-title">Rental Monitoring Report</h1>
                </div>
                <a href="index.php" class="button outline small">Reset Filter</a>
            </div>

        <!-- Filter Card -->
            <div class="card p-3 card-surface mb-4">
                <form method="GET" class="row g-2 items-center filter-form">
                    <div class="auto-col">
                        <label class="mb-0 weight-semibold">Filter by Vehicle Type:</label>
                    </div>
                    <div class="col-4">
                        <select name="vehicleType" onchange="this.form.submit()">
                            <option value="">-- All Vehicle Types --</option>
                        <?php while($t = $typeResult->fetch_assoc()): ?>
                            <option value="<?php echo htmlspecialchars($t['vehicleType']); ?>" <?php echo $filterType === $t['vehicleType'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($t['vehicleType']); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="auto-col filter-actions">
                        <button type="submit" class="button">Filter Records</button>
                        <a class="button outline" href="index.php">Clear</a></div>
            
                </form>
            </div>

        <!-- The 3 Required Aggregate KPI Cards -->
            <div class="row g-3 mb-4">
                <div class="col-4">
                    <div class="card p-3 card-surface stat-card">
                        <span class="text-light small weight-semibold">a. Total Number of Records (count)</span>
                        <h2 class="text-primary mb-0"><?php echo $count; ?> <small class="text-light fs-6">Rentals</small></h2>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card p-3 card-surface stat-card success">
                        <span class="text-light small weight-semibold">b. Total Fees Collected (sum)</span>
                        <h2 class="text-success mb-0">₱<?php echo number_format($sumRevenue, 2); ?></h2>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card p-3 card-surface stat-card warning">
                        <span class="text-light small weight-semibold">c. Average Rental Duration (formula)</span>
                        <h2 class="text-warning mb-0"><?php echo $avgDays; ?> <small class="text-light fs-6">Days / Trip</small></h2>
                    </div>
                </div>
            </div>

        <!-- Table displaying filtered records -->
            <div class="card card-surface p-0">
                <div class="card-header py-3">
                    <h5 class="mb-0">
                    Results for: <span class="badge surface-muted"><?php echo $filterType !== '' ? htmlspecialchars($filterType) : 'All Vehicles'; ?></span>
                    </h5>
                </div>
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>Vehicle Details</th>
                            <th>Type</th>
                            <th>Customer Full Name</th>
                            <th>Rental Period</th>
                            <th>Duration</th>
                            <th>Fee Paid</th>
                            <th>Payment Mode</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($records && $records->num_rows > 0): ?>
                        <?php while($row = $records->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($row['brandModel']); ?></strong>
                                <small class="text-light block"><?php echo htmlspecialchars($row['plateNumber']); ?></small>
                            </td>
                            <td><span class="badge surface-muted"><?php echo htmlspecialchars($row['vehicleType']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><?php echo $row['rentalDate']; ?> to <?php echo $row['returnDate']; ?></td>
                            <td><?php echo $row['totalDays']; ?> days</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalFee'], 2); ?></strong></td>
                            <td><span class="badge surface-muted text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="align-center py-4 text-light">No rental records found matching this filter.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>