<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
    $conn->query("DELETE FROM customers WHERE customerID = $id");
}
header("Location: index.php");
exit;