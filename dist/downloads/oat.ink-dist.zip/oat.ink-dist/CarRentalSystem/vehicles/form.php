<?php
$editing = $editing ?? false;
require __DIR__ . '/../database.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$title = $editing ? 'Edit Vehicle' : 'Add Vehicle';
$values = ['plateNumber' => '', 'brandModel' => '', 'vehicleType' => 'Sedan', 'dailyRate' => '', 'status' => 'Available'];
$errors = [];
$missing = false;
if ($editing) {
    $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2147483647]]);
    $vehicle = null;
    if ($id) {
        $statement = mysqli_prepare($conn, 'SELECT * FROM vehicles WHERE vehicleID = ?');
        mysqli_stmt_bind_param($statement, 'i', $id);
        mysqli_stmt_execute($statement);
        $vehicle = mysqli_fetch_assoc(mysqli_stmt_get_result($statement));
    }
    if ($vehicle) $values = $vehicle;
    else { $missing = true; http_response_code(404); }
}
if (!$missing && $_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (['plateNumber', 'brandModel', 'vehicleType', 'dailyRate', 'status'] as $field) $values[$field] = is_string($_POST[$field] ?? null) ? trim($_POST[$field]) : '';
    if (!is_string($_POST['csrf_token'] ?? null) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $errors['_form'] = 'Your form expired. Reload this page and try again.';
        http_response_code(403);
    } else {
        if (!preg_match('/^.{1,50}$/us', $values['plateNumber'])) $errors['plateNumber'] = 'Enter a plate number of 1 to 50 characters.';
        if (!preg_match('/^.{1,100}$/us', $values['brandModel'])) $errors['brandModel'] = 'Enter a brand and model of 1 to 100 characters.';
        if (!in_array($values['vehicleType'], ['Sedan', 'SUV', 'Van', 'Pickup'], true)) $errors['vehicleType'] = 'Choose Sedan, SUV, Van or Pickup.';
        if (!preg_match('/^\d+(?:\.\d{1,2})?$/D', $values['dailyRate']) || !is_finite((float)$values['dailyRate']) || (float)$values['dailyRate'] <= 0 || (float)$values['dailyRate'] > 99999999.99) $errors['dailyRate'] = 'Enter a daily rate from 0.01 to 99,999,999.99, with up to two decimal places.';
        if (!in_array($values['status'], ['Available', 'Rented', 'Maintenance'], true)) $errors['status'] = 'Choose Available, Rented or Maintenance.';
        if ($errors) http_response_code(422);
        else {
            try {
                $sql = $editing ? 'UPDATE vehicles SET plateNumber = ?, brandModel = ?, vehicleType = ?, dailyRate = ?, status = ? WHERE vehicleID = ?' : 'INSERT INTO vehicles (plateNumber, brandModel, vehicleType, dailyRate, status) VALUES (?, ?, ?, ?, ?)';
                $statement = mysqli_prepare($conn, $sql);
                if ($editing) mysqli_stmt_bind_param($statement, 'sssssi', $values['plateNumber'], $values['brandModel'], $values['vehicleType'], $values['dailyRate'], $values['status'], $id);
                else mysqli_stmt_bind_param($statement, 'sssss', $values['plateNumber'], $values['brandModel'], $values['vehicleType'], $values['dailyRate'], $values['status']);
                mysqli_stmt_execute($statement);
                header('Location: index.php?msg=' . ($editing ? 'updated' : 'added'));
                exit;
            } catch (mysqli_sql_exception $error) {
                if ($error->getCode() === 1062) {
                    http_response_code(422);
                    $errors['plateNumber'] = 'That plate number already exists. Enter a different plate number.';
                } else {
                    error_log($error->getMessage());
                    http_response_code(503);
                    $errors['_form'] = 'The vehicle could not be saved. Your entries are kept below. Check the database and try again.';
                }
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="../assets/css/oat.min.css">
    <link rel="stylesheet" href="../assets/css/app.css">
    <script src="../assets/js/oat.min.js" defer></script>
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<main class="container form-page" style="max-width: 600px;">
    <h1 class="page-title"><?= $title ?></h1>
    <?php if ($missing): ?><div class="notice notice-warning" role="alert">This vehicle does not exist or has been deleted.</div><a class="button outline" href="index.php">Back to vehicles</a>
    <?php else: ?>
    <?php if ($errors): ?><div class="notice notice-danger" role="alert"><strong>Review the form before saving.</strong><ul><?php foreach ($errors as $field => $message): ?><li><?php if ($field !== '_form'): ?><a href="#input-<?= $field ?>"><?= htmlspecialchars($message) ?></a><?php else: ?><?= htmlspecialchars($message) ?><?php endif; ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <form method="post" class="entry-form form-panel">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
        <p class="page-note">All fields are required. Plate numbers must be unique.</p>
        <div class="field-grid">
            <?php foreach (['plateNumber' => 'Plate Number', 'brandModel' => 'Brand & Model', 'dailyRate' => 'Daily Rental Rate (PHP)'] as $field => $label): ?>
            <div>
                <label for="input-<?= $field ?>"><?= $label ?></label>
                <input id="input-<?= $field ?>" name="<?= $field ?>" <?= $field === 'dailyRate' ? 'type="number" min="0.01" max="99999999.99" step="0.01"' : 'type="text" maxlength="'.($field === 'plateNumber' ? 50 : 100).'"' ?> required value="<?= htmlspecialchars($values[$field], ENT_QUOTES, 'UTF-8') ?>" <?= isset($errors[$field]) ? 'aria-invalid="true" aria-describedby="error-'.$field.'"' : '' ?>>
                <?php if (isset($errors[$field])): ?><p id="error-<?= $field ?>" class="text-danger small"><?= htmlspecialchars($errors[$field]) ?></p><?php endif; ?>
            </div>
            <?php endforeach; ?>
            <?php foreach (['vehicleType' => ['Vehicle Type', ['Sedan', 'SUV', 'Van', 'Pickup']], 'status' => ['Status', ['Available', 'Rented', 'Maintenance']]] as $field => [$label, $options]): ?>
            <div>
                <label for="input-<?= $field ?>"><?= $label ?></label>
                <select id="input-<?= $field ?>" name="<?= $field ?>" required <?= isset($errors[$field]) ? 'aria-invalid="true" aria-describedby="error-'.$field.'"' : '' ?>><option value="">Choose <?= $label ?></option><?php foreach ($options as $option): ?><option <?= $values[$field] === $option ? 'selected' : '' ?>><?= $option ?></option><?php endforeach; ?></select>
                <?php if (isset($errors[$field])): ?><p id="error-<?= $field ?>" class="text-danger small"><?= htmlspecialchars($errors[$field]) ?></p><?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="form-actions"><button type="submit"><?= $editing ? 'Save Changes' : 'Save Vehicle' ?></button><a class="button outline" href="index.php">Cancel</a></div>
    </form>
    <?php endif; ?>
</main>
</body>
</html>
