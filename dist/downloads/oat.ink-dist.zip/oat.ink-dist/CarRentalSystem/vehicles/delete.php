<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
    $conn->query("DELETE FROM vehicles WHERE vehicleID = $id");
}
header("Location: index.php");
exit;