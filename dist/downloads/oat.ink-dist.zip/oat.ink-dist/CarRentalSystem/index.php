<?php
require_once 'database.php';

$totalVehicles = $conn->query("SELECT COUNT(*) FROM vehicles")->fetch_row()[0];
$totalCustomers = $conn->query("SELECT COUNT(*) FROM customers")->fetch_row()[0];
$totalRentals = $conn->query("SELECT COUNT(*) FROM rentals")->fetch_row()[0];
$totalRevenue = $conn->query("SELECT IFNULL(SUM(totalFee), 0) FROM rentals")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Car Rental System - Dashboard</title>
    
    
    </head>
    <body>
    <?php include 'navbar.php'; ?>
        <main class="container">
            <h1 class="page-title">Car Rental System</h1>
            <h2>Summary</h2>
            <div class="stats-grid">
                <div class="stat-card"><span class="stat-label">Vehicles</span><strong class="stat-value"><?= $totalVehicles ?></strong></div>
                <div class="stat-card"><span class="stat-label">Customers</span><strong class="stat-value"><?= $totalCustomers ?></strong></div>
                <div class="stat-card"><span class="stat-label">Rentals</span><strong class="stat-value"><?= $totalRentals ?></strong></div>
                <div class="stat-card"><span class="stat-label">Revenue</span><strong class="stat-value"><?= 'PHP ' . number_format($totalRevenue, 2) ?></strong></div>
            </div>
            <h2 class="mt-3">Menu</h2>
            <ul class="simple-menu">
                <li><a href="vehicles/index.php">Vehicles</a></li>
                <li><a href="customers/index.php">Customers</a></li>
                <li><a href="rentals/index.php">Rentals</a></li>
                <li><a href="monitoring/index.php">Reports</a></li>
            </ul>
        </main>
    </body>
</html>
