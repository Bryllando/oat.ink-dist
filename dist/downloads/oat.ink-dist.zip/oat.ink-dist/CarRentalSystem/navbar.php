<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav mb-4">
    <div class="container">
        <a class="app-brand" href="<?php echo $baseUrl; ?>index.php">Car Rental System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'vehicles') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>vehicles/index.php">Vehicles</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'customers') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>customers/index.php">Customers</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'rentals') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>rentals/index.php">Rentals</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>