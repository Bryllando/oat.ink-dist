<?php include 'database.php'; ?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Hotel Reservation System</title>
    </head>
    <body>
    <?php include 'navbar.php'; ?>
        <div class="container">
            <div class="page-heading">
                <h1 class="page-title">Hotel Reservation System</h1>
            </div>

            <div class="simple-panel mb-4">
                <ul class="simple-menu">
                    <li><a href="guests/index.php"><span>Guests</span> </a></li>
                    <li><a href="rooms/index.php"><span>Rooms</span> </a></li>
                    <li><a href="reservations/index.php"><span>Reservations</span> </a></li>
                    <li><a href="monitoring/index.php"><span>Reports</span></a></li>
                </ul>
            </div>
        </div>

    
    </body>
</html>
