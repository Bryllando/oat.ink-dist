<?php
require_once __DIR__ . '/../database.php';

$filter = isset($_GET['roomType']) ? db_escape($_GET['roomType']) : '';
$where = '';
if ($filter !== '') {
    $where = "WHERE rm.roomType = '{$filter}'";
}

$query = "SELECT r.*, g.fName, g.lName, rm.roomNo, rm.roomType, rm.price 
          FROM reservations r
          JOIN guests g ON r.guestID = g.guestID
          JOIN rooms rm ON r.roomID = rm.roomID
          {$where}
          ORDER BY r.reserveID DESC";
$result = mysqli_query($conn, $query);

// Aggregates
$aggQuery = "SELECT COUNT(*) AS totalRes, SUM(r.totalPaid) AS totalAmount, AVG(r.totalPaid) AS avgAmount
             FROM reservations r
             JOIN rooms rm ON r.roomID = rm.roomID
             {$where}";
$aggRes = mysqli_query($conn, $aggQuery);
$agg = mysqli_fetch_assoc($aggRes);
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Reservation Monitoring</title>
    </head>
    <body>
  <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="site-hero mb-3">
                <h1 class="page-title">Reservation Monitoring & Inquiry</h1>
                <small class="text-light">Filter reservations by room type.</small>
            </div>

            <div class="card-surface p-3 mb-3">
                <form method="get" class="row g-2 items-center filter-form">
                    <div class="auto-col">
                        <label class="weight-bold">Filter by Room Type:</label>
                    </div>
                    <div class="auto-col">
                        <select name="roomType">
                            <option value="">-- All Room Types --</option>
                            <option value="Standard" <?= $filter === 'Standard' ? 'selected' : '' ?>>Standard</option>
                            <option value="Deluxe" <?= $filter === 'Deluxe' ? 'selected' : '' ?>>Deluxe</option>
                            <option value="VIP" <?= $filter === 'VIP' ? 'selected' : '' ?>>VIP</option>
                        </select>
                    </div>
                    <div class="auto-col">
                        <button type="submit" class="button">Filter</button>
                        <a href="index.php" class="button outline">Reset</a>
                    </div>
                </form>
            </div>

            <div class="card-surface mb-4">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Guest Full Name</th>
                            <th>Room No</th>
                            <th>Room Type</th>
                            <th>Check In</th>
                            <th>Check Out</th>
                            <th>Total Paid</th>
                        </tr>
                    </thead>
                    <tbody>
        <?php if ($result && mysqli_num_rows($result) > 0): ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?= $row['reserveID'] ?></td>
                            <td><strong><?= htmlspecialchars($row['fName'] . ' ' . $row['lName']) ?></strong></td>
                            <td><?= htmlspecialchars($row['roomNo']) ?></td>
                            <td><span class="badge surface-muted text-dark"><?= htmlspecialchars($row['roomType']) ?></span></td>
                            <td><?= htmlspecialchars($row['checkIn']) ?></td>
                            <td><?= htmlspecialchars($row['checkOut']) ?></td>
                            <td>₱<?= number_format($row['totalPaid'], 2) ?></td>
                        </tr>
          <?php endwhile; ?>
        <?php else: ?>
                        <tr><td colspan="7" class="align-center text-light py-3">No reservations found.</td></tr>
        <?php endif; ?>
                    </tbody>
                </table>

      <!-- Aggregate Summary Cards -->
                <h3 class="mt-4 mb-3">Summary Metrics</h3>
                <div class="row g-3">
                    <div class="col-4">
                        <div class="stat-card">
                            <div class="stat-val"><?= (int)$agg['totalRes'] ?></div>
                            <div class="stat-label">Total Reservations</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="stat-card">
                            <div class="stat-val text-success">₱<?= number_format($agg['totalAmount'] ?? 0, 2) ?></div>
                            <div class="stat-label">Total Revenue Collected</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="stat-card">
                            <div class="stat-val text-primary">₱<?= number_format($agg['avgAmount'] ?? 0, 2) ?></div>
                            <div class="stat-label">Average Paid per Reservation</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  
    </body>
</html>
