<?php include '../database.php'; include '../helpers.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id){
    mysqli_query($conn, "DELETE FROM guests WHERE guestID={$id}");
    set_flash('Guest deleted.', 'success');
}
header('Location: index.php'); exit;
?>
