<?php include '../database.php'; ?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Guests Management</title>
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="site-hero mb-3">
                <h1 class="page-title">Guests Management</h1>
                <small class="text-light">Register and manage hotel guests</small>
            </div>

            <div class="card-surface mb-4">
                <div class="flex justify-between items-center mb-3">
                    <a class="button" href="add.php">Add New Guest</a>
          <?php
          $search = $_GET['search'] ?? '';
          $query = "SELECT * FROM guests";
          if ($search) {
              $safeSearch = mysqli_real_escape_string($conn, $search);
              $query .= " WHERE fName LIKE '%$safeSearch%' OR lName LIKE '%$safeSearch%' OR address LIKE '%$safeSearch%'";
          }
          $query .= " ORDER BY guestID DESC";
          $res = mysqli_query($conn, $query);
          ?>
                    <form method="get" class="flex gap-2 filter-form" style="max-width: 320px;">
                        <input type="text" name="search" placeholder="Search guests..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="button">Search</button>
            <?php if ($search): ?>
                        <a href="index.php" class="button outline">Clear</a>
            <?php endif; ?>
                    </form>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Full Name</th>
                            <th>Address</th>
                            <th>Contact No</th>
                            <th style="width: 140px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
          <?php if ($res && mysqli_num_rows($res) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($res)): ?>
                        <tr>
                            <td><?= $row['guestID'] ?></td>
                            <td><strong><?= htmlspecialchars($row['fName'].' '.$row['lName']) ?></strong></td>
                            <td><?= htmlspecialchars($row['address']) ?></td>
                            <td><?= htmlspecialchars($row['contactNo']) ?></td>
                            <td>
                                <a class="button small outline" href="edit.php?id=<?= $row['guestID'] ?>">Edit</a>
                                <a class="button small danger-action ms-1" href="delete.php?id=<?= $row['guestID'] ?>" onclick="return confirm('Delete this guest record?')">Delete</a>
                            </td>
                        </tr>
            <?php endwhile; ?>
          <?php else: ?>
                        <tr><td colspan="5" class="align-center text-light py-3">No guests found.</td></tr>
          <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>
