<?php include '../database.php'; include '../helpers.php';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $f = db_escape($_POST['fName']);
  $l = db_escape($_POST['lName']);
  $a = db_escape($_POST['address']);
  $c = db_escape($_POST['contactNo']);
  mysqli_query($conn, "INSERT INTO guests (fName,lName,address,contactNo) VALUES ('{$f}','{$l}','{$a}','{$c}')");
  set_flash('Guest added successfully.', 'success');
  header('Location: index.php'); exit;
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add Guest</title>
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page">
            <h1 class="page-title">Add Guest</h1>
            <form method="post" class="entry-form form-panel">
                <div class="field-grid">
                    <div class="mb-2"><label for="input-fName">First name</label><input required name="fName" id="input-fName"></div>
                    <div class="mb-2"><label for="input-lName">Last name</label><input required name="lName" id="input-lName"></div>
                    <div class="mb-2"><label for="input-address">Address</label><textarea name="address" id="input-address"></textarea></div>
                    <div class="mb-2"><label for="input-contactNo">Contact</label><input name="contactNo" id="input-contactNo"></div>
                </div>
                <div class="form-actions">
                    <button class="button">Save</button>
                    <a class="button outline" href="index.php">Cancel</a>
                </div>
            </form>
        </div>
    </body>
</html>
