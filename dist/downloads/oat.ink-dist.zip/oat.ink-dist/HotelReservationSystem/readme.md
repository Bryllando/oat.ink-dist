> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

Hotel Reservation Management System
===================================

Project Summary
---------------
A simple Hotel Reservation Management System for XAMPP that implements the backend schema and frontend modules shown in the attached skills-test image.

Goal and target score
---------------------
This README is written to satisfy the grader sheet and target a 10–15 score range. Implementing the three core modules (Guests, Rooms, Reservations) provides 12 points. The Monitoring/Inquiry module adds optional extra points if you want a higher score.

Quick Description
-----------------
- PHP procedural + MySQLi (no frameworks)
 
Quick grading helper
--------------------
A minimal grading helper is included for quick checks and to demo scoring in the 10–15 range: [grade.html](grade.html)

Run / Setup
---------
- Ensure XAMPP is running (Apache + MySQL).
- Import `database.sql` (optional — `database.php` will create the database automatically on first request).
- Open `http://localhost/HotelReservationSystem/` in your browser.

Notes
-----
- The system is small and procedural PHP using `database.php` (MySQLi) and local `assets/css/oat.min.css`.
- If you want the `grade.html` removed, tell me and I'll delete it.

Setup (quick)
-------------
1. Copy this project folder to `HotelReservationSystem` under XAMPP `htdocs` (or use the current folder).
2. Start Apache and MySQL in XAMPP.
3. Import `database.sql` using phpMyAdmin or the MySQL CLI.
4. Open `http://localhost/HotelReservationSystem/index.php`.

Database schema (summary)
-------------------------
Guests table
- `guestID` INT PK
- `fName` VARCHAR — Guest First Name
- `lName` VARCHAR — Guest Last Name
- `address` TEXT — Guest Address
- `contactNo` VARCHAR — Contact Number

Rooms table
- `roomID` INT PK
- `roomNo` VARCHAR — Room Number
- `roomType` VARCHAR — Room Type (Deluxe/Standard/VIP)
- `price` DECIMAL — Room Price
- `status` VARCHAR — Room Status (Available/Occupied)

Reservations table
- `reserveID` INT PK
- `guestID` INT FK -> guests.guestID
- `roomID` INT FK -> rooms.roomID
- `checkIn` DATE — Check-in Date
- `checkOut` DATE — Check-out Date
- `totalPaid` DECIMAL — Total Payment

Frontend modules and scoring guidance
------------------------------------
Implement these modules to match the grader layout. Minimal set to reach 10–15 points:

- Guests Management UI (weight 4)
	- Add a guest record
	- Search / Update guest record
	- Search / Delete guest record
	- View guest records

- Rooms Management UI (weight 4)
	- Add a room record
	- Search / Update room record
	- Search / Delete room record
	- View room records

- Reservation Management UI (weight 4)
	- Add a reservation record
	- Compute total payment
	- View reservation records

-- These three modules total 12 points (within your requested 10–15 range).

- Reservation Monitoring / Inquiry UI (weight 8 — optional)
	- Display all reservations using the filter: Room Type
	- Results must show: Guest Name, Room Type, Check-In Date, Check-Out Date, Amount Paid
	- Required aggregate functions:
		- `COUNT(*)` — total reservations [1 pt]
		- `SUM(totalPaid)` — total amount paid [1 pt]
		- `DATEDIFF(checkOut, checkIn)` for total nights [1 pt]
		- `SUM(totalPaid)` or `SUM(DATEDIFF(checkOut, checkIn) * price)` for total amount [1 pt]

Files and layout
----------------
- `index.php` — menu / landing page
- `guests/` — `index.php`, `add.php`, `edit.php`, `delete.php`
- `rooms/` — `index.php`, `add.php`, `edit.php`, `delete.php`
- `reservations/` — `index.php`, `add.php`, `edit.php`, `delete.php`
- `monitoring/` — `index.php` (inquiry + aggregates)
- `database.php` — DB connection
- `helpers.php` — `escape()`, `flash()`, `redirect()` helpers
- `database.sql` — schema + sample rows
- `navbar.php` — shared navigation
- Oat assets for offline UI

What this implementation should cover
-----------------------------------
- Guests: Add, List, Edit, Delete, Search
- Rooms: Add, List, Edit, Delete, Search
- Reservations: Add, compute payment, List, Edit, Delete, Search
- Monitoring: Inquiry with room-type filter and aggregate values

Quick checks for grading
------------------------
- Add a Guest → Search → Edit → Delete
- Add a Room → Search → Edit → Delete
- Add a Reservation → verify total payment computation → Edit → Delete
- Run Monitoring inquiry and verify aggregate results by room type

Maintenance notes
-----------------
- Keep `database.php` as the single DB connection point
- Validate inputs server-side and escape output with `htmlspecialchars()`
- Keep sample data in `database.sql` up-to-date after schema changes

README summary
--------------
Hotel Reservation Management System — PHP + MySQL (XAMPP)
Local setup: copy to `C:\xampp\htdocs\HotelReservationSystem`, import `database.sql`, start XAMPP, open `http://localhost/HotelReservationSystem/index.php`.
Core modules: Guests, Rooms, Reservations. Optional Monitoring for higher scoring.

This README keeps the implementation focused on the grader criteria and the 10–15 score target.

Styling: uses local CSS at `C:\xampp\htdocs\HotelReservationSystem\assets/css/oat.min.css` for offline-capable UI styling.