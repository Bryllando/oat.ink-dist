<?php
$editing = $editing ?? false;
require __DIR__ . '/../database.php';
require __DIR__ . '/../helpers.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
$title = $editing ? 'Edit Room' : 'Add Room';
$values = ['roomNo' => '', 'roomType' => '', 'price' => '', 'status' => 'Available'];
$errors = [];
$missing = false;
if ($editing) {
    $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2147483647]]);
    $room = null;
    if ($id) {
        $statement = mysqli_prepare($conn, 'SELECT * FROM rooms WHERE roomID = ?');
        mysqli_stmt_bind_param($statement, 'i', $id);
        mysqli_stmt_execute($statement);
        $room = mysqli_fetch_assoc(mysqli_stmt_get_result($statement));
    }
    if ($room) $values = $room;
    else { $missing = true; http_response_code(404); }
}
if (!$missing && $_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (['roomNo', 'roomType', 'price', 'status'] as $field) $values[$field] = is_string($_POST[$field] ?? null) ? trim($_POST[$field]) : '';
    if (!is_string($_POST['csrf_token'] ?? null) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $errors['_form'] = 'Your form expired. Reload this page and try again.';
        http_response_code(403);
    } else {
        if (!preg_match('/^.{1,50}$/us', $values['roomNo'])) $errors['roomNo'] = 'Enter a room number of 1 to 50 characters.';
        if (!preg_match('/^.{1,50}$/us', $values['roomType'])) $errors['roomType'] = 'Enter a room type of 1 to 50 characters.';
        if (!preg_match('/^\d+(?:\.\d{1,2})?$/D', $values['price']) || !is_finite((float)$values['price']) || (float)$values['price'] > 99999999.99) $errors['price'] = 'Enter a price from 0 to 99,999,999.99, with up to two decimal places.';
        if (!in_array($values['status'], ['Available', 'Occupied'], true)) $errors['status'] = 'Choose Available or Occupied.';
        if ($errors) http_response_code(422);
        else {
            try {
                $sql = $editing ? 'UPDATE rooms SET roomNo = ?, roomType = ?, price = ?, status = ? WHERE roomID = ?' : 'INSERT INTO rooms (roomNo, roomType, price, status) VALUES (?, ?, ?, ?)';
                $statement = mysqli_prepare($conn, $sql);
                if ($editing) mysqli_stmt_bind_param($statement, 'ssssi', $values['roomNo'], $values['roomType'], $values['price'], $values['status'], $id);
                else mysqli_stmt_bind_param($statement, 'ssss', $values['roomNo'], $values['roomType'], $values['price'], $values['status']);
                mysqli_stmt_execute($statement);
                set_flash($editing ? 'Room updated.' : 'Room added.', 'success');
                header('Location: index.php');
                exit;
            } catch (mysqli_sql_exception $error) {
                error_log($error->getMessage());
                http_response_code(503);
                $errors['_form'] = 'The room could not be saved. Your entries are kept below. Check the database and try again.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="../assets/css/oat.min.css">
    <link rel="stylesheet" href="../assets/css/app.css">
    <script src="../assets/js/oat.min.js" defer></script>
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
<?php include __DIR__ . '/../navbar.php'; ?>
<main class="container form-page">
    <h1 class="page-title"><?= $title ?></h1>
    <?php if ($missing): ?><div class="notice notice-warning" role="alert">This room does not exist or has been deleted.</div><a class="button outline" href="index.php">Back to rooms</a>
    <?php else: ?>
    <?php if ($errors): ?><div class="notice notice-danger" role="alert"><strong>Review the form before saving.</strong><ul><?php foreach ($errors as $field => $message): ?><li><?php if ($field !== '_form'): ?><a href="#input-<?= $field ?>"><?= htmlspecialchars($message) ?></a><?php else: ?><?= htmlspecialchars($message) ?><?php endif; ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <form method="post" class="entry-form form-panel">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
        <p class="page-note">All fields are required. Price is per night and can be zero or more.</p>
        <div class="field-grid">
            <?php foreach (['roomNo' => 'Room No', 'roomType' => 'Room Type', 'price' => 'Price per Night (PHP)'] as $field => $label): ?>
            <div>
                <label for="input-<?= $field ?>"><?= $label ?></label>
                <input id="input-<?= $field ?>" name="<?= $field ?>" <?= $field === 'price' ? 'type="number" min="0" max="99999999.99" step="0.01"' : 'type="text" maxlength="50"' ?> required value="<?= htmlspecialchars($values[$field], ENT_QUOTES, 'UTF-8') ?>" <?= isset($errors[$field]) ? 'aria-invalid="true" aria-describedby="error-'.$field.'"' : '' ?>>
                <?php if (isset($errors[$field])): ?><p id="error-<?= $field ?>" class="text-danger small"><?= htmlspecialchars($errors[$field]) ?></p><?php endif; ?>
            </div>
            <?php endforeach; ?>
            <div>
                <label for="input-status">Status</label>
                <select id="input-status" name="status" required <?= isset($errors['status']) ? 'aria-invalid="true" aria-describedby="error-status"' : '' ?>><option value="">Choose a status</option><?php foreach (['Available', 'Occupied'] as $status): ?><option <?= $values['status'] === $status ? 'selected' : '' ?>><?= $status ?></option><?php endforeach; ?></select>
                <?php if (isset($errors['status'])): ?><p id="error-status" class="text-danger small"><?= htmlspecialchars($errors['status']) ?></p><?php endif; ?>
            </div>
        </div>
        <div class="form-actions"><button type="submit"><?= $editing ? 'Save Changes' : 'Save Room' ?></button><a class="button outline" href="index.php">Cancel</a></div>
    </form>
    <?php endif; ?>
</main>
</body>
</html>
