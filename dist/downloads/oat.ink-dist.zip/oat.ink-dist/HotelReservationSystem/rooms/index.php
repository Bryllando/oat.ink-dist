<?php include '../database.php'; ?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Rooms Management</title>
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="site-hero mb-3">
                <h1 class="page-title">Rooms Inventory</h1>
                <small class="text-light">Manage available rooms, types, and rates</small>
            </div>

            <div class="card-surface mb-4">
                <div class="flex justify-between items-center mb-3">
                    <a class="button" href="add.php">Add New Room</a>
          <?php
          $search = $_GET['search'] ?? '';
          $query = "SELECT * FROM rooms";
          if ($search) {
              $safeSearch = mysqli_real_escape_string($conn, $search);
              $query .= " WHERE roomNo LIKE '%$safeSearch%' OR roomType LIKE '%$safeSearch%'";
          }
          $query .= " ORDER BY roomID DESC";
          $res = mysqli_query($conn, $query);
          ?>
                    <form method="get" class="flex gap-2 filter-form" style="max-width: 320px;">
                        <input type="text" name="search" placeholder="Search room no or type..." value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="button">Search</button>
            <?php if ($search): ?>
                        <a href="index.php" class="button outline">Clear</a>
            <?php endif; ?>
                    </form>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Room No</th>
                            <th>Room Type</th>
                            <th>Rate / Night</th>
                            <th>Status</th>
                            <th style="width: 140px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
          <?php if ($res && mysqli_num_rows($res) > 0): ?>
            <?php while($r = mysqli_fetch_assoc($res)): ?>
                        <tr>
                            <td><?= $r['roomID'] ?></td>
                            <td><strong><?= htmlspecialchars($r['roomNo']) ?></strong></td>
                            <td><span class="badge surface-muted text-dark"><?= htmlspecialchars($r['roomType']) ?></span></td>
                            <td>₱<?= number_format($r['price'], 2) ?></td>
                            <td>
                  <?php if ($r['status'] === 'Available'): ?>
                                <span class="badge status-success">Available</span>
                  <?php else: ?>
                                <span class="badge surface-muted"><?= htmlspecialchars($r['status']) ?></span>
                  <?php endif; ?>
                            </td>
                            <td>
                                <a class="button small outline" href="edit.php?id=<?= $r['roomID'] ?>">Edit</a>
                                <a class="button small danger-action ms-1" href="delete.php?id=<?= $r['roomID'] ?>" onclick="return confirm('Delete this room?')">Delete</a>
                            </td>
                        </tr>
            <?php endwhile; ?>
          <?php else: ?>
                        <tr><td colspan="6" class="align-center text-light py-3">No rooms found.</td></tr>
          <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>
