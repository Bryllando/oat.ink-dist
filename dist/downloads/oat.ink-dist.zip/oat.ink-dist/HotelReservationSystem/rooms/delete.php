<?php include '../database.php'; include '../helpers.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id){
    mysqli_query($conn, "DELETE FROM rooms WHERE roomID={$id}");
    set_flash('Room deleted.', 'success');
}
header('Location: index.php'); exit;
?>
