<?php
if(session_status() === PHP_SESSION_NONE) session_start();

function set_flash($msg, $type='info'){
    $_SESSION['_flash'] = ['msg'=>$msg, 'type'=>$type];
}

function get_flash(){
    if(isset($_SESSION['_flash'])){ $f = $_SESSION['_flash']; unset($_SESSION['_flash']); return $f; }
    return null;
}

function display_flash(){
    $f = get_flash();
    if(!$f) return;
    $type = $f['type'];
    $cls = 'notice-info';
    if($type === 'success') $cls = 'notice-success';
    if($type === 'error') $cls = 'notice-danger';
    echo "<div class=\"container mt-2\"><div class=\"notice {$cls}\" role=\"alert\">".htmlspecialchars($f['msg'])."</div></div>";
}

function save_reservation($conn, $data, $id = 0) {
    $guest = (int)($data['guestID'] ?? 0);
    $room = (int)($data['roomID'] ?? 0);
    $in = $data['checkIn'] ?? '';
    $out = $data['checkOut'] ?? '';
    $start = DateTimeImmutable::createFromFormat('!Y-m-d', $in);
    $end = DateTimeImmutable::createFromFormat('!Y-m-d', $out);
    if (!$start || !$end || $start->format('Y-m-d') !== $in || $end->format('Y-m-d') !== $out || $end <= $start) {
        throw new InvalidArgumentException('Check-out must be a valid date after check-in.');
    }
    if (!mysqli_begin_transaction($conn)) throw new RuntimeException('Could not start reservation.');
    try {
        $oldRoom = 0;
        if ($id) {
            $result = mysqli_query($conn, "SELECT roomID FROM reservations WHERE reserveID=$id FOR UPDATE");
            $old = $result ? mysqli_fetch_assoc($result) : null;
            if (!$old) throw new InvalidArgumentException('Reservation not found.');
            $oldRoom = (int)$old['roomID'];
        }
        $result = mysqli_query($conn, "SELECT price, status FROM rooms WHERE roomID=$room FOR UPDATE");
        $selected = $result ? mysqli_fetch_assoc($result) : null;
        $result = mysqli_query($conn, "SELECT guestID FROM guests WHERE guestID=$guest");
        if (!$selected || !$result || !mysqli_fetch_assoc($result)) {
            throw new InvalidArgumentException('Choose an existing guest and room.');
        }
        $result = mysqli_query($conn, "SELECT reserveID FROM reservations WHERE roomID=$room AND reserveID<>$id LIMIT 1");
        if (!$result) throw new RuntimeException('Could not check room availability.');
        if (mysqli_num_rows($result) || ($room !== $oldRoom && $selected['status'] !== 'Available')) {
            throw new InvalidArgumentException('This room is unavailable. Choose another room.');
        }
        $total = $start->diff($end)->days * (float)$selected['price'];
        $sql = $id
            ? "UPDATE reservations SET guestID=?, roomID=?, checkIn=?, checkOut=?, totalPaid=? WHERE reserveID=$id"
            : 'INSERT INTO reservations (guestID, roomID, checkIn, checkOut, totalPaid) VALUES (?, ?, ?, ?, ?)';
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) throw new RuntimeException('Could not save reservation.');
        mysqli_stmt_bind_param($stmt, 'iissd', $guest, $room, $in, $out, $total);
        if (!mysqli_stmt_execute($stmt)) throw new RuntimeException('Could not save reservation.');
        if (!mysqli_query($conn, "UPDATE rooms r SET status=IF(EXISTS(SELECT 1 FROM reservations b WHERE b.roomID=r.roomID), 'Occupied', 'Available') WHERE roomID IN ($room, $oldRoom)")) {
            throw new RuntimeException('Could not update room availability.');
        }
        if (!mysqli_commit($conn)) throw new RuntimeException('Could not finish reservation.');
        return $total;
    } catch (Throwable $error) {
        mysqli_rollback($conn);
        throw $error;
    }
}

?>
