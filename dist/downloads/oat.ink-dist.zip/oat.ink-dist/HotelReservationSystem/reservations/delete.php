<?php include '../database.php'; include '../helpers.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id){
    $r = mysqli_query($conn, "SELECT roomID FROM reservations WHERE reserveID={$id}");
    $rr = mysqli_fetch_assoc($r);
    if($rr && mysqli_query($conn, "DELETE FROM reservations WHERE reserveID={$id}")){
        $room = (int)$rr['roomID'];
        mysqli_query($conn, "UPDATE rooms SET status='Available' WHERE roomID=$room AND NOT EXISTS (SELECT 1 FROM reservations WHERE roomID=$room)");
        set_flash('Reservation deleted.', 'success');
    }
}
header('Location: index.php'); exit;
?>
