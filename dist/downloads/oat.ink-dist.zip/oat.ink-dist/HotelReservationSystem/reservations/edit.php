<?php include '../database.php'; include '../helpers.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$res = mysqli_query($conn, "SELECT * FROM reservations WHERE reserveID={$id}");
$row = mysqli_fetch_assoc($res);
if (!$row) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $total = save_reservation($conn, $_POST, $id);
        set_flash('Reservation saved. Total: ' . number_format($total, 2), 'success');
        header('Location: index.php');
        exit;
    } catch (Throwable $error) {
        set_flash($error->getMessage(), 'error');
    }
}

$guests = mysqli_query($conn, "SELECT guestID,fName,lName FROM guests");
$rooms = mysqli_query($conn, "SELECT roomID,roomNo,roomType,price FROM rooms");
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Edit Reservation</title>
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page">
            <h1 class="page-title">Edit Reservation</h1>
            <form method="post" class="entry-form form-panel">
                <div class="field-grid">
                    <div class="mb-2"><label for="input-guestID">Guest</label><select name="guestID" required id="input-guestID">
          <?php while($g = mysqli_fetch_assoc($guests)): ?>
                            <option value="<?= $g['guestID'] ?>" <?= $g['guestID']==$row['guestID']?'selected':''?>><?= htmlspecialchars($g['fName'].' '.$g['lName']) ?></option>
          <?php endwhile; ?>
                        </select></div>
                    <div class="mb-2"><label for="input-roomID">Room</label><select name="roomID" required id="input-roomID">
          <?php while($rm = mysqli_fetch_assoc($rooms)): ?>
                            <option value="<?= $rm['roomID'] ?>" <?= $rm['roomID']==$row['roomID']?'selected':''?>><?= htmlspecialchars($rm['roomNo'].' - '.$rm['roomType'].' ('.number_format($rm['price'],2).')') ?></option>
          <?php endwhile; ?>
                        </select></div>
                    <div class="mb-2"><label for="input-checkIn">Check-in</label><input type="date" name="checkIn" required value="<?= $row['checkIn'] ?>" id="input-checkIn"></div>
                    <div class="mb-2"><label for="input-checkOut">Check-out</label><input type="date" name="checkOut" required value="<?= $row['checkOut'] ?>" id="input-checkOut"></div>
                </div>
                <div class="form-actions">
                    <button class="button">Update</button>
                    <a class="button outline" href="index.php">Cancel</a>
                </div>
            </form>
        </div>
    </body>
</html>
