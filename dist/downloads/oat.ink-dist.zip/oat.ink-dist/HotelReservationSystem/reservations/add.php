<?php include '../database.php'; include '../helpers.php';
// fetch guests and rooms for selects
$guests = mysqli_query($conn, "SELECT guestID, fName, lName FROM guests ORDER BY fName");
$rooms = mysqli_query($conn, "SELECT roomID, roomNo, roomType, price FROM rooms WHERE status='Available' ORDER BY roomNo");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $total = save_reservation($conn, $_POST);
        set_flash('Reservation saved. Total: ' . number_format($total, 2), 'success');
        header('Location: index.php');
        exit;
    } catch (Throwable $error) {
        set_flash($error->getMessage(), 'error');
    }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add Reservation</title>
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page">
            <h1 class="page-title">Add Reservation</h1>
            <form method="post" class="entry-form form-panel">
                <div class="field-grid">
                    <div class="mb-2"><label for="input-guestID">Guest</label><select name="guestID" required id="input-guestID">
          <?php while($g = mysqli_fetch_assoc($guests)): ?>
                            <option value="<?= $g['guestID'] ?>"><?= htmlspecialchars($g['fName'].' '.$g['lName']) ?></option>
          <?php endwhile; ?>
                        </select></div>

                    <div class="mb-2"><label for="input-roomID">Room</label><select name="roomID" required id="input-roomID">
          <?php while($rm = mysqli_fetch_assoc($rooms)): ?>
                            <option value="<?= $rm['roomID'] ?>"><?= htmlspecialchars($rm['roomNo'].' - '.$rm['roomType'].' ('.number_format($rm['price'],2).')') ?></option>
          <?php endwhile; ?>
                        </select></div>

                    <div class="mb-2"><label for="input-checkIn">Check-in</label><input type="date" name="checkIn" required id="input-checkIn"></div>
                    <div class="mb-2"><label for="input-checkOut">Check-out</label><input type="date" name="checkOut" required id="input-checkOut"></div>
                </div>
                <div class="form-actions">
                    <button class="button">Reserve</button>
                    <a class="button outline" href="index.php">Cancel</a>
                </div>
            </form>
        </div>
    </body>
</html>
