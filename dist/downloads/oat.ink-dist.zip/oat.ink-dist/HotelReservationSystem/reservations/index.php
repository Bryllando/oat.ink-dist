<?php include '../database.php'; ?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Reservations Management</title>
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="site-hero mb-3">
                <h1 class="page-title">Reservations Management</h1>
                <small class="text-light">Process guest bookings and compute total payments</small>
            </div>

            <div class="card-surface mb-4">
                <div class="flex justify-between items-center mb-3">
                    <a class="button" href="add.php">+ Process New Reservation</a>
                    <a class="button outline" href="../monitoring/index.php">View Monitoring Report</a>
                </div>

        <?php
        $q = "SELECT r.*, g.fName, g.lName, rm.roomNo, rm.roomType FROM reservations r
              JOIN guests g ON r.guestID=g.guestID
              JOIN rooms rm ON r.roomID=rm.roomID
              ORDER BY r.reserveID DESC";
        $res = mysqli_query($conn, $q);
        ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Guest Name</th>
                            <th>Room Assigned</th>
                            <th>Check-In</th>
                            <th>Check-Out</th>
                            <th>Total Paid</th>
                            <th style="width: 140px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
          <?php if ($res && mysqli_num_rows($res) > 0): ?>
            <?php while($r = mysqli_fetch_assoc($res)): ?>
                        <tr>
                            <td><?= $r['reserveID'] ?></td>
                            <td><strong><?= htmlspecialchars($r['fName'].' '.$r['lName']) ?></strong></td>
                            <td><span class="badge surface-muted text-dark"><?= htmlspecialchars($r['roomNo'].' ('.$r['roomType'].')') ?></span></td>
                            <td><?= htmlspecialchars($r['checkIn']) ?></td>
                            <td><?= htmlspecialchars($r['checkOut']) ?></td>
                            <td><strong class="text-success fs-6">₱<?= number_format($r['totalPaid'], 2) ?></strong></td>
                            <td>
                                <a class="button small outline" href="edit.php?id=<?= $r['reserveID'] ?>">Edit</a>
                                <a class="button small danger-action ms-1" href="delete.php?id=<?= $r['reserveID'] ?>" onclick="return confirm('Delete this reservation?')">Delete</a>
                            </td>
                        </tr>
            <?php endwhile; ?>
          <?php else: ?>
                        <tr><td colspan="7" class="align-center text-light py-3">No reservations found.</td></tr>
          <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>
