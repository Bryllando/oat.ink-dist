CREATE DATABASE IF NOT EXISTS booksystem_db;
USE booksystem_db;

CREATE TABLE IF NOT EXISTS books (
    isbn VARCHAR(50) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    copyright VARCHAR(50) NOT NULL,
    edition VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL
);
