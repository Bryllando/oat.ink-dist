> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

⭐ Project Structure Philosophy — Apply to ALL Future ProjectsKeep the folder structure minimal and flat. This is the preferred approach for all future PHP projects, same as the styling below. Do NOT over-engineer with subfolders, config layers, includes, or assets directories unless the project truly demands it.✅ Preferred: Minimal Flat Structure (use this)ProjectName/
├── styles.css          ← single shared stylesheet
├── db.php              ← single DB connection file
├── index.php           ← dashboard / home
├── [feature].php       ← one file per feature/module
└── [feature].sql       ← database schema
❌ Avoid: Over-engineered Structure (unnecessary for small projects)ProjectName/
├── assets/css/app.css
├── config/database.php
├── includes/header.php
├── includes/footer.php
├── events/index.php
├── participants/index.php
└── ...
Why Minimal?✅ Faster to build and navigate✅ Easier to understand at a glance✅ No unnecessary abstraction✅ Less chance of path/include errorsThe complex nested structure is only useful for large enterprise apps with many developers. For capstone tests, skills tests, and small projects — flat is always better.Backend RequirementsDatabase SchemaTable Name: Books TableFields & Structure:ISBN — Primary KeyTitleCopyrightEditionPriceQuantityFrontend Layout & Element SpecificationsThe user interface consists of four core structural sections: a data entry FORM, a control panel of action BUTTONS, a feedback PROMPT region, and a dynamic tabular LIST.1. The FORM (Data Entry Fields)General Form Rules:If searching: ISBN# should be supplied first.If editing: searching is done first.If deleting: searching is done first.Fields Layout:ISBN #: (Text input field)Title: (Text input field)Copyright: (Text input field)Edition: (Text input field)Price: (Text input field)Quantity: (Text input field)2. Action Buttons & Behavioral RulesSEARCH ButtonBehavior: When clicked after an ISBN# is inputted and found, it will display all the rest of the fields in the FORM. Otherwise, it will not display anything in the rest of the fields.Feedback Display:Display "ITEM NOT FOUND" in the PROMPT if the item is not found.Display "ITEM IS FOUND" in the PROMPT if the item is found.EDIT ButtonBehavior: When clicked after a successful search is made, it will save all modifications made in all field values in the FORM except ISBN# (which must be non-editable).Feedback Display:Display "RECORD SUCCESSFULLY UPDATED" in the PROMPT.If the FORM is blank, display "NO RECORD TO EDIT" in the PROMPT.If ISBN# is not found, display "ISBN# NOT FOUND" in the PROMPT.DELETE ButtonBehavior: When clicked after a successful search, it will delete the record, update, and refresh the LIST.Feedback Display: * Display "RECORD SUCCESSFULLY DELETED" in the PROMPT.ADD ButtonBehavior & Logic:When clicked although the FORM is blank, it will position the cursor to the ISBN# textbox and display "NO RECORD TO ADD" in the PROMPT.When clicked after the values are supplied, it will add the record and display "RECORD SUCCESSFULLY SAVED" in the PROMPT.If the ISBN# already exists, display "RECORD ALREADY EXISTS" in the PROMPT and set focus back to the ISBN# textbox.3. PROMPT RegionBehavior: Located below the action buttons / form. This dedicated feedback area is where all system prompts (e.g., error messages, confirmation messages, etc.) must be dynamically displayed.4. The LIST (Data Table Layout & Summary Calculations)Table StructureThe table displays all the database records dynamically and updates continuously.Column Headers: ISBN | Title | Copyright | Edition | Price | Quantity | TOTALCalculated Column Rule: TOTAL column value is calculated line-by-line as [price * quantity].Table State & Refresh RulesWhen editing, the application will refresh the list.When adding, the application will refresh the list.When deleting, the application will refresh the list.Reference Data Preview (From Image View)ISBNTitleCopyrightEditionPriceQuantityTOTAL1Harry Potter20051st$95.0031785.002Lord of the Rings20043rd$999.00109990.003Java Programming2010UPE$549.0021098.004The Notebook1999US$750.00118250.00Summary Row RequirementsEvery view of the table must explicitly include a footer containing cumulative grand summaries:Grand Total of Quantity: 26 (Sum of all quantities)Grand Total of TOTALs: 21123.00 (Sum of all calculated totals)Display Rule: Every display cycle will include the total number of Books and the Grand Total of the TOTALS even with or without result.UI Style Guide⭐ Preferred Style — Apply to ALL future PHP projects.This is the standard look and layout the developer prefers. When starting any new PHP/HTML project, replicate this structure, color palette, and CSS classes. Copy styles.css into the project root and link it in every page's <head> with <link rel="stylesheet" href="styles.css">.General RulesFont: Arial, Helvetica, sans-serif — standard system font, no Google Fonts import needed.Background: Light gray #f4f6f9 on body, white #ffffff for all cards/tables.Text: Dark gray #333333 for headings, #555555 for secondary/muted text.Border: All borders use 1px solid #ddd with border-radius: 4px for a flat, non-rounded look.Color Palette (Basic Colors Only)PurposeColorHex CodePrimary / BlueLinks, Buttons, Focus#007bffSuccess / GreenAttendance / Saves confirmed#28a745Warning / YellowEdit buttons#ffc107Danger / RedDelete buttons, Error alerts#dc3545Light GrayTable headers, Badges, Hover#f1f1f1 / #f9f9f9WhiteCards, Navbar, Inputs#ffffffLayout Pattern (Every Page)Every page must follow this exact structure. The <nav> is a direct child of <body> (NOT inside .page-container) so that position: fixed spans the full browser width:HTML<body>
  <nav class="navbar">
    <a href="index.php" class="navbar-brand">App Name</a>
    <div class="navbar-nav">
      <a href="page.php" class="nav-link active">Page</a>  </div>
  </nav>

  <div class="page-container">           <div class="page-title">...</div>    <div class="card">...</div>          <div class="table-container">        <table>...</table>
    </div>

  </div>
</body>
Form InputsUse class form-control on all <input>, <select>.Wrap multiple inputs side-by-side in a <form class="form-inline"> (uses display: flex; gap: 15px;).For stacked labeled fields (e.g. Edit page), use <div class="form-group"> with a <label> above.ButtonsClassColorUsebtn btn-primaryBlue #007bffMain submit/save/add actionsbtn btn-secondaryWhite + gray borderCancel / back actionsbtn-action btn-editYellow #ffc107Inline table Edit actionbtn-action btn-deleteRed #dc3545Inline table Delete actionAlertsClassColorWhen to usealert alert-successGreen backgroundSuccessful operation (Item Found / Saved)alert alert-warningRed/pink backgroundError or already-exists warning (Not Found)Table StructureHTML<div class="table-container">
  <table>
    <thead>
      <tr>
        <th>Column</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Data</td>
        <td>
          <div class="action-buttons">
            <a href="edit.php?id=..." class="btn-action btn-edit">Edit</a>
            <a href="?del=..."      class="btn-action btn-delete">Delete</a>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
</div>
Active Nav LinkAdd class="nav-link active" to the link matching the current page. This makes the nav pill highlight blue.PHP<a href="index.php"        class="nav-link active">Books Inventory</a>
<a href="registration.php" class="nav-link">Registration</a>
<a href="attendance.php"   class="nav-link">Attendance</a>
<a href="raffle.php"       class="nav-link">Raffle</a>