<?php
require_once 'db.php';

$isbn = '';
$title = '';
$copyright = '';
$edition = '';
$price = '';
$quantity = '';
$prompt_msg = '';
$prompt_class = '';
$action = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $isbn = trim($_POST['isbn'] ?? '');
    $title = trim($_POST['title'] ?? '');
    $copyright = trim($_POST['copyright'] ?? '');
    $edition = trim($_POST['edition'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $quantity = trim($_POST['quantity'] ?? '');
    $validBook = $isbn !== '' && $title !== '' && is_numeric($price) && $price >= 0 && ctype_digit($quantity);

    if ($action == 'SEARCH') {
        if (empty($isbn)) {
            $prompt_msg = "ISBN# should be supplied";
            $prompt_class = "notice-warning";
        } else {
            $stmt = mysqli_prepare($conn, "SELECT * FROM books WHERE isbn = ?");
            mysqli_stmt_bind_param($stmt, "s", $isbn);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if ($row = mysqli_fetch_assoc($result)) {
                $title = $row['title'];
                $copyright = $row['copyright'];
                $edition = $row['edition'];
                $price = $row['price'];
                $quantity = $row['quantity'];
                $prompt_msg = "ITEM IS FOUND";
                $prompt_class = "notice-success";
            } else {
                $prompt_msg = "ITEM NOT FOUND";
                $prompt_class = "notice-warning";
                $title = '';
                $copyright = '';
                $edition = '';
                $price = '';
                $quantity = '';
            }
            mysqli_stmt_close($stmt);
        }
    } elseif ($action == 'ADD') {
        if (!$validBook) {
            $prompt_msg = "NO RECORD TO ADD. Enter ISBN, title, a non-negative price, and a whole quantity.";
            $prompt_class = "notice-warning";
        } else {
            $stmt = mysqli_prepare($conn, "SELECT * FROM books WHERE isbn = ?");
            mysqli_stmt_bind_param($stmt, "s", $isbn);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if (mysqli_fetch_assoc($result)) {
                $prompt_msg = "RECORD ALREADY EXISTS";
                $prompt_class = "notice-warning";
            } else {
                $stmt2 = mysqli_prepare($conn, "INSERT INTO books (isbn, title, copyright, edition, price, quantity) VALUES (?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt2, "ssssdi", $isbn, $title, $copyright, $edition, $price, $quantity);
                if (mysqli_stmt_execute($stmt2)) {
                    $prompt_msg = "RECORD SUCCESSFULLY SAVED";
                    $prompt_class = "notice-success";
                } else {
                    $prompt_msg = "ERROR SAVING RECORD";
                    $prompt_class = "notice-danger";
                }
                mysqli_stmt_close($stmt2);
            }
            mysqli_stmt_close($stmt);
        }
    } elseif ($action == 'EDIT') {
        if ($validBook) {
            $stmt = mysqli_prepare($conn, "SELECT isbn FROM books WHERE isbn=?");
            mysqli_stmt_bind_param($stmt, "s", $isbn);
            mysqli_stmt_execute($stmt);
            $found = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            mysqli_stmt_close($stmt);
            if (!$found) {
                $prompt_msg = "ISBN# NOT FOUND";
                $prompt_class = "notice-warning";
            } else {
                $stmt = mysqli_prepare($conn, "UPDATE books SET title=?, copyright=?, edition=?, price=?, quantity=? WHERE isbn=?");
                mysqli_stmt_bind_param($stmt, "sssdis", $title, $copyright, $edition, $price, $quantity, $isbn);
                $saved = mysqli_stmt_execute($stmt);
                $prompt_msg = $saved ? "RECORD SUCCESSFULLY UPDATED" : "ERROR SAVING RECORD";
                $prompt_class = $saved ? "notice-success" : "notice-danger";
                mysqli_stmt_close($stmt);
            }
        } else {
            $prompt_msg = "NO RECORD TO EDIT. Enter ISBN, title, a non-negative price, and a whole quantity.";
            $prompt_class = "notice-warning";
        }
    } elseif ($action == 'DELETE') {
        if (empty($isbn)) {
            $prompt_msg = "ISBN# should be supplied";
            $prompt_class = "notice-warning";
        } else {
            $stmt = mysqli_prepare($conn, "DELETE FROM books WHERE isbn=?");
            mysqli_stmt_bind_param($stmt, "s", $isbn);
            mysqli_stmt_execute($stmt);
            if (mysqli_stmt_affected_rows($stmt) > 0) {
                $prompt_msg = "RECORD SUCCESSFULLY DELETED";
                $prompt_class = "notice-success";
                $isbn = '';
                $title = '';
                $copyright = '';
                $edition = '';
                $price = '';
                $quantity = '';
            } else {
                $prompt_msg = "ITEM NOT FOUND";
                $prompt_class = "notice-warning";
            }
            mysqli_stmt_close($stmt);
        }
    }
}

$books = [];
$result = mysqli_query($conn, "SELECT * FROM books");
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $books[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BookSystem</title>
    
    
    </head>

    <body>
        <nav class="app-nav">
            <a href="index.php" class="app-brand">BookSystem</a>
            <div class="nav-links">
                <a href="index.php" class="nav-link active">Books</a>
            </div>
        </nav>

        <div class="page-container">
            <div class="page-heading"><h1 class="page-title">Book Records</h1></div>
            <div class="card">
                <form method="POST" action="index.php" id="bookForm" class="entry-form">
                    <div class="book-system-layout">
                        <div class="book-form-section">
                            <div class="form-row">
                                <label for="isbn">ISBN #:</label>
                                <input type="text" name="isbn" id="isbn"
                                value="<?php echo htmlspecialchars($isbn); ?>" <?php echo ($action == 'SEARCH' && $prompt_msg == 'ITEM IS FOUND') ? 'readonly style="background-color: #e9ecef;"' : ''; ?>>
                            </div>
                            <div class="form-row">
                                <label for="title">Title:</label>
                                <input type="text" name="title"
                                value="<?php echo htmlspecialchars($title); ?>" id="title">
                            </div>
                            <div class="form-row">
                                <label for="copyright">Copyright:</label>
                                <input type="text" name="copyright"
                                value="<?php echo htmlspecialchars($copyright); ?>" id="copyright">
                            </div>
                            <div class="form-row">
                                <label for="edition">Edition:</label>
                                <input type="text" name="edition"
                                value="<?php echo htmlspecialchars($edition); ?>" id="edition">
                            </div>
                            <div class="form-row">
                                <label for="price">Price:</label>
                                <input type="text" name="price"
                                value="<?php echo htmlspecialchars($price); ?>" id="price">
                            </div>
                            <div class="form-row">
                                <label for="quantity">Quantity:</label>
                                <input type="text" name="quantity"
                                value="<?php echo htmlspecialchars($quantity); ?>" id="quantity">
                            </div>
                        </div>

                        <div class="book-buttons-section" style="width: 250px;">
                            <div class="button-panel">
                                <button type="submit" name="action" value="SEARCH" class="button outline">SEARCH</button>
                                <button type="submit" name="action" value="EDIT" class="button outline">EDIT</button>
                                <button type="submit" name="action" value="DELETE" class="button danger-action">DELETE</button>
                                <button type="submit" name="action" value="ADD" class="button">ADD</button>
                            </div>
                        </div>
                    </div>
                </form>

            <?php if (!empty($prompt_msg)): ?>
                <div role="alert" class="notice <?php echo $prompt_class; ?>" id="promptBox">
                    <?php echo $prompt_msg; ?>
                </div>
            <?php endif; ?>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ISBN</th>
                            <th>Title</th>
                            <th>Copyright</th>
                            <th>Edition</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>TOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    if (count($books) > 0):
                        foreach ($books as $book):
                            $total = $book['price'] * $book['quantity'];
                            ?>
                        <tr>
                            <td><?php echo htmlspecialchars($book['isbn']); ?></td>
                            <td><?php echo htmlspecialchars($book['title']); ?></td>
                            <td><?php echo htmlspecialchars($book['copyright']); ?></td>
                            <td><?php echo htmlspecialchars($book['edition']); ?></td>
                            <td>$<?php echo number_format($book['price'], 2); ?></td>
                            <td><?php echo htmlspecialchars($book['quantity']); ?></td>
                            <td><?php echo number_format($total, 2); ?></td>
                        </tr>
                        <?php
                        endforeach;
                    endif;
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>

</html>
