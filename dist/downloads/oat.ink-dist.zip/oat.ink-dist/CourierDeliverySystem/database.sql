CREATE DATABASE IF NOT EXISTS `courier_delivery_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `courier_delivery_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `clients` (
  `clientID` INT AUTO_INCREMENT PRIMARY KEY,
  `clientName` VARCHAR(100) NOT NULL,
  `companyName` VARCHAR(100) NOT NULL,
  `senderAddress` VARCHAR(150) NOT NULL,
  `contactNumber` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `delivery_routes` (
  `routeID` INT AUTO_INCREMENT PRIMARY KEY,
  `originCity` VARCHAR(100) NOT NULL,
  `destinationCity` VARCHAR(100) NOT NULL,
  `baseFreightRate` DECIMAL(10,2) NOT NULL,
  `transitDays` INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `shipments` (
  `shipmentID` INT AUTO_INCREMENT PRIMARY KEY,
  `clientID` INT NOT NULL,
  `routeID` INT NOT NULL,
  `trackingNumber` VARCHAR(50) NOT NULL,
  `shipDate` DATE NOT NULL,
  `weightKg` DECIMAL(10,2) NOT NULL,
  `shippingFee` DECIMAL(10,2) NOT NULL,
  `deliveryStatus` VARCHAR(50) DEFAULT 'In Transit',
  FOREIGN KEY (`clientID`) REFERENCES `clients`(`clientID`) ON DELETE CASCADE,
  FOREIGN KEY (`routeID`) REFERENCES `delivery_routes`(`routeID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `clients` (`clientName`, `companyName`, `senderAddress`, `contactNumber`) VALUES
('Rowena Macasero', 'Cebu Crafts Online', 'Colon St., Cebu City', '09176543210'),
('Ignacio Torrevillas', 'Island Seafood Traders', 'Pasil Fish Port, Cebu', '09187654321'),
('Teresa Alcantara', 'Boutique Threads PH', 'Ayala Mall Hub, Cebu', '09228765432');

INSERT INTO `delivery_routes` (`originCity`, `destinationCity`, `baseFreightRate`, `transitDays`) VALUES
('Cebu City', 'Manila Metro Hub', 180.0, 2),
('Cebu City', 'Davao City Terminal', 220.0, 3),
('Cebu City', 'Iloilo City Port', 140.0, 1);

INSERT INTO `shipments` (`clientID`, `routeID`, `trackingNumber`, `shipDate`, `weightKg`, `shippingFee`, `deliveryStatus`) VALUES
(1, 1, 'EXP-2026-9001', '2026-10-28', 3.5, 480.0, 'Delivered'),
(2, 2, 'EXP-2026-9002', '2026-10-30', 12.0, 1650.0, 'In Transit'),
(3, 3, 'EXP-2026-9003', '2026-11-02', 1.8, 280.0, 'In Transit');

SET FOREIGN_KEY_CHECKS=1;
