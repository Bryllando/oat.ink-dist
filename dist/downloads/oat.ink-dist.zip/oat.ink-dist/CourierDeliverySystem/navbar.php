<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Courier Logistics & Parcel Shipping System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'clients') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>clients/index.php">Senders & Clients</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'delivery_routes') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>delivery_routes/index.php">Delivery Routes</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'shipments') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>shipments/index.php">Waybill Shipments</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
