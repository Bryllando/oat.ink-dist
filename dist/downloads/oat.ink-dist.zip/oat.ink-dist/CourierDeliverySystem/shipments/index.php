<?php
require_once __DIR__ . '/../database.php';

$sql = "SELECT t.*, e1.clientName AS e1_title, e2.destinationCity AS e2_title 
        FROM `shipments` t 
        JOIN `clients` e1 ON t.clientID = e1.clientID 
        JOIN `delivery_routes` e2 ON t.routeID = e2.routeID 
        ORDER BY t.shipmentID DESC";
$records = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Waybill Shipments - Courier Logistics & Parcel Shipping System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Manage Waybill Shipments</h3>
            <a href="add.php" class="button">+ Record New Shipment</a>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="mb-0">
                    <thead class="">
                        <tr>
                            <th>#</th>
                            <th>Client</th>
                            <th>Route</th>
                            <th>Tracking Number</th>
<th>Dispatch Date</th>
<th>Package Weight (KG)</th>
<th>Total Shipping Fee</th>
<th>Status</th>

                            <th class="align-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['shipmentID'] ?></td>
                                    <td class="weight-bold"><?= htmlspecialchars($r['e1_title']) ?></td>
                                    <td><?= htmlspecialchars($r['e2_title']) ?></td>
                                    <td><?= htmlspecialchars($r['trackingNumber']) ?></td>
<td><?= htmlspecialchars($r['shipDate']) ?></td>
<td><?= htmlspecialchars($r['weightKg']) ?></td>
<td><?= htmlspecialchars($r['shippingFee']) ?></td>
<td><?= htmlspecialchars($r['deliveryStatus']) ?></td>

                                    <td class="align-right">
                                        <form method="POST" action="delete.php" class="inline-block" onsubmit="return confirm('Delete this record and any linked transactions?');">
                                            <input type="hidden" name="id" value="<?= $r['shipmentID'] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                                            <button type="submit" class="button small outline danger-action">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" class="align-center py-4 text-light">No transaction records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
</body>
</html>
