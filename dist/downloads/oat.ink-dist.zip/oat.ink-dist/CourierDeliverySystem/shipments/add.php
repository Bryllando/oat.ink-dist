<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `clientID`, `clientName` FROM `clients` ORDER BY `clientName` ASC");
$e2List = $conn->query("SELECT `routeID`, `destinationCity` FROM `delivery_routes` ORDER BY `destinationCity` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['clientID'] ?? 0);
    $id2 = (int)($_POST['routeID'] ?? 0);
    $trackingNumber = is_string($_POST['trackingNumber'] ?? null) ? trim($_POST['trackingNumber']) : '';
    $shipDate = is_string($_POST['shipDate'] ?? null) ? trim($_POST['shipDate']) : '';
    $weightKg = is_string($_POST['weightKg'] ?? null) ? trim($_POST['weightKg']) : '';
    $shippingFee = is_string($_POST['shippingFee'] ?? null) ? trim($_POST['shippingFee']) : '';
    $deliveryStatus = is_string($_POST['deliveryStatus'] ?? null) ? trim($_POST['deliveryStatus']) : '';

    if ($trackingNumber === '' ||
        $shipDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $shipDate) ||
        date('Y-m-d', strtotime($shipDate) ?: 0) !== $shipDate ||
        $weightKg === '' ||
        !is_numeric($weightKg) ||
        !is_finite((float)$weightKg) ||
        (float)$weightKg < 0 ||
        $shippingFee === '' ||
        !is_numeric($shippingFee) ||
        !is_finite((float)$shippingFee) ||
        (float)$shippingFee < 0 ||
        $deliveryStatus === '' ||
        $id1 <= 0 ||
        $id2 <= 0) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `shipments` (`clientID`, `routeID`, `trackingNumber`, `shipDate`, `weightKg`, `shippingFee`, `deliveryStatus`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($trackingNumber) . "', '" . $conn->real_escape_string($shipDate) . "', '" . $conn->real_escape_string($weightKg) . "', '" . $conn->real_escape_string($shippingFee) . "', '" . $conn->real_escape_string($deliveryStatus) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Shipment - Courier Logistics & Parcel Shipping System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Shipment</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="clientID" class="weight-semibold">Select Client</label>
                        <select id="clientID" name="clientID" class="" required>
                            <option value="">-- Choose Client --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['clientID'] ?>" <?= ((int)($_POST['clientID'] ?? 0) === (int)$r['clientID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['clientName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="routeID" class="weight-semibold">Select Route</label>
                        <select id="routeID" name="routeID" class="" required>
                            <option value="">-- Choose Route --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['routeID'] ?>" <?= ((int)($_POST['routeID'] ?? 0) === (int)$r['routeID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['destinationCity']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="trackingNumber" class="weight-semibold">Tracking Number</label>
                <input type="text" id="trackingNumber" name="trackingNumber" class=""  required value="<?= htmlspecialchars($trackingNumber ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="shipDate" class="weight-semibold">Dispatch Date</label>
                <input type="date" id="shipDate" name="shipDate" class=""  required value="<?= htmlspecialchars($shipDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="weightKg" class="weight-semibold">Package Weight (KG)</label>
                <input type="number" id="weightKg" name="weightKg" min="0" class="" step="0.01" required value="<?= htmlspecialchars($weightKg ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="shippingFee" class="weight-semibold">Total Shipping Fee</label>
                <input type="number" id="shippingFee" name="shippingFee" min="0" class="" step="0.01" required value="<?= htmlspecialchars($shippingFee ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="deliveryStatus" class="weight-semibold">Status</label>
                <input type="text" id="deliveryStatus" name="deliveryStatus" class=""  required value="<?= htmlspecialchars($deliveryStatus ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Shipment</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
