<?php
require_once __DIR__ . '/database.php';

$countE1 = $conn->query("SELECT COUNT(*) AS total FROM `clients`")->fetch_assoc()['total'] ?? 0;
$countE2 = $conn->query("SELECT COUNT(*) AS total FROM `delivery_routes`")->fetch_assoc()['total'] ?? 0;
$countTr = $conn->query("SELECT COUNT(*) AS total FROM `shipments`")->fetch_assoc()['total'] ?? 0;
$sumTotal = $conn->query("SELECT IFNULL(SUM(shippingFee), 0) AS total FROM `shipments`")->fetch_assoc()['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Courier Logistics & Parcel Shipping System - Dashboard</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/navbar.php'; ?>

    <div class="container my-4">
        <div class="p-4 mb-4 rounded border">
            <h1 class="display-6 weight-bold mb-2">Courier Logistics & Parcel Shipping System</h1>
            <p class="lead text-light mb-0">Universal College Capstone & Skills Test Management System</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Senders & Clients</span>
                    <h2 class="weight-bold text-primary mb-2"><?= $countE1 ?></h2>
                    <a href="<?= $baseUrl ?>clients/index.php" class="button outline small">Manage Senders & Clients </a>
                </div>
            </div>
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Delivery Routes</span>
                    <h2 class="weight-bold text-success mb-2"><?= $countE2 ?></h2>
                    <a href="<?= $baseUrl ?>delivery_routes/index.php" class="button outline success-action small">Manage Delivery Routes </a>
                </div>
            </div>
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Waybill Shipments</span>
                    <h2 class="weight-bold mb-2"><?= $countTr ?></h2>
                    <a href="<?= $baseUrl ?>shipments/index.php" class="button outline small">View Waybill Shipments </a>
                </div>
            </div>
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Total Freight Collections</span>
                    <h2 class="weight-bold text-warning mb-2">₱<?= number_format((float)$sumTotal, 2) ?></h2>
                    <a href="<?= $baseUrl ?>monitoring/index.php" class="button outline small">View Analytics </a>
                </div>
            </div>
        </div>

        <div class="card p-4">
            <h4 class="weight-bold mb-3">Quick Actions</h4>
            <div class="form-actions">
                <a href="<?= $baseUrl ?>clients/add.php" class="button">+ Add New Client</a>
                <a href="<?= $baseUrl ?>delivery_routes/add.php" class="button success-action">+ Add New Route</a>
                <a href="<?= $baseUrl ?>shipments/add.php" class="button outline">+ Record New Shipment</a>
                <a href="<?= $baseUrl ?>monitoring/index.php" class="button outline">Generate Monitoring Report</a>
            </div>
        </div>
    </div>

    
</body>
</html>
