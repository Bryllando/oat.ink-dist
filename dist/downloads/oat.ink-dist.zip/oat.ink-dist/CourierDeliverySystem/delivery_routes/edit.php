<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `delivery_routes` WHERE `routeID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $originCity = is_string($_POST['originCity'] ?? null) ? trim($_POST['originCity']) : '';
    $destinationCity = is_string($_POST['destinationCity'] ?? null) ? trim($_POST['destinationCity']) : '';
    $baseFreightRate = is_string($_POST['baseFreightRate'] ?? null) ? trim($_POST['baseFreightRate']) : '';
    $transitDays = is_string($_POST['transitDays'] ?? null) ? trim($_POST['transitDays']) : '';

    if ($originCity === '' ||
        $destinationCity === '' ||
        $baseFreightRate === '' ||
        !is_numeric($baseFreightRate) ||
        !is_finite((float)$baseFreightRate) ||
        (float)$baseFreightRate < 0 ||
        $transitDays === '' ||
        !is_numeric($transitDays) ||
        !is_finite((float)$transitDays) ||
        (float)$transitDays < 0 ||
        filter_var($transitDays, FILTER_VALIDATE_INT) === false) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `delivery_routes` SET `originCity` = '" . $conn->real_escape_string($originCity) . "', `destinationCity` = '" . $conn->real_escape_string($destinationCity) . "', `baseFreightRate` = '" . $conn->real_escape_string($baseFreightRate) . "', `transitDays` = '" . $conn->real_escape_string($transitDays) . "' WHERE `routeID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Route - Courier Logistics & Parcel Shipping System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Route</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="originCity" class="weight-semibold">Origin City</label>
                <input type="text" id="originCity" name="originCity" class=""  required value="<?= htmlspecialchars($record['originCity'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="destinationCity" class="weight-semibold">Destination City</label>
                <input type="text" id="destinationCity" name="destinationCity" class=""  required value="<?= htmlspecialchars($record['destinationCity'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="baseFreightRate" class="weight-semibold">Base Freight Rate</label>
                <input type="number" id="baseFreightRate" name="baseFreightRate" min="0" class="" step="0.01" required value="<?= htmlspecialchars($record['baseFreightRate'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="transitDays" class="weight-semibold">Estimated Transit (Days)</label>
                <input type="number" id="transitDays" name="transitDays" min="0" class="" step="1" required value="<?= htmlspecialchars($record['transitDays'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Route</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
