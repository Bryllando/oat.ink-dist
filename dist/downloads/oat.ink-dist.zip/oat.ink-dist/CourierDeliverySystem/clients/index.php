<?php
require_once __DIR__ . '/../database.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$where = "1=1";
if ($search !== '') {
    $esc = $conn->real_escape_string($search);
    $where .= " AND (`clientName` LIKE '%$esc%')";
}

$records = $conn->query("SELECT * FROM `clients` WHERE $where ORDER BY `clientID` DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Senders & Clients - Courier Logistics & Parcel Shipping System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Manage Senders & Clients</h3>
            <a href="add.php" class="button">+ Add New Client</a>
        </div>

        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-10">
                    <input type="text" name="search" class="" placeholder="Search by Client Name..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-2 flex gap-2">
                    <button type="submit" class="button outline w-100">Search</button>
                    <?php if ($search !== ''): ?>
                        <a href="index.php" class="button outline">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="mb-0">
                    <thead class="">
                        <tr>
                            <th>#</th>
                            <th>Client Name</th>
<th>Company / Enterprise</th>
<th>Pickup Address</th>
<th>Contact Number</th>

                            <th class="align-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['clientID'] ?></td>
                                    <td><?= htmlspecialchars($r['clientName']) ?></td>
<td><?= htmlspecialchars($r['companyName']) ?></td>
<td><?= htmlspecialchars($r['senderAddress']) ?></td>
<td><?= htmlspecialchars($r['contactNumber']) ?></td>

                                    <td class="align-right">
                                        <a href="edit.php?id=<?= $r['clientID'] ?>" class="button small outline">Edit</a>
                                        <form method="POST" action="delete.php" class="inline-block" onsubmit="return confirm('Delete this record and any linked transactions?');">
                                            <input type="hidden" name="id" value="<?= $r['clientID'] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                                            <button type="submit" class="button small outline danger-action">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="align-center py-4 text-light">No records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
</body>
</html>
