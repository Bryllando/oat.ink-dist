<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $clientName = is_string($_POST['clientName'] ?? null) ? trim($_POST['clientName']) : '';
    $companyName = is_string($_POST['companyName'] ?? null) ? trim($_POST['companyName']) : '';
    $senderAddress = is_string($_POST['senderAddress'] ?? null) ? trim($_POST['senderAddress']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($clientName === '' ||
        $companyName === '' ||
        $senderAddress === '' ||
        $contactNumber === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `clients` (`clientName`, `companyName`, `senderAddress`, `contactNumber`) VALUES ('" . $conn->real_escape_string($clientName) . "', '" . $conn->real_escape_string($companyName) . "', '" . $conn->real_escape_string($senderAddress) . "', '" . $conn->real_escape_string($contactNumber) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Client - Courier Logistics & Parcel Shipping System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Add New Client</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="clientName" class="weight-semibold">Client Name</label>
                <input type="text" id="clientName" name="clientName" class=""  required value="<?= htmlspecialchars($clientName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="companyName" class="weight-semibold">Company / Enterprise</label>
                <input type="text" id="companyName" name="companyName" class=""  required value="<?= htmlspecialchars($companyName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="senderAddress" class="weight-semibold">Pickup Address</label>
                <input type="text" id="senderAddress" name="senderAddress" class=""  required value="<?= htmlspecialchars($senderAddress ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactNumber" class="weight-semibold">Contact Number</label>
                <input type="text" id="contactNumber" name="contactNumber" class=""  required value="<?= htmlspecialchars($contactNumber ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Save Client</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
