<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `residentID`, `fullName` FROM `residents` ORDER BY `fullName` ASC");
$e2List = $conn->query("SELECT `typeID`, `typeName` FROM `clearance_types` ORDER BY `typeName` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['residentID'] ?? 0);
    $id2 = (int)($_POST['typeID'] ?? 0);
    $issueDate = is_string($_POST['issueDate'] ?? null) ? trim($_POST['issueDate']) : '';
    $purpose = is_string($_POST['purpose'] ?? null) ? trim($_POST['purpose']) : '';
    $amountPaid = is_string($_POST['amountPaid'] ?? null) ? trim($_POST['amountPaid']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($issueDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $issueDate) ||
        date('Y-m-d', strtotime($issueDate) ?: 0) !== $issueDate ||
        $purpose === '' ||
        $amountPaid === '' ||
        !is_numeric($amountPaid) ||
        !is_finite((float)$amountPaid) ||
        (float)$amountPaid < 0 ||
        $status === '' ||
        $id1 <= 0 ||
        $id2 <= 0) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `clearances` (`residentID`, `typeID`, `issueDate`, `purpose`, `amountPaid`, `status`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($issueDate) . "', '" . $conn->real_escape_string($purpose) . "', '" . $conn->real_escape_string($amountPaid) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Clearance Issuance - Barangay Clearance & Certification System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Clearance Issuance</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="residentID" class="weight-semibold">Select Resident</label>
                        <select id="residentID" name="residentID" class="" required>
                            <option value="">-- Choose Resident --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['residentID'] ?>" <?= ((int)($_POST['residentID'] ?? 0) === (int)$r['residentID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['fullName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="typeID" class="weight-semibold">Select Clearance Type</label>
                        <select id="typeID" name="typeID" class="" required>
                            <option value="">-- Choose Clearance Type --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['typeID'] ?>" <?= ((int)($_POST['typeID'] ?? 0) === (int)$r['typeID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['typeName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="issueDate" class="weight-semibold">Date Issued</label>
                <input type="date" id="issueDate" name="issueDate" class=""  required value="<?= htmlspecialchars($issueDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="purpose" class="weight-semibold">Purpose</label>
                <input type="text" id="purpose" name="purpose" class=""  required value="<?= htmlspecialchars($purpose ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="amountPaid" class="weight-semibold">Amount Paid</label>
                <input type="number" id="amountPaid" name="amountPaid" min="0" class="" step="0.01" required value="<?= htmlspecialchars($amountPaid ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="status" class="weight-semibold">Status</label>
                <input type="text" id="status" name="status" class=""  required value="<?= htmlspecialchars($status ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Clearance Issuance</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
