CREATE DATABASE IF NOT EXISTS `barangay_clearance_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `barangay_clearance_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `residents` (
  `residentID` INT AUTO_INCREMENT PRIMARY KEY,
  `fullName` VARCHAR(100) NOT NULL,
  `birthDate` DATE NOT NULL,
  `civilStatus` VARCHAR(50) NOT NULL,
  `address` VARCHAR(150) NOT NULL,
  `contactNumber` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `clearance_types` (
  `typeID` INT AUTO_INCREMENT PRIMARY KEY,
  `typeName` VARCHAR(100) NOT NULL,
  `fee` DECIMAL(10,2) NOT NULL,
  `requirements` VARCHAR(150) NOT NULL,
  `validityMonths` INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `clearances` (
  `clearanceID` INT AUTO_INCREMENT PRIMARY KEY,
  `residentID` INT NOT NULL,
  `typeID` INT NOT NULL,
  `issueDate` DATE NOT NULL,
  `purpose` VARCHAR(150) NOT NULL,
  `amountPaid` DECIMAL(10,2) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Released',
  FOREIGN KEY (`residentID`) REFERENCES `residents`(`residentID`) ON DELETE CASCADE,
  FOREIGN KEY (`typeID`) REFERENCES `clearance_types`(`typeID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `residents` (`fullName`, `birthDate`, `civilStatus`, `address`, `contactNumber`) VALUES
('Danilo Dela Cruz', '1988-04-12', 'Married', 'Purok 3, Barangay Luz', '09171112233'),
('Marites Ramos', '1995-09-24', 'Single', 'Purok 1, Barangay Luz', '09182223344'),
('Ronaldo Gutierrez', '1976-11-05', 'Married', 'Purok 5, Barangay Luz', '09223334455');

INSERT INTO `clearance_types` (`typeName`, `fee`, `requirements`, `validityMonths`) VALUES
('Barangay Clearance for Employment', 50.0, 'Valid ID, Cedula', 6),
('Certificate of Residency', 30.0, 'Voters ID or Proof of Billing', 6),
('Certificate of Indigency', 0.0, 'Barangay Tanod Endorsement', 3);

INSERT INTO `clearances` (`residentID`, `typeID`, `issueDate`, `purpose`, `amountPaid`, `status`) VALUES
(1, 1, '2026-11-01', 'Job Application at BPO', 50.0, 'Released'),
(2, 2, '2026-11-02', 'Bank Account Opening', 30.0, 'Released'),
(3, 3, '2026-11-03', 'Scholarship Financial Assistance', 0.0, 'Released');

SET FOREIGN_KEY_CHECKS=1;
