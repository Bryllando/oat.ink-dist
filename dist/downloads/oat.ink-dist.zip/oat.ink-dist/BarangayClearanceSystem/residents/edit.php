<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `residents` WHERE `residentID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = is_string($_POST['fullName'] ?? null) ? trim($_POST['fullName']) : '';
    $birthDate = is_string($_POST['birthDate'] ?? null) ? trim($_POST['birthDate']) : '';
    $civilStatus = is_string($_POST['civilStatus'] ?? null) ? trim($_POST['civilStatus']) : '';
    $address = is_string($_POST['address'] ?? null) ? trim($_POST['address']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($fullName === '' ||
        $birthDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $birthDate) ||
        date('Y-m-d', strtotime($birthDate) ?: 0) !== $birthDate ||
        $civilStatus === '' ||
        $address === '' ||
        $contactNumber === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `residents` SET `fullName` = '" . $conn->real_escape_string($fullName) . "', `birthDate` = '" . $conn->real_escape_string($birthDate) . "', `civilStatus` = '" . $conn->real_escape_string($civilStatus) . "', `address` = '" . $conn->real_escape_string($address) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE `residentID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Resident - Barangay Clearance & Certification System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Resident</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="fullName" class="weight-semibold">Full Name</label>
                <input type="text" id="fullName" name="fullName" class=""  required value="<?= htmlspecialchars($record['fullName'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="birthDate" class="weight-semibold">Birth Date</label>
                <input type="date" id="birthDate" name="birthDate" class=""  required value="<?= htmlspecialchars($record['birthDate'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="civilStatus" class="weight-semibold">Civil Status</label>
                <input type="text" id="civilStatus" name="civilStatus" class=""  required value="<?= htmlspecialchars($record['civilStatus'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="address" class="weight-semibold">Purok / Address</label>
                <input type="text" id="address" name="address" class=""  required value="<?= htmlspecialchars($record['address'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactNumber" class="weight-semibold">Contact Number</label>
                <input type="text" id="contactNumber" name="contactNumber" class=""  required value="<?= htmlspecialchars($record['contactNumber'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Resident</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
