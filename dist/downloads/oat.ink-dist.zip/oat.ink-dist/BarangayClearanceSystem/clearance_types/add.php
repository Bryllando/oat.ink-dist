<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $typeName = is_string($_POST['typeName'] ?? null) ? trim($_POST['typeName']) : '';
    $fee = is_string($_POST['fee'] ?? null) ? trim($_POST['fee']) : '';
    $requirements = is_string($_POST['requirements'] ?? null) ? trim($_POST['requirements']) : '';
    $validityMonths = is_string($_POST['validityMonths'] ?? null) ? trim($_POST['validityMonths']) : '';

    if ($typeName === '' ||
        $fee === '' ||
        !is_numeric($fee) ||
        !is_finite((float)$fee) ||
        (float)$fee < 0 ||
        $requirements === '' ||
        $validityMonths === '' ||
        !is_numeric($validityMonths) ||
        !is_finite((float)$validityMonths) ||
        (float)$validityMonths < 0 ||
        filter_var($validityMonths, FILTER_VALIDATE_INT) === false) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `clearance_types` (`typeName`, `fee`, `requirements`, `validityMonths`) VALUES ('" . $conn->real_escape_string($typeName) . "', '" . $conn->real_escape_string($fee) . "', '" . $conn->real_escape_string($requirements) . "', '" . $conn->real_escape_string($validityMonths) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Clearance Type - Barangay Clearance & Certification System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Add New Clearance Type</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="typeName" class="weight-semibold">Clearance Name</label>
                <input type="text" id="typeName" name="typeName" class=""  required value="<?= htmlspecialchars($typeName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="fee" class="weight-semibold">Standard Fee</label>
                <input type="number" id="fee" name="fee" min="0" class="" step="0.01" required value="<?= htmlspecialchars($fee ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="requirements" class="weight-semibold">Requirements</label>
                <input type="text" id="requirements" name="requirements" class=""  required value="<?= htmlspecialchars($requirements ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="validityMonths" class="weight-semibold">Validity (Months)</label>
                <input type="number" id="validityMonths" name="validityMonths" min="0" class="" step="1" required value="<?= htmlspecialchars($validityMonths ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Save Clearance Type</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
