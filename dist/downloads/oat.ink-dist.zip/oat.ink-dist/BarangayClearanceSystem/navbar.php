<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Barangay Clearance & Certification System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'residents') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>residents/index.php">Residents</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'clearance_types') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>clearance_types/index.php">Clearance Types</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'clearances') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>clearances/index.php">Clearance Issuances</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
