<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
session_start();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

function escape_value($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    (!is_string($_POST['csrf_token'] ?? null) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']))) {
    http_response_code(403);
    $pageTitle = 'Form expired';
    require __DIR__ . '/includes/header.php';
    echo '<div class="notice notice-danger" role="alert">Your form token is missing or expired. Reload the form and try again.</div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'complete_crud_practice_db';

try {
    if (!preg_match('/^[A-Za-z0-9_]{1,64}$/', $DB_NAME)) throw new RuntimeException('Use letters, numbers and underscores for the database name.');
    $conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS);
    mysqli_set_charset($conn, 'utf8mb4');
    mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS `$DB_NAME` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    mysqli_select_db($conn, $DB_NAME);
    $tables = mysqli_query($conn, 'SHOW TABLES');
    // Import only into an empty database, so opening the app never resets existing data.
    if (mysqli_num_rows($tables) === 0) {
        $schema = file_get_contents(__DIR__ . '/database.sql');
        if ($schema === false) throw new RuntimeException('Cannot read database.sql.');
        mysqli_multi_query($conn, $schema);
        do {
            if ($result = mysqli_store_result($conn)) mysqli_free_result($result);
        } while (mysqli_more_results($conn) && mysqli_next_result($conn));
    }
    mysqli_query($conn, 'SELECT id, name, email, phone, status, notes, created_at, updated_at FROM records LIMIT 0');
} catch (Throwable $error) {
    error_log($error->getMessage());
    http_response_code(503);
    $pageTitle = 'Database setup';
    require __DIR__ . '/includes/header.php';
    echo '<section class="form-panel"><h2>Check your database setup</h2><p>Start MySQL in XAMPP and check the credentials in database.php. Use an empty database for a new practice project.</p><p>If this database already has other tables or a different records table, choose a new database name. Existing data has been kept.</p><p>Read readme.md for the manual setup steps. Technical details are in the PHP error log.</p><a class="button outline" href="index.php">Try again</a></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

function find_record($conn) {
    $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 4294967295]]);
    if ($id !== false && $id !== null) {
        $statement = mysqli_prepare($conn, 'SELECT * FROM records WHERE id = ?');
        mysqli_stmt_bind_param($statement, 'i', $id);
        mysqli_stmt_execute($statement);
        $record = mysqli_fetch_assoc(mysqli_stmt_get_result($statement));
        if ($record) return $record;
    }
    http_response_code(404);
    $pageTitle = 'Record not found';
    require __DIR__ . '/includes/header.php';
    echo '<section class="form-panel"><p>This record does not exist or has already been deleted.</p><a class="button outline" href="index.php">Back to records</a></section>';
    require __DIR__ . '/includes/footer.php';
    exit;
}

function validate_record($input) {
    $values = [];
    $errors = [];
    foreach (['name', 'email', 'phone', 'status', 'notes'] as $field) {
        $values[$field] = is_string($input[$field] ?? null) ? trim($input[$field]) : '';
    }
    if (!preg_match('/^.{1,100}$/us', $values['name'])) $errors['name'] = 'Enter a name of 1 to 100 characters.';
    if (strlen($values['email']) > 120 || !filter_var($values['email'], FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Enter a valid email address, up to 120 characters.';
    if (!preg_match('/^[0-9+() .-]{0,30}$/', $values['phone'])) $errors['phone'] = 'Use up to 30 digits, spaces, +, -, dots or parentheses.';
    if (!in_array($values['status'], ['Active', 'Inactive'], true)) $errors['status'] = 'Choose Active or Inactive.';
    if (!preg_match('/^.{0,1000}$/us', $values['notes'])) $errors['notes'] = 'Keep notes within 1,000 characters.';
    return [$values, $errors];
}
