<?php
require __DIR__ . '/database.php';
$record = find_record($conn);
$errorMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $statement = mysqli_prepare($conn, 'DELETE FROM records WHERE id = ?');
        mysqli_stmt_bind_param($statement, 'i', $record['id']);
        mysqli_stmt_execute($statement);
        $_SESSION['flash'] = 'Record deleted successfully.';
        header('Location: index.php');
        exit;
    } catch (mysqli_sql_exception $error) {
        error_log($error->getMessage());
        http_response_code(503);
        $errorMessage = 'The record could not be deleted. Check the database and try again.';
    }
}
$pageTitle = 'Delete record?';
$pageDescription = 'Review the record before confirming this action.';
require __DIR__ . '/includes/header.php';
?>
<?php if ($errorMessage): ?><div class="notice notice-danger" role="alert"><?= escape_value($errorMessage) ?></div><?php endif; ?>
<section class="form-panel">
    <h2><?= escape_value($record['name']) ?></h2>
    <p><?= escape_value($record['email']) ?></p>
    <p>This permanently removes this record. It cannot be undone.</p>
    <form method="post" class="form-actions">
        <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['csrf_token']) ?>">
        <button class="danger-action" type="submit">Yes, delete record</button>
        <a class="button outline" href="view.php?id=<?= (int)$record['id'] ?>">Keep record</a>
    </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
