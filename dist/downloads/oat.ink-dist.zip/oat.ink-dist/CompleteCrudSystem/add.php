<?php
require __DIR__ . '/database.php';
$pageTitle = 'Add record';
$pageDescription = 'Create a new contact record.';
$values = ['name' => '', 'email' => '', 'phone' => '', 'status' => 'Active', 'notes' => ''];
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$values, $errors] = validate_record($_POST);
    if (!$errors) {
        try {
            $statement = mysqli_prepare($conn, 'INSERT INTO records (name, email, phone, status, notes) VALUES (?, ?, ?, ?, ?)');
            mysqli_stmt_bind_param($statement, 'sssss', $values['name'], $values['email'], $values['phone'], $values['status'], $values['notes']);
            mysqli_stmt_execute($statement);
            $_SESSION['flash'] = 'Record added successfully.';
            header('Location: view.php?id=' . mysqli_insert_id($conn));
            exit;
        } catch (mysqli_sql_exception $error) {
            error_log($error->getMessage());
            $errors['_form'] = 'The record could not be saved. Your entries are kept below. Check the database and try again.';
        }
    }
    http_response_code(isset($errors['_form']) ? 503 : 422);
}
$submitLabel = 'Save record';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/form.php';
require __DIR__ . '/includes/footer.php';
