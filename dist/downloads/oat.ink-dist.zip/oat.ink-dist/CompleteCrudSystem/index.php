<?php
require __DIR__ . '/database.php';
$pageTitle = 'Records';
$pageDescription = 'Add, find and manage contact records. Start with a sample or create your own.';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$status = is_string($_GET['status'] ?? null) && in_array($_GET['status'], ['Active', 'Inactive'], true) ? $_GET['status'] : '';
// shortcut: one unpaginated list suits small exam datasets; paginate for larger collections.
$statement = mysqli_prepare($conn, "SELECT id, name, email, phone, status FROM records WHERE (name LIKE ? OR email LIKE ? OR phone LIKE ?) AND (? = '' OR status = ?) ORDER BY id DESC");
$like = '%' . $search . '%';
mysqli_stmt_bind_param($statement, 'sssss', $like, $like, $like, $status, $status);
mysqli_stmt_execute($statement);
$records = mysqli_stmt_get_result($statement);
$counts = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total, COALESCE(SUM(status = 'Active'), 0) AS active, COALESCE(SUM(status = 'Inactive'), 0) AS inactive FROM records"));
require __DIR__ . '/includes/header.php';
?>
<section class="stats-grid" aria-label="All records summary">
    <?php foreach (['total' => 'All records', 'active' => 'Active', 'inactive' => 'Inactive'] as $key => $label): ?>
    <div class="stat-card"><span class="stat-label"><?= $label ?></span><strong class="stat-value"><?= (int)$counts[$key] ?></strong></div>
    <?php endforeach; ?>
</section>
<section aria-labelledby="records-heading">
    <div class="actions-bar"><h2 id="records-heading">Record list</h2><a class="button" href="add.php">Add record</a></div>
    <form method="get" class="filter-form filter-panel">
        <div class="search-field"><label for="search">Search name, email or phone</label><input id="search" name="search" type="search" value="<?= escape_value($search) ?>" placeholder="Type a name, email or phone"></div>
        <div><label for="status">Status</label><select id="status" name="status"><option value="">All statuses</option><?php foreach (['Active', 'Inactive'] as $option): ?><option <?= $status === $option ? 'selected' : '' ?>><?= $option ?></option><?php endforeach; ?></select></div>
        <div class="filter-actions"><button type="submit">Apply filters</button><a class="button outline" href="index.php">Clear</a></div>
    </form>
    <p class="page-note"><?= mysqli_num_rows($records) ?> matching record(s). Summary cards above always show all records.</p>
    <div class="table-responsive" role="region" aria-label="Records table" tabindex="0">
        <table>
            <caption class="visually-hidden">Contact records with links to view, edit and delete</caption>
            <thead><tr><th scope="col">Name</th><th scope="col">Email</th><th scope="col">Phone</th><th scope="col">Status</th><th scope="col">Actions</th></tr></thead>
            <tbody>
            <?php while ($record = mysqli_fetch_assoc($records)): ?>
                <tr><th scope="row"><?= escape_value($record['name']) ?></th><td><?= escape_value($record['email']) ?></td><td><?= $record['phone'] === '' ? 'Not provided' : escape_value($record['phone']) ?></td><td><span class="badge <?= $record['status'] === 'Active' ? 'status-success' : '' ?>"><?= escape_value($record['status']) ?></span></td><td class="actions-cell">
                    <a class="button small outline" href="view.php?id=<?= (int)$record['id'] ?>" aria-label="View <?= escape_value($record['name']) ?>">View</a>
                    <a class="button small outline" href="edit.php?id=<?= (int)$record['id'] ?>" aria-label="Edit <?= escape_value($record['name']) ?>">Edit</a>
                    <a class="button small danger-action" href="delete.php?id=<?= (int)$record['id'] ?>" aria-label="Delete <?= escape_value($record['name']) ?>">Delete</a>
                </td></tr>
            <?php endwhile; ?>
            <?php if (mysqli_num_rows($records) === 0): ?><tr><td colspan="5" class="empty-state"><?= (int)$counts['total'] === 0 ? 'No records yet. Add your first record to get started.' : 'No records match these filters. Try another search or clear the filters.' ?></td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
