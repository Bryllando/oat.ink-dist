-- Select your database before importing this file manually.
CREATE TABLE IF NOT EXISTS records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL,
    phone VARCHAR(30) NOT NULL DEFAULT '',
    status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
    notes VARCHAR(1000) NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO records (name, email, phone, status, notes) VALUES
('Sample Member', 'member@example.test', '09123456789', 'Active', 'Edit this sample to practice updating a record.'),
('Practice Contact', 'contact@example.test', '', 'Inactive', 'Sample only. You may delete this record.');
