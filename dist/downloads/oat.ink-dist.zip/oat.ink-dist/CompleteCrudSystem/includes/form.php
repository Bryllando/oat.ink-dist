<?php if ($errors): ?>
<div class="notice notice-danger" role="alert">
    <strong>Review the form before saving.</strong>
    <ul><?php foreach ($errors as $field => $message): ?>
        <li><?php if ($field !== '_form'): ?><a href="#<?= escape_value($field) ?>"><?= escape_value($message) ?></a><?php else: ?><?= escape_value($message) ?><?php endif; ?></li>
    <?php endforeach; ?></ul>
</div>
<?php endif; ?>
<form method="post" class="entry-form form-panel">
    <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['csrf_token']) ?>">
    <p class="page-note">Name, email and status are required. Phone and notes are optional.</p>
    <div class="field-grid">
        <?php foreach (['name' => ['Name', 'text', 100], 'email' => ['Email', 'email', 120], 'phone' => ['Phone (optional)', 'tel', 30]] as $field => [$label, $type, $limit]): ?>
        <div>
            <label for="<?= $field ?>"><?= $label ?></label>
            <input id="<?= $field ?>" name="<?= $field ?>" type="<?= $type ?>" maxlength="<?= $limit ?>" autocomplete="<?= $field === 'phone' ? 'tel' : $field ?>" value="<?= escape_value($values[$field]) ?>" <?= $field !== 'phone' ? 'required' : '' ?> <?= isset($errors[$field]) ? 'aria-invalid="true" aria-describedby="'.$field.'-error"' : '' ?>>
            <?php if (isset($errors[$field])): ?><p id="<?= $field ?>-error" class="field-error"><?= escape_value($errors[$field]) ?></p><?php endif; ?>
        </div>
        <?php endforeach; ?>
        <div>
            <label for="status">Status</label>
            <select id="status" name="status" required <?= isset($errors['status']) ? 'aria-invalid="true" aria-describedby="status-error"' : '' ?>>
                <option value="">Choose a status</option>
                <?php foreach (['Active', 'Inactive'] as $status): ?><option <?= $values['status'] === $status ? 'selected' : '' ?>><?= $status ?></option><?php endforeach; ?>
            </select>
            <?php if (isset($errors['status'])): ?><p id="status-error" class="field-error"><?= escape_value($errors['status']) ?></p><?php endif; ?>
        </div>
        <div>
            <label for="notes">Notes (optional)</label>
            <textarea id="notes" name="notes" rows="4" maxlength="1000" aria-describedby="notes-help<?= isset($errors['notes']) ? ' notes-error' : '' ?>" <?= isset($errors['notes']) ? 'aria-invalid="true"' : '' ?>><?= escape_value($values['notes']) ?></textarea>
            <p id="notes-help" class="page-note">Up to 1,000 characters. Use this for additional details.</p>
            <?php if (isset($errors['notes'])): ?><p id="notes-error" class="field-error"><?= escape_value($errors['notes']) ?></p><?php endif; ?>
        </div>
    </div>
    <div class="form-actions">
        <button type="submit"><?= $submitLabel ?></button>
        <a class="button outline" href="<?= isset($record) ? 'view.php?id='.(int)$record['id'] : 'index.php' ?>">Cancel</a>
    </div>
</form>
