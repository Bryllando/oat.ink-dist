<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= escape_value($pageTitle) ?> | CRUD Practice</title>
    <link rel="stylesheet" href="assets/css/oat.min.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/css/practice.css">
    <script src="assets/js/oat.min.js" defer></script>
    <script src="assets/js/app.js" defer></script>
</head>
<body>
<a href="#main" class="skip-link">Skip to content</a>
<nav class="app-nav" aria-label="Main navigation">
    <a class="app-brand" href="index.php">CRUD Practice</a>
    <div class="nav-links">
        <a href="index.php" <?= basename($_SERVER['SCRIPT_NAME']) === 'index.php' ? 'aria-current="page"' : '' ?>>Records</a>
        <a href="add.php" <?= basename($_SERVER['SCRIPT_NAME']) === 'add.php' ? 'aria-current="page"' : '' ?>>Add record</a>
    </div>
</nav>
<main id="main" class="container">
    <header class="page-heading">
        <p class="page-note">Practice template / Records</p>
        <h1><?= escape_value($pageTitle) ?></h1>
        <?php if (!empty($pageDescription)): ?><p class="page-note"><?= escape_value($pageDescription) ?></p><?php endif; ?>
    </header>
    <?php if (!empty($_SESSION['flash'])): ?>
        <div class="notice notice-success" role="status"><?= escape_value($_SESSION['flash']) ?></div>
    <?php unset($_SESSION['flash']); endif; ?>
