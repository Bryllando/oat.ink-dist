</main>
<footer class="app-footer">Complete CRUD Practice · Offline Oat UI · Setup and design guide: readme.md</footer>
</body>
</html>
