<?php
require __DIR__ . '/database.php';
$record = find_record($conn);
$pageTitle = 'Record details';
$pageDescription = 'View the saved details before editing or deleting.';
require __DIR__ . '/includes/header.php';
?>
<section class="form-panel">
    <div class="card-header">
        <h2><?= escape_value($record['name']) ?></h2>
        <span class="badge <?= $record['status'] === 'Active' ? 'status-success' : '' ?>"><?= escape_value($record['status']) ?></span>
    </div>
    <dl class="record-details">
        <?php foreach (['id' => 'Record ID', 'email' => 'Email', 'phone' => 'Phone', 'notes' => 'Notes', 'created_at' => 'Created', 'updated_at' => 'Last updated'] as $field => $label): ?>
        <div><dt><?= $label ?></dt><dd><?= $record[$field] === '' ? 'Not provided' : nl2br(escape_value($record[$field])) ?></dd></div>
        <?php endforeach; ?>
    </dl>
    <div class="form-actions">
        <a class="button" href="edit.php?id=<?= (int)$record['id'] ?>">Edit record</a>
        <a class="button outline" href="index.php">Back to records</a>
        <a class="button danger-action" href="delete.php?id=<?= (int)$record['id'] ?>">Delete record</a>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
