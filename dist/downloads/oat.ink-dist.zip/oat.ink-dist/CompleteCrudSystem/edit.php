<?php
require __DIR__ . '/database.php';
$record = find_record($conn);
$pageTitle = 'Edit record';
$pageDescription = 'Update the details for ' . $record['name'] . '.';
$values = $record;
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$values, $errors] = validate_record($_POST);
    if (!$errors) {
        try {
            $statement = mysqli_prepare($conn, 'UPDATE records SET name = ?, email = ?, phone = ?, status = ?, notes = ? WHERE id = ?');
            mysqli_stmt_bind_param($statement, 'sssssi', $values['name'], $values['email'], $values['phone'], $values['status'], $values['notes'], $record['id']);
            mysqli_stmt_execute($statement);
            $_SESSION['flash'] = 'Record updated successfully.';
            header('Location: view.php?id=' . $record['id']);
            exit;
        } catch (mysqli_sql_exception $error) {
            error_log($error->getMessage());
            $errors['_form'] = 'Changes could not be saved. Your entries are kept below. Check the database and try again.';
        }
    }
    http_response_code(isset($errors['_form']) ? 503 : 422);
}
$submitLabel = 'Save changes';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/form.php';
require __DIR__ . '/includes/footer.php';
