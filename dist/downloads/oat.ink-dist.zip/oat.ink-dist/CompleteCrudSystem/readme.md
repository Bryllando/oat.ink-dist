# Complete CRUD Practice — setup and offline Oat UI template

Choose **44** under **PRACTICE TEMPLATES** in `deploy_exam.bat`.

**Want ready-to-copy code? Jump to [section 4: Oat page, form, table, modal and PHP recipes](#4-reuse-the-complete-oat-design).** For option 43 use [the Basic CRUD guide](../BasicCrudSystem/readme.md).

`README.md` displays the code; PHP runs only after you save a code block as a `.php` file and open it through `http://localhost/...`. Ayaw i-open as `file:///...`.

This is a working single-table contact manager written in procedural PHP and MySQLi. It includes Create, Read, Update and Delete, detail pages, search, status filters, summary counts, validation, retained form entries, success messages and delete confirmation. Its complete design uses local **Oat (oat.ink)** and the workspace's shared styles. Running it needs no internet or package installation.

## 1. Run with XAMPP

1. Start **Apache** and **MySQL** in the XAMPP Control Panel.
2. Double-click `deploy_exam.bat` in the main `Skilltest` folder.
3. Choose **44**, then enter a new folder name, such as `CrudPractice`.
4. Open `http://localhost/CrudPractice/`.
5. The first visit creates `complete_crud_practice_db`, its table and two marked sample records. Later visits keep your records.

Or run this from `Skilltest`:

```powershell
.\deploy_exam.bat -SystemName CompleteCrudSystem -FolderName CrudPractice
```

To copy manually, copy the **whole** `CompleteCrudSystem` folder into `C:\xampp\htdocs`, optionally rename it to `CrudPractice`, then open that URL. Keep `assets`, `includes`, SQL and PHP files together. The source folder name is not hardcoded into page links.

**Renaming the folder does not rename the database.** Before opening an independent copy, give it a unique `$DB_NAME` in `database.php`. Otherwise both copies share data. This SQL file has no database name to change.

### Connection and manual setup

Edit these settings in `database.php` to match your XAMPP:

```php
$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'complete_crud_practice_db';
```

MySQLi uses its configured port, normally 3306. For a custom port, pass it as the fifth argument to `mysqli_connect`. Database names accept 1–64 letters, numbers or underscores.

For manual setup, open local phpMyAdmin, create and select a **new empty** database matching `$DB_NAME`, choose `utf8mb4_unicode_ci`, then import `database.sql` once. Open the project URL afterward.

The SQL creates `records` and inserts sample rows. Reimporting adds another set of samples; it is not a reset script. The automatic importer runs only for an empty database. An incompatible existing schema shows setup guidance instead of replacing tables. Use another database name for a fresh exercise.

## 2. Understand the structure

```text
C:/xampp/htdocs/CrudPractice/
|-- index.php                    List, counts, search and status filter
|-- add.php                      Validate and insert
|-- view.php                     Show one saved record
|-- edit.php                     Load, validate and update
|-- delete.php                   Confirmation; only POST deletes
|-- database.php                 Connection, setup, CSRF and helpers
|-- database.sql                 Schema and sample rows
|-- includes/
|   |-- header.php               Head, navigation, title and messages
|   |-- form.php                 Shared add/edit fields and errors
|   `-- footer.php               Closing layout
|-- assets/
|   |-- css/
|   |   |-- oat.min.css          Downloaded Oat library
|   |   |-- app.css              Shared theme and components
|   |   `-- practice.css         Local refinements
|   `-- js/
|       |-- oat.min.js           Local Oat script
|       `-- app.js               Shared navigation/table enhancements
`-- readme.md                    This guide
```

| Example | Meaning | Where to change it |
| --- | --- | --- |
| `CrudPractice/` | Project folder under `htdocs` | Name chosen in deployer |
| `/CrudPractice/add.php` | Page address | Filename and its links |
| `complete_crud_practice_db` | MySQL database | `$DB_NAME` in `database.php` |
| `records` | Table storing the entries | SQL schema and queries |
| `name`, `email`, `phone`, `status`, `notes` | Stored columns | Schema, queries, validation and form |
| Record / Records | Singular / plural display labels | Headings, buttons and messages |

**Singular** means one: “Add record”. **Plural** means the collection: “Records”. Changing a label does not rename a table or file. A URL folder and a database table are separate things. This example keeps the PHP pages together so you can follow each operation easily.

## 3. Follow the CRUD flow

```text
index.php (list, search, filter)
|-- Add -> add.php -> Save -> view.php?id=...
`-- View -> view.php?id=...
    |-- Edit -> edit.php?id=... -> Save changes -> view.php?id=...
    `-- Delete -> delete.php?id=...
        |-- Keep record -> view.php?id=...
        `-- Confirm [POST] -> index.php
```

| Action | SQL | Result |
| --- | --- | --- |
| Create | Prepared INSERT in `add.php` | Redirect to details with a success message |
| Read | Prepared SELECT in `index.php` and `find_record()` | Display escaped values; missing IDs return 404 |
| Update | Prepared UPDATE with ID in `edit.php` | Save this record, then redirect to details |
| Delete | Prepared DELETE with ID in `delete.php` | GET opens confirmation; valid POST deletes |

Search checks name, email and phone; status filtering combines with it. `%` and `_` use MySQL LIKE wildcard behaviour. Results are newest first. Summary cards always count **all** records, even while filters are active.

Name, email and status are required. Phone and notes are optional. The server checks lengths, email syntax, allowed phone characters and allowed statuses. Invalid submissions retain your values, link errors to the fields, and show inline feedback. Email addresses need not be unique in this schema.

Writes require session CSRF tokens. Prepared queries protect user values; displayed text is escaped. Successful writes redirect, so a normal refresh does not repeat the save.

## 4. Reuse the complete Oat design

The working templates are `includes/header.php`, `includes/form.php`, `includes/footer.php` and the stylesheets. Load Oat first, shared `app.css` second, and local `practice.css` last. Keep all four shared CSS/JS assets together. Edit source markup and local styles rather than the minified library.

### A complete new page

Save this as `help.php` next to `index.php`, then open `/CrudPractice/help.php`:

```php
<?php
require __DIR__ . '/database.php';
$pageTitle = 'Practice help';
$pageDescription = 'A short guide for the person using this system.';
require __DIR__ . '/includes/header.php';
?>
<section class="form-panel" aria-labelledby="help-heading">
    <h2 id="help-heading">Getting started</h2>
    <p>Open Records, then choose Add record to create an entry.</p>
    <div class="form-actions">
        <a class="button" href="add.php">Add record</a>
        <a class="button outline" href="index.php">Back to records</a>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
```

This reuses the complete document head, assets, navigation, title, feedback and footer. Add a Help navigation link in `header.php` if you need it on every page.

### Copy-and-paste map (option 44)

Igo ra nimo i-copy ang **entire code block**, i-save sa exact filename, then open its local URL. Keep the code fences (the lines with backticks) out of the saved file. These examples use an already-deployed **44** folder; they do not replace your existing files.

| Want to copy | Save as, inside your deployed folder | Open |
| --- | --- | --- |
| Complete designed page: cards, form, search, table, information/delete modals | `ui-kit.php` + `assets/css/ui-kit.css` | `/CrudPractice/ui-kit.php` |
| Form inside a modal, connected to the existing save handler | `modal-add.php` | `/CrudPractice/modal-add.php` |
| Add page including its PHP INSERT handler | `quick-add.php` | `/CrudPractice/quick-add.php` |
| Edit page including its PHP UPDATE handler | `quick-edit.php` | Use `/CrudPractice/quick-edit.php?id=1` for an existing ID |
| Delete page including its PHP DELETE handler | `quick-delete.php` | Use `/CrudPractice/quick-delete.php?id=1` for an existing ID |

Use your actual deployment folder in place of `CrudPractice`. For **43**, use [its matching copy-and-paste example](../BasicCrudSystem/readme.md); it has `address` instead of `status` and `notes`. If this guide is in a standalone deployment, open the Basic guide in your original Skilltest folder.

### A. Complete designed page: save as `ui-kit.php`

This is an actual working page. Its form posts to your existing `add.php`; View/Edit links open your existing pages; each delete modal posts to your existing `delete.php`. It reads real data through `database.php`. Create the CSS file in B too. The title, form labels, cards, buttons, table and modals are already designed.

```php
<?php
require __DIR__ . '/database.php';
$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$like = '%' . $search . '%';
$statement = mysqli_prepare($conn, 'SELECT * FROM records WHERE name LIKE ? OR email LIKE ? OR phone LIKE ? ORDER BY id DESC');
mysqli_stmt_bind_param($statement, 'sss', $like, $like, $like);
mysqli_stmt_execute($statement);
// shortcut: this practice list is unpaginated; add pagination for large datasets.
$records = mysqli_fetch_all(mysqli_stmt_get_result($statement), MYSQLI_ASSOC);
$counts = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total, COALESCE(SUM(status = 'Active'), 0) AS active FROM records"));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oat component practice</title>
    <link rel="stylesheet" href="assets/css/oat.min.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/css/ui-kit.css">
    <script src="assets/js/oat.min.js" defer></script>
    <script src="assets/js/app.js" defer></script>
</head>
<body>
<nav class="app-nav" aria-label="Main navigation">
    <a class="app-brand" href="index.php">CRUD Practice</a>
    <div class="nav-links">
        <a href="index.php">Records</a>
        <a href="ui-kit.php" aria-current="page">UI examples</a>
    </div>
</nav>
<main class="container">
    <header class="page-heading">
        <h1>Oat component practice</h1>
        <p class="page-note">Forms, cards, alerts, tables and modals connected to your records.</p>
    </header>

    <section class="stats-grid" aria-label="Record summary">
        <div class="stat-card"><span class="stat-label">All records</span><strong class="stat-value"><?= (int)$counts['total'] ?></strong></div>
        <div class="stat-card"><span class="stat-label">Active</span><strong class="stat-value"><?= (int)$counts['active'] ?></strong></div>
    </section>

    <section class="card-surface" aria-labelledby="components-heading">
        <h2 id="components-heading">Buttons, badges and an information modal</h2>
        <div class="form-actions">
            <a class="button" href="add.php">Add record</a>
            <a class="button outline" href="index.php">Back to records</a>
            <button type="button" commandfor="help-modal" command="show-modal">Open information modal</button>
            <span class="badge status-success">Active</span>
            <span class="badge">Inactive</span>
        </div>
        <div class="notice notice-warning" role="note">This example uses your actual database. Saving and confirming deletion change its records.</div>
    </section>

    <dialog id="help-modal" aria-labelledby="help-title" aria-describedby="help-description">
        <header><h2 id="help-title">How this page connects</h2></header>
        <div><p id="help-description">The form sends its fields to add.php. The table reads MySQL through database.php. Each delete modal posts to delete.php with its record ID and form token.</p></div>
        <footer><button type="button" class="outline" commandfor="help-modal" command="close" autofocus>Close</button></footer>
    </dialog>

    <section class="ui-section" aria-labelledby="form-heading">
        <h2 id="form-heading">A complete add form</h2>
        <form method="post" action="add.php" class="entry-form form-panel">
            <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['csrf_token']) ?>">
            <p class="page-note">Name, email and status are required. Phone and notes are optional.</p>
            <div class="field-grid">
                <div><label for="kit-name">Name</label><input id="kit-name" name="name" type="text" maxlength="100" autocomplete="name" required></div>
                <div><label for="kit-email">Email</label><input id="kit-email" name="email" type="email" maxlength="120" autocomplete="email" required></div>
                <div><label for="kit-phone">Phone (optional)</label><input id="kit-phone" name="phone" type="tel" maxlength="30" autocomplete="tel"></div>
                <div><label for="kit-status">Status</label><select id="kit-status" name="status" required><option>Active</option><option>Inactive</option></select></div>
                <div><label for="kit-notes">Notes (optional)</label><textarea id="kit-notes" name="notes" rows="4" maxlength="1000" aria-describedby="kit-notes-help"></textarea><p id="kit-notes-help" class="page-note">Up to 1,000 characters.</p></div>
            </div>
            <div class="form-actions"><button type="submit">Save record</button><a class="button outline" href="index.php">Cancel</a></div>
        </form>
    </section>

    <section class="ui-section" aria-labelledby="list-heading">
        <h2 id="list-heading">Search, table and delete modals</h2>
        <form method="get" action="ui-kit.php" class="filter-form filter-panel">
            <div class="ui-search"><label for="kit-search">Search name, email or phone</label><input id="kit-search" name="search" type="search" value="<?= escape_value($search) ?>"></div>
            <div class="filter-actions"><button type="submit">Search</button><a class="button outline" href="ui-kit.php">Clear</a></div>
        </form>
        <p class="page-note"><?= count($records) ?> matching record(s).</p>
        <div class="table-responsive" role="region" aria-label="Record results" tabindex="0">
            <table>
                <caption>Saved records</caption>
                <thead><tr><th scope="col">Name</th><th scope="col">Email</th><th scope="col">Status</th><th scope="col">Actions</th></tr></thead>
                <tbody>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <th scope="row"><?= escape_value($record['name']) ?></th>
                        <td><?= escape_value($record['email']) ?></td>
                        <td><span class="badge <?= $record['status'] === 'Active' ? 'status-success' : '' ?>"><?= escape_value($record['status']) ?></span></td>
                        <td class="actions-cell">
                            <a class="button small outline" href="view.php?id=<?= (int)$record['id'] ?>" aria-label="View <?= escape_value($record['name']) ?>">View</a>
                            <a class="button small outline" href="edit.php?id=<?= (int)$record['id'] ?>" aria-label="Edit <?= escape_value($record['name']) ?>">Edit</a>
                            <button type="button" class="small danger-action" commandfor="delete-<?= (int)$record['id'] ?>" command="show-modal" aria-label="Delete <?= escape_value($record['name']) ?>">Delete</button>
                            <noscript><a href="delete.php?id=<?= (int)$record['id'] ?>">Delete confirmation page</a></noscript>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$records): ?><tr><td colspan="4" class="empty-state">No matching records. Clear the search or add a record.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <?php foreach ($records as $record): ?>
    <dialog id="delete-<?= (int)$record['id'] ?>" aria-labelledby="delete-title-<?= (int)$record['id'] ?>">
        <form method="post" action="delete.php?id=<?= (int)$record['id'] ?>">
            <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['csrf_token']) ?>">
            <header><h2 id="delete-title-<?= (int)$record['id'] ?>">Delete record?</h2></header>
            <div><p><?= escape_value($record['name']) ?></p><p>This permanently removes the record. You cannot undo it.</p></div>
            <footer>
                <button type="button" class="outline" commandfor="delete-<?= (int)$record['id'] ?>" command="close" autofocus>Keep record</button>
                <button type="submit" class="danger-action">Yes, delete record</button>
            </footer>
        </form>
    </dialog>
    <?php endforeach; ?>
</main>
<footer class="app-footer">Offline Oat UI practice</footer>
</body>
</html>
```

### B. Page refinements: save as `assets/css/ui-kit.css`

```css
/* Load after oat.min.css and app.css. */
.ui-section { margin-block: 2rem; }
.ui-search { flex: 1; min-width: min(100%, 240px); }
.filter-form label { display: block; margin-bottom: 5px; }
.table-responsive table { width: 100%; }
.table-responsive tbody th { white-space: normal; background: transparent; }
.table-responsive td { overflow-wrap: anywhere; }
dialog footer { flex-wrap: wrap; }
dialog h2 { font-size: 20px; }
dialog .field-grid { gap: 16px; }
dialog .field-grid label { display: block; margin-bottom: 5px; }
@media (max-width: 768px) {
    dialog footer button { flex: 1 1 auto; }
}
```

The page links to this file **after** Oat and `app.css`, so these rules can refine the design. The CSS file does not need PHP tags. Cards, inputs, buttons, alerts and modal styling are already provided by your local Oat/shared CSS; this file adds spacing and small-screen refinements.

### C. A form inside an Oat modal: save as `modal-add.php`

The regular add-page link remains available. The Save button posts all five field names and the CSRF token to `add.php`. A valid save redirects to record details. If validation fails, `add.php` shows the normal form with your entries and errors; it does not reopen this modal. This keeps validation in the existing handler.

```php
<?php
require __DIR__ . '/database.php';
$pageTitle = 'Add with a modal';
$pageDescription = 'The modal posts to the existing add.php handler.';
require __DIR__ . '/includes/header.php';
?>
<p><button type="button" commandfor="add-modal" command="show-modal">Add record in a modal</button></p>
<p><a href="add.php">Open the regular add page</a></p>
<dialog id="add-modal" aria-labelledby="add-modal-title">
    <form method="post" action="add.php" class="entry-form">
        <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['csrf_token']) ?>">
        <header><h2 id="add-modal-title">Add record</h2><p>Name, email and status are required.</p></header>
        <div class="field-grid">
            <div><label for="modal-name">Name</label><input id="modal-name" name="name" maxlength="100" autocomplete="name" required autofocus></div>
            <div><label for="modal-email">Email</label><input id="modal-email" name="email" type="email" maxlength="120" autocomplete="email" required></div>
            <div><label for="modal-phone">Phone (optional)</label><input id="modal-phone" name="phone" type="tel" maxlength="30" autocomplete="tel"></div>
            <div><label for="modal-status">Status</label><select id="modal-status" name="status" required><option>Active</option><option>Inactive</option></select></div>
            <div><label for="modal-notes">Notes (optional)</label><textarea id="modal-notes" name="notes" maxlength="1000" rows="3"></textarea></div>
        </div>
        <footer>
            <button type="button" class="outline" commandfor="add-modal" command="close">Cancel</button>
            <button type="submit">Save record</button>
        </footer>
    </form>
</dialog>
<?php require __DIR__ . '/includes/footer.php'; ?>
```

Oat uses native `<dialog>` with `commandfor` and `command="show-modal"` / `command="close"`. The bundled Oat script includes a fallback for browsers without native command support. The browser manages modal keyboard focus and Escape. Give each modal a unique ID, match its buttons to that ID, and label it with `aria-labelledby`. See the [official Oat dialog reference](https://oat.ink/components/dialog/).

**A database form uses `method="post"`.** `method="dialog"` only closes a dialog; it does not send an INSERT to PHP. Cancel/Close/Open buttons use `type="button"`; only Save/Delete uses `type="submit"`. Do not put a modal's form inside another form. Keep delete confirmation outside the table as in A. Escape or Cancel does not save or delete anything.

### D. How the form connects to MySQL

```text
Browser: ui-kit.php or modal-add.php
  -> <form method="post" action="add.php">
  -> name / email / phone / status / notes / csrf_token
  -> add.php requires database.php
  -> database.php starts the session, checks the token and opens $conn
  -> validate_record($_POST) checks the submitted values
  -> mysqli_prepare + bind_param + execute runs the INSERT
  -> redirect to view.php?id=NEW_ID
  -> view.php SELECTs and displays the saved record
```

| Code | What must match |
| --- | --- |
| `require __DIR__ . '/database.php';` | This file must be alongside the example PHP page. It provides `$conn`, `escape_value()`, `validate_record()` and the session token. |
| `<input name="email">` | PHP reads `$_POST['email']`; the INSERT names the `email` column. `id="..."` connects its label, not the database. |
| `action="add.php"` | Destination PHP handler; it is relative to the page URL, not to an included file. |
| `method="post"` | Sends values in the POST body. GET is for reading/searching and opening confirmation pages. |
| `csrf_token` | Comes from this session and must be sent with every save/delete. The server rejects a missing/wrong token with 403. |
| `VALUES (?, ?, ?, ?, ?)` | Five placeholders require five matching values in the same order. `sssss` means five text parameters. |
| `header('Location: ...'); exit;` | Runs before HTML and redirects after a successful write. |

The existing connection in `database.php` uses procedural MySQLi: `mysqli_connect($DB_HOST, $DB_USER, $DB_PASS)`, then selects `$DB_NAME` and sets `utf8mb4`. Change credentials there once; do not create a second connection inside every form.

### E. Full PHP save example: save as `quick-add.php`

This is the actual add flow in a separate practice filename. The shared `includes/form.php` supplies the complete designed fields, retained values and inline errors. It has no `action`, so it posts back to `quick-add.php`. Keep `database.php`, `includes/form.php`, `header.php`, `footer.php` and `assets` from option 44. For a form on a different page that should use this handler, set `action="quick-add.php"`.

```php
<?php
require __DIR__ . '/database.php';
$pageTitle = 'Add record';
$pageDescription = 'Create a new contact record.';
$values = ['name' => '', 'email' => '', 'phone' => '', 'status' => 'Active', 'notes' => ''];
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$values, $errors] = validate_record($_POST);
    if (!$errors) {
        try {
            $statement = mysqli_prepare($conn, 'INSERT INTO records (name, email, phone, status, notes) VALUES (?, ?, ?, ?, ?)');
            mysqli_stmt_bind_param($statement, 'sssss', $values['name'], $values['email'], $values['phone'], $values['status'], $values['notes']);
            mysqli_stmt_execute($statement);
            $_SESSION['flash'] = 'Record added successfully.';
            header('Location: view.php?id=' . mysqli_insert_id($conn));
            exit;
        } catch (mysqli_sql_exception $error) {
            error_log($error->getMessage());
            $errors['_form'] = 'The record could not be saved. Your entries are kept below. Check the database and try again.';
        }
    }
    http_response_code(isset($errors['_form']) ? 503 : 422);
}
$submitLabel = 'Save record';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/form.php';
require __DIR__ . '/includes/footer.php';
```

### F. Full update example: save as `quick-edit.php`

Use an existing record ID in the URL. `find_record()` validates the ID and loads its row, the form pre-fills values, and a valid POST updates that ID. Missing records return 404. The final `i` in `sssssi` binds the integer ID.

```php
<?php
require __DIR__ . '/database.php';
$record = find_record($conn);
$pageTitle = 'Edit record';
$pageDescription = 'Update the details for ' . $record['name'] . '.';
$values = $record;
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    [$values, $errors] = validate_record($_POST);
    if (!$errors) {
        try {
            $statement = mysqli_prepare($conn, 'UPDATE records SET name = ?, email = ?, phone = ?, status = ?, notes = ? WHERE id = ?');
            mysqli_stmt_bind_param($statement, 'sssssi', $values['name'], $values['email'], $values['phone'], $values['status'], $values['notes'], $record['id']);
            mysqli_stmt_execute($statement);
            $_SESSION['flash'] = 'Record updated successfully.';
            header('Location: view.php?id=' . $record['id']);
            exit;
        } catch (mysqli_sql_exception $error) {
            error_log($error->getMessage());
            $errors['_form'] = 'Changes could not be saved. Your entries are kept below. Check the database and try again.';
        }
    }
    http_response_code(isset($errors['_form']) ? 503 : 422);
}
$submitLabel = 'Save changes';
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/form.php';
require __DIR__ . '/includes/footer.php';
```

### G. Full delete example: save as `quick-delete.php`

Open it with an existing ID to see confirmation. A POST with a valid token deletes; opening its URL does not delete. To point a modal at this practice handler, use `action="quick-delete.php?id=..."` with the real integer ID, as in A.

```php
<?php
require __DIR__ . '/database.php';
$record = find_record($conn);
$errorMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $statement = mysqli_prepare($conn, 'DELETE FROM records WHERE id = ?');
        mysqli_stmt_bind_param($statement, 'i', $record['id']);
        mysqli_stmt_execute($statement);
        $_SESSION['flash'] = 'Record deleted successfully.';
        header('Location: index.php');
        exit;
    } catch (mysqli_sql_exception $error) {
        error_log($error->getMessage());
        http_response_code(503);
        $errorMessage = 'The record could not be deleted. Check the database and try again.';
    }
}
$pageTitle = 'Delete record?';
$pageDescription = 'Review the record before confirming this action.';
require __DIR__ . '/includes/header.php';
?>
<?php if ($errorMessage): ?><div class="notice notice-danger" role="alert"><?= escape_value($errorMessage) ?></div><?php endif; ?>
<section class="form-panel">
    <h2><?= escape_value($record['name']) ?></h2>
    <p><?= escape_value($record['email']) ?></p>
    <p>This permanently removes this record. It cannot be undone.</p>
    <form method="post" class="form-actions">
        <input type="hidden" name="csrf_token" value="<?= escape_value($_SESSION['csrf_token']) ?>">
        <button class="danger-action" type="submit">Yes, delete record</button>
        <a class="button outline" href="view.php?id=<?= (int)$record['id'] ?>">Keep record</a>
    </form>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
```

### H. Small components to paste inside an existing page

Paste these **between** the header and footer, inside `<main>`. Oat and `app.css` must already be loaded. These use the same design as A; the alert text is a UI example and is not proof that a database save happened.

```html
<section class="card-surface">
    <h2>Member information</h2>
    <p>Add a member, then search the list to find their details.</p>
    <div class="form-actions">
        <a class="button" href="add.php">Add member</a>
        <a class="button outline" href="index.php">Back to list</a>
    </div>
</section>

<div class="notice notice-success" role="status">Example success message.</div>
<div class="notice notice-danger" role="alert">Check the required fields before saving.</div>
<div class="notice notice-warning" role="note">Review the details before deleting.</div>

<span class="badge status-success">Active</span>
<span class="badge">Inactive</span>
```

For real success messages, set `$_SESSION['flash'] = 'Record saved.';` only after the SQL succeeds, then redirect. The existing header displays the flash once. For real validation errors, use E/F and the shared form instead of showing a static success alert.

### I. Connecting a brand-new folder from scratch (optional)

For the shortest setup, deploy **44** and copy A/B or C. If your teacher asks you to build a fresh folder manually, copy these existing support files **unchanged**, then add the example pages:

```text
YourProject/
|-- database.php            Copy from CompleteCrudSystem; set a new $DB_NAME
|-- database.sql            Copy from CompleteCrudSystem
|-- index.php               Copy the original list page
|-- add.php                 Required by the example forms
|-- view.php
|-- edit.php
|-- delete.php
|-- includes/               Copy the whole folder
|-- assets/                 Copy the whole folder
|   `-- css/ui-kit.css      Paste B here
|-- ui-kit.php              Paste A here
`-- modal-add.php           Paste C here, if wanted
```

Start Apache/MySQL, place the folder in `htdocs`, and open its local URL. The first-run importer creates the schema in the new empty database. Copying only the form leaves its connection, handler and layout missing.

### Design rules

| Part | Complete template design | Where |
| --- | --- | --- |
| Page | Light grey background, white panels, maximum 1120px width | `app.css`: root variables, `.container` |
| Type | Arial, 25px main heading, 14–15px form/body text | `app.css` |
| Navigation | App name, direct links, current-page state | `header.php` |
| Primary action | Filled blue Save/Add button | `.button`, `button` |
| Secondary action | Outlined Cancel/Back button | `.button.outline` |
| Delete | Red-tinted action, separate confirmation | `.danger-action`, `delete.php` |
| Form | Two columns, full-width notes, actions below | `.field-grid`, `.form-panel` |
| Feedback | Linked error summary, inline errors, success message | `form.php`, `header.php` |
| Details | Labeled values, preserved note line breaks | `view.php`, `.record-details` |
| Small screens | One-column form/details, wrapped controls, scrolling table | CSS media queries at 768px |
| Accessibility | Labels, focus states, skip link, table headers, status text | Markup and `practice.css` |

Change `--primary`, `--background`, `--foreground` and `--border` in the local `app.css` for a different theme. Put additional page-specific CSS in `practice.css`. Keep readable contrast and visible keyboard focus. Keep status words visible so colour is not the only cue.

The PHP flow works without JavaScript. All runtime assets are local, with no image, font or CDN requests.

## 5. Adapt it to an exam

Example: rename Record/Records to **Member/Members**.

1. Deploy a new copy with its own database name before opening it.
2. Change headings, navigation, buttons and messages to Member/Members. Initially keep the working file/table names so the flow is easy to follow.
3. Match the fields to the actual exam instructions.
4. To add a column, update **all** of: `database.sql`, the setup column check and `validate_record()` in `database.php`, defaults in `add.php`, `includes/form.php`, INSERT/UPDATE columns/placeholders/bind types, and relevant list/detail displays.
5. For an existing table, deliberately migrate it with `ALTER TABLE` in phpMyAdmin or use another empty practice database. Editing `database.sql` does not migrate existing data.

For example, an optional `course VARCHAR(100) NOT NULL DEFAULT ''` field needs an input, length validation, an add default, INSERT/UPDATE parameters and a displayed detail. A form input alone is not a new database column. MySQLi bind types are `s` for text, `i` for integer and `d` for decimal numbers.

Use **42 — SystemMorpher** when you need different tables, additional columns or relationships. Use **41 — Universal Master Template** for resource + client + transaction + monitoring practice. This template teaches one complete CRUD cycle.

## 6. Final checklist

- Open list and details; follow Add, Edit, Back and Cancel.
- Save a valid entry, refresh the detail page, and check that no duplicate was added.
- Submit a missing name, invalid email and invalid status. Check rejection, error feedback and retained entries.
- Edit an entry, search its changed name, combine search with status, then Clear.
- Try an absent search and check the empty state.
- Open Delete, choose Keep record, and check that it remains.
- Confirm deletion, check that the row disappears, and verify its old URL returns 404.
- Try a made-up ID; check the friendly missing-record page.
- Use Tab through controls and check a narrow browser width.
- Disconnect the internet and reload; styling should remain available.

## Troubleshooting and limits

| Symptom | Check |
| --- | --- |
| Cannot open page | Start Apache; verify the folder in `htdocs` and its URL. |
| Database setup page | Start MySQL; check credentials/name in `database.php`; inspect the PHP error log. |
| Different existing schema | Keep it and use a new database name, or intentionally migrate it. |
| No styles after copying | Copy the entire `assets` folder; check local asset requests. |
| Expired form token | Reload the form; PHP sessions and cookies must work. |
| Two copies share records | Give each independent copy its own database name. |
| SQL changes do not appear | Automatic import only runs when the database is empty. |

This is for local exam practice. It has no login or permissions; anyone who can reach it can manage its records. Keep it local until authentication and deployment hardening are added. The list is unpaginated for small datasets; add pagination for large collections. Uploads, exports and additional modules are outside this single-table exercise.
