CREATE DATABASE IF NOT EXISTS `repair_service`;
USE `repair_service`;

CREATE TABLE IF NOT EXISTS `customers` (
  `customerID` INT AUTO_INCREMENT PRIMARY KEY,
  `customerFName` VARCHAR(100) NOT NULL,
  `customerLName` VARCHAR(100) NOT NULL,
  `contactNo` VARCHAR(50) NOT NULL,
  `address` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `technicians` (
  `techID` INT AUTO_INCREMENT PRIMARY KEY,
  `techFName` VARCHAR(100) NOT NULL,
  `techLName` VARCHAR(100) NOT NULL,
  `specialization` VARCHAR(150) NOT NULL,
  `contactNo` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `devices` (
  `deviceID` INT AUTO_INCREMENT PRIMARY KEY,
  `deviceType` VARCHAR(100) NOT NULL,
  `brand` VARCHAR(100) NOT NULL,
  `model` VARCHAR(100) NOT NULL,
  `serialNo` VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `repair_transactions` (
  `repairID` INT AUTO_INCREMENT PRIMARY KEY,
  `customerID` INT NOT NULL,
  `deviceID` INT NOT NULL,
  `techID` INT NOT NULL,
  `problem` TEXT NOT NULL,
  `serviceFee` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `partsCost` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `discount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `totalAmount` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `status` VARCHAR(50) NOT NULL,
  `dateReceived` DATE NOT NULL,
  `dateCompleted` DATE DEFAULT NULL,
  FOREIGN KEY (`customerID`) REFERENCES `customers`(`customerID`) ON DELETE CASCADE,
  FOREIGN KEY (`deviceID`) REFERENCES `devices`(`deviceID`) ON DELETE CASCADE,
  FOREIGN KEY (`techID`) REFERENCES `technicians`(`techID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `customers` (`customerFName`, `customerLName`, `contactNo`, `address`) VALUES
('Maria', 'Reyes', '09151234567', '123 Main St'),
('Jose', 'Santos', '09171234567', '45 Rizal Ave');

INSERT INTO `technicians` (`techFName`, `techLName`, `specialization`, `contactNo`) VALUES
('Anna', 'Lopez', 'Smartphone Repair', '09221234567'),
('Roberto', 'Garcia', 'Laptop Repair', '09231234567');

INSERT INTO `devices` (`deviceType`, `brand`, `model`, `serialNo`) VALUES
('Smartphone', 'Samsung', 'Galaxy A12', 'SN123456789'),
('Laptop', 'Acer', 'Aspire 5', 'SN987654321');
