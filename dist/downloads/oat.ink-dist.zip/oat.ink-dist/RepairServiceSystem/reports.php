<?php
include 'db.php';
$technicians = fetchAll('SELECT techID, techFName, techLName FROM technicians ORDER BY techFName');
$statusOptions = ['Pending', 'Completed'];
$where = [];
$filters = [];
if (!empty($_GET['techID'])) {
    $techID = (int)$_GET['techID'];
    $where[] = "r.techID=$techID";
    $filters[] = "Technician=" . $techID;
}
if (!empty($_GET['status'])) {
    $status = $mysqli->real_escape_string($_GET['status']);
    $where[] = "r.status='$status'";
}
if (!empty($_GET['dateFrom'])) {
    $dateFrom = $mysqli->real_escape_string($_GET['dateFrom']);
    $where[] = "r.dateReceived >= '$dateFrom'";
}
if (!empty($_GET['dateTo'])) {
    $dateTo = $mysqli->real_escape_string($_GET['dateTo']);
    $where[] = "r.dateReceived <= '$dateTo'";
}
$sql = 'SELECT r.*, c.customerFName, c.customerLName, d.deviceType, d.brand, d.model, t.techFName, t.techLName FROM repair_transactions r LEFT JOIN customers c ON r.customerID=c.customerID LEFT JOIN devices d ON r.deviceID=d.deviceID LEFT JOIN technicians t ON r.techID=t.techID';
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY r.repairID DESC';
$reports = fetchAll($sql);
$totalAmount = 0;
foreach ($reports as $row) {
    $totalAmount += (float)$row['totalAmount'];
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Reports</title>
    
    </head>
    <body>
        <div class="container">
            <h1 class="page-title">Reports</h1>
            <nav>
                <a href="index.php">Dashboard</a>
                <a href="customers.php">Customers</a>
                <a href="technicians.php">Technicians</a>
                <a href="devices.php">Devices</a>
                <a href="repair_transactions.php">Transactions</a>
                <a href="reports.php">Reports</a>
            </nav>
            <div class="card">
                <h2>Filter</h2>
                <form method="get" class="filter-form">
                    <div class="form-group">
                        <label>Technician</label>
                        <select name="techID">
                            <option value="">All</option>
                    <?php foreach ($technicians as $tech): ?>
                            <option value="<?php echo $tech['techID']; ?>" <?php echo !empty($_GET['techID']) && $_GET['techID'] == $tech['techID'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($tech['techFName'] . ' ' . $tech['techLName']); ?></option>
                    <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">All</option>
                    <?php foreach ($statusOptions as $option): ?>
                            <option value="<?php echo $option; ?>" <?php echo !empty($_GET['status']) && $_GET['status'] == $option ? 'selected' : ''; ?>><?php echo $option; ?></option>
                    <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Date From</label>
                        <input type="date" name="dateFrom" value="<?php echo htmlspecialchars($_GET['dateFrom'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Date To</label>
                        <input type="date" name="dateTo" value="<?php echo htmlspecialchars($_GET['dateTo'] ?? ''); ?>">
                    </div>
                    <input type="submit" value="Apply Filter">
                    <a class="button outline" href="reports.php">Clear</a>
                </form>
            </div>
            <div class="card">
                <h2>Report Results</h2>
                <p>Total Transactions: <strong><?php echo count($reports); ?></strong></p>
                <p>Total Amount: <strong><?php echo number_format($totalAmount, 2); ?></strong></p>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Device</th>
                            <th>Technician</th>
                            <th>Problem</th>
                            <th>Service Fee</th>
                            <th>Parts Cost</th>
                            <th>Discount</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Date Received</th>
                            <th>Date Completed</th>
                        </tr>
                    </thead>
                    <tbody>
            <?php foreach ($reports as $row): ?>
                        <tr>
                            <td><?php echo $row['repairID']; ?></td>
                            <td><?php echo htmlspecialchars($row['customerFName'] . ' ' . $row['customerLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['deviceType'] . ' ' . $row['brand'] . ' ' . $row['model']); ?></td>
                            <td><?php echo htmlspecialchars($row['techFName'] . ' ' . $row['techLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['problem']); ?></td>
                            <td><?php echo number_format($row['serviceFee'], 2); ?></td>
                            <td><?php echo number_format($row['partsCost'], 2); ?></td>
                            <td><?php echo number_format($row['discount'], 2); ?></td>
                            <td><?php echo number_format($row['totalAmount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                            <td><?php echo htmlspecialchars($row['dateReceived']); ?></td>
                            <td><?php echo htmlspecialchars($row['dateCompleted']); ?></td>
                        </tr>
            <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
