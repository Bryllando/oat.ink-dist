<?php
include 'db.php';
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_device'])) {
    $deviceType = $mysqli->real_escape_string($_POST['deviceType']);
    $brand = $mysqli->real_escape_string($_POST['brand']);
    $model = $mysqli->real_escape_string($_POST['model']);
    $serialNo = $mysqli->real_escape_string($_POST['serialNo']);
    $mysqli->query("INSERT INTO devices (deviceType, brand, model, serialNo) VALUES ('$deviceType', '$brand', '$model', '$serialNo')");
    $message = 'Device added successfully.';
}
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $mysqli->query("DELETE FROM devices WHERE deviceID=$id");
    header('Location: devices.php');
    exit;
}
$devices = fetchAll('SELECT * FROM devices ORDER BY deviceID DESC');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Devices</title>
    
    </head>
    <body>
        <div class="container">
            <h1 class="page-title">Devices</h1>
            <nav>
                <a href="index.php">Dashboard</a>
                <a href="customers.php">Customers</a>
                <a href="technicians.php">Technicians</a>
                <a href="devices.php">Devices</a>
                <a href="repair_transactions.php">Transactions</a>
                <a href="reports.php">Reports</a>
            </nav>
    <?php if ($message): ?><div role="alert" class="notice"><?php echo $message; ?></div><?php endif; ?>
            <div class="card">
                <h2>Add Device</h2>
                <form method="post" class="entry-form">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-deviceType">Device Type</label>
                            <input type="text" name="deviceType" required id="input-deviceType">
                        </div>
                        <div class="form-group">
                            <label for="input-brand">Brand</label>
                            <input type="text" name="brand" required id="input-brand">
                        </div>
                        <div class="form-group">
                            <label for="input-model">Model</label>
                            <input type="text" name="model" required id="input-model">
                        </div>
                        <div class="form-group">
                            <label for="input-serialNo">Serial Number</label>
                            <input type="text" name="serialNo" required id="input-serialNo">
                        </div>
                    </div>
                    <div class="form-actions">
                        <input type="submit" name="save_device" value="Save Device">
                    </div>
                </form>
            </div>
            <div class="card">
                <h2>Device List</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Brand</th>
                            <th>Model</th>
                            <th>Serial No</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
            <?php foreach ($devices as $device): ?>
                        <tr>
                            <td><?php echo $device['deviceID']; ?></td>
                            <td><?php echo htmlspecialchars($device['deviceType']); ?></td>
                            <td><?php echo htmlspecialchars($device['brand']); ?></td>
                            <td><?php echo htmlspecialchars($device['model']); ?></td>
                            <td><?php echo htmlspecialchars($device['serialNo']); ?></td>
                            <td><a href="devices.php?delete=<?php echo $device['deviceID']; ?>" style="color: #c0392b;" class="button small danger-action" onclick="return confirm(&#x27;Delete this record?&#x27;)">Delete</a></td>
                        </tr>
            <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
