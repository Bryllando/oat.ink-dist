> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

# Repair Service Management System

This project is a simple offline Repair Service Management System built for XAMPP localhost.

## Features

- PHP procedural mysqli
- MySQL database: `repair_service`
- Oat UI (Local CSS & JS)
- Offline ready
- No OOP
- No MVC
- No AJAX
- No Composer
- Beginner-friendly CRUD
- Simple Reports with COUNT() and SUM()

---

## Setup

1. Copy the project to:

```text
C:\xampp\htdocs\RepairServiceSystem
```

2. Start Apache and MySQL in XAMPP.

3. Import the database:

```sql
mysql -u root < "C:/xampp/htdocs/RepairServiceSystem/repair_service.sql"
```

4. Open:

```text
http://localhost/RepairServiceSystem/index.php
```

---

# Database

Database name:

```text
repair_service
```

### customers

- customerID (PK)
- customerFName
- customerLName
- contactNo
- address

### technicians

- techID (PK)
- techFName
- techLName
- specialization
- contactNo

### devices

- deviceID (PK)
- deviceType
- brand
- model
- serialNo

### repair_transactions

- repairID (PK)
- customerID (FK)
- deviceID (FK)
- techID (FK)
- problem
- serviceFee
- partsCost
- discount
- totalAmount
- status
- dateReceived
- dateCompleted

---

# Modules

## Dashboard

- index.php

## Customers

- Add
- Search
- Edit
- Delete
- View

## Technicians

- Add
- Search
- Edit
- Delete
- View

## Devices

- Add
- Search
- Edit
- Delete
- View

## Repair Transactions

- Create Repair Transaction
- Select Customer
- Select Device
- Select Technician
- Input Problem
- Input Service Fee
- Input Parts Cost
- Input Discount
- Compute Total Amount
- Save Transaction
- Edit Transaction
- Delete Transaction
- View Transactions

## Reports

Filter by:

- Technician
- Status
- Date From – Date To

Display:

- Customer
- Device
- Technician
- Problem
- Service Fee
- Parts Cost
- Discount
- Total Amount
- Status
- Date Received
- Date Completed

---

# Formula

```text
totalAmount =
serviceFee + partsCost - discount
```

---

# Aggregate Functions

```sql
COUNT(*) AS totalRepairs
```

```sql
COUNT(CASE WHEN status='Completed' THEN 1 END)
```

```sql
COUNT(CASE WHEN status='Pending' THEN 1 END)
```

```sql
SUM(totalAmount)
```

---

# Project Structure

```text
RepairServiceSystem/

styles.css
db.php
index.php
customers.php
technicians.php
devices.php
repairs.php
reports.php
repair_service.sql
README.md
```

---

# Verification Checklist

- [x] Database Connection
- [x] Customers CRUD
- [x] Technicians CRUD
- [x] Devices CRUD
- [x] Repair Transactions
- [x] Reports
- [x] COUNT()
- [x] SUM()
- [x] Bootstrap Local
- [x] Offline Ready

---

# How to Use

1. Add Customers.
2. Add Technicians.
3. Add Devices.
4. Create Repair Transactions.
5. Generate Reports.

---

# IMPORTANT (Copilot Prompt)

This is a college skills test project.

Requirements:

- PHP procedural mysqli only
- XAMPP localhost
- MySQL
- Bootstrap local CSS & JS only
- Offline ready
- No internet required
- No frameworks
- No OOP
- No MVC
- No AJAX
- No Composer
- Beginner-friendly
- Easy to understand
- Prioritize passing the skills test rather than enterprise architecture

---

# UI Style Guide

## General

- Font: Arial, Helvetica, sans-serif
- Body: `#f4f6f9`
- Cards/Tables/Navbar: `#ffffff`
- Text: `#333333`
- Border: `1px solid #ddd`
- Border Radius: `4px`

## Colors

| Purpose | Color |
|---------|--------|
| Primary | `#007bff` |
| Success | `#28a745` |
| Warning | `#ffc107` |
| Danger | `#dc3545` |
| Gray | `#f1f1f1` |
| White | `#ffffff` |

## Buttons

| Class | Use |
|------|------|
| `btn btn-primary` | Save / Add |
| `btn btn-secondary` | Back / Cancel |
| `btn-action btn-edit` | Edit |
| `btn-action btn-delete` | Delete |

## Alerts

| Class | Use |
|------|------|
| `alert alert-success` | Success |
| `alert alert-warning` | Error / Not Found |

## Layout

- Fixed Navbar
- Page Title
- Card Container
- Bootstrap Table
- Bootstrap Forms

## Rules

- PHP Procedural mysqli only
- Bootstrap Local Files
- Offline Ready
- Flat Folder Structure
- Simple CRUD
- Easy Navigation
- College Skills Test Ready