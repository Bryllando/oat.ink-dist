<?php
mysqli_report(MYSQLI_REPORT_OFF);
$host = '127.0.0.1';
$user = 'root';
$password = '';
$database = 'repair_service';

$mysqli = @new mysqli($host, $user, $password);
if ($mysqli->connect_errno) {
    die('Database connection failed: ' . $mysqli->connect_error);
}

$mysqli->query("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci") or die('Database setup failed: ' . htmlspecialchars($mysqli->error));
$mysqli->select_db($database) or die('Database setup failed: ' . htmlspecialchars($mysqli->error));
$mysqli->set_charset('utf8mb4') or die('Database setup failed: ' . htmlspecialchars($mysqli->error));

$tables = $mysqli->query("SHOW TABLES");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($mysqli->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/repair_service.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $mysqli->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($mysqli->error));
    do {
        if ($result = $mysqli->store_result()) $result->free();
    } while ($mysqli->more_results() && $mysqli->next_result());
    if ($mysqli->errno) die('Database setup failed: ' . htmlspecialchars($mysqli->error));
}
function fetchAll($query) {
    global $mysqli;
    $result = $mysqli->query($query);
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}
function fetchRow($query) {
    global $mysqli;
    $result = $mysqli->query($query);
    return $result ? $result->fetch_assoc() : null;
}
?>