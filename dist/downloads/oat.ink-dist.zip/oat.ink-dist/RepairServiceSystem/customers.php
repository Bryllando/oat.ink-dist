<?php
include 'db.php';
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_customer'])) {
        $fname = $mysqli->real_escape_string($_POST['customerFName']);
        $lname = $mysqli->real_escape_string($_POST['customerLName']);
        $contact = $mysqli->real_escape_string($_POST['contactNo']);
        $address = $mysqli->real_escape_string($_POST['address']);
        $mysqli->query("INSERT INTO customers (customerFName, customerLName, contactNo, address) VALUES ('$fname', '$lname', '$contact', '$address')");
        $message = 'Customer added successfully.';
    }
}
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $mysqli->query("DELETE FROM customers WHERE customerID=$id");
    header('Location: customers.php');
    exit;
}
$customers = fetchAll('SELECT * FROM customers ORDER BY customerID DESC');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Customers</title>
    
    </head>
    <body>
        <div class="container">
            <h1 class="page-title">Customers</h1>
            <nav>
                <a href="index.php">Dashboard</a>
                <a href="customers.php">Customers</a>
                <a href="technicians.php">Technicians</a>
                <a href="devices.php">Devices</a>
                <a href="repair_transactions.php">Transactions</a>
                <a href="reports.php">Reports</a>
            </nav>
    <?php if ($message): ?><div role="alert" class="notice"><?php echo $message; ?></div><?php endif; ?>
            <div class="card">
                <h2>Add Customer</h2>
                <form method="post" class="entry-form">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-customerFName">First Name</label>
                            <input type="text" name="customerFName" required id="input-customerFName">
                        </div>
                        <div class="form-group">
                            <label for="input-customerLName">Last Name</label>
                            <input type="text" name="customerLName" required id="input-customerLName">
                        </div>
                        <div class="form-group">
                            <label for="input-contactNo">Contact Number</label>
                            <input type="text" name="contactNo" required id="input-contactNo">
                        </div>
                        <div class="form-group">
                            <label for="input-address">Address</label>
                            <textarea name="address" rows="3" required id="input-address"></textarea>
                        </div>
                    </div>
                    <div class="form-actions">
                        <input type="submit" name="save_customer" value="Save Customer">
                    </div>
                </form>
            </div>
            <div class="card">
                <h2>Customer List</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Contact</th>
                            <th>Address</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
            <?php foreach ($customers as $customer): ?>
                        <tr>
                            <td><?php echo $customer['customerID']; ?></td>
                            <td><?php echo htmlspecialchars($customer['customerFName'] . ' ' . $customer['customerLName']); ?></td>
                            <td><?php echo htmlspecialchars($customer['contactNo']); ?></td>
                            <td><?php echo htmlspecialchars($customer['address']); ?></td>
                            <td>
                                <a href="customers.php?delete=<?php echo $customer['customerID']; ?>" style="color: #c0392b;" class="button small danger-action" onclick="return confirm(&#x27;Delete this record?&#x27;)">Delete</a>
                            </td>
                        </tr>
            <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
