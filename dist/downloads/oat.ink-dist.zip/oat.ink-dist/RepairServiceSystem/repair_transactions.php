<?php
include 'db.php';
$message = '';
$customers = fetchAll('SELECT customerID, customerFName, customerLName FROM customers ORDER BY customerFName');
$devices = fetchAll('SELECT deviceID, deviceType, brand, model FROM devices ORDER BY deviceType');
$technicians = fetchAll('SELECT techID, techFName, techLName FROM technicians ORDER BY techFName');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_repair'])) {
    $customerID = (int)$_POST['customerID'];
    $deviceID = (int)$_POST['deviceID'];
    $techID = (int)$_POST['techID'];
    $problem = $mysqli->real_escape_string($_POST['problem']);
    $serviceFee = (float)$_POST['serviceFee'];
    $partsCost = (float)$_POST['partsCost'];
    $discount = (float)$_POST['discount'];
    $totalAmount = $serviceFee + $partsCost - $discount;
    $status = $mysqli->real_escape_string($_POST['status']);
    $dateReceived = $mysqli->real_escape_string($_POST['dateReceived']);
    $dateCompleted = $mysqli->real_escape_string($_POST['dateCompleted']);
    $mysqli->query("INSERT INTO repair_transactions (customerID, deviceID, techID, problem, serviceFee, partsCost, discount, totalAmount, status, dateReceived, dateCompleted) VALUES ($customerID, $deviceID, $techID, '$problem', $serviceFee, $partsCost, $discount, $totalAmount, '$status', '$dateReceived', '$dateCompleted')");
    $message = 'Repair transaction saved.';
}
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $mysqli->query("DELETE FROM repair_transactions WHERE repairID=$id");
    header('Location: repair_transactions.php');
    exit;
}
$repairs = fetchAll('SELECT r.*, c.customerFName, c.customerLName, d.deviceType, d.brand, d.model, t.techFName, t.techLName FROM repair_transactions r LEFT JOIN customers c ON r.customerID=c.customerID LEFT JOIN devices d ON r.deviceID=d.deviceID LEFT JOIN technicians t ON r.techID=t.techID ORDER BY r.repairID DESC');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Repair Transactions</title>
    
    </head>
    <body>
        <div class="container">
            <h1 class="page-title">Repair Transactions</h1>
            <nav>
                <a href="index.php">Dashboard</a>
                <a href="customers.php">Customers</a>
                <a href="technicians.php">Technicians</a>
                <a href="devices.php">Devices</a>
                <a href="repair_transactions.php">Transactions</a>
                <a href="reports.php">Reports</a>
            </nav>
    <?php if ($message): ?><div role="alert" class="notice"><?php echo $message; ?></div><?php endif; ?>
            <div class="card">
                <h2>Create Repair Transaction</h2>
                <form method="post" class="entry-form">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-customerID">Customer</label>
                            <select name="customerID" required id="input-customerID">
                                <option value="">Select Customer</option>
                    <?php foreach ($customers as $customer): ?>
                                <option value="<?php echo $customer['customerID']; ?>"><?php echo htmlspecialchars($customer['customerFName'] . ' ' . $customer['customerLName']); ?></option>
                    <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="input-deviceID">Device</label>
                            <select name="deviceID" required id="input-deviceID">
                                <option value="">Select Device</option>
                    <?php foreach ($devices as $device): ?>
                                <option value="<?php echo $device['deviceID']; ?>"><?php echo htmlspecialchars($device['deviceType'] . ' - ' . $device['brand'] . ' ' . $device['model']); ?></option>
                    <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="input-techID">Technician</label>
                            <select name="techID" required id="input-techID">
                                <option value="">Select Technician</option>
                    <?php foreach ($technicians as $tech): ?>
                                <option value="<?php echo $tech['techID']; ?>"><?php echo htmlspecialchars($tech['techFName'] . ' ' . $tech['techLName']); ?></option>
                    <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="input-problem">Problem</label>
                            <textarea name="problem" rows="3" required id="input-problem"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="input-serviceFee">Service Fee</label>
                            <input type="number" step="0.01" name="serviceFee" value="0" required id="input-serviceFee">
                        </div>
                        <div class="form-group">
                            <label for="input-partsCost">Parts Cost</label>
                            <input type="number" step="0.01" name="partsCost" value="0" required id="input-partsCost">
                        </div>
                        <div class="form-group">
                            <label for="input-discount">Discount</label>
                            <input type="number" step="0.01" name="discount" value="0" required id="input-discount">
                        </div>
                        <div class="form-group">
                            <label for="input-status">Status</label>
                            <select name="status" required id="input-status">
                                <option value="Pending">Pending</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="input-dateReceived">Date Received</label>
                            <input type="date" name="dateReceived" required id="input-dateReceived">
                        </div>
                        <div class="form-group">
                            <label for="input-dateCompleted">Date Completed</label>
                            <input type="date" name="dateCompleted" id="input-dateCompleted">
                        </div>
                    </div>
                    <div class="form-actions">
                        <input type="submit" name="save_repair" value="Save Transaction">
                    </div>
                </form>
            </div>
            <div class="card">
                <h2>Transactions</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Device</th>
                            <th>Technician</th>
                            <th>Problem</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Date Received</th>
                            <th>Date Completed</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
            <?php foreach ($repairs as $repair): ?>
                        <tr>
                            <td><?php echo $repair['repairID']; ?></td>
                            <td><?php echo htmlspecialchars($repair['customerFName'] . ' ' . $repair['customerLName']); ?></td>
                            <td><?php echo htmlspecialchars($repair['deviceType'] . ' ' . $repair['brand'] . ' ' . $repair['model']); ?></td>
                            <td><?php echo htmlspecialchars($repair['techFName'] . ' ' . $repair['techLName']); ?></td>
                            <td><?php echo htmlspecialchars($repair['problem']); ?></td>
                            <td><?php echo number_format($repair['totalAmount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($repair['status']); ?></td>
                            <td><?php echo htmlspecialchars($repair['dateReceived']); ?></td>
                            <td><?php echo htmlspecialchars($repair['dateCompleted']); ?></td>
                            <td><a href="repair_transactions.php?delete=<?php echo $repair['repairID']; ?>" style="color: #c0392b;" class="button small danger-action" onclick="return confirm(&#x27;Delete this record?&#x27;)">Delete</a></td>
                        </tr>
            <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
