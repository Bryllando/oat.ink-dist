<?php
include 'db.php';
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_technician'])) {
    $fname = $mysqli->real_escape_string($_POST['techFName']);
    $lname = $mysqli->real_escape_string($_POST['techLName']);
    $specialization = $mysqli->real_escape_string($_POST['specialization']);
    $contact = $mysqli->real_escape_string($_POST['contactNo']);
    $mysqli->query("INSERT INTO technicians (techFName, techLName, specialization, contactNo) VALUES ('$fname', '$lname', '$specialization', '$contact')");
    $message = 'Technician added successfully.';
}
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $mysqli->query("DELETE FROM technicians WHERE techID=$id");
    header('Location: technicians.php');
    exit;
}
$technicians = fetchAll('SELECT * FROM technicians ORDER BY techID DESC');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Technicians</title>
    
    </head>
    <body>
        <div class="container">
            <h1 class="page-title">Technicians</h1>
            <nav>
                <a href="index.php">Dashboard</a>
                <a href="customers.php">Customers</a>
                <a href="technicians.php">Technicians</a>
                <a href="devices.php">Devices</a>
                <a href="repair_transactions.php">Transactions</a>
                <a href="reports.php">Reports</a>
            </nav>
    <?php if ($message): ?><div role="alert" class="notice"><?php echo $message; ?></div><?php endif; ?>
            <div class="card">
                <h2>Add Technician</h2>
                <form method="post" class="entry-form">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-techFName">First Name</label>
                            <input type="text" name="techFName" required id="input-techFName">
                        </div>
                        <div class="form-group">
                            <label for="input-techLName">Last Name</label>
                            <input type="text" name="techLName" required id="input-techLName">
                        </div>
                        <div class="form-group">
                            <label for="input-specialization">Specialization</label>
                            <input type="text" name="specialization" required id="input-specialization">
                        </div>
                        <div class="form-group">
                            <label for="input-contactNo">Contact Number</label>
                            <input type="text" name="contactNo" required id="input-contactNo">
                        </div>
                    </div>
                    <div class="form-actions">
                        <input type="submit" name="save_technician" value="Save Technician">
                    </div>
                </form>
            </div>
            <div class="card">
                <h2>Technician List</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Specialization</th>
                            <th>Contact</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
            <?php foreach ($technicians as $tech): ?>
                        <tr>
                            <td><?php echo $tech['techID']; ?></td>
                            <td><?php echo htmlspecialchars($tech['techFName'] . ' ' . $tech['techLName']); ?></td>
                            <td><?php echo htmlspecialchars($tech['specialization']); ?></td>
                            <td><?php echo htmlspecialchars($tech['contactNo']); ?></td>
                            <td><a href="technicians.php?delete=<?php echo $tech['techID']; ?>" style="color: #c0392b;" class="button small danger-action" onclick="return confirm(&#x27;Delete this record?&#x27;)">Delete</a></td>
                        </tr>
            <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
