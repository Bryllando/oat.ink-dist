<?php
include 'db.php';
$customerCount = fetchRow('SELECT COUNT(*) AS cnt FROM customers')['cnt'] ?? 0;
$technicianCount = fetchRow('SELECT COUNT(*) AS cnt FROM technicians')['cnt'] ?? 0;
$deviceCount = fetchRow('SELECT COUNT(*) AS cnt FROM devices')['cnt'] ?? 0;
$repairCount = fetchRow('SELECT COUNT(*) AS cnt FROM repair_transactions')['cnt'] ?? 0;
$completedCount = fetchRow("SELECT COUNT(*) AS cnt FROM repair_transactions WHERE status='Completed'")['cnt'] ?? 0;
$pendingCount = fetchRow("SELECT COUNT(*) AS cnt FROM repair_transactions WHERE status='Pending'")['cnt'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Repair Service System</title>
    
    </head>
    <body>
        <div class="container">
            <h1 class="page-title">Repair Service Dashboard</h1>
            <nav>
                <a href="index.php">Dashboard</a>
                <a href="customers.php">Customers</a>
                <a href="technicians.php">Technicians</a>
                <a href="devices.php">Devices</a>
                <a href="repair_transactions.php">Transactions</a>
                <a href="reports.php">Reports</a>
            </nav>
            <div class="card">
                <h2>Summary</h2>
                <p>Total Customers: <strong><?php echo $customerCount; ?></strong></p>
                <p>Total Technicians: <strong><?php echo $technicianCount; ?></strong></p>
                <p>Total Devices: <strong><?php echo $deviceCount; ?></strong></p>
                <p>Total Transactions: <strong><?php echo $repairCount; ?></strong></p>
                <p>Completed Repairs: <strong><?php echo $completedCount; ?></strong></p>
                <p>Pending Repairs: <strong><?php echo $pendingCount; ?></strong></p>
            </div>
            <div class="card">
                <h2>Quick Actions</h2>
                <ul class="simple-menu">
                    <li><a href="customers.php">Customers</a></li>
                    <li><a href="technicians.php">Technicians</a></li>
                    <li><a href="devices.php">Devices</a></li>
                    <li><a href="repair_transactions.php">Repair Transactions</a></li>
                </ul>
            </div>
        </div>
    </body>
</html>
