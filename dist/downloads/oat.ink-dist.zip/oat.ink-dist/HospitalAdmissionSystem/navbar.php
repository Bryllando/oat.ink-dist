<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Hospital Patient Admission & Ward Management System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'patients') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>patients/index.php">Patients</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'wards') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>wards/index.php">Hospital Wards</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'admissions') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>admissions/index.php">Patient Admissions</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
