CREATE DATABASE IF NOT EXISTS `hospital_admission_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `hospital_admission_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `patients` (
  `patientID` INT AUTO_INCREMENT PRIMARY KEY,
  `patientName` VARCHAR(100) NOT NULL,
  `birthDate` DATE NOT NULL,
  `gender` VARCHAR(20) NOT NULL,
  `bloodType` VARCHAR(10) NOT NULL,
  `contactNumber` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `wards` (
  `wardID` INT AUTO_INCREMENT PRIMARY KEY,
  `wardNumber` VARCHAR(50) NOT NULL,
  `wardName` VARCHAR(100) NOT NULL,
  `dailyRate` DECIMAL(10,2) NOT NULL,
  `floorLevel` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `admissions` (
  `admissionID` INT AUTO_INCREMENT PRIMARY KEY,
  `patientID` INT NOT NULL,
  `wardID` INT NOT NULL,
  `admitDate` DATE NOT NULL,
  `dischargeDate` DATE NOT NULL,
  `attendingDoctor` VARCHAR(100) NOT NULL,
  `totalBilling` DECIMAL(10,2) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Admitted',
  FOREIGN KEY (`patientID`) REFERENCES `patients`(`patientID`) ON DELETE CASCADE,
  FOREIGN KEY (`wardID`) REFERENCES `wards`(`wardID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `patients` (`patientName`, `birthDate`, `gender`, `bloodType`, `contactNumber`) VALUES
('Herminia Pascual', '1965-02-14', 'Female', 'O+', '09177778899'),
('Carmelo Rivera', '1991-08-30', 'Male', 'A+', '09188889900'),
('Milagros Mendoza', '1980-12-19', 'Female', 'B+', '09229990011');

INSERT INTO `wards` (`wardNumber`, `wardName`, `dailyRate`, `floorLevel`) VALUES
('W-301', 'General Medical Ward', 800.0, '3rd Floor North'),
('P-405', 'Private Deluxe Room', 2500.0, '4th Floor East'),
('ICU-202', 'Intensive Care Unit', 5500.0, '2nd Floor West');

INSERT INTO `admissions` (`patientID`, `wardID`, `admitDate`, `dischargeDate`, `attendingDoctor`, `totalBilling`, `status`) VALUES
(1, 1, '2026-10-20', '2026-10-24', 'Dr. Ramon Santos', 3200.0, 'Discharged'),
(2, 2, '2026-10-25', '2026-10-28', 'Dr. Liza Soberano', 7500.0, 'Discharged'),
(3, 3, '2026-11-01', '2026-11-05', 'Dr. Victor Morales', 22000.0, 'Admitted');

SET FOREIGN_KEY_CHECKS=1;
