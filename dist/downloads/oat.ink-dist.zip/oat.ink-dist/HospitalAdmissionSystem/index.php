<?php
require_once __DIR__ . '/database.php';

$countE1 = $conn->query("SELECT COUNT(*) AS total FROM `patients`")->fetch_assoc()['total'] ?? 0;
$countE2 = $conn->query("SELECT COUNT(*) AS total FROM `wards`")->fetch_assoc()['total'] ?? 0;
$countTr = $conn->query("SELECT COUNT(*) AS total FROM `admissions`")->fetch_assoc()['total'] ?? 0;
$sumTotal = $conn->query("SELECT IFNULL(SUM(totalBilling), 0) AS total FROM `admissions`")->fetch_assoc()['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Patient Admission & Ward Management System - Dashboard</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/navbar.php'; ?>

    <div class="container my-4">
        <div class="p-4 mb-4 rounded border">
            <h1 class="display-6 weight-bold mb-2">Hospital Patient Admission & Ward Management System</h1>
            <p class="lead text-light mb-0">Universal College Capstone & Skills Test Management System</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Patients</span>
                    <h2 class="weight-bold text-primary mb-2"><?= $countE1 ?></h2>
                    <a href="<?= $baseUrl ?>patients/index.php" class="button outline small">Manage Patients </a>
                </div>
            </div>
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Hospital Wards</span>
                    <h2 class="weight-bold text-success mb-2"><?= $countE2 ?></h2>
                    <a href="<?= $baseUrl ?>wards/index.php" class="button outline success-action small">Manage Hospital Wards </a>
                </div>
            </div>
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Patient Admissions</span>
                    <h2 class="weight-bold mb-2"><?= $countTr ?></h2>
                    <a href="<?= $baseUrl ?>admissions/index.php" class="button outline small">View Patient Admissions </a>
                </div>
            </div>
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Total Hospital Admission Billings</span>
                    <h2 class="weight-bold text-warning mb-2">₱<?= number_format((float)$sumTotal, 2) ?></h2>
                    <a href="<?= $baseUrl ?>monitoring/index.php" class="button outline small">View Analytics </a>
                </div>
            </div>
        </div>

        <div class="card p-4">
            <h4 class="weight-bold mb-3">Quick Actions</h4>
            <div class="form-actions">
                <a href="<?= $baseUrl ?>patients/add.php" class="button">+ Add New Patient</a>
                <a href="<?= $baseUrl ?>wards/add.php" class="button success-action">+ Add New Ward</a>
                <a href="<?= $baseUrl ?>admissions/add.php" class="button outline">+ Record New Admission</a>
                <a href="<?= $baseUrl ?>monitoring/index.php" class="button outline">Generate Monitoring Report</a>
            </div>
        </div>
    </div>

    
</body>
</html>
