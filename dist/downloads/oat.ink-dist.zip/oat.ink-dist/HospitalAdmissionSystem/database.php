<?php
// Database connection configuration
mysqli_report(MYSQLI_REPORT_OFF);

session_start();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    (!is_string($_POST['csrf_token'] ?? null) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']))) {
    http_response_code(403);
    exit('Invalid form token. Reload the page and try again.');
}


$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'hospital_admission_db';

$conn = @mysqli_connect($DB_HOST, $DB_USER, $DB_PASS);
if (!$conn) {
    die('Database connection failed: ' . htmlspecialchars(mysqli_connect_error()));
}

// Auto-create database if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS `{$DB_NAME}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci") or die('Database setup failed: ' . htmlspecialchars($conn->error));
$conn->select_db($DB_NAME) or die('Database setup failed: ' . htmlspecialchars($conn->error));
$conn->set_charset('utf8mb4') or die('Database setup failed: ' . htmlspecialchars($conn->error));

$tables = $conn->query("SHOW TABLES");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($conn->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/database.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $conn->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($conn->error));
    do {
        if ($result = $conn->store_result()) $result->free();
    } while ($conn->more_results() && $conn->next_result());
    if ($conn->errno) die('Database setup failed: ' . htmlspecialchars($conn->error));
}

// shortcut: project must be inside the web root; use an explicit URL for Apache aliases.
$docRoot = rtrim(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])), '/');
$projectDir = str_replace('\\', '/', __DIR__);
$baseUrl = substr($projectDir, strlen($docRoot)) . '/';

return $conn;