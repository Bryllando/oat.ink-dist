<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `patientID`, `patientName` FROM `patients` ORDER BY `patientName` ASC");
$e2List = $conn->query("SELECT `wardID`, `wardName` FROM `wards` ORDER BY `wardName` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['patientID'] ?? 0);
    $id2 = (int)($_POST['wardID'] ?? 0);
    $admitDate = is_string($_POST['admitDate'] ?? null) ? trim($_POST['admitDate']) : '';
    $dischargeDate = is_string($_POST['dischargeDate'] ?? null) ? trim($_POST['dischargeDate']) : '';
    $attendingDoctor = is_string($_POST['attendingDoctor'] ?? null) ? trim($_POST['attendingDoctor']) : '';
    $totalBilling = is_string($_POST['totalBilling'] ?? null) ? trim($_POST['totalBilling']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($admitDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $admitDate) ||
        date('Y-m-d', strtotime($admitDate) ?: 0) !== $admitDate ||
        $dischargeDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $dischargeDate) ||
        date('Y-m-d', strtotime($dischargeDate) ?: 0) !== $dischargeDate ||
        $attendingDoctor === '' ||
        $totalBilling === '' ||
        !is_numeric($totalBilling) ||
        !is_finite((float)$totalBilling) ||
        (float)$totalBilling < 0 ||
        $status === '' ||
        $id1 <= 0 ||
        $id2 <= 0 ||
        $dischargeDate < $admitDate) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `admissions` (`patientID`, `wardID`, `admitDate`, `dischargeDate`, `attendingDoctor`, `totalBilling`, `status`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($admitDate) . "', '" . $conn->real_escape_string($dischargeDate) . "', '" . $conn->real_escape_string($attendingDoctor) . "', '" . $conn->real_escape_string($totalBilling) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Admission - Hospital Patient Admission & Ward Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Admission</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="patientID" class="weight-semibold">Select Patient</label>
                        <select id="patientID" name="patientID" class="" required>
                            <option value="">-- Choose Patient --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['patientID'] ?>" <?= ((int)($_POST['patientID'] ?? 0) === (int)$r['patientID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['patientName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="wardID" class="weight-semibold">Select Ward</label>
                        <select id="wardID" name="wardID" class="" required>
                            <option value="">-- Choose Ward --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['wardID'] ?>" <?= ((int)($_POST['wardID'] ?? 0) === (int)$r['wardID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['wardName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="admitDate" class="weight-semibold">Admission Date</label>
                <input type="date" id="admitDate" name="admitDate" class=""  required value="<?= htmlspecialchars($admitDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="dischargeDate" class="weight-semibold">Discharge Date</label>
                <input type="date" id="dischargeDate" name="dischargeDate" class=""  required value="<?= htmlspecialchars($dischargeDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="attendingDoctor" class="weight-semibold">Attending Doctor</label>
                <input type="text" id="attendingDoctor" name="attendingDoctor" class=""  required value="<?= htmlspecialchars($attendingDoctor ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="totalBilling" class="weight-semibold">Total Room Billing</label>
                <input type="number" id="totalBilling" name="totalBilling" min="0" class="" step="0.01" required value="<?= htmlspecialchars($totalBilling ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="status" class="weight-semibold">Admission Status</label>
                <input type="text" id="status" name="status" class=""  required value="<?= htmlspecialchars($status ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Admission</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
