<?php
require_once __DIR__ . '/../database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Use the Delete button on the records page.');
}
$id = is_string($_POST['id'] ?? null) ? (int)$_POST['id'] : 0;
if ($id > 0) {
    if (!$conn->query("DELETE FROM `admissions` WHERE `admissionID` = $id")) {
        http_response_code(500);
        exit('Delete failed: ' . htmlspecialchars($conn->error));
    }
}

header("Location: index.php");
exit;
