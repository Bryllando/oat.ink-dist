<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $wardNumber = is_string($_POST['wardNumber'] ?? null) ? trim($_POST['wardNumber']) : '';
    $wardName = is_string($_POST['wardName'] ?? null) ? trim($_POST['wardName']) : '';
    $dailyRate = is_string($_POST['dailyRate'] ?? null) ? trim($_POST['dailyRate']) : '';
    $floorLevel = is_string($_POST['floorLevel'] ?? null) ? trim($_POST['floorLevel']) : '';

    if ($wardNumber === '' ||
        $wardName === '' ||
        $dailyRate === '' ||
        !is_numeric($dailyRate) ||
        !is_finite((float)$dailyRate) ||
        (float)$dailyRate < 0 ||
        $floorLevel === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `wards` (`wardNumber`, `wardName`, `dailyRate`, `floorLevel`) VALUES ('" . $conn->real_escape_string($wardNumber) . "', '" . $conn->real_escape_string($wardName) . "', '" . $conn->real_escape_string($dailyRate) . "', '" . $conn->real_escape_string($floorLevel) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Ward - Hospital Patient Admission & Ward Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Add New Ward</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="wardNumber" class="weight-semibold">Ward / Room No</label>
                <input type="text" id="wardNumber" name="wardNumber" class=""  required value="<?= htmlspecialchars($wardNumber ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="wardName" class="weight-semibold">Ward Category</label>
                <input type="text" id="wardName" name="wardName" class=""  required value="<?= htmlspecialchars($wardName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="dailyRate" class="weight-semibold">Daily Room Rate</label>
                <input type="number" id="dailyRate" name="dailyRate" min="0" class="" step="0.01" required value="<?= htmlspecialchars($dailyRate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="floorLevel" class="weight-semibold">Floor / Wing</label>
                <input type="text" id="floorLevel" name="floorLevel" class=""  required value="<?= htmlspecialchars($floorLevel ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Save Ward</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
