<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patientName = is_string($_POST['patientName'] ?? null) ? trim($_POST['patientName']) : '';
    $birthDate = is_string($_POST['birthDate'] ?? null) ? trim($_POST['birthDate']) : '';
    $gender = is_string($_POST['gender'] ?? null) ? trim($_POST['gender']) : '';
    $bloodType = is_string($_POST['bloodType'] ?? null) ? trim($_POST['bloodType']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($patientName === '' ||
        $birthDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $birthDate) ||
        date('Y-m-d', strtotime($birthDate) ?: 0) !== $birthDate ||
        $gender === '' ||
        $bloodType === '' ||
        $contactNumber === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `patients` (`patientName`, `birthDate`, `gender`, `bloodType`, `contactNumber`) VALUES ('" . $conn->real_escape_string($patientName) . "', '" . $conn->real_escape_string($birthDate) . "', '" . $conn->real_escape_string($gender) . "', '" . $conn->real_escape_string($bloodType) . "', '" . $conn->real_escape_string($contactNumber) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Patient - Hospital Patient Admission & Ward Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Add New Patient</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="patientName" class="weight-semibold">Patient Full Name</label>
                <input type="text" id="patientName" name="patientName" class=""  required value="<?= htmlspecialchars($patientName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="birthDate" class="weight-semibold">Birth Date</label>
                <input type="date" id="birthDate" name="birthDate" class=""  required value="<?= htmlspecialchars($birthDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="gender" class="weight-semibold">Gender</label>
                <input type="text" id="gender" name="gender" class=""  required value="<?= htmlspecialchars($gender ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="bloodType" class="weight-semibold">Blood Type</label>
                <input type="text" id="bloodType" name="bloodType" class=""  required value="<?= htmlspecialchars($bloodType ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactNumber" class="weight-semibold">Emergency Contact</label>
                <input type="text" id="contactNumber" name="contactNumber" class=""  required value="<?= htmlspecialchars($contactNumber ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Save Patient</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
