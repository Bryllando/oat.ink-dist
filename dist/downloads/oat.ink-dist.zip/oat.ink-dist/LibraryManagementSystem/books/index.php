<?php
include_once __DIR__ . '/../config/database.php';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Books - Library</title>
    </head>
    <body class="p-4">
        <div class="container">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Books</h1>
            <p>
                <a href="add.php" class="button">Add Book</a>
                <a href="search.php" class="button outline">Search</a>
            </p>

    <?php
    $sql = "SELECT * FROM books ORDER BY bookID DESC";
    $res = mysqli_query($conn, $sql);
    if (!$res) {
      echo '<div role="alert" class="notice notice-danger">Query error: ' . mysqli_error($conn) . '</div>';
    }
    ?>

            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Copies</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
        <?php while ($row = mysqli_fetch_assoc($res)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['bookID']); ?></td>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['author']); ?></td>
                        <td><?php echo htmlspecialchars($row['category']); ?></td>
                        <td><?php echo htmlspecialchars($row['price']); ?></td>
                        <td><?php echo htmlspecialchars($row['copies']); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['bookID']; ?>" class="button small outline">Edit</a>
                            <a href="delete.php?id=<?php echo $row['bookID']; ?>" class="button small danger-action" onclick="return confirm('Delete this book?');">Delete</a>
                        </td>
                    </tr>
        <?php endwhile; ?>
                </tbody>
            </table>
        </div>
  
    </body>
</html>
