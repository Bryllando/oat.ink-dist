<?php
include_once __DIR__ . '/../config/database.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id > 0) {
    $sql = "DELETE FROM books WHERE bookID={$id} LIMIT 1";
    mysqli_query($conn, $sql);
}
header('Location: index.php');
exit;
