<?php
include_once __DIR__ . '/../config/database.php';

$results = [];
if (!empty($_GET['q'])) {
    $q = mysqli_real_escape_string($conn, $_GET['q']);
    $sql = "SELECT * FROM books WHERE title LIKE '%{$q}%' OR author LIKE '%{$q}%' OR category LIKE '%{$q}%' ORDER BY bookID DESC";
    $res = mysqli_query($conn, $sql);
    if ($res) {
        while ($r = mysqli_fetch_assoc($res)) {
            $results[] = $r;
        }
    }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Search Books</title>
    </head>
    <body class="p-4">
        <div class="container">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Search Books</h1>
            <form class="mb-3 filter-form filter-panel" method="get">
                <div class="input-group">
                    <input name="q" placeholder="Search by title, author or category" value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>">
                    <button class="button">Search</button>
                    <a class="button outline" href="search.php">Clear</a></div>
    
            </form>

    <?php if (!empty($results)): ?>
            <table>
                <thead><tr><th>#</th><th>Title</th><th>Author</th><th>Category</th><th>Copies</th><th>Actions</th></tr></thead>
                <tbody>
        <?php foreach ($results as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['bookID']); ?></td>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['author']); ?></td>
                        <td><?php echo htmlspecialchars($row['category']); ?></td>
                        <td><?php echo htmlspecialchars($row['copies']); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['bookID']; ?>" class="button small outline">Edit</a>
                            <a href="delete.php?id=<?php echo $row['bookID']; ?>" class="button small danger-action" onclick="return confirm('Delete this book?');">Delete</a>
                        </td>
                    </tr>
        <?php endforeach; ?>
                </tbody>
            </table>
    <?php elseif (isset($_GET['q'])): ?>
            <div role="alert" class="notice notice-info">No results found.</div>
    <?php endif; ?>
            <p><a href="index.php" class="button outline">Back to list</a></p>
        </div>
  
    </body>
</html>
