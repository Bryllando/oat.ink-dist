<?php
include_once __DIR__ . '/../config/database.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = (float) $_POST['price'];
    $copies = (int) $_POST['copies'];

    $sql = "UPDATE books SET title='{$title}', author='{$author}', category='{$category}', price={$price}, copies={$copies} WHERE bookID={$id}";
    if (mysqli_query($conn, $sql)) {
      header('Location: index.php');
      exit;
    } else {
      $error = mysqli_error($conn);
      set_flash('error', $error);
    }
}

$res = mysqli_query($conn, "SELECT * FROM books WHERE bookID={$id} LIMIT 1");
$book = mysqli_fetch_assoc($res);
if (!$book) {
    header('Location: index.php');
    exit;
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Edit Book</title>
    </head>
    <body class="p-4">
        <div class="container form-page">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Edit Book</h1>
            <form method="post" class="entry-form form-panel">
                <div class="field-grid">
                    <div class="mb-3">
                        <label for="input-title">Title</label>
                        <input name="title" required value="<?php echo htmlspecialchars($book['title']); ?>" id="input-title">
                    </div>
                    <div class="mb-3">
                        <label for="input-author">Author</label>
                        <input name="author" value="<?php echo htmlspecialchars($book['author']); ?>" id="input-author">
                    </div>
                    <div class="mb-3">
                        <label for="input-category">Category</label>
                        <input name="category" value="<?php echo htmlspecialchars($book['category']); ?>" id="input-category">
                    </div>
                    <div class="mb-3">
                        <label for="input-price">Price</label>
                        <input name="price" type="number" step="0.01" value="<?php echo htmlspecialchars($book['price']); ?>" id="input-price">
                    </div>
                    <div class="mb-3">
                        <label for="input-copies">Copies</label>
                        <input name="copies" type="number" value="<?php echo htmlspecialchars($book['copies']); ?>" id="input-copies">
                    </div>
                </div>
                <div class="form-actions">
                    <button class="button">Update</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
  
    </body>
</html>
