<?php
include_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = (float) $_POST['price'];
    $copies = (int) $_POST['copies'];

    $sql = "INSERT INTO books (title, author, category, price, copies) VALUES ('{$title}','{$author}','{$category}', {$price}, {$copies})";
    if (mysqli_query($conn, $sql)) {
      header('Location: index.php');
      exit;
    } else {
      $error = mysqli_error($conn);
      set_flash('error', $error);
    }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Add Book</title>
    </head>
    <body class="p-4">
        <div class="container form-page">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Add Book</h1>
            <form method="post" class="entry-form form-panel">
                <div class="field-grid">
                    <div class="mb-3">
                        <label for="input-title">Title</label>
                        <input name="title" required id="input-title">
                    </div>
                    <div class="mb-3">
                        <label for="input-author">Author</label>
                        <input name="author" id="input-author">
                    </div>
                    <div class="mb-3">
                        <label for="input-category">Category</label>
                        <input name="category" id="input-category">
                    </div>
                    <div class="mb-3">
                        <label for="input-price">Price</label>
                        <input name="price" type="number" step="0.01" value="0.00" id="input-price">
                    </div>
                    <div class="mb-3">
                        <label for="input-copies">Copies</label>
                        <input name="copies" type="number" value="1" id="input-copies">
                    </div>
                </div>
                <div class="form-actions">
                    <button class="button">Save</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
  
    </body>
</html>
