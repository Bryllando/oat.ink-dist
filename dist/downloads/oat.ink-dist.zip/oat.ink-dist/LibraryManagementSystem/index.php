<?php
require_once __DIR__ . '/config/database.php';
$pageTitle = 'Dashboard';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Library Management System</title>
    </head>
    <body>
  <?php include_once __DIR__ . '/includes/navbar.php'; ?>
        <div class="container">
            <div class="page-heading">
                <h1 class="page-title">Library Management System</h1>
            </div>

            <div class="simple-panel mb-4">
                <ul class="simple-menu">
                    <li><a href="books/index.php"><span>Books</span> </a></li>
                    <li><a href="borrowers/index.php"><span>Borrowers</span> </a></li>
                    <li><a href="borrow/index.php"><span>Borrow and Return</span> </a></li>
                    <li><a href="reports/index.php"><span>Reports</span></a></li>
                </ul>
            </div>
        </div>
  
    </body>
</html>
