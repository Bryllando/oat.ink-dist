<?php
if (!isset($baseUrl)) {
    require_once __DIR__ . '/../config/database.php';
}
$navBase = rtrim($baseUrl, '/');
$currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
?>

<nav class="app-nav mb-4">
    <div class="container-fluid container">
        <a class="app-brand nav-brand" href="<?php echo $navBase; ?>/index.php">Library Management</a>
    
        <div class="nav-region" id="mainNav">
            <ul class="nav-links ms-auto">
                <li><a class="nav-link <?php echo (strpos($currentUri, '/books/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/books/index.php">Books</a></li>
                <li><a class="nav-link <?php echo (strpos($currentUri, '/borrowers/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/borrowers/index.php">Borrowers</a></li>
                <li><a class="nav-link <?php echo (strpos($currentUri, '/borrow/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/borrow/index.php">Borrow / Return</a></li>
                <li><a class="nav-link <?php echo (strpos($currentUri, '/reports/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/reports/index.php">Reports</a></li>
            </ul>
        </div>
    </div>
</nav>
