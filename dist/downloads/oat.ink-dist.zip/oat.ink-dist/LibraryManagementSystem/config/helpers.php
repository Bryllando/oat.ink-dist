<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function esc($s) {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function sanitize_db($conn, $s) {
    return mysqli_real_escape_string($conn, trim($s));
}

function post($name) {
    return isset($_POST[$name]) ? trim($_POST[$name]) : '';
}

function set_flash($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function display_flash() {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        $cls = ($f['type'] === 'success') ? 'success' : 'danger';
        echo '<div role="alert" class="notice notice-' . $cls . '">' . esc($f['msg']) . '</div>';
        unset($_SESSION['flash']);
    }
}

?>
