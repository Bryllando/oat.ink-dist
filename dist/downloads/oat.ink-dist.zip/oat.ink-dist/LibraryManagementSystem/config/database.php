<?php
mysqli_report(MYSQLI_REPORT_OFF);
// Beginner-friendly procedural MySQLi connection
$host = '127.0.0.1';
$user = 'root';
$pass = '';
$db   = 'librarydb';

$conn = @mysqli_connect($host, $user, $pass);
if (!$conn) {
    die('Database connection failed: ' . htmlspecialchars(mysqli_connect_error()));
}

// Auto-create database if not exists
mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS `{$db}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci") or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));
mysqli_select_db($conn, $db) or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));
mysqli_set_charset($conn, 'utf8mb4') or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));

$tables = $conn->query("SHOW TABLES");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($conn->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/../database.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $conn->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($conn->error));
    do {
        if ($result = $conn->store_result()) $result->free();
    } while ($conn->more_results() && $conn->next_result());
    if ($conn->errno) die('Database setup failed: ' . htmlspecialchars($conn->error));
    mysqli_query($conn, "INSERT INTO `books` (`title`,`author`,`category`,`price`,`copies`) VALUES ('Introduction to PHP','Jane Doe','Programming',200.00,3), ('Data Structures and Algorithms','John Smith','Computer Science',350.00,2)");
    mysqli_query($conn, "INSERT INTO `borrowers` (`fname`,`lname`,`course`,`contactNo`) VALUES ('Juan','Dela Cruz','BSCS','09171234567'), ('Maria','Santos','BSIT','09181234567')");
}

// shortcut: project must be inside the web root; use an explicit URL for Apache aliases.
$docRoot = rtrim(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])), '/');
$projectDir = str_replace('\\', '/', dirname(__DIR__));
$baseUrl = substr($projectDir, strlen($docRoot)) . '/';

// Include helper functions
include_once __DIR__ . '/helpers.php';
?>
