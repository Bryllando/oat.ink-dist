<?php
include_once __DIR__ . '/../config/database.php';

$fine_per_day = 10.00; // simple fine rate

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) { header('Location: index.php'); exit; }

$res = mysqli_query($conn, "SELECT * FROM borrow WHERE borrowID={$id} LIMIT 1");
$row = mysqli_fetch_assoc($res);
if (!$row) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $returnDate = isset($_POST['returnDate']) ? mysqli_real_escape_string($conn, $_POST['returnDate']) : '';

  // validate
  try {
    $due = new DateTime($row['dueDate']);
    $ret = new DateTime($returnDate);
  } catch (Exception $e) {
    $error = 'Invalid date format.';
    set_flash('error', $error);
  }

  if (empty($error)) {
    // if already returned, do nothing
    if (!empty($row['returnDate'])) {
      $error = 'This transaction is already returned.';
      set_flash('error', $error);
    }
  }

  if (empty($error)) {
    $fine = 0.00;
    if ($ret > $due) {
      $diff = $due->diff($ret);
      $days = (int) $diff->format('%a');
      $fine = $days * $fine_per_day;
    }

    // update borrow and increment book copies in a transaction
    mysqli_begin_transaction($conn);
    $sql = "UPDATE borrow SET returnDate='{$returnDate}', fine={$fine} WHERE borrowID={$id} AND (returnDate IS NULL)";
    $ok = mysqli_query($conn, $sql);
      if ($ok && mysqli_affected_rows($conn) > 0) {
      // increment copies
      $u = mysqli_query($conn, "UPDATE books SET copies = copies + 1 WHERE bookID={$row['bookID']}");
      if ($u) {
        mysqli_commit($conn);
        header('Location: index.php');
        exit;
      } else {
        mysqli_rollback($conn);
          $error = 'Failed to update book copies.';
          set_flash('error', $error);
      }
    } else {
      mysqli_rollback($conn);
      $error = mysqli_error($conn);
      set_flash('error', $error);
    }
  }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Return Book</title>
    </head>
    <body class="p-4">
        <div class="container form-page">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Return Book</h1>
            <form method="post" class="entry-form form-panel">
                <div class="mb-3">
                    <label for="input-returnDate">Return Date</label>
                    <input name="returnDate" type="date" value="<?php echo date('Y-m-d'); ?>" required id="input-returnDate">
                </div>
                <div class="form-actions">
                    <button class="button">Process Return</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
            <p class="mt-3"><strong>Borrow Info:</strong><br>
      Borrow Date: <?php echo htmlspecialchars($row['borrowDate']); ?><br>
      Due Date: <?php echo htmlspecialchars($row['dueDate']); ?>
            </p>
        </div>
  
    </body>
</html>
