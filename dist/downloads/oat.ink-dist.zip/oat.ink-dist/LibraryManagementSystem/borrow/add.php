<?php
include_once __DIR__ . '/../config/database.php';

// Default fine per day
$fine_per_day = 10.00;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $borrowerID = isset($_POST['borrowerID']) ? (int) $_POST['borrowerID'] : 0;
  $bookID = isset($_POST['bookID']) ? (int) $_POST['bookID'] : 0;
  $borrowDate = isset($_POST['borrowDate']) ? mysqli_real_escape_string($conn, $_POST['borrowDate']) : '';
  $dueDate = isset($_POST['dueDate']) ? mysqli_real_escape_string($conn, $_POST['dueDate']) : '';

  // Basic validation
  if ($borrowerID <= 0 || $bookID <= 0) {
    $error = 'Please select a borrower and a book.';
  } else {
    // verify borrower exists
    $bRes = mysqli_query($conn, "SELECT borrowerID FROM borrowers WHERE borrowerID={$borrowerID} LIMIT 1");
    if (!($bRes && mysqli_num_rows($bRes))) {
      $error = 'Selected borrower not found.';
      set_flash('error', $error);
    }
  }

  // verify book and copies availability
  if (empty($error)) {
    $bkRes = mysqli_query($conn, "SELECT bookID, copies FROM books WHERE bookID={$bookID} LIMIT 1");
    $bk = $bkRes ? mysqli_fetch_assoc($bkRes) : null;
    if (!$bk) {
      $error = 'Selected book not found.';
      set_flash('error', $error);
    } elseif ((int)$bk['copies'] <= 0) {
      $error = 'No copies available for this book.';
      set_flash('error', $error);
    }
  }

  // validate dates
  if (empty($error)) {
    try {
      $bd = new DateTime($borrowDate);
      $dd = new DateTime($dueDate);
      if ($dd < $bd) { $error = 'Due date must be after borrow date.'; }
    } catch (Exception $e) {
      $error = 'Invalid date format.';
      set_flash('error', $error);
    }
  }

  if (empty($error)) {
    // perform insert and decrement copies in a transaction
    mysqli_begin_transaction($conn);
    $sql = "INSERT INTO borrow (borrowerID, bookID, borrowDate, dueDate) VALUES ({$borrowerID}, {$bookID}, '{$borrowDate}', '{$dueDate}')";
    $ok = mysqli_query($conn, $sql);
      if ($ok) {
      $u = mysqli_query($conn, "UPDATE books SET copies = copies - 1 WHERE bookID={$bookID} AND copies > 0");
      if ($u && mysqli_affected_rows($conn) > 0) {
        mysqli_commit($conn);
        header('Location: index.php');
        exit;
      } else {
        mysqli_rollback($conn);
          $error = 'Failed to decrement book copies.';
          set_flash('error', $error);
      }
    } else {
      mysqli_rollback($conn);
        $error = mysqli_error($conn);
        set_flash('error', $error);
    }
  }
}

$borrowers = mysqli_query($conn, "SELECT borrowerID, fname, lname FROM borrowers ORDER BY fname");
$books = mysqli_query($conn, "SELECT bookID, title, copies FROM books ORDER BY title");
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>New Borrow</title>
    </head>
    <body class="p-4">
        <div class="container form-page">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Borrow a Book</h1>
            <form method="post" class="entry-form form-panel">
                <div class="field-grid">
                    <div class="mb-3">
                        <label for="input-borrowerID">Borrower</label>
                        <select name="borrowerID" required id="input-borrowerID">
                            <option value="">Select borrower</option>
          <?php while ($b = mysqli_fetch_assoc($borrowers)): ?>
                            <option value="<?php echo $b['borrowerID']; ?>"><?php echo htmlspecialchars($b['fname'].' '.$b['lname']); ?></option>
          <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="input-bookID">Book</label>
                        <select name="bookID" required id="input-bookID">
                            <option value="">Select book</option>
          <?php while ($bk = mysqli_fetch_assoc($books)): ?>
                            <option value="<?php echo $bk['bookID']; ?>"><?php echo htmlspecialchars($bk['title']); ?> (<?php echo $bk['copies']; ?>)</option>
          <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="input-borrowDate">Borrow Date</label>
                        <input name="borrowDate" type="date" value="<?php echo date('Y-m-d'); ?>" required id="input-borrowDate">
                    </div>
                    <div class="mb-3">
                        <label for="input-dueDate">Due Date</label>
                        <input name="dueDate" type="date" value="<?php echo date('Y-m-d', strtotime('+7 days')); ?>" required id="input-dueDate">
                    </div>
                </div>
                <div class="form-actions">
                    <button class="button">Borrow</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
  
    </body>
</html>
