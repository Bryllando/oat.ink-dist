<?php
include_once __DIR__ . '/../config/database.php';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Borrow Transactions</title>
    </head>
    <body class="p-4">
        <div class="container">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Borrow Transactions</h1>
            <p>
                <a href="add.php" class="button">New Borrow</a>
            </p>

    <?php
    $sql = "SELECT b.*, br.fname, br.lname, bk.title FROM borrow b
            LEFT JOIN borrowers br ON b.borrowerID = br.borrowerID
            LEFT JOIN books bk ON b.bookID = bk.bookID
            ORDER BY b.borrowID DESC";
    $res = mysqli_query($conn, $sql);
    ?>

            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Book</th>
                        <th>Borrower</th>
                        <th>Borrow Date</th>
                        <th>Due Date</th>
                        <th>Return Date</th>
                        <th>Fine</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
        <?php while ($row = mysqli_fetch_assoc($res)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['borrowID']); ?></td>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['fname'] . ' ' . $row['lname']); ?></td>
                        <td><?php echo htmlspecialchars($row['borrowDate']); ?></td>
                        <td><?php echo htmlspecialchars($row['dueDate']); ?></td>
                        <td><?php echo htmlspecialchars($row['returnDate'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($row['fine']); ?></td>
                        <td>
            <?php if (empty($row['returnDate'])): ?>
                            <a href="return.php?id=<?php echo $row['borrowID']; ?>" class="button small success-action">Return</a>
            <?php else: ?>
              -
            <?php endif; ?>
                        </td>
                    </tr>
        <?php endwhile; ?>
                </tbody>
            </table>
        </div>
  
    </body>
</html>
