-- Database: librarydb
CREATE DATABASE IF NOT EXISTS `librarydb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `librarydb`;

-- Table: books
CREATE TABLE IF NOT EXISTS `books` (
  `bookID` INT NOT NULL AUTO_INCREMENT,
  `title` TEXT NOT NULL,
  `author` TEXT,
  `category` TEXT,
  `price` DECIMAL(10,2) DEFAULT 0.00,
  `copies` INT DEFAULT 1,
  PRIMARY KEY (`bookID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: borrowers
CREATE TABLE IF NOT EXISTS `borrowers` (
  `borrowerID` INT NOT NULL AUTO_INCREMENT,
  `fname` VARCHAR(100) NOT NULL,
  `lname` VARCHAR(100) NOT NULL,
  `course` VARCHAR(100),
  `contactNo` VARCHAR(50),
  PRIMARY KEY (`borrowerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: borrow (transactions)
CREATE TABLE IF NOT EXISTS `borrow` (
  `borrowID` INT NOT NULL AUTO_INCREMENT,
  `borrowerID` INT NOT NULL,
  `bookID` INT NOT NULL,
  `borrowDate` DATE NOT NULL,
  `dueDate` DATE NOT NULL,
  `returnDate` DATE DEFAULT NULL,
  `fine` DECIMAL(10,2) DEFAULT 0.00,
  PRIMARY KEY (`borrowID`),
  INDEX `idx_borrower` (`borrowerID`),
  INDEX `idx_book` (`bookID`),
  CONSTRAINT `fk_borrow_borrower` FOREIGN KEY (`borrowerID`) REFERENCES `borrowers`(`borrowerID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_borrow_book` FOREIGN KEY (`bookID`) REFERENCES `books`(`bookID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample data (optional): uncomment to insert test rows
-- INSERT INTO `books` (`title`,`author`,`category`,`price`,`copies`) VALUES ('Introduction to PHP','Jane Doe','Programming',200.00,3);
-- INSERT INTO `borrowers` (`fname`,`lname`,`course`,`contactNo`) VALUES ('Juan','Dela Cruz','BSCS','09171234567');