<?php
include_once __DIR__ . '/../config/database.php';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Borrowers - Library</title>
    </head>
    <body class="p-4">
        <div class="container">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Borrowers</h1>
            <p>
                <a href="add.php" class="button">Add Borrower</a>
                <a href="search.php" class="button outline">Search</a>
            </p>

    <?php
    $sql = "SELECT * FROM borrowers ORDER BY borrowerID DESC";
    $res = mysqli_query($conn, $sql);
    ?>

            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Course</th>
                        <th>Contact</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
        <?php while ($row = mysqli_fetch_assoc($res)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['borrowerID']); ?></td>
                        <td><?php echo htmlspecialchars($row['fname']); ?></td>
                        <td><?php echo htmlspecialchars($row['lname']); ?></td>
                        <td><?php echo htmlspecialchars($row['course']); ?></td>
                        <td><?php echo htmlspecialchars($row['contactNo']); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['borrowerID']; ?>" class="button small outline">Edit</a>
                            <a href="delete.php?id=<?php echo $row['borrowerID']; ?>" class="button small danger-action" onclick="return confirm('Delete this borrower?');">Delete</a>
                        </td>
                    </tr>
        <?php endwhile; ?>
                </tbody>
            </table>
        </div>
  
    </body>
</html>
