<?php
include_once __DIR__ . '/../config/database.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($id <= 0) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $course = mysqli_real_escape_string($conn, $_POST['course']);
    $contactNo = mysqli_real_escape_string($conn, $_POST['contactNo']);

    $sql = "UPDATE borrowers SET fname='{$fname}', lname='{$lname}', course='{$course}', contactNo='{$contactNo}' WHERE borrowerID={$id}";
    if (mysqli_query($conn, $sql)) {
      header('Location: index.php');
      exit;
    } else {
      $error = mysqli_error($conn);
      set_flash('error', $error);
    }
}

$res = mysqli_query($conn, "SELECT * FROM borrowers WHERE borrowerID={$id} LIMIT 1");
$b = mysqli_fetch_assoc($res);
if (!$b) { header('Location: index.php'); exit; }
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Edit Borrower</title>
    </head>
    <body class="p-4">
        <div class="container form-page">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Edit Borrower</h1>
            <form method="post" class="entry-form form-panel">
                <div class="field-grid">
                    <div class="mb-3">
                        <label for="input-fname">First Name</label>
                        <input name="fname" required value="<?php echo htmlspecialchars($b['fname']); ?>" id="input-fname">
                    </div>
                    <div class="mb-3">
                        <label for="input-lname">Last Name</label>
                        <input name="lname" required value="<?php echo htmlspecialchars($b['lname']); ?>" id="input-lname">
                    </div>
                    <div class="mb-3">
                        <label for="input-course">Course</label>
                        <input name="course" value="<?php echo htmlspecialchars($b['course']); ?>" id="input-course">
                    </div>
                    <div class="mb-3">
                        <label for="input-contactNo">Contact No</label>
                        <input name="contactNo" value="<?php echo htmlspecialchars($b['contactNo']); ?>" id="input-contactNo">
                    </div>
                </div>
                <div class="form-actions">
                    <button class="button">Update</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
  
    </body>
</html>
