<?php
include_once __DIR__ . '/../config/database.php';

$results = [];
if (!empty($_GET['q'])) {
    $q = mysqli_real_escape_string($conn, $_GET['q']);
    $sql = "SELECT * FROM borrowers WHERE fname LIKE '%{$q}%' OR lname LIKE '%{$q}%' OR course LIKE '%{$q}%' ORDER BY borrowerID DESC";
    $res = mysqli_query($conn, $sql);
    if ($res) {
        while ($r = mysqli_fetch_assoc($res)) { $results[] = $r; }
    }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Search Borrowers</title>
    </head>
    <body class="p-4">
        <div class="container">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Search Borrowers</h1>
            <form class="mb-3 filter-form filter-panel" method="get">
                <div class="input-group">
                    <input name="q" placeholder="Search by name or course" value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>">
                    <button class="button">Search</button>
                    <a class="button outline" href="search.php">Clear</a></div>
    
            </form>

    <?php if (!empty($results)): ?>
            <table>
                <thead><tr><th>#</th><th>First</th><th>Last</th><th>Course</th><th>Contact</th><th>Actions</th></tr></thead>
                <tbody>
        <?php foreach ($results as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['borrowerID']); ?></td>
                        <td><?php echo htmlspecialchars($row['fname']); ?></td>
                        <td><?php echo htmlspecialchars($row['lname']); ?></td>
                        <td><?php echo htmlspecialchars($row['course']); ?></td>
                        <td><?php echo htmlspecialchars($row['contactNo']); ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['borrowerID']; ?>" class="button small outline">Edit</a>
                            <a href="delete.php?id=<?php echo $row['borrowerID']; ?>" class="button small danger-action" onclick="return confirm('Delete this borrower?');">Delete</a>
                        </td>
                    </tr>
        <?php endforeach; ?>
                </tbody>
            </table>
    <?php elseif (isset($_GET['q'])): ?>
            <div role="alert" class="notice notice-info">No results found.</div>
    <?php endif; ?>
            <p><a href="index.php" class="button outline">Back to list</a></p>
        </div>
  
    </body>
</html>
