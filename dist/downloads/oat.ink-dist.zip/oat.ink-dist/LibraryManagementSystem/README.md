> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

Step 2: First prompt to Copilot

Open an empty README.md or comment block and write:

Create a simple offline Library Management System using:

- PHP procedural mysqli
- MySQL using XAMPP
- Oat UI local files only
- No internet connection required
- Simple CRUD operations
- Designed for a school skills test
- Keep the code beginner-friendly
- Do not use OOP, frameworks, AJAX, Composer, or APIs

Folder structure:

config/
assets/
books/
borrowers/
borrow/
reports/

Requirements:

BOOKS MODULE
- Add Book
- Search Book
- Edit Book
- Delete Book
- View all Books

BORROWERS MODULE
- Add Borrower
- Search Borrower
- Edit Borrower
- Delete Borrower
- View all Borrowers

BORROW TRANSACTION MODULE
- Borrow a Book
- Return a Book
- Calculate Fine
- View Transactions

REPORTS MODULE
- Display records by category
- Use COUNT()
- Use SUM()

Create database.sql first.
Step 3: Tell Copilot to make the database
Create the MySQL database schema for XAMPP phpMyAdmin.

Database name:
librarydb

Tables:
books
borrowers
borrow

Use proper primary keys and foreign keys.

Output only SQL.
Step 4: Create database connection

Create:

config/database.php

Then tell Copilot:

Create a beginner-friendly PHP mysqli connection file.

Requirements:
- procedural mysqli
- localhost
- username root
- empty password
- database librarydb
- show connection error if failed
Step 5: Create Books Module

Inside:

books/

Tell Copilot:

Create a simple PHP CRUD module for books.

Fields:
bookID
title
author
category
price
copies

Files:
index.php
add.php
edit.php
delete.php
search.php

Requirements:
- Bootstrap local CSS
- procedural mysqli
- beginner friendly
- suitable for a college skills test
- no AJAX
- no JavaScript frameworks
Step 6: Create Borrowers Module
Create a simple Borrowers CRUD module.

Fields:
borrowerID
fname
lname
course
contactNo

Files:
index.php
add.php
edit.php
delete.php
search.php

Use procedural PHP mysqli.
Step 7: Create Borrow Module
Create a borrow transaction module.

Requirements:
- select borrower
- select book
- borrow date
- due date
- return date
- fine

Compute fine if overdue.

Files:
index.php
add.php
return.php
Step 8: Create Reports
Create a reports page.

Requirements:
- filter by category
- display:
    book title
    borrower name
    borrow date
    due date
    fine

Use SQL aggregate functions:

COUNT()
SUM()

Display:
- Total Borrowed Books
- Total Returned Books
- Total Fine Collected
For a skills test, don't overengineer.

Instead of this:

MVC
Controllers
Repositories
Services
Classes
Composer
AJAX
REST APIs
Authentication

Do this:

index.php
add.php
edit.php
delete.php
search.php
database.php
assets/css/oat.min.css
assets/js/oat.min.js
style.css
My actual strategy if I wanted 10–15 points quickly:
✓ Database works          (4 pts)
✓ Add works               (2 pts)
✓ Search works            (2 pts)

---

# Project Status

This repository now contains a working Library Management System template built with:
- procedural PHP + MySQLi
- XAMPP / localhost database
- Oat UI local assets only
- simple CRUD modules for Books, Borrowers, Borrow transactions, and Reports
- server-side sanitization, flash messaging, and a mobile hamburger menu

## What’s done
- `database.sql` created with `books`, `borrowers`, and `borrow` tables
- `config/database.php` and `config/helpers.php` added
- `books/`, `borrowers/`, `borrow/`, and `reports/` modules created
- responsive navbar and uniform error handling included
- borrow and return logic decrements/increments book copies and computes fines

## Reusing this for a new system
To start an Event Registration System next, use the same structure and workflow:

1. Copy this repository folder to a new project folder (for example, `EventRegistrationSystem`).
2. Update `README.md` with the new system requirements.
3. Create a new `database.sql` for your event system schema.
4. Keep `config/database.php` and `config/helpers.php` as the shared starter base.
5. Create modules with the same file pattern:
   - `events/index.php`, `events/add.php`, `events/edit.php`, `events/delete.php`, `events/search.php`
   - `attendees/index.php`, `attendees/add.php`, `attendees/edit.php`, `attendees/delete.php`, `attendees/search.php`
   - `registrations/index.php`, `registrations/add.php`, `registrations/return.php` (or equivalent)
   - `reports/index.php`
6. Use local Oat assets in `assets/css/` and `assets/js/`.

## Why this is reusable
- The folder layout is generic and easy to adapt.
- `config/database.php` and `config/helpers.php` provide a reusable foundation.
- The UI pattern is consistent across modules.
- The same SQL/CRUD workflow applies to event registration data.

## Notes
- Yes, it is okay to move on to the next system now.
- Keep the same beginner-friendly approach: simple forms, procedural code, and no AJAX.
- Preserve the `includes/navbar.php` pattern for a mobile-ready menu.

## Next steps for event system
- define event fields and attendee fields
- create `database.sql` for event tables
- build module pages using the same `index/add/edit/delete/search` pattern
- add report filters and summary aggregates as needed

✓ Edit works              (2 pts)
✓ Delete works            (2 pts)
✓ Display table works     (2 pts)
✓ COUNT() works           (1 pt)
✓ SUM() works             (1 pt)

Ignore:
✗ Fancy animations
✗ Login systems
✗ AJAX
✗ Responsive perfection
✗ Security perfection
✗ Professional architecture
The most important prompt to put at the top of EVERY Copilot request:
IMPORTANT:

This is a college skills test project.

Requirements:
- PHP procedural mysqli only
- XAMPP localhost
- MySQL
- Bootstrap local files only
- Offline ready
- No internet required
- No frameworks
- No OOP
- No Composer
- No AJAX
- Beginner-friendly code
- Easy to understand
- Prioritize passing the skills test rather than enterprise architecture

