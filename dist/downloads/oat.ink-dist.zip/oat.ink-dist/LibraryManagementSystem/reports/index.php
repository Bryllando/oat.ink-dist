<?php
include_once __DIR__ . '/../config/database.php';

$category = isset($_GET['category']) ? mysqli_real_escape_string($conn, $_GET['category']) : '';

$categories = [];
$resC = mysqli_query($conn, "SELECT DISTINCT category FROM books WHERE category IS NOT NULL AND category <> '' ORDER BY category");
while ($c = mysqli_fetch_assoc($resC)) { $categories[] = $c['category']; }

$where = '';
if ($category !== '') {
    $where = "WHERE bk.category = '" . mysqli_real_escape_string($conn, $category) . "'";
}

$sql = "SELECT b.borrowID, bk.title, bk.author, CONCAT(br.fname,' ',br.lname) AS borrowerName, b.borrowDate, b.dueDate, b.returnDate, b.fine
        FROM borrow b
        LEFT JOIN books bk ON b.bookID = bk.bookID
        LEFT JOIN borrowers br ON b.borrowerID = br.borrowerID
        {$where}
        ORDER BY b.borrowDate DESC";

$res = mysqli_query($conn, $sql);

// aggregates
$aggSql = "SELECT
    COUNT(*) AS totalBorrowed,
    SUM(b.fine) AS totalFine,
    SUM(CASE WHEN b.returnDate IS NOT NULL THEN 1 ELSE 0 END) AS totalReturned,
    SUM(CASE WHEN b.returnDate IS NULL AND b.dueDate < CURDATE() THEN 1 ELSE 0 END) AS totalOverdue
    FROM borrow b
    LEFT JOIN books bk ON b.bookID = bk.bookID
    " . ($category !== '' ? "WHERE bk.category='" . mysqli_real_escape_string($conn, $category) . "'" : "");

$aggRes = mysqli_query($conn, $aggSql);
$agg = mysqli_fetch_assoc($aggRes);

?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
        <title>Reports</title>
    </head>
    <body class="p-4">
        <div class="container">
    <?php include_once __DIR__ . '/../includes/navbar.php'; display_flash(); ?>
            <h1 class="mb-3 page-title">Reports - Borrow Transactions by Category</h1>
            <form class="mb-3 filter-form filter-panel" method="get">
                <div class="row g-2 items-center">
                    <div class="auto-col">
                        <select name="category">
                            <option value="">-- All Categories --</option>
            <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $cat === $category ? 'selected' : ''; ?>><?php echo htmlspecialchars($cat); ?></option>
            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="auto-col filter-actions">
                        <button class="button">Filter</button>
                        <a class="button outline" href="index.php">Clear</a></div>
                </div>
    
            </form>

            <div class="mb-3">
                <strong>Totals:</strong>
                <ul>
                    <li>Total Borrowed Books: <?php echo (int) $agg['totalBorrowed']; ?></li>
                    <li>Total Returned Books: <?php echo (int) $agg['totalReturned']; ?></li>
                    <li>Total Overdue Books: <?php echo (int) $agg['totalOverdue']; ?></li>
                    <li>Total Fine Collected: <?php echo number_format((float)$agg['totalFine'],2); ?></li>
                </ul>
            </div>

            <table>
                <thead>
                    <tr><th>#</th><th>Book Title</th><th>Author</th><th>Borrower</th><th>Borrow Date</th><th>Due Date</th><th>Return Date</th><th>Fine</th></tr>
                </thead>
                <tbody>
        <?php while ($r = mysqli_fetch_assoc($res)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($r['borrowID']); ?></td>
                        <td><?php echo htmlspecialchars($r['title']); ?></td>
                        <td><?php echo htmlspecialchars($r['author']); ?></td>
                        <td><?php echo htmlspecialchars($r['borrowerName']); ?></td>
                        <td><?php echo htmlspecialchars($r['borrowDate']); ?></td>
                        <td><?php echo htmlspecialchars($r['dueDate']); ?></td>
                        <td><?php echo htmlspecialchars($r['returnDate'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($r['fine']); ?></td>
                    </tr>
        <?php endwhile; ?>
                </tbody>
            </table>
        </div>
  
    </body>
</html>
