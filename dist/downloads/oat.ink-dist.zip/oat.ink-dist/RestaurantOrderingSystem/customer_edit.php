<?php
require_once 'db.php';
$id = (int)($_GET['id'] ?? 0);
$q = mysqli_query($conn, "SELECT * FROM customers WHERE customerID = $id");
$r = mysqli_fetch_assoc($q);
if (!$r) { header('Location: customers.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fname = mysqli_real_escape_string($conn, $_POST['customerFName']);
    $lname = mysqli_real_escape_string($conn, $_POST['customerLName']);
    $contact = mysqli_real_escape_string($conn, $_POST['contactNo']);
    
    if (mysqli_query($conn, "UPDATE customers SET customerFName='$fname', customerLName='$lname', contactNo='$contact' WHERE customerID=$id")) {
        header("Location: customers.php?msg=Customer+Updated&type=success");
        exit;
    } else {
        $error = "Error updating customer: " . mysqli_error($conn);
    }
}
include 'header.php';
?>
<div class="card">
    <h1 class="page-title">Edit Customer</h1>
    <?php if(isset($error)) echo "<div role='alert' class='notice notice-warning'>$error</div>"; ?>
    <form method="POST" class="entry-form">
        <div class="field-grid">
            <div class="form-group"><label for="input-customerFName">First Name:</label>
                <input type="text" name="customerFName" value="<?php echo htmlspecialchars($r['customerFName']); ?>" required id="input-customerFName"></div>
        
            <div class="form-group"><label for="input-customerLName">Last Name:</label>
                <input type="text" name="customerLName" value="<?php echo htmlspecialchars($r['customerLName']); ?>" required id="input-customerLName"></div>
        
            <div class="form-group"><label for="input-contactNo">Contact Number:</label>
                <input type="text" name="contactNo" value="<?php echo htmlspecialchars($r['contactNo']); ?>" required id="input-contactNo"></div>
        </div>
        
        <div class="form-actions">
            <button type="submit" class="button">Save</button>
            <a href="customers.php" class="button outline">Cancel</a>
        </div>
    </form>
</div>
<?php include 'footer.php'; ?>
