<?php
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fname = mysqli_real_escape_string($conn, $_POST['customerFName']);
    $lname = mysqli_real_escape_string($conn, $_POST['customerLName']);
    $contact = mysqli_real_escape_string($conn, $_POST['contactNo']);
    
    if (mysqli_query($conn, "INSERT INTO customers (customerFName, customerLName, contactNo) VALUES ('$fname', '$lname', '$contact')")) {
        header("Location: customers.php?msg=Customer+Added&type=success");
        exit;
    } else {
        $error = "Error adding customer: " . mysqli_error($conn);
    }
}
include 'header.php';
?>
<div class="card">
    <h1 class="page-title">Add Customer</h1>
    <?php if(isset($error)) echo "<div role='alert' class='notice notice-warning'>$error</div>"; ?>
    <form method="POST" class="entry-form">
        <div class="field-grid">
            <div class="form-group"><label for="input-customerFName">First Name:</label>
                <input type="text" name="customerFName" required id="input-customerFName"></div>
        
            <div class="form-group"><label for="input-customerLName">Last Name:</label>
                <input type="text" name="customerLName" required id="input-customerLName"></div>
        
            <div class="form-group"><label for="input-contactNo">Contact Number:</label>
                <input type="text" name="contactNo" required id="input-contactNo"></div>
        </div>
        
        <div class="form-actions">
            <button type="submit" class="button">Save</button>
            <a href="customers.php" class="button outline">Cancel</a>
        </div>
    </form>
</div>
<?php include 'footer.php'; ?>
