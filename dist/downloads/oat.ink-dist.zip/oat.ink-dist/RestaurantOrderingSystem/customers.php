<?php
require_once 'db.php';

if (isset($_GET['delete_id'])) {
    $delId = (int)$_GET['delete_id'];
    if (mysqli_query($conn, "DELETE FROM customers WHERE customerID = $delId")) {
        header("Location: customers.php?msg=Customer+Deleted&type=success");
        exit;
    } else {
        header("Location: customers.php?msg=Cannot+delete+customer+(may+have+orders)&type=warning");
        exit;
    }
}

include 'header.php';
?>
<div class="card">
    <h1 class="page-title">Customers Management</h1>
    <a href="customer_add.php" class="button" style="margin-bottom:15px;">Add Customer</a>
    
    <?php
    if (isset($_GET['msg'])) {
        $msg = htmlspecialchars($_GET['msg']);
        if (isset($_GET['type']) && $_GET['type'] == 'success') echo "<div role='alert' class='notice notice-success'>$msg</div>";
        else echo "<div role='alert' class='notice notice-warning'>$msg</div>";
    }
    ?>

    <table>
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Contact No.</th>
            <th>Actions</th>
        </tr>
        <?php
        $q = mysqli_query($conn, "SELECT * FROM customers");
        while ($r = mysqli_fetch_assoc($q)) {
            echo "<tr>";
            echo "<td>{$r['customerID']}</td>";
            echo "<td>" . htmlspecialchars($r['customerFName']) . "</td>";
            echo "<td>" . htmlspecialchars($r['customerLName']) . "</td>";
            echo "<td>" . htmlspecialchars($r['contactNo']) . "</td>";
            echo "<td>
                <a href='customer_edit.php?id={$r['customerID']}' class='button small outline'>Edit</a>
                <a href='customers.php?delete_id={$r['customerID']}' class='button small danger-action' onclick='return confirm(\"Are you sure?\")'>Delete</a>
            </td>";
            echo "</tr>";
        }
        ?>
    </table>
</div>
<?php include 'footer.php'; ?>
