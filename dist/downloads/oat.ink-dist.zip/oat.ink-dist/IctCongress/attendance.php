<?php
require 'db.php';
$msg = "";
$msgType = "info"; 
$student = null;

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $res = $conn->query("SELECT * FROM Registration WHERE idNum='$id'");
    if ($res->num_rows == 0) {
        $msg = "NOT YET REGISTERED!";
        $msgType = "warning";
    } else {
        $student = $res->fetch_assoc();
    }
}

if (isset($_GET['attend'])) {
    $id = $_GET['attend'];
    $res = $conn->query("SELECT * FROM Registration WHERE idNum='$id'");
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if ($row['attended'] == 'Yes') {
            $msg = "Student's Attendance RECORD ALREADY EXIST!";
            $msgType = "warning";
        } else {
            $conn->query("UPDATE Registration SET attended='Yes' WHERE idNum='$id'");
            $msg = "Student Attendance is SUCCESSFULLY RECORDED!";
            $msgType = "success";
            $res = $conn->query("SELECT * FROM Registration WHERE idNum='$id'");
            $student = $res->fetch_assoc();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Attendance - ICT Congress</title>
    
    </head>
    <body>
        <nav class="app-nav">
            <a href="index.php" class="app-brand">ICT Congress</a>
            <div class="nav-links">
                <a href="registration.php" class="nav-link">Registration</a>
                <a href="attendance.php" class="nav-link active">Attendance</a>
                <a href="raffle.php" class="nav-link">Raffle</a>
            </div>
        </nav>
        <div class="page-container">
            <div class="page-title">Attendance Tracker</div>
        
            <div class="card" style="margin-bottom: 30px;">
                <form method="POST" class="form-inline entry-form" style="margin-bottom: 0;">
                    <div class="form-group"><label for="input-id">Id</label>
                        <input type="text" name="id" placeholder="Scan or Type ID Number" style="flex: 1;" required autocomplete="off" autofocus id="input-id"></div> 
                    <div class="form-actions">
                        <button type="submit" name="submit" class="button">Verify Status</button>
                    </div>
                </form>
            </div>

        <?php if ($msg): ?>
            <div role="alert" class="notice notice-<?= $msgType ?>">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <?php if ($student): ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID Number</th>
                            <th>Name</th>
                            <th>Campus</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?= $student['idNum'] ?></td>
                            <td style="font-weight:bold;"><?= htmlspecialchars($student['studFName'] . ' ' . $student['studLName']) ?></td>
                            <td><?= $student['campus'] ?></td>
                            <td>
                            <?php if($student['attended'] == 'Yes'): ?>
                                <span>Verified</span>
                            <?php else: ?>
                                <a href="attendance.php?attend=<?= $student['idNum'] ?>" class="button">Mark Attended</a>
                            <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        </div>
    </body>
</html>
