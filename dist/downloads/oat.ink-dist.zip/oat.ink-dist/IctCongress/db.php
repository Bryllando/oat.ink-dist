<?php
mysqli_report(MYSQLI_REPORT_OFF);
$host = '127.0.0.1';
$user = 'root';
$password = '';
$conn = @mysqli_connect($host, $user, $password);
if (!$conn) {
    die('Database connection failed: ' . htmlspecialchars(mysqli_connect_error()));
}

$conn->query("CREATE DATABASE IF NOT EXISTS IctCongress CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci") or die('Database setup failed: ' . htmlspecialchars($conn->error));
$conn->select_db('IctCongress') or die('Database setup failed: ' . htmlspecialchars($conn->error));
$conn->set_charset('utf8mb4') or die('Database setup failed: ' . htmlspecialchars($conn->error));

$tables = $conn->query("SHOW TABLES");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($conn->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/Registration.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $conn->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($conn->error));
    do {
        if ($result = $conn->store_result()) $result->free();
    } while ($conn->more_results() && $conn->next_result());
    if ($conn->errno) die('Database setup failed: ' . htmlspecialchars($conn->error));
}
?>
