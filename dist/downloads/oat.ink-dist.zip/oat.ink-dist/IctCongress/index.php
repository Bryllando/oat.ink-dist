<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Dashboard - ICT Congress</title>
    
    </head>
    <body>
        <nav class="app-nav">
            <a href="index.php" class="app-brand">ICT Congress</a>
            <div class="nav-links">
                <a href="registration.php" class="nav-link">Registration</a>
                <a href="attendance.php" class="nav-link">Attendance</a>
                <a href="raffle.php" class="nav-link">Raffle</a>
            </div>
        </nav>
        <main class="container">
            <h1 class="page-title">ICT Congress</h1>
            <ul class="simple-menu">
                <li><a href="registration.php">Registration</a></li>
                <li><a href="attendance.php">Attendance</a></li>
                <li><a href="raffle.php">Raffle</a></li>
            </ul>
        </main>
    </body>
</html>
