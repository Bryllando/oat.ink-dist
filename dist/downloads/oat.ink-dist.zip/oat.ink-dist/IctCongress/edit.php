<?php
require 'db.php';
$id = $conn->real_escape_string($_GET['id'] ?? '');
if (isset($_POST['update'])) {
    $campus = $conn->real_escape_string($_POST['campus']);
    $fname = $conn->real_escape_string($_POST['studFName']);
    $lname = $conn->real_escape_string($_POST['studLName']);
    $amount = (float)$_POST['amountPaid'];
    $conn->query("UPDATE Registration SET campus='$campus', studFName='$fname', studLName='$lname', amountPaid='$amount' WHERE idNum='$id'");
    header("Location: registration.php");
    exit();
}
$row = $conn->query("SELECT * FROM Registration WHERE idNum='$id'")->fetch_assoc();
if (!$row) { header('Location: registration.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Edit Registration - ICT Congress</title>
    
    </head>
    <body>
        <nav class="app-nav">
            <a href="index.php" class="app-brand">ICT Congress</a>
            <div class="nav-links">
                <a href="registration.php" class="nav-link active">Registration</a>
            </div>
        </nav>
        <div class="page-container form-page" style="max-width: 600px;">
            <div class="page-title">Edit Entry: <?= htmlspecialchars($row['idNum']) ?></div>
        
            <div class="card">
                <form method="POST" class="entry-form">
                    <div class="field-grid">
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label for="input-studFName">First Name</label>
                            <input type="text" name="studFName" value="<?= htmlspecialchars($row['studFName']) ?>" required id="input-studFName">
                        </div>
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label for="input-studLName">Last Name</label>
                            <input type="text" name="studLName" value="<?= htmlspecialchars($row['studLName']) ?>" required id="input-studLName">
                        </div>
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label for="input-campus">Campus</label>
                            <select name="campus" id="input-campus">
                                <option value="Main" <?= $row['campus']=='Main'?'selected':'' ?>>Main</option>
                                <option value="Banilad" <?= $row['campus']=='Banilad'?'selected':'' ?>>Banilad</option>
                                <option value="LM" <?= $row['campus']=='LM'?'selected':'' ?>>LM</option>
                            </select>
                        </div>
                        <div class="form-group" style="margin-bottom: 30px;">
                            <label for="input-amountPaid">Amount Paid</label>
                            <input type="number" step="0.01" name="amountPaid" value="<?= $row['amountPaid'] ?>" required id="input-amountPaid">
                        </div>
                    </div>
                
                    <div style="display: flex; gap: 15px;" class="form-actions">
                        <button type="submit" name="update" class="button" style="flex: 1;">Save Changes</button>
                        <a href="registration.php" class="button outline" style="flex: 1; text-align: center;">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>
