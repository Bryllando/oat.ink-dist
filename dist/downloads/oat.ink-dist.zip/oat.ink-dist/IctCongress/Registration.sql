CREATE DATABASE IF NOT EXISTS IctCongress;
USE IctCongress;

CREATE TABLE IF NOT EXISTS Registration (
    idNum VARCHAR(50) PRIMARY KEY,
    campus VARCHAR(50),
    studFName VARCHAR(100),
    studLName VARCHAR(100),
    amountPaid DECIMAL(10,2),
    attended VARCHAR(10) DEFAULT 'No'
);
