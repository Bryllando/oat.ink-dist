> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

# UC ICT Congress Registration System

### Objective
This project is an implementation of the Capstone Project 1 Skills Test for the UC ICT Congress Registration System. To stay "under the radar" and achieve a target score of **10 to 15 points** out of the possible 20, the development scope is intentionally limited to a subset of core features while ensuring they are fully functional.

### Target Features & Point Allocation
We will focus on implementing the following modules fully, while deliberately skipping some of the more advanced reports to comfortably score within the 10-15 point range (Target: 12-13 Points).

1. **Menu / Index Page (2 points)**
   - A central navigation hub with links to the functional modules.
2. **Registration (4 points)**
   - CRUD operations (Add, List, Edit, Delete) for the registration table.
   - Includes generating the ID#, Name, Campus, Amount, and Actions list.
3. **Attendance (3 points)**
   - Input ID number mechanism to log attendance.
   - Feedback prompts ("NOT YET REGISTERED", "SUCCESSFULLY RECORDED", "ALREADY EXIST").
4. **Raffle OR Report (Summary) (3-4 points)**
   - We will implement one of these additional modules (e.g., Raffle) to bring the total points to 12-13 points, safely within the 10-15 point threshold without over-delivering.

### Database Schema
* **Backend Tools:** `Registration.sql` 
* **Table:** `Registration`
* **Fields:**
  - `idNum` (PK, text): Student's ID Number
  - `campus` (text): Student's Campus Name
  - `studFName` (text): Student's First Name
  - `studLName` (text): Student's Last Name
  - `amountPaid` (number): Amount Paid
  - `attended` (text): Yes or No

### Skipped Features (Intentional)
To prevent scoring perfectly (20/20) and drawing unwanted attention:
- *Report (By Campus) (4 points)* will likely be skipped or left non-functional.
- Relying on basic styling via basic HTML or minimal CSS (like plain Bootstrap) without advanced modern aesthetic flairs unless strictly necessary.

### Setup Instructions
1. Import `Registration.sql` into your database (e.g., `phpMyAdmin`).
2. Update database connection settings in the relevant connection file.
3. Launch the app locally via XAMPP or similar (e.g., `localhost/IctCongress`).

---

## ⭐ Project Structure Philosophy — Apply to ALL Future Projects

**Keep the folder structure minimal and flat.** This is the preferred approach for all future PHP projects, same as the styling below. Do NOT over-engineer with subfolders, config layers, includes, or assets directories unless the project truly demands it.

### ✅ Preferred: Minimal Flat Structure (use this)
```
ProjectName/
├── styles.css          ← single shared stylesheet
├── db.php              ← single DB connection file
├── index.php           ← dashboard / home
├── [feature].php       ← one file per feature/module
└── [feature].sql       ← database schema
```

### ❌ Avoid: Over-engineered Structure (unnecessary for small projects)
```
ProjectName/
├── assets/css/app.css
├── config/database.php
├── includes/header.php
├── includes/footer.php
├── events/index.php
├── participants/index.php
└── ...
```

### Why Minimal?
- ✅ Faster to build and navigate
- ✅ Easier to understand at a glance
- ✅ No unnecessary abstraction
- ✅ Less chance of path/include errors

> The complex nested structure is only useful for large enterprise apps with many developers. For capstone tests, skills tests, and small projects — **flat is always better.**

---

## UI Style Guide

> **⭐ Preferred Style — Apply to ALL future PHP projects.**
> This is the standard look and layout the developer prefers. When starting any new PHP/HTML project, replicate this structure, color palette, and CSS classes. Copy `assets/css/app.css` into the project root and link it in every page's `<head>` with `<link rel="stylesheet" href="styles.css">`.

### General Rules
- **Font:** `Arial, Helvetica, sans-serif` — standard system font, no Google Fonts import needed.
- **Background:** Light gray `#f4f6f9` on `body`, white `#ffffff` for all cards/tables.
- **Text:** Dark gray `#333333` for headings, `#555555` for secondary/muted text.
- **Border:** All borders use `1px solid #ddd` with `border-radius: 4px` for a flat, non-rounded look.

### Color Palette (Basic Colors Only)

| Purpose       | Color        | Hex Code  |
|---------------|--------------|-----------|
| Primary / Blue | Links, Buttons, Focus | `#007bff` |
| Success / Green | Attendance confirmed | `#28a745` |
| Warning / Yellow | Edit buttons | `#ffc107` |
| Danger / Red | Delete buttons, Error alerts | `#dc3545` |
| Light Gray | Table headers, Badges, Hover | `#f1f1f1` / `#f9f9f9` |
| White | Cards, Navbar, Inputs | `#ffffff` |

### Layout Pattern (Every Page)
Every page must follow this exact structure. The `<nav>` is a **direct child of `<body>`** (NOT inside `.page-container`) so that `position: fixed` spans the full browser width:

```html
<body>
  <!-- Navbar: OUTSIDE page-container so it spans full width -->
  <nav class="navbar">
    <a href="index.php" class="navbar-brand">App Name</a>
    <div class="navbar-nav">
      <a href="page.php" class="nav-link active">Page</a>  <!-- active = blue highlight -->
    </div>
  </nav>

  <!-- All page content goes inside page-container -->
  <div class="page-container">           <!-- max-width: 1000px, centered via margin:auto -->

    <div class="page-title">...</div>    <!-- bold 28px heading -->

    <div class="card">...</div>          <!-- white box with gray border, padding: 30px -->

    <div class="table-container">        <!-- wraps <table>, adds border + rounding -->
      <table>...</table>
    </div>

  </div>
</body>
```

### Form Inputs
- Use class `form-control` on all `<input>`, `<select>`.
- Wrap multiple inputs side-by-side in a `<form class="form-inline">` (uses `display: flex; gap: 15px;`).
- For stacked labeled fields (e.g. Edit page), use `<div class="form-group">` with a `<label>` above.

### Buttons

| Class | Color | Use |
|---|---|---|
| `btn btn-primary` | Blue `#007bff` | Main submit/save actions |
| `btn btn-secondary` | White + gray border | Cancel / back actions |
| `btn-action btn-edit` | Yellow `#ffc107` | Inline table Edit action |
| `btn-action btn-delete` | Red `#dc3545` | Inline table Delete action |

### Alerts

| Class | Color | When to use |
|---|---|---|
| `alert alert-success` | Green background | Successful operation |
| `alert alert-warning` | Red/pink background | Error or already-exists warning |

### Table Structure
```html
<div class="table-container">
  <table>
    <thead>
      <tr>
        <th>Column</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Data</td>
        <td>
          <div class="action-buttons">
            <a href="edit.php?id=..." class="btn-action btn-edit">Edit</a>
            <a href="?del=..."      class="btn-action btn-delete">Delete</a>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
</div>
```

### Active Nav Link
Add `class="nav-link active"` to the link matching the current page. This makes the nav pill highlight blue.

```php
<!-- Example in registration.php -->
<a href="registration.php" class="nav-link active">Registration</a>
<a href="attendance.php"   class="nav-link">Attendance</a>
<a href="raffle.php"       class="nav-link">Raffle</a>
```
