<?php
require 'db.php';
if (isset($_GET['del'])) {
    $id = $_GET['del'];
    $conn->query("DELETE FROM Registration WHERE idNum='$id'");
    header("Location: registration.php");
    exit();
}
if (isset($_POST['add'])) {
    $id = $_POST['idNum'];
    $campus = $_POST['campus'];
    $fname = $_POST['studFName'];
    $lname = $_POST['studLName'];
    $amount = $_POST['amountPaid'];
    $conn->query("INSERT INTO Registration (idNum, campus, studFName, studLName, amountPaid, attended) VALUES ('$id', '$campus', '$fname', '$lname', '$amount', 'No')");
    header("Location: registration.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Registration - ICT Congress</title>
    
    </head>
    <body>
        <nav class="app-nav">
            <a href="index.php" class="app-brand">ICT Congress</a>
            <div class="nav-links">
                <a href="registration.php" class="nav-link active">Registration</a>
                <a href="attendance.php" class="nav-link">Attendance</a>
                <a href="raffle.php" class="nav-link">Raffle</a>
            </div>
        </nav>
        <div class="page-container">
            <div class="page-title">Participant Registration</div>
        
            <div class="card" style="margin-bottom: 30px;">
                <form method="POST" class="form-inline entry-form" style="margin-bottom: 0;">
                    <div class="field-grid">
                        <div class="form-group"><label for="input-idNum">Student ID</label>
                            <input type="text" name="idNum" placeholder="Student ID" required id="input-idNum"></div>
                        <div class="form-group"><label for="input-studFName">First Name</label>
                            <input type="text" name="studFName" placeholder="First Name" required id="input-studFName"></div>
                        <div class="form-group"><label for="input-studLName">Last Name</label>
                            <input type="text" name="studLName" placeholder="Last Name" required id="input-studLName"></div>
                        <div class="form-group"><label for="input-campus">Campus</label>
                            <select name="campus" required id="input-campus">
                                <option value="" disabled selected>Campus</option>
                                <option value="Main">Main</option>
                                <option value="Banilad">Banilad</option>
                                <option value="LM">LM</option>
                            </select></div>
                        <div class="form-group"><label for="input-amountPaid">Fee ($)</label>
                            <input type="number" step="0.01" name="amountPaid" placeholder="Fee ($)" required id="input-amountPaid"></div>
                    </div>
                
                    <div class="form-actions">
                        <button type="submit" name="add" class="button">Register Student</button>
                    </div>
                </form>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID Number</th>
                            <th>Full Name</th>
                            <th>Campus</th>
                            <th>Amount Paid</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $result = $conn->query("SELECT * FROM Registration");
                    if($result->num_rows == 0) echo "<tr><td colspan='5' style='text-align:center;'>No users registered yet.</td></tr>";
                    while ($row = $result->fetch_assoc()) {
                        $name = htmlspecialchars($row['studFName'] . ' ' . $row['studLName']);
                        echo "<tr>";
                        echo "<td>{$row['idNum']}</td>";
                        echo "<td><strong>{$name}</strong></td>";
                        echo "<td>{$row['campus']}</td>";
                        echo "<td>$" . number_format($row['amountPaid'], 2) . "</td>";
                        echo "<td>
                                <div class='action-buttons'>
                                    <a href='edit.php?id={$row['idNum']}' class='button small outline'>Edit</a>
                                    <a href='registration.php?del={$row['idNum']}' class='button small danger-action'>Delete</a>
                                </div>
                              </td>";
                        echo "</tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
