<?php
require 'db.php';
$winner = null;

if (isset($_POST['reveal'])) {
    $res = $conn->query("SELECT * FROM Registration WHERE attended='Yes' ORDER BY RAND() LIMIT 1");
    if ($res->num_rows > 0) {
        $winner = $res->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Raffle - ICT Congress</title>
    
    </head>
    <body>
        <nav class="app-nav">
            <a href="index.php" class="app-brand">ICT Congress</a>
            <div class="nav-links">
                <a href="registration.php" class="nav-link">Registration</a>
                <a href="attendance.php" class="nav-link">Attendance</a>
                <a href="raffle.php" class="nav-link active">Raffle</a>
            </div>
        </nav>
        <main class="page-container">
            <h1 class="page-title">Raffle</h1>
            <p>Draw one winner from participants marked as attended.</p>
            <form method="POST">
                <button type="submit" name="reveal">Draw Winner</button>
            </form>
        <?php if ($winner): ?>
            <h2 class="mt-3">Winner</h2>
            <p>Name: <?= htmlspecialchars($winner['studFName'] . ' ' . $winner['studLName']) ?></p>
            <p>ID: <?= htmlspecialchars($winner['idNum']) ?></p>
            <p>Campus: <?= htmlspecialchars($winner['campus']) ?></p>
        <?php endif; ?>
        </main>
    </body>
</html>
