<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM customers WHERE customerID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$c = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = trim($_POST['custFName']);
    $lname = trim($_POST['custLName']);
    $type = trim($_POST['customerType']);
    $contact = trim($_POST['contactNumber']);

    $stmt = $conn->prepare("UPDATE customers SET custFName=?, custLName=?, customerType=?, contactNumber=? WHERE customerID=?");
    $stmt->bind_param("ssssi", $fname, $lname, $type, $contact, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Edit Moviegoer</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 600px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Edit Moviegoer</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="input-custFName">First Name</label>
                            <input type="text" name="custFName" required value="<?php echo htmlspecialchars($c['custFName']); ?>" id="input-custFName">
                        </div>
                        <div class="col-6">
                            <label for="input-custLName">Last Name</label>
                            <input type="text" name="custLName" required value="<?php echo htmlspecialchars($c['custLName']); ?>" id="input-custLName">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="input-customerType">Customer Classification</label>
                        <select name="customerType" id="input-customerType">
                        <?php foreach(['Regular', 'Student', 'Senior'] as $opt): ?>
                            <option value="<?php echo $opt; ?>" <?php echo $c['customerType'] === $opt ? 'selected' : ''; ?>><?php echo $opt; ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="input-contactNumber">Contact Number</label>
                        <input type="text" name="contactNumber" value="<?php echo htmlspecialchars($c['contactNumber']); ?>" id="input-contactNumber">
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button outline w-100">Update Profile</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to List</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>