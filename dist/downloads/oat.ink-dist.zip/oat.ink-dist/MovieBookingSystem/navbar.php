<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Cinema Booking System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'movies') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>movies/index.php">Movies</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'customers') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>customers/index.php">Moviegoers</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'bookings') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>bookings/index.php">Ticket Bookings</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>