<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM movies WHERE movieID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$m = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['movieTitle']);
    $genre = trim($_POST['genre']);
    $hall = trim($_POST['cinemaHall']);
    $dur = intval($_POST['durationMinutes']);
    $price = floatval($_POST['ticketPrice']);

    $stmt = $conn->prepare("UPDATE movies SET movieTitle=?, genre=?, cinemaHall=?, durationMinutes=?, ticketPrice=? WHERE movieID=?");
    $stmt->bind_param("sssddi", $title, $genre, $hall, $dur, $price, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Edit Movie</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 600px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Edit Movie</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="mb-3">
                        <label for="input-movieTitle">Movie Title</label>
                        <input type="text" name="movieTitle" required value="<?php echo htmlspecialchars($m['movieTitle']); ?>" id="input-movieTitle">
                    </div>
                    <div class="mb-3">
                        <label for="input-genre">Genre</label>
                        <select name="genre" required id="input-genre">
                        <?php foreach(['Action / Adventure', 'Animation / Family', 'Horror / Thriller', 'Sci-Fi / Fantasy', 'Comedy / Romance'] as $g): ?>
                            <option value="<?php echo $g; ?>" <?php echo $m['genre'] === $g ? 'selected' : ''; ?>><?php echo $g; ?></option>
                        <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="input-cinemaHall">Cinema Hall</label>
                        <input type="text" name="cinemaHall" required value="<?php echo htmlspecialchars($m['cinemaHall']); ?>" id="input-cinemaHall">
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="input-durationMinutes">Duration (minutes)</label>
                            <input type="number" name="durationMinutes" required value="<?php echo $m['durationMinutes']; ?>" id="input-durationMinutes">
                        </div>
                        <div class="col-6">
                            <label for="input-ticketPrice">Ticket Price (₱)</label>
                            <input type="number" step="0.01" name="ticketPrice" required value="<?php echo $m['ticketPrice']; ?>" id="input-ticketPrice">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button outline w-100">Update Movie</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to List</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>