<?php
require_once '../database.php';
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $stmt = $conn->prepare("SELECT * FROM movies WHERE movieTitle LIKE ? OR genre LIKE ? OR cinemaHall LIKE ? ORDER BY movieID DESC");
    $param = "%$search%";
    $stmt->bind_param("sss", $param, $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM movies ORDER BY movieID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Movies Management</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Movies Management</h1>
                <a href="add.php" class="button">Add New Movie</a>
            </div>
            <div class="card p-3 card-surface mb-3">
                <form method="GET" class="row g-2 filter-form">
                    <div class="col-10">
                        <input type="text" name="search" placeholder="Search by title, genre, or cinema hall..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-2 filter-actions">
                        <button type="submit" class="button outline ">Search</button>
                        <a class="button outline" href="index.php">Clear</a></div>
            
                </form>
            </div>
            <div class="card card-surface p-0">
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Movie Title</th>
                            <th>Genre</th>
                            <th>Cinema Hall</th>
                            <th>Duration</th>
                            <th>Ticket Price</th>
                            <th class="align-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['movieID']; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['movieTitle']); ?></strong></td>
                            <td><span class="badge surface-muted"><?php echo htmlspecialchars($row['genre']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['cinemaHall']); ?></td>
                            <td><?php echo $row['durationMinutes']; ?> mins</td>
                            <td><strong class="text-primary">₱<?php echo number_format($row['ticketPrice'], 2); ?></strong></td>
                            <td class="align-right">
                                <a href="edit.php?id=<?php echo $row['movieID']; ?>" class="button small outline">Edit</a>
                                <a href="delete.php?id=<?php echo $row['movieID']; ?>" class="button small danger-action" onclick="return confirm('Delete movie?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="align-center py-4 text-light">No movies found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>