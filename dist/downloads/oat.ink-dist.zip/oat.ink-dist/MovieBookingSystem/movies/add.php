<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['movieTitle']);
    $genre = trim($_POST['genre']);
    $hall = trim($_POST['cinemaHall']);
    $dur = intval($_POST['durationMinutes']);
    $price = floatval($_POST['ticketPrice']);

    if ($title && $genre && $price > 0) {
        $stmt = $conn->prepare("INSERT INTO movies (movieTitle, genre, cinemaHall, durationMinutes, ticketPrice) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdd", $title, $genre, $hall, $dur, $price);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Add Movie</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 600px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Add New Movie</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="mb-3">
                        <label for="input-movieTitle">Movie Title</label>
                        <input type="text" name="movieTitle" required placeholder="e.g. Avengers: Secret Wars" id="input-movieTitle">
                    </div>
                    <div class="mb-3">
                        <label for="input-genre">Genre</label>
                        <select name="genre" required id="input-genre">
                            <option value="Action / Adventure">Action / Adventure</option>
                            <option value="Animation / Family">Animation / Family</option>
                            <option value="Horror / Thriller">Horror / Thriller</option>
                            <option value="Sci-Fi / Fantasy">Sci-Fi / Fantasy</option>
                            <option value="Comedy / Romance">Comedy / Romance</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="input-cinemaHall">Cinema Hall</label>
                        <input type="text" name="cinemaHall" required placeholder="e.g. Cinema 1 (IMAX)" id="input-cinemaHall">
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="input-durationMinutes">Duration (minutes)</label>
                            <input type="number" name="durationMinutes" required value="120" id="input-durationMinutes">
                        </div>
                        <div class="col-6">
                            <label for="input-ticketPrice">Ticket Price (₱)</label>
                            <input type="number" step="0.01" name="ticketPrice" required placeholder="350.00" id="input-ticketPrice">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button w-100">Save Movie</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to List</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>