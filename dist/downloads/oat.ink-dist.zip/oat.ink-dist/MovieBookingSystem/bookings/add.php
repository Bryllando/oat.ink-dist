<?php
require_once '../database.php';
$msg = '';

$movies = $conn->query("SELECT * FROM movies ORDER BY movieTitle ASC");
$customers = $conn->query("SELECT * FROM customers ORDER BY custLName ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $movieID = intval($_POST['movieID']);
    $custID = intval($_POST['customerID']);
    $bDate = trim($_POST['bookingDate']);
    $tickets = intval($_POST['numTickets']);
    $mode = trim($_POST['paymentMode']);

    // Fetch movie base ticket price
    $mRow = $conn->query("SELECT ticketPrice FROM movies WHERE movieID = $movieID")->fetch_assoc();
    $basePrice = $mRow ? floatval($mRow['ticketPrice']) : 0;

    // Fetch customer type for discount
    $cRow = $conn->query("SELECT customerType FROM customers WHERE customerID = $custID")->fetch_assoc();
    $custType = $cRow['customerType'] ?? 'Regular';

    $discountRate = ($custType === 'Student' || $custType === 'Senior') ? 0.20 : 0.00;
    $pricePerTicket = $basePrice * (1.0 - $discountRate);
    $totalAmount = $tickets * $pricePerTicket;

    if ($movieID && $custID && $tickets > 0) {
        $stmt = $conn->prepare("INSERT INTO bookings (movieID, customerID, bookingDate, numTickets, totalAmountPaid, paymentMode) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisids", $movieID, $custID, $bDate, $tickets, $totalAmount, $mode);
        if ($stmt->execute()) {
            header("Location: index.php?msg=booked");
            exit;
        } else {
            $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Book Movie Ticket</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 650px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Book Movie Tickets</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="mb-3">
                        <label for="input-movieID">Select Movie</label>
                        <select name="movieID" required id="input-movieID">
                            <option value="">-- Choose Movie --</option>
                        <?php while($m = $movies->fetch_assoc()): ?>
                            <option value="<?php echo $m['movieID']; ?>">
                            <?php echo htmlspecialchars($m['movieTitle'] . ' (' . $m['cinemaHall'] . ') - ₱' . number_format($m['ticketPrice'], 2)); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="input-customerID">Select Moviegoer</label>
                        <select name="customerID" required id="input-customerID">
                            <option value="">-- Choose Moviegoer --</option>
                        <?php while($c = $customers->fetch_assoc()): ?>
                            <option value="<?php echo $c['customerID']; ?>">
                            <?php echo htmlspecialchars($c['custLName'] . ', ' . $c['custFName'] . ' [' . $c['customerType'] . ']'); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                        <small class="text-light">Students and Seniors automatically receive 20% off.</small>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="input-bookingDate">Booking Date</label>
                            <input type="date" name="bookingDate" required value="<?php echo date('Y-m-d'); ?>" id="input-bookingDate">
                        </div>
                        <div class="col-6">
                            <label for="input-numTickets">Number of Tickets</label>
                            <input type="number" name="numTickets" required min="1" value="1" id="input-numTickets">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="input-paymentMode">Payment Mode</label>
                        <select name="paymentMode" id="input-paymentMode">
                            <option value="Cash">Cash</option>
                            <option value="GCash">GCash</option>
                            <option value="Credit Card">Credit Card</option>
                        </select>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button w-100">Confirm Ticket Purchase</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to Bookings</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>