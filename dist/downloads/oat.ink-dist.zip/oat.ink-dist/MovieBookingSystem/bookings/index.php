<?php
require_once '../database.php';

$query = "SELECT b.*, m.movieTitle, m.cinemaHall, m.ticketPrice, c.custFName, c.custLName, c.customerType 
          FROM bookings b
          JOIN movies m ON b.movieID = m.movieID
          JOIN customers c ON b.customerID = c.customerID
          ORDER BY b.bookingID DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Ticket Bookings</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Ticket Bookings</h1>
                <a href="add.php" class="button">+ Book Movie Ticket</a>
            </div>
            <div class="card card-surface p-0">
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>Booking #</th>
                            <th>Movie Title</th>
                            <th>Customer</th>
                            <th>Type</th>
                            <th>Date</th>
                            <th>Tickets</th>
                            <th>Amount Paid</th>
                            <th>Payment Mode</th>
                            <th class="align-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $row['bookingID']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['movieTitle']); ?></strong>
                                <small class="text-light block"><?php echo htmlspecialchars($row['cinemaHall']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><span class="badge text-dark border"><?php echo htmlspecialchars($row['customerType']); ?></span></td>
                            <td><?php echo $row['bookingDate']; ?></td>
                            <td><?php echo $row['numTickets']; ?> ticket(s)</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalAmountPaid'], 2); ?></strong></td>
                            <td><span class="badge surface-muted text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                            <td class="align-right">
                                <a href="delete.php?id=<?php echo $row['bookingID']; ?>" class="button small danger-action" onclick="return confirm('Cancel/Delete booking?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="9" class="align-center py-4 text-light">No ticket bookings recorded yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>