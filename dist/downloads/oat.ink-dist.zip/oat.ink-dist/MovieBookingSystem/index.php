<?php
require_once 'database.php';

$totalMovies = $conn->query("SELECT COUNT(*) FROM movies")->fetch_row()[0];
$totalCustomers = $conn->query("SELECT COUNT(*) FROM customers")->fetch_row()[0];
$totalBookings = $conn->query("SELECT COUNT(*) FROM bookings")->fetch_row()[0];
$totalRevenue = $conn->query("SELECT IFNULL(SUM(totalAmountPaid), 0) FROM bookings")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Cinema Booking System - Dashboard</title>
    
    
    </head>
    <body>
    <?php include 'navbar.php'; ?>
        <main class="container">
            <h1 class="page-title">Movie Booking System</h1>
            <h2>Summary</h2>
            <div class="stats-grid">
                <div class="stat-card"><span class="stat-label">Movies</span><strong class="stat-value"><?= $totalMovies ?></strong></div>
                <div class="stat-card"><span class="stat-label">Customers</span><strong class="stat-value"><?= $totalCustomers ?></strong></div>
                <div class="stat-card"><span class="stat-label">Bookings</span><strong class="stat-value"><?= $totalBookings ?></strong></div>
                <div class="stat-card"><span class="stat-label">Revenue</span><strong class="stat-value"><?= 'PHP ' . number_format($totalRevenue, 2) ?></strong></div>
            </div>
            <h2 class="mt-3">Menu</h2>
            <ul class="simple-menu">
                <li><a href="movies/index.php">Movies</a></li>
                <li><a href="customers/index.php">Customers</a></li>
                <li><a href="bookings/index.php">Bookings</a></li>
                <li><a href="monitoring/index.php">Reports</a></li>
            </ul>
        </main>
    </body>
</html>
