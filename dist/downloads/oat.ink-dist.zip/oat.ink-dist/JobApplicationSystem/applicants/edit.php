<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `applicants` WHERE `applicantID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $applicantName = is_string($_POST['applicantName'] ?? null) ? trim($_POST['applicantName']) : '';
    $degree = is_string($_POST['degree'] ?? null) ? trim($_POST['degree']) : '';
    $yearsExperience = is_string($_POST['yearsExperience'] ?? null) ? trim($_POST['yearsExperience']) : '';
    $email = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($applicantName === '' ||
        $degree === '' ||
        $yearsExperience === '' ||
        !is_numeric($yearsExperience) ||
        !is_finite((float)$yearsExperience) ||
        (float)$yearsExperience < 0 ||
        filter_var($yearsExperience, FILTER_VALIDATE_INT) === false ||
        $email === '' ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        $contactNumber === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `applicants` SET `applicantName` = '" . $conn->real_escape_string($applicantName) . "', `degree` = '" . $conn->real_escape_string($degree) . "', `yearsExperience` = '" . $conn->real_escape_string($yearsExperience) . "', `email` = '" . $conn->real_escape_string($email) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE `applicantID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Applicant - Corporate Job Recruitment & Applicant Tracking System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Applicant</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="applicantName" class="weight-semibold">Applicant Name</label>
                <input type="text" id="applicantName" name="applicantName" class=""  required value="<?= htmlspecialchars($record['applicantName'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="degree" class="weight-semibold">Highest Degree</label>
                <input type="text" id="degree" name="degree" class=""  required value="<?= htmlspecialchars($record['degree'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="yearsExperience" class="weight-semibold">Years Experience</label>
                <input type="number" id="yearsExperience" name="yearsExperience" min="0" class="" step="1" required value="<?= htmlspecialchars($record['yearsExperience'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="email" class="weight-semibold">Email Address</label>
                <input type="email" id="email" name="email" class=""  required value="<?= htmlspecialchars($record['email'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactNumber" class="weight-semibold">Contact Number</label>
                <input type="text" id="contactNumber" name="contactNumber" class=""  required value="<?= htmlspecialchars($record['contactNumber'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Applicant</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
