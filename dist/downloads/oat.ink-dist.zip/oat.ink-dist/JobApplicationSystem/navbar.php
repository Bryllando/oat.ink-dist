<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Corporate Job Recruitment & Applicant Tracking System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'job_openings') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>job_openings/index.php">Job Vacancies</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'applicants') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>applicants/index.php">Job Seekers</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'job_applications') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>job_applications/index.php">Applications</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
