<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jobTitle = is_string($_POST['jobTitle'] ?? null) ? trim($_POST['jobTitle']) : '';
    $department = is_string($_POST['department'] ?? null) ? trim($_POST['department']) : '';
    $baseSalary = is_string($_POST['baseSalary'] ?? null) ? trim($_POST['baseSalary']) : '';
    $employmentType = is_string($_POST['employmentType'] ?? null) ? trim($_POST['employmentType']) : '';

    if ($jobTitle === '' ||
        $department === '' ||
        $baseSalary === '' ||
        !is_numeric($baseSalary) ||
        !is_finite((float)$baseSalary) ||
        (float)$baseSalary < 0 ||
        $employmentType === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `job_openings` (`jobTitle`, `department`, `baseSalary`, `employmentType`) VALUES ('" . $conn->real_escape_string($jobTitle) . "', '" . $conn->real_escape_string($department) . "', '" . $conn->real_escape_string($baseSalary) . "', '" . $conn->real_escape_string($employmentType) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Job Vacancy - Corporate Job Recruitment & Applicant Tracking System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Add New Job Vacancy</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="jobTitle" class="weight-semibold">Position Title</label>
                <input type="text" id="jobTitle" name="jobTitle" class=""  required value="<?= htmlspecialchars($jobTitle ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="department" class="weight-semibold">Department</label>
                <input type="text" id="department" name="department" class=""  required value="<?= htmlspecialchars($department ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="baseSalary" class="weight-semibold">Monthly Base Salary</label>
                <input type="number" id="baseSalary" name="baseSalary" min="0" class="" step="0.01" required value="<?= htmlspecialchars($baseSalary ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="employmentType" class="weight-semibold">Employment Type</label>
                <input type="text" id="employmentType" name="employmentType" class=""  required value="<?= htmlspecialchars($employmentType ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Save Job Vacancy</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
