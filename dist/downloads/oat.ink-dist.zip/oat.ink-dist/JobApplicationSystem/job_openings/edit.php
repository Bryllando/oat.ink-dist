<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `job_openings` WHERE `jobID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jobTitle = is_string($_POST['jobTitle'] ?? null) ? trim($_POST['jobTitle']) : '';
    $department = is_string($_POST['department'] ?? null) ? trim($_POST['department']) : '';
    $baseSalary = is_string($_POST['baseSalary'] ?? null) ? trim($_POST['baseSalary']) : '';
    $employmentType = is_string($_POST['employmentType'] ?? null) ? trim($_POST['employmentType']) : '';

    if ($jobTitle === '' ||
        $department === '' ||
        $baseSalary === '' ||
        !is_numeric($baseSalary) ||
        !is_finite((float)$baseSalary) ||
        (float)$baseSalary < 0 ||
        $employmentType === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `job_openings` SET `jobTitle` = '" . $conn->real_escape_string($jobTitle) . "', `department` = '" . $conn->real_escape_string($department) . "', `baseSalary` = '" . $conn->real_escape_string($baseSalary) . "', `employmentType` = '" . $conn->real_escape_string($employmentType) . "' WHERE `jobID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Job Vacancy - Corporate Job Recruitment & Applicant Tracking System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Job Vacancy</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="jobTitle" class="weight-semibold">Position Title</label>
                <input type="text" id="jobTitle" name="jobTitle" class=""  required value="<?= htmlspecialchars($record['jobTitle'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="department" class="weight-semibold">Department</label>
                <input type="text" id="department" name="department" class=""  required value="<?= htmlspecialchars($record['department'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="baseSalary" class="weight-semibold">Monthly Base Salary</label>
                <input type="number" id="baseSalary" name="baseSalary" min="0" class="" step="0.01" required value="<?= htmlspecialchars($record['baseSalary'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="employmentType" class="weight-semibold">Employment Type</label>
                <input type="text" id="employmentType" name="employmentType" class=""  required value="<?= htmlspecialchars($record['employmentType'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Job Vacancy</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
