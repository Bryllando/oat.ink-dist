<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `jobID`, `jobTitle` FROM `job_openings` ORDER BY `jobTitle` ASC");
$e2List = $conn->query("SELECT `applicantID`, `applicantName` FROM `applicants` ORDER BY `applicantName` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['jobID'] ?? 0);
    $id2 = (int)($_POST['applicantID'] ?? 0);
    $applyDate = is_string($_POST['applyDate'] ?? null) ? trim($_POST['applyDate']) : '';
    $expectedSalary = is_string($_POST['expectedSalary'] ?? null) ? trim($_POST['expectedSalary']) : '';
    $interviewDate = is_string($_POST['interviewDate'] ?? null) ? trim($_POST['interviewDate']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($applyDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $applyDate) ||
        date('Y-m-d', strtotime($applyDate) ?: 0) !== $applyDate ||
        $expectedSalary === '' ||
        !is_numeric($expectedSalary) ||
        !is_finite((float)$expectedSalary) ||
        (float)$expectedSalary < 0 ||
        $interviewDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $interviewDate) ||
        date('Y-m-d', strtotime($interviewDate) ?: 0) !== $interviewDate ||
        $status === '' ||
        $id1 <= 0 ||
        $id2 <= 0 ||
        $interviewDate < $applyDate) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `job_applications` (`jobID`, `applicantID`, `applyDate`, `expectedSalary`, `interviewDate`, `status`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($applyDate) . "', '" . $conn->real_escape_string($expectedSalary) . "', '" . $conn->real_escape_string($interviewDate) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Application - Corporate Job Recruitment & Applicant Tracking System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Application</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="jobID" class="weight-semibold">Select Job Vacancy</label>
                        <select id="jobID" name="jobID" class="" required>
                            <option value="">-- Choose Job Vacancy --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['jobID'] ?>" <?= ((int)($_POST['jobID'] ?? 0) === (int)$r['jobID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['jobTitle']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="applicantID" class="weight-semibold">Select Applicant</label>
                        <select id="applicantID" name="applicantID" class="" required>
                            <option value="">-- Choose Applicant --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['applicantID'] ?>" <?= ((int)($_POST['applicantID'] ?? 0) === (int)$r['applicantID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['applicantName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="applyDate" class="weight-semibold">Application Date</label>
                <input type="date" id="applyDate" name="applyDate" class=""  required value="<?= htmlspecialchars($applyDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="expectedSalary" class="weight-semibold">Expected Monthly Salary</label>
                <input type="number" id="expectedSalary" name="expectedSalary" min="0" class="" step="0.01" required value="<?= htmlspecialchars($expectedSalary ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="interviewDate" class="weight-semibold">Interview Schedule</label>
                <input type="date" id="interviewDate" name="interviewDate" class=""  required value="<?= htmlspecialchars($interviewDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="status" class="weight-semibold">Hiring Status</label>
                <input type="text" id="status" name="status" class=""  required value="<?= htmlspecialchars($status ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Application</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
