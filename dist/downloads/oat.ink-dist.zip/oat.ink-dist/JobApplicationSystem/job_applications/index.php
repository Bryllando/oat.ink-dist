<?php
require_once __DIR__ . '/../database.php';

$sql = "SELECT t.*, e1.jobTitle AS e1_title, e2.applicantName AS e2_title 
        FROM `job_applications` t 
        JOIN `job_openings` e1 ON t.jobID = e1.jobID 
        JOIN `applicants` e2 ON t.applicantID = e2.applicantID 
        ORDER BY t.applicationID DESC";
$records = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Applications - Corporate Job Recruitment & Applicant Tracking System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Manage Applications</h3>
            <a href="add.php" class="button">+ Record New Application</a>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="mb-0">
                    <thead class="">
                        <tr>
                            <th>#</th>
                            <th>Job Vacancy</th>
                            <th>Applicant</th>
                            <th>Application Date</th>
<th>Expected Monthly Salary</th>
<th>Interview Schedule</th>
<th>Hiring Status</th>

                            <th class="align-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['applicationID'] ?></td>
                                    <td class="weight-bold"><?= htmlspecialchars($r['e1_title']) ?></td>
                                    <td><?= htmlspecialchars($r['e2_title']) ?></td>
                                    <td><?= htmlspecialchars($r['applyDate']) ?></td>
<td><?= htmlspecialchars($r['expectedSalary']) ?></td>
<td><?= htmlspecialchars($r['interviewDate']) ?></td>
<td><?= htmlspecialchars($r['status']) ?></td>

                                    <td class="align-right">
                                        <form method="POST" action="delete.php" class="inline-block" onsubmit="return confirm('Delete this record and any linked transactions?');">
                                            <input type="hidden" name="id" value="<?= $r['applicationID'] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                                            <button type="submit" class="button small outline danger-action">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="align-center py-4 text-light">No transaction records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
</body>
</html>
