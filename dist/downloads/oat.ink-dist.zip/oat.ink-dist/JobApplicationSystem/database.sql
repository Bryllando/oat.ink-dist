CREATE DATABASE IF NOT EXISTS `job_application_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `job_application_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `job_openings` (
  `jobID` INT AUTO_INCREMENT PRIMARY KEY,
  `jobTitle` VARCHAR(100) NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `baseSalary` DECIMAL(10,2) NOT NULL,
  `employmentType` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `applicants` (
  `applicantID` INT AUTO_INCREMENT PRIMARY KEY,
  `applicantName` VARCHAR(100) NOT NULL,
  `degree` VARCHAR(100) NOT NULL,
  `yearsExperience` INT NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `contactNumber` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `job_applications` (
  `applicationID` INT AUTO_INCREMENT PRIMARY KEY,
  `jobID` INT NOT NULL,
  `applicantID` INT NOT NULL,
  `applyDate` DATE NOT NULL,
  `expectedSalary` DECIMAL(10,2) NOT NULL,
  `interviewDate` DATE NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Interview Scheduled',
  FOREIGN KEY (`jobID`) REFERENCES `job_openings`(`jobID`) ON DELETE CASCADE,
  FOREIGN KEY (`applicantID`) REFERENCES `applicants`(`applicantID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `job_openings` (`jobTitle`, `department`, `baseSalary`, `employmentType`) VALUES
('Junior Full-Stack Web Developer', 'Information Technology', 28000.0, 'Full-Time Permanent'),
('Database Administrator Specialist', 'Enterprise Infrastructure', 45000.0, 'Full-Time Permanent'),
('Digital Marketing & Content Associate', 'Public Relations', 22000.0, 'Contractual');

INSERT INTO `applicants` (`applicantName`, `degree`, `yearsExperience`, `email`, `contactNumber`) VALUES
('Vincent Paul Navarro', 'BS Information Technology', 2, 'vincent.navarro@gmail.com', '09174445566'),
('Stephanie Anne Sy', 'BS Computer Science', 4, 'steph.sy@yahoo.com', '09185556677'),
('Jericho Miguel Tan', 'AB Communications', 1, 'jericho.tan@outlook.com', '09226667788');

INSERT INTO `job_applications` (`jobID`, `applicantID`, `applyDate`, `expectedSalary`, `interviewDate`, `status`) VALUES
(1, 1, '2026-10-25', 26000.0, '2026-11-05', 'Shortlisted'),
(2, 2, '2026-10-27', 42000.0, '2026-11-08', 'Hired'),
(3, 3, '2026-11-01', 20000.0, '2026-11-12', 'Under Review');

SET FOREIGN_KEY_CHECKS=1;
