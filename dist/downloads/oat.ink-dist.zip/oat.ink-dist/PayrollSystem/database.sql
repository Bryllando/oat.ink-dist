CREATE DATABASE IF NOT EXISTS payroll_system;
USE payroll_system;

CREATE TABLE IF NOT EXISTS Positions (
    positionID INT AUTO_INCREMENT PRIMARY KEY,
    positionName VARCHAR(100) NOT NULL,
    basicSalary DECIMAL(10, 2) NOT NULL,
    allowance DECIMAL(10, 2) NOT NULL
);

CREATE TABLE IF NOT EXISTS Employees (
    empID INT AUTO_INCREMENT PRIMARY KEY,
    empFName VARCHAR(100) NOT NULL,
    empLName VARCHAR(100) NOT NULL,
    positionID INT,
    dateHired DATE,
    contactNo VARCHAR(50),
    FOREIGN KEY (positionID) REFERENCES Positions(positionID) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS Payroll (
    payrollID INT AUTO_INCREMENT PRIMARY KEY,
    empID INT,
    payDate DATE,
    basicSalary DECIMAL(10, 2),
    allowance DECIMAL(10, 2),
    deduction DECIMAL(10, 2),
    netPay DECIMAL(10, 2),
    FOREIGN KEY (empID) REFERENCES Employees(empID) ON DELETE CASCADE
);
