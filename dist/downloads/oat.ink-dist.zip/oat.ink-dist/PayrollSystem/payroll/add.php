<?php
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $empID = intval($_POST['empID']);
    $payDate = $conn->real_escape_string($_POST['payDate']);
    $deduction = floatval($_POST['deduction']);

    $empQuery = $conn->query("SELECT p.basicSalary, p.allowance FROM Employees e LEFT JOIN Positions p ON e.positionID = p.positionID WHERE e.empID = $empID");
    $empData = $empQuery->fetch_assoc();
    
    $basicSalary = floatval($empData['basicSalary']);
    $allowance = floatval($empData['allowance']);
    $netPay = $basicSalary + $allowance - $deduction;

    $conn->query("INSERT INTO Payroll (empID, payDate, basicSalary, allowance, deduction, netPay) VALUES ($empID, '$payDate', $basicSalary, $allowance, $deduction, $netPay)");
    header("Location: index.php");
    exit;
}

$employees = $conn->query("SELECT e.empID, e.empFName, e.empLName, p.positionName, p.basicSalary, p.allowance FROM Employees e LEFT JOIN Positions p ON e.positionID = p.positionID ORDER BY e.empLName ASC");

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="mb-4">
    <h1 class="page-title">Process Payroll</h1>
    <small class="text-light">Select an employee, enter pay period date, deductions, and compute net salary</small>
</div>

<form method="POST" style="max-width: 600px;" class="entry-form form-panel">
    <div class="field-grid">
        <div class="mb-3">
            <label class="weight-bold" for="input-empID">Select Employee:</label>
            <select name="empID" required id="input-empID">
                <option value="">-- Choose Employee --</option>
            <?php while($e = $employees->fetch_assoc()): ?>
                <option value="<?= $e['empID'] ?>">
                    <?= htmlspecialchars($e['empFName'] . ' ' . $e['empLName']) ?> (<?= htmlspecialchars($e['positionName'] ?? 'No Position') ?> - Basic: ₱<?= number_format($e['basicSalary'], 2) ?>)
                </option>
            <?php endwhile; ?>
            </select>
            <div class="form-text">Basic salary and allowances are auto-retrieved from the employee's assigned position.</div>
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-payDate">Payroll Date:</label>
            <input type="date" name="payDate" value="<?= date('Y-m-d') ?>" required id="input-payDate">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-deduction">Total Deductions (SSS / PhilHealth / Pag-IBIG / Tax ₱):</label>
            <input type="number" step="0.01" name="deduction" value="0.00" required id="input-deduction">
        </div>
    </div>
    <div class="mt-4 form-actions">
        <button type="submit" class="button">Save & Compute Net Pay</button>
        <a href="index.php" class="button outline ms-2">Cancel</a>
    </div>
</form>

<?php require_once '../includes/footer.php'; ?>
