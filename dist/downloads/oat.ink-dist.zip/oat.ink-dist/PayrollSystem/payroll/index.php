<?php
require_once '../config/database.php';

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM Payroll WHERE payrollID = $id");
    header("Location: index.php");
    exit;
}

$search = $_GET['search'] ?? '';
$where = "";
if ($search) {
    $escaped = $conn->real_escape_string($search);
    $where = "WHERE e.empFName LIKE '%$escaped%' OR e.empLName LIKE '%$escaped%'";
}

$query = "SELECT pr.*, e.empFName, e.empLName 
          FROM Payroll pr 
          LEFT JOIN Employees e ON pr.empID = e.empID 
          $where 
          ORDER BY pr.payrollID DESC";
$result = $conn->query($query);

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="flex justify-between items-center mb-3">
    <div>
        <h1 class="mb-0 page-title">Payroll Transactions</h1>
        <small class="text-light">Process employee salaries, deductions, and computed net pay</small>
    </div>
    <a href="add.php" class="button">+ Process New Payroll</a>
</div>

<div class="card p-3 mb-3 border">
    <form method="GET" class="row g-2 items-center filter-form">
        <div class="auto-col">
            <label class="weight-bold">Search Employee:</label>
        </div>
        <div class="auto-col">
            <input type="text" name="search" placeholder="Search employee name..." value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="auto-col">
            <button type="submit" class="button">Search</button>
            <?php if ($search): ?>
            <a href="index.php" class="button outline">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Employee Name</th>
            <th>Pay Date</th>
            <th>Basic Salary</th>
            <th>Allowance</th>
            <th>Deduction</th>
            <th>Net Pay</th>
            <th style="width: 150px;">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['payrollID'] ?></td>
            <td><strong><?= htmlspecialchars($row['empFName'] . ' ' . $row['empLName']) ?></strong></td>
            <td><?= htmlspecialchars($row['payDate']) ?></td>
            <td>₱<?= number_format($row['basicSalary'], 2) ?></td>
            <td>₱<?= number_format($row['allowance'], 2) ?></td>
            <td class="text-danger">-₱<?= number_format($row['deduction'], 2) ?></td>
            <td><strong class="text-success fs-6">₱<?= number_format($row['netPay'], 2) ?></strong></td>
            <td>
                <a href="edit.php?id=<?= $row['payrollID'] ?>" class="button small outline">Edit</a>
                <a href="index.php?delete=<?= $row['payrollID'] ?>" class="button small danger-action ms-1" onclick="return confirm('Delete this payroll record?')">Delete</a>
            </td>
        </tr>
            <?php endwhile; ?>
        <?php else: ?>
        <tr><td colspan="8" class="align-center text-light py-3">No payroll records found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once '../includes/footer.php'; ?>
