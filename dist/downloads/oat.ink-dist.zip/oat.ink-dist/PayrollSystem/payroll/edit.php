<?php
require_once '../config/database.php';

$id = intval($_GET['id'] ?? 0);

$result = $conn->query("SELECT pr.*, e.empFName, e.empLName FROM Payroll pr LEFT JOIN Employees e ON pr.empID = e.empID WHERE pr.payrollID=$id");
$row = $result->fetch_assoc();
if (!$row) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payDate = $conn->real_escape_string($_POST['payDate']);
    $basicSalary = floatval($_POST['basicSalary']);
    $allowance = floatval($_POST['allowance']);
    $deduction = floatval($_POST['deduction']);
    $netPay = $basicSalary + $allowance - $deduction;

    $conn->query("UPDATE Payroll SET payDate='$payDate', basicSalary=$basicSalary, allowance=$allowance, deduction=$deduction, netPay=$netPay WHERE payrollID=$id");
    header("Location: index.php");
    exit;
}

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="mb-4">
    <h1 class="page-title">Edit Payroll Record</h1>
    <small class="text-light">Modify compensation adjustments and re-calculate net pay</small>
</div>

<form method="POST" style="max-width: 600px;" class="entry-form form-panel">
    <div class="field-grid">
        <div class="mb-3">
            <label class="weight-bold" for="input-0">Employee:</label>
            <input type="text" value="<?= htmlspecialchars($row['empFName'] . ' ' . $row['empLName']) ?>" readonly id="input-0">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-payDate">Pay Date:</label>
            <input type="date" name="payDate" value="<?= $row['payDate'] ?>" required id="input-payDate">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-basicSalary">Basic Salary (₱):</label>
            <input type="number" step="0.01" name="basicSalary" value="<?= $row['basicSalary'] ?>" required id="input-basicSalary">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-allowance">Allowance (₱):</label>
            <input type="number" step="0.01" name="allowance" value="<?= $row['allowance'] ?>" required id="input-allowance">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-deduction">Total Deductions (₱):</label>
            <input type="number" step="0.01" name="deduction" value="<?= $row['deduction'] ?>" required id="input-deduction">
        </div>
    </div>
    <div class="mt-4 form-actions">
        <button type="submit" class="button">Update & Re-calculate Net Pay</button>
        <a href="index.php" class="button outline ms-2">Cancel</a>
    </div>
</form>

<?php require_once '../includes/footer.php'; ?>
