<?php
// Redirect to dashboard, login removed as requested
header("Location: dashboard.php");
exit;
?>
