<?php
mysqli_report(MYSQLI_REPORT_OFF);
$host = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "payroll_system";

$conn = @mysqli_connect($host, $username, $password);
if (!$conn) {
    die('Database connection failed: ' . htmlspecialchars(mysqli_connect_error()));
}

// Auto-create database if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS `{$dbname}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci") or die('Database setup failed: ' . htmlspecialchars($conn->error));
$conn->select_db($dbname) or die('Database setup failed: ' . htmlspecialchars($conn->error));
$conn->set_charset("utf8mb4") or die('Database setup failed: ' . htmlspecialchars($conn->error));

$tables = $conn->query("SHOW TABLES");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($conn->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/../database/payroll.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $conn->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($conn->error));
    do {
        if ($result = $conn->store_result()) $result->free();
    } while ($conn->more_results() && $conn->next_result());
    if ($conn->errno) die('Database setup failed: ' . htmlspecialchars($conn->error));
    $conn->query("INSERT INTO Positions (positionName, basicSalary, allowance) VALUES ('Manager', 35000.00, 5000.00), ('Staff', 18000.00, 2000.00)");
    $conn->query("INSERT INTO Employees (empFName, empLName, positionID, dateHired, contactNo) VALUES ('Juan', 'Dela Cruz', 1, CURDATE(), '09171234567'), ('Maria', 'Santos', 2, CURDATE(), '09181234567')");
}

// shortcut: project must be inside the web root; use an explicit URL for Apache aliases.
$docRoot = rtrim(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])), '/');
$projectDir = str_replace('\\', '/', dirname(__DIR__));
$baseUrl = substr($projectDir, strlen($docRoot)) . '/';
?>
