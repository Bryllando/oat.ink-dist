<?php
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fname = $conn->real_escape_string($_POST['empFName']);
    $lname = $conn->real_escape_string($_POST['empLName']);
    $posID = intval($_POST['positionID']);
    $dateHired = $conn->real_escape_string($_POST['dateHired']);
    $contact = $conn->real_escape_string($_POST['contactNo']);

    $conn->query("INSERT INTO Employees (empFName, empLName, positionID, dateHired, contactNo) VALUES ('$fname', '$lname', $posID, '$dateHired', '$contact')");
    header("Location: index.php");
    exit;
}

$positions = $conn->query("SELECT * FROM Positions ORDER BY positionName ASC");

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="mb-4">
    <h1 class="page-title">Add New Employee</h1>
    <small class="text-light">Enter employee details and assign a job position</small>
</div>

<form method="POST" style="max-width: 600px;" class="entry-form form-panel">
    <div class="field-grid">
        <div class="mb-3">
            <label class="weight-bold" for="input-empFName">First Name:</label>
            <input type="text" name="empFName" required placeholder="e.g. Juan" id="input-empFName">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-empLName">Last Name:</label>
            <input type="text" name="empLName" required placeholder="e.g. Dela Cruz" id="input-empLName">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-positionID">Position / Job Title:</label>
            <select name="positionID" required id="input-positionID">
                <option value="">-- Select Position --</option>
            <?php while($p = $positions->fetch_assoc()): ?>
                <option value="<?= $p['positionID'] ?>"><?= htmlspecialchars($p['positionName']) ?></option>
            <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-dateHired">Date Hired:</label>
            <input type="date" name="dateHired" value="<?= date('Y-m-d') ?>" required id="input-dateHired">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-contactNo">Contact Number:</label>
            <input type="text" name="contactNo" required placeholder="e.g. 09171234567" id="input-contactNo">
        </div>
    </div>
    <div class="mt-4 form-actions">
        <button type="submit" class="button">Save Employee</button>
        <a href="index.php" class="button outline ms-2">Cancel</a>
    </div>
</form>

<?php require_once '../includes/footer.php'; ?>
