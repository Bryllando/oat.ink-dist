<?php
require_once '../config/database.php';

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM Employees WHERE empID = $id");
    header("Location: index.php");
    exit;
}

$search = $_GET['search'] ?? '';
$where = "";
if ($search) {
    $escaped = $conn->real_escape_string($search);
    $where = "WHERE e.empFName LIKE '%$escaped%' OR e.empLName LIKE '%$escaped%'";
}

$query = "SELECT e.*, p.positionName FROM Employees e LEFT JOIN Positions p ON e.positionID = p.positionID $where ORDER BY e.empID DESC";
$result = $conn->query($query);

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="flex justify-between items-center mb-3">
    <div>
        <h1 class="mb-0 page-title">Employees</h1>
        <small class="text-light">Manage employee records and assigned positions</small>
    </div>
    <a href="add.php" class="button">Add New Employee</a>
</div>

<div class="card p-3 mb-3 border">
    <form method="GET" class="row g-2 items-center filter-form">
        <div class="auto-col">
            <label class="weight-bold">Search Employee:</label>
        </div>
        <div class="auto-col">
            <input type="text" name="search" placeholder="Search first or last name..." value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="auto-col">
            <button type="submit" class="button">Search</button>
            <?php if ($search): ?>
            <a href="index.php" class="button outline">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Position</th>
            <th>Date Hired</th>
            <th>Contact No</th>
            <th style="width: 150px;">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['empID'] ?></td>
            <td><strong><?= htmlspecialchars($row['empFName'] . ' ' . $row['empLName']) ?></strong></td>
            <td><span class="badge surface-muted text-dark"><?= htmlspecialchars($row['positionName'] ?? 'Unassigned') ?></span></td>
            <td><?= htmlspecialchars($row['dateHired']) ?></td>
            <td><?= htmlspecialchars($row['contactNo']) ?></td>
            <td>
                <a href="edit.php?id=<?= $row['empID'] ?>" class="button small outline">Edit</a>
                <a href="index.php?delete=<?= $row['empID'] ?>" class="button small danger-action ms-1" onclick="return confirm('Delete this employee record?')">Delete</a>
            </td>
        </tr>
            <?php endwhile; ?>
        <?php else: ?>
        <tr><td colspan="6" class="align-center text-light py-3">No employees found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once '../includes/footer.php'; ?>
