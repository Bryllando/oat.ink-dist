<?php
require_once '../config/database.php';

$id = intval($_GET['id'] ?? 0);

$result = $conn->query("SELECT * FROM Positions WHERE positionID=$id");
$row = $result->fetch_assoc();
if (!$row) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['positionName']);
    $salary = floatval($_POST['basicSalary']);
    $allowance = floatval($_POST['allowance']);

    $conn->query("UPDATE Positions SET positionName='$name', basicSalary=$salary, allowance=$allowance WHERE positionID=$id");
    header("Location: index.php");
    exit;
}

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="mb-4">
    <h1 class="page-title">Edit Position</h1>
    <small class="text-light">Update job position title and compensation</small>
</div>

<form method="POST" style="max-width: 600px;" class="entry-form form-panel">
    <div class="field-grid">
        <div class="mb-3">
            <label class="weight-bold" for="input-positionName">Position Title:</label>
            <input type="text" name="positionName" value="<?= htmlspecialchars($row['positionName']) ?>" required id="input-positionName">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-basicSalary">Basic Salary (₱):</label>
            <input type="number" step="0.01" name="basicSalary" value="<?= $row['basicSalary'] ?>" required id="input-basicSalary">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-allowance">Allowance (₱):</label>
            <input type="number" step="0.01" name="allowance" value="<?= $row['allowance'] ?>" required id="input-allowance">
        </div>
    </div>
    <div class="mt-4 form-actions">
        <button type="submit" class="button">Update Position</button>
        <a href="index.php" class="button outline ms-2">Cancel</a>
    </div>
</form>

<?php require_once '../includes/footer.php'; ?>
