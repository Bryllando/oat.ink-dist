<?php
require_once '../config/database.php';

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM Positions WHERE positionID = $id");
    header("Location: index.php");
    exit;
}

$search = $_GET['search'] ?? '';
$where = "";
if ($search) {
    $where = "WHERE positionName LIKE '%" . $conn->real_escape_string($search) . "%'";
}
$result = $conn->query("SELECT * FROM Positions $where ORDER BY positionID DESC");

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="flex justify-between items-center mb-3">
    <div>
        <h1 class="mb-0 page-title">Positions & Salary Grades</h1>
        <small class="text-light">Manage job roles, base salary rates, and allowances</small>
    </div>
    <a href="add.php" class="button">Add New Position</a>
</div>

<div class="card p-3 mb-3 border">
    <form method="GET" class="row g-2 items-center filter-form">
        <div class="auto-col">
            <label class="weight-bold">Search Position:</label>
        </div>
        <div class="auto-col">
            <input type="text" name="search" placeholder="Search position title..." value="<?= htmlspecialchars($search) ?>">
        </div>
        <div class="auto-col">
            <button type="submit" class="button">Search</button>
            <?php if ($search): ?>
            <a href="index.php" class="button outline">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Position Title</th>
            <th>Basic Salary</th>
            <th>Allowance</th>
            <th style="width: 150px;">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['positionID'] ?></td>
            <td><strong><?= htmlspecialchars($row['positionName']) ?></strong></td>
            <td>₱<?= number_format($row['basicSalary'], 2) ?></td>
            <td>₱<?= number_format($row['allowance'], 2) ?></td>
            <td>
                <a href="edit.php?id=<?= $row['positionID'] ?>" class="button small outline">Edit</a>
                <a href="index.php?delete=<?= $row['positionID'] ?>" class="button small danger-action ms-1" onclick="return confirm('Delete this position?')">Delete</a>
            </td>
        </tr>
            <?php endwhile; ?>
        <?php else: ?>
        <tr><td colspan="5" class="align-center text-light py-3">No positions found.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require_once '../includes/footer.php'; ?>
