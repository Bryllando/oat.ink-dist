<?php
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['positionName']);
    $salary = floatval($_POST['basicSalary']);
    $allowance = floatval($_POST['allowance']);

    $conn->query("INSERT INTO Positions (positionName, basicSalary, allowance) VALUES ('$name', $salary, $allowance)");
    header("Location: index.php");
    exit;
}

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<div class="mb-4">
    <h1 class="page-title">Add New Position</h1>
    <small class="text-light">Enter job title, basic monthly salary, and standard allowance</small>
</div>

<form method="POST" style="max-width: 600px;" class="entry-form form-panel">
    <div class="field-grid">
        <div class="mb-3">
            <label class="weight-bold" for="input-positionName">Position Title:</label>
            <input type="text" name="positionName" required placeholder="e.g. Software Engineer" id="input-positionName">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-basicSalary">Basic Salary (₱):</label>
            <input type="number" step="0.01" name="basicSalary" required placeholder="e.g. 25000.00" id="input-basicSalary">
        </div>
        <div class="mb-3">
            <label class="weight-bold" for="input-allowance">Allowance (₱):</label>
            <input type="number" step="0.01" name="allowance" required placeholder="e.g. 3000.00" id="input-allowance">
        </div>
    </div>
    <div class="mt-4 form-actions">
        <button type="submit" class="button">Save Position</button>
        <a href="index.php" class="button outline ms-2">Cancel</a>
    </div>
</form>

<?php require_once '../includes/footer.php'; ?>
