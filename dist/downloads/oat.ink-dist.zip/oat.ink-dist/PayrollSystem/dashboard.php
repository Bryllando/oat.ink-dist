<?php
require_once 'includes/header.php';
require_once 'includes/navbar.php';
?>
<div class="page-heading">
    <h1 class="page-title">Payroll Management System</h1>
</div>

<ul class="simple-menu">
    <li><a href="employees/index.php"><span>Employees</span> </a></li>
    <li><a href="positions/index.php"><span>Positions</span> </a></li>
    <li><a href="payroll/index.php"><span>Payroll</span> </a></li>
    <li><a href="reports/index.php"><span>Payroll Reports & Monitoring</span></a></li>
</ul>

<?php
require_once 'includes/footer.php';
?>
