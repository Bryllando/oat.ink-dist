<?php
if (!isset($baseUrl)) {
    require_once __DIR__ . '/../config/database.php';
}
$navBase = rtrim($baseUrl, '/');
$currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
?>
<nav class="app-nav">
    <div class="container-fluid container">
        <a class="app-brand nav-brand" href="<?php echo $navBase; ?>/dashboard.php">Payroll System</a>
        
        <div class="nav-region" id="navPayroll">
            <ul class="nav-links ms-auto">
                <li><a class="nav-link <?php echo (strpos($currentUri, '/employees/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/employees/index.php">Employees</a></li>
                <li><a class="nav-link <?php echo (strpos($currentUri, '/positions/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/positions/index.php">Positions</a></li>
                <li><a class="nav-link <?php echo (strpos($currentUri, '/payroll/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/payroll/index.php">Payroll</a></li>
                <li><a class="nav-link <?php echo (strpos($currentUri, '/reports/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/reports/index.php">Reports</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-4">
    <div class="card-surface">