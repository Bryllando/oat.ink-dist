<?php
if (!isset($baseUrl)) {
    require_once __DIR__ . '/../config/database.php';
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="<?php echo $baseUrl; ?>assets/css/oat.min.css">
        <link rel="stylesheet" href="<?php echo $baseUrl; ?>assets/css/app.css">
        <script src="<?php echo $baseUrl; ?>assets/js/oat.min.js" defer></script>
        <script src="<?php echo $baseUrl; ?>assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Payroll Management System</title>
    
    
    </head>
    <body>
