<?php
require_once '../config/database.php';

$filterDate = $_GET['payDate'] ?? '';
$where = "";
if ($filterDate) {
    $escapedDate = $conn->real_escape_string($filterDate);
    $where = "WHERE pr.payDate = '$escapedDate'";
}

$query = "SELECT pr.*, e.empFName, e.empLName, p.positionName 
          FROM Payroll pr 
          LEFT JOIN Employees e ON pr.empID = e.empID 
          LEFT JOIN Positions p ON e.positionID = p.positionID 
          $where";
$result = $conn->query($query);

$aggQuery = "SELECT 
                COUNT(*) as totalEmployees, 
                SUM(allowance) as totalAllowances, 
                SUM(deduction) as totalDeductions, 
                SUM(netPay) as totalNetPay 
             FROM Payroll pr 
             $where";
$aggResult = $conn->query($aggQuery);
$aggRow = $aggResult ? $aggResult->fetch_assoc() : null;

require_once '../includes/header.php';
require_once '../includes/navbar.php';
?>

<h1 class="page-title">Payroll Monitoring & Reports</h1>

<form method="GET" class="mb-4 filter-form filter-panel">
    <div class="row g-2 items-center">
        <div class="auto-col">
            <label class="weight-bold">Filter by Pay Date:</label>
        </div>
        <div class="auto-col">
            <input type="date" name="payDate" value="<?= htmlspecialchars($filterDate) ?>">
        </div>
        <div class="auto-col">
            <button type="submit" class="button">Filter</button>
            <a href="index.php" class="button outline">Clear</a>
        </div>
    </div>
</form>

<table>
    <tr>
        <th>Employee Name</th>
        <th>Position</th>
        <th>Basic Salary</th>
        <th>Allowance</th>
        <th>Deduction</th>
        <th>Net Pay</th>
        <th>Pay Date</th>
    </tr>
    <?php if($result && $result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['empFName'] . ' ' . $row['empLName']) ?></td>
        <td><?= htmlspecialchars($row['positionName'] ?? '') ?></td>
        <td>₱<?= number_format($row['basicSalary'], 2) ?></td>
        <td>₱<?= number_format($row['allowance'], 2) ?></td>
        <td>₱<?= number_format($row['deduction'], 2) ?></td>
        <td><strong>₱<?= number_format($row['netPay'], 2) ?></strong></td>
        <td><?= htmlspecialchars($row['payDate']) ?></td>
    </tr>
        <?php endwhile; ?>
    <?php else: ?>
    <tr><td colspan="7" class="align-center text-light">No payroll records found.</td></tr>
    <?php endif; ?>
</table>

<?php if($aggRow && $aggRow['totalEmployees'] > 0): ?>
<h3>Payroll Summary</h3>
<div class="row g-3 mt-2">
    <div class="col-3">
        <div class="stat-card">
            <div class="stat-val"><?= (int)$aggRow['totalEmployees'] ?></div>
            <div class="stat-label">Total Records</div>
        </div>
    </div>
    <div class="col-3">
        <div class="stat-card">
            <div class="stat-val text-success">₱<?= number_format($aggRow['totalAllowances'] ?? 0, 2) ?></div>
            <div class="stat-label">Total Allowances</div>
        </div>
    </div>
    <div class="col-3">
        <div class="stat-card">
            <div class="stat-val text-danger">₱<?= number_format($aggRow['totalDeductions'] ?? 0, 2) ?></div>
            <div class="stat-label">Total Deductions</div>
        </div>
    </div>
    <div class="col-3">
        <div class="stat-card">
            <div class="stat-val text-primary">₱<?= number_format($aggRow['totalNetPay'] ?? 0, 2) ?></div>
            <div class="stat-label">Total Net Pay</div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require_once '../includes/footer.php'; ?>
