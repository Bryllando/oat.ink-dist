<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$id = $_GET['id'] ?? null;
if (!$id) redirect('index.php');

$stmt = $mysqli->prepare("SELECT * FROM consultations WHERE consulID = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row) redirect('index.php');

$patients = $mysqli->query("SELECT * FROM patients ORDER BY patLName, patFName");
$doctors = $mysqli->query("SELECT * FROM doctors ORDER BY docLName, docFName");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pat = $_POST['patID'];
    $doc = $_POST['docID'];
    $date = $_POST['consulDate'] ?: date('Y-m-d H:i:s');
    $diag = $_POST['diagnosis'] ?? '';
    $pres = $_POST['prescription'] ?? '';
    $up = $mysqli->prepare("UPDATE consultations SET patID=?, docID=?, consulDate=?, diagnosis=?, prescription=? WHERE consulID=?");
    $up->bind_param('issssi', $pat, $doc, $date, $diag, $pres, $id);
    $up->execute();
    flash('success','Consultation updated.');
    redirect('index.php');
}
?>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container form-page">
    <h1 class="page-title">Edit Consultation</h1>
    <form method="post" class="entry-form form-panel">
        <div class="field-grid">
            <div class="mb-2"><label for="input-patID">Patient</label>
                <select name="patID" required id="input-patID">
        <?php while($p = $patients->fetch_assoc()): ?>
                    <option value="<?php echo $p['patID']; ?>" <?php if($p['patID']==$row['patID']) echo 'selected'; ?>><?php echo e($p['patFName'].' '.$p['patLName']); ?></option>
        <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-2"><label for="input-docID">Doctor</label>
                <select name="docID" required id="input-docID">
        <?php while($d = $doctors->fetch_assoc()): ?>
                    <option value="<?php echo $d['docID']; ?>" <?php if($d['docID']==$row['docID']) echo 'selected'; ?>><?php echo e($d['docFName'].' '.$d['docLName'].' ('.$d['docSpecial'].')'); ?></option>
        <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-2"><label for="input-consulDate">Date/Time</label><input name="consulDate" value="<?php echo e($row['consulDate']); ?>" id="input-consulDate"></div>
            <div class="mb-2"><label for="input-diagnosis">Diagnosis</label><textarea name="diagnosis" id="input-diagnosis"><?php echo e($row['diagnosis']); ?></textarea></div>
            <div class="mb-2"><label for="input-prescription">Prescription</label><textarea name="prescription" id="input-prescription"><?php echo e($row['prescription']); ?></textarea></div>
        </div>
        <div class="form-actions">
            <button class="button">Update Consultation</button>
            <a href="index.php" class="button outline">Cancel</a>
        </div>
    </form>
</div>
</body>
</html>
