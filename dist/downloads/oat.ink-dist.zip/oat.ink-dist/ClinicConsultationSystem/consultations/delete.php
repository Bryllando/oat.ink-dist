<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $mysqli->prepare("DELETE FROM consultations WHERE consulID = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    flash('success','Consultation deleted.');
}
redirect('index.php');
