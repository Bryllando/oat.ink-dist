<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$res = $mysqli->query("SELECT c.*, p.patFName, p.patLName, d.docFName, d.docLName FROM consultations c JOIN patients p ON c.patID=p.patID JOIN doctors d ON c.docID=d.docID ORDER BY c.consulDate DESC");
?>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
    <div class="site-hero mb-3">
        <h1 class="page-title">Consultations Log</h1>
        <small class="text-light">Record medical consultations, diagnosis, and doctor prescriptions</small>
    </div>

    <div class="card-surface mb-4">
        <div class="flex justify-between items-center mb-3">
            <a class="button" href="add.php">+ Record New Consultation</a>
            <a class="button outline" href="../monitoring/index.php">View Monitoring Report</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Patient</th>
                    <th>Attending Doctor</th>
                    <th>Diagnosis</th>
                    <th>Prescription</th>
                </tr>
            </thead>
            <tbody>
      <?php if ($res && $res->num_rows > 0): ?>
        <?php while ($r = $res->fetch_assoc()): ?>
                <tr>
                    <td><?php echo e($r['consulDate']); ?></td>
                    <td><strong><?php echo e($r['patFName'].' '.$r['patLName']); ?></strong></td>
                    <td><span class="badge surface-muted text-dark">Dr. <?php echo e($r['docFName'].' '.$r['docLName']); ?></span></td>
                    <td><?php echo e($r['diagnosis']); ?></td>
                    <td><?php echo e($r['prescription']); ?></td>
                </tr>
        <?php endwhile; ?>
      <?php else: ?>
                <tr><td colspan="5" class="align-center text-light py-3">No consultations logged yet.</td></tr>
      <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
