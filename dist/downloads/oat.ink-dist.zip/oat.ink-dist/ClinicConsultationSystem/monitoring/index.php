<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

$doctors = $mysqli->query("SELECT docID, docFName, docLName, docSpecial FROM doctors ORDER BY docLName");
$patients = $mysqli->query("SELECT patID, patFName, patLName FROM patients ORDER BY patLName");

$results = null;
$count = 0;
if ($_SERVER['REQUEST_METHOD'] === 'GET' && (!empty($_GET['action']))) {
    $where = [];
    $params = [];
    $types = '';
    if (!empty($_GET['docID'])) { $where[] = 'c.docID = ?'; $params[] = $_GET['docID']; $types .= 'i'; }
    if (!empty($_GET['patID'])) { $where[] = 'c.patID = ?'; $params[] = $_GET['patID']; $types .= 'i'; }
    if (!empty($_GET['docSpecial'])) { $where[] = 'd.docSpecial LIKE ?'; $params[] = '%'.$_GET['docSpecial'].'%'; $types .= 's'; }
    if (!empty($_GET['from']) && !empty($_GET['to'])) { $where[] = 'c.consulDate BETWEEN ? AND ?'; $params[] = $_GET['from']; $params[] = $_GET['to']; $types .= 'ss'; }
    $sql = 'SELECT COUNT(*) as total FROM consultations c JOIN doctors d ON c.docID=d.docID';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $stmt = $mysqli->prepare($sql);
    if ($params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $results = $stmt->get_result()->fetch_assoc();
    $count = $results['total'] ?? 0;
}
?>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
    <div class="site-hero mb-3">
        <h1 class="page-title">Monitoring & Inquiry</h1>
        <small class="text-light">Filter consultations by doctor, patient, and date.</small>
    </div>

    <div class="card-surface mb-4">
        <form method="get" class="row g-3 mb-4 filter-form">
            <div class="col-3">
                <label class="weight-bold">Doctor:</label>
                <select name="docID">
                    <option value="">-- All Doctors --</option>
          <?php while($d = $doctors->fetch_assoc()): ?>
                    <option value="<?php echo $d['docID']; ?>"><?php echo e($d['docFName'].' '.$d['docLName'].' ('.$d['docSpecial'].')'); ?></option>
          <?php endwhile; ?>
                </select>
            </div>
            <div class="col-3">
                <label class="weight-bold">Patient:</label>
                <select name="patID">
                    <option value="">-- All Patients --</option>
          <?php while($p = $patients->fetch_assoc()): ?>
                    <option value="<?php echo $p['patID']; ?>"><?php echo e($p['patFName'].' '.$p['patLName']); ?></option>
          <?php endwhile; ?>
                </select>
            </div>
            <div class="col-3">
                <label class="weight-bold">Doctor Specialty:</label>
                <input name="docSpecial" placeholder="e.g. Cardiology">
            </div>
            <div class="col-3">
                <label class="weight-bold">From Date:</label>
                <input type="date" name="from">
            </div>
            <div class="col-3">
                <label class="weight-bold">To Date:</label>
                <input type="date" name="to">
            </div>
            <div class="col-3 self-end">
                <input type="hidden" name="action" value="count">
                <button class="button">Run Inquiry (COUNT)</button>
                <a href="index.php" class="button outline ms-1">Reset</a>
            </div>
        </form>

    <?php if ($results !== null): ?>
        <div class="row g-3 mt-2">
            <div class="col-4">
                <div class="stat-card">
                    <div class="stat-val"><?php echo e($count); ?></div>
                    <div class="stat-label">Matching Consultations</div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    </div>
</div>

</body>
</html>
