<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = $_POST['docFName'] ?? '';
    $l = $_POST['docLName'] ?? '';
    $addr = $_POST['docAddress'] ?? '';
    $spec = $_POST['docSpecial'] ?? '';
    $stmt = $mysqli->prepare("INSERT INTO doctors (docFName, docLName, docAddress, docSpecial) VALUES (?,?,?,?)");
    $stmt->bind_param('ssss', $f, $l, $addr, $spec);
    $stmt->execute();
    flash('success', 'Doctor added.');
    redirect('index.php');
}
?>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container form-page">
    <h1 class="page-title">Add Doctor</h1>
    <form method="post" class="entry-form form-panel">
        <div class="field-grid">
            <div class="mb-2">
                <label for="input-docFName">First Name</label>
                <input name="docFName" required id="input-docFName">
            </div>
            <div class="mb-2">
                <label for="input-docLName">Last Name</label>
                <input name="docLName" required id="input-docLName">
            </div>
            <div class="mb-2">
                <label for="input-docAddress">Address</label>
                <input name="docAddress" id="input-docAddress">
            </div>
            <div class="mb-2">
                <label for="input-docSpecial">Specialization</label>
                <input name="docSpecial" id="input-docSpecial">
            </div>
        </div>
        <div class="form-actions">
            <button class="button">Save</button>
            <a href="index.php" class="button outline">Cancel</a>
        </div>
    </form>
</div>
</body>
</html>
