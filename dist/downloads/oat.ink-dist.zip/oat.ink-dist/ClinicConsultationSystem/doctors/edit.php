<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$id = $_GET['id'] ?? null;
if (!$id) redirect('index.php');

$stmt = $mysqli->prepare("SELECT * FROM doctors WHERE docID = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row) redirect('index.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = $_POST['docFName'] ?? '';
    $l = $_POST['docLName'] ?? '';
    $addr = $_POST['docAddress'] ?? '';
    $spec = $_POST['docSpecial'] ?? '';
    $up = $mysqli->prepare("UPDATE doctors SET docFName=?, docLName=?, docAddress=?, docSpecial=? WHERE docID=?");
    $up->bind_param('ssssi', $f, $l, $addr, $spec, $id);
    $up->execute();
    flash('success','Doctor updated.');
    redirect('index.php');
}
?>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container form-page">
    <h1 class="page-title">Edit Doctor</h1>
    <form method="post" class="entry-form form-panel">
        <div class="field-grid">
            <div class="mb-2">
                <label for="input-docFName">First Name</label>
                <input name="docFName" value="<?php echo e($row['docFName']); ?>" required id="input-docFName">
            </div>
            <div class="mb-2">
                <label for="input-docLName">Last Name</label>
                <input name="docLName" value="<?php echo e($row['docLName']); ?>" required id="input-docLName">
            </div>
            <div class="mb-2">
                <label for="input-docAddress">Address</label>
                <input name="docAddress" value="<?php echo e($row['docAddress']); ?>" id="input-docAddress">
            </div>
            <div class="mb-2">
                <label for="input-docSpecial">Specialization</label>
                <input name="docSpecial" value="<?php echo e($row['docSpecial']); ?>" id="input-docSpecial">
            </div>
        </div>
        <div class="form-actions">
            <button class="button">Update</button>
            <a href="index.php" class="button outline">Cancel</a>
        </div>
    </form>
</div>
</body>
</html>
