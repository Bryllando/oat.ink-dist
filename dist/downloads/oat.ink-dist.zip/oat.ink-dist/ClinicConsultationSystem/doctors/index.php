<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

$q = '';
if (!empty($_GET['q'])) {
    $q = $_GET['q'];
    $stmt = $mysqli->prepare("SELECT * FROM doctors WHERE docFName LIKE CONCAT('%',?,'%') OR docLName LIKE CONCAT('%',?,'%') OR docSpecial LIKE CONCAT('%',?,'%') ORDER BY docID DESC");
    $stmt->bind_param('sss', $q, $q, $q);
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    $res = $mysqli->query("SELECT * FROM doctors ORDER BY docID DESC");
}
?>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
    <div class="site-hero mb-3">
        <h1 class="page-title">Doctors</h1>
        <small class="text-light">Manage registered physicians and medical specialties</small>
    </div>

    <div class="card-surface mb-4">
        <div class="flex justify-between items-center mb-3">
            <a class="button" href="add.php">Add New Doctor</a>
            <form class="flex gap-2 filter-form" method="get" style="max-width: 340px;">
                <input name="q" placeholder="Search name or specialty..." value="<?php echo e($q); ?>">
                <button type="submit" class="button">Search</button>
        <?php if ($q): ?>
                <a href="index.php" class="button outline">Clear</a>
        <?php endif; ?>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Specialization</th>
                    <th style="width: 140px;">Actions</th>
                </tr>
            </thead>
            <tbody>
      <?php if ($res && $res->num_rows > 0): ?>
        <?php while ($row = $res->fetch_assoc()): ?>
                <tr>
                    <td><?php echo e($row['docID']); ?></td>
                    <td><strong>Dr. <?php echo e($row['docFName'] . ' ' . $row['docLName']); ?></strong></td>
                    <td><span class="badge surface-muted text-dark"><?php echo e($row['docSpecial']); ?></span></td>
                    <td>
                        <a class="button small outline" href="edit.php?id=<?php echo $row['docID']; ?>">Edit</a>
                        <a class="button small danger-action ms-1" href="delete.php?id=<?php echo $row['docID']; ?>" onclick="return confirm('Delete doctor?');">Delete</a>
                    </td>
                </tr>
        <?php endwhile; ?>
      <?php else: ?>
                <tr><td colspan="4" class="align-center text-light py-3">No doctors found.</td></tr>
      <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
