<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $mysqli->prepare("DELETE FROM doctors WHERE docID = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    flash('success','Doctor deleted.');
}
redirect('index.php');
