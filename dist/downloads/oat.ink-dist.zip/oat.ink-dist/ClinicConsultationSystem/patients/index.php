<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

$q = '';
if (!empty($_GET['q'])) {
    $q = $_GET['q'];
    $stmt = $mysqli->prepare("SELECT * FROM patients WHERE patFName LIKE CONCAT('%',?,'%') OR patLName LIKE CONCAT('%',?,'%') ORDER BY patID DESC");
    $stmt->bind_param('ss', $q, $q);
    $stmt->execute();
    $res = $stmt->get_result();
} else {
    $res = $mysqli->query("SELECT * FROM patients ORDER BY patID DESC");
}
?>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container">
    <div class="site-hero mb-3">
        <h1 class="page-title">Patients</h1>
        <small class="text-light">Register and search patient medical profiles</small>
    </div>

    <div class="card-surface mb-4">
        <div class="flex justify-between items-center mb-3">
            <a class="button" href="add.php">Add New Patient</a>
            <form class="flex gap-2 filter-form" method="get" style="max-width: 340px;">
                <input name="q" placeholder="Search patient name..." value="<?php echo e($q); ?>">
                <button type="submit" class="button">Search</button>
        <?php if ($q): ?>
                <a href="index.php" class="button outline">Clear</a>
        <?php endif; ?>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Full Name</th>
                    <th>Birthdate</th>
                    <th>Telephone</th>
                    <th style="width: 140px;">Actions</th>
                </tr>
            </thead>
            <tbody>
      <?php if ($res && $res->num_rows > 0): ?>
        <?php while ($row = $res->fetch_assoc()): ?>
                <tr>
                    <td><?php echo e($row['patID']); ?></td>
                    <td><strong><?php echo e($row['patFName'] . ' ' . $row['patLName']); ?></strong></td>
                    <td><?php echo e($row['patBDate']); ?></td>
                    <td><?php echo e($row['patTelNo']); ?></td>
                    <td>
                        <a class="button small outline" href="edit.php?id=<?php echo $row['patID']; ?>">Edit</a>
                        <a class="button small danger-action ms-1" href="delete.php?id=<?php echo $row['patID']; ?>" onclick="return confirm('Delete patient?');">Delete</a>
                    </td>
                </tr>
        <?php endwhile; ?>
      <?php else: ?>
                <tr><td colspan="5" class="align-center text-light py-3">No patients found.</td></tr>
      <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
