<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$id = $_GET['id'] ?? null;
if (!$id) redirect('index.php');
$stmt = $mysqli->prepare("SELECT * FROM patients WHERE patID = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
if (!$row) redirect('index.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = $_POST['patFName'] ?? '';
    $l = $_POST['patLName'] ?? '';
    $b = $_POST['patBDate'] ?? null;
    $t = $_POST['patTelNo'] ?? '';
    $up = $mysqli->prepare("UPDATE patients SET patFName=?, patLName=?, patBDate=?, patTelNo=? WHERE patID=?");
    $up->bind_param('ssssi', $f, $l, $b, $t, $id);
    $up->execute();
    flash('success','Patient updated.');
    redirect('index.php');
}
?>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container form-page">
    <h1 class="page-title">Edit Patient</h1>
    <form method="post" class="entry-form form-panel">
        <div class="field-grid">
            <div class="mb-2"><label for="input-patFName">First Name</label><input name="patFName" value="<?php echo e($row['patFName']); ?>" required id="input-patFName"></div>
            <div class="mb-2"><label for="input-patLName">Last Name</label><input name="patLName" value="<?php echo e($row['patLName']); ?>" required id="input-patLName"></div>
            <div class="mb-2"><label for="input-patBDate">Birth Date</label><input type="date" name="patBDate" value="<?php echo e($row['patBDate']); ?>" id="input-patBDate"></div>
            <div class="mb-2"><label for="input-patTelNo">Tel No</label><input name="patTelNo" value="<?php echo e($row['patTelNo']); ?>" id="input-patTelNo"></div>
        </div>
        <div class="form-actions">
            <button class="button">Update</button>
            <a href="index.php" class="button outline">Cancel</a>
        </div>
    </form>
</div>
</body>
</html>
