<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';
$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $mysqli->prepare("DELETE FROM patients WHERE patID = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    flash('success','Patient deleted.');
}
redirect('index.php');
