<?php
require_once __DIR__ . '/../helpers.php';
$mysqli = require __DIR__ . '/../database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $f = $_POST['patFName'] ?? '';
    $l = $_POST['patLName'] ?? '';
    $b = $_POST['patBDate'] ?? null;
    $t = $_POST['patTelNo'] ?? '';
    $stmt = $mysqli->prepare("INSERT INTO patients (patFName, patLName, patBDate, patTelNo) VALUES (?,?,?,?)");
    $stmt->bind_param('ssss', $f, $l, $b, $t);
    $stmt->execute();
    flash('success','Patient added.');
    redirect('index.php');
}
?>
<?php include __DIR__ . '/../navbar.php'; ?>
<div class="container form-page">
    <h1 class="page-title">Add Patient</h1>
    <form method="post" class="entry-form form-panel">
        <div class="field-grid">
            <div class="mb-2"><label for="input-patFName">First Name</label><input name="patFName" required id="input-patFName"></div>
            <div class="mb-2"><label for="input-patLName">Last Name</label><input name="patLName" required id="input-patLName"></div>
            <div class="mb-2"><label for="input-patBDate">Birth Date</label><input type="date" name="patBDate" id="input-patBDate"></div>
            <div class="mb-2"><label for="input-patTelNo">Tel No</label><input name="patTelNo" id="input-patTelNo"></div>
        </div>
        <div class="form-actions">
            <button class="button">Save</button>
            <a href="index.php" class="button outline">Cancel</a>
        </div>
    </form>
</div>
</body>
</html>
