-- Clinic Consultation System database schema and sample data
CREATE DATABASE IF NOT EXISTS clinicdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE clinicdb;

-- Doctors table
CREATE TABLE IF NOT EXISTS doctors (
  docID INT AUTO_INCREMENT PRIMARY KEY,
  docFName VARCHAR(100) NOT NULL,
  docLName VARCHAR(100) NOT NULL,
  docAddress VARCHAR(255),
  docSpecial VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Patients table
CREATE TABLE IF NOT EXISTS patients (
  patID INT AUTO_INCREMENT PRIMARY KEY,
  patFName VARCHAR(100) NOT NULL,
  patLName VARCHAR(100) NOT NULL,
  patBDate DATE,
  patTelNo VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Consultations table
CREATE TABLE IF NOT EXISTS consultations (
  consulID INT AUTO_INCREMENT PRIMARY KEY,
  patID INT NOT NULL,
  docID INT NOT NULL,
  consulDate DATETIME NOT NULL,
  diagnosis TEXT,
  prescription TEXT,
  FOREIGN KEY (patID) REFERENCES patients(patID) ON DELETE CASCADE,
  FOREIGN KEY (docID) REFERENCES doctors(docID) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample data (single set)
INSERT INTO doctors (docFName, docLName, docAddress, docSpecial) VALUES
('Alice','Reyes','123 Mango St','Pediatrics'),
('Ben','Santos','45 Oak Ave','General Medicine'),
('Clara','Lopez','8 Pine Rd','Cardiology');

INSERT INTO patients (patFName, patLName, patBDate, patTelNo) VALUES
('Juan','Dela Cruz','1985-05-12','09171234567'),
('Maria','Perez','1990-10-01','09179876543'),
('Jose','Gomez','2000-03-22','09170001111');

INSERT INTO consultations (patID, docID, consulDate, diagnosis, prescription) VALUES
(1,1,'2024-10-29 09:00:00','Flu-like symptoms','Paracetamol 500mg'),
(2,2,'2024-10-30 10:30:00','Routine check-up','No medication'),
(3,3,'2024-11-01 14:15:00','Chest pain','Refer to cardiology'),
(1,2,'2024-11-02 11:00:00','Follow-up','Continue meds'),
(2,1,'2024-11-03 15:45:00','Allergy','Antihistamine');

-- End of clean seed
-- End of sample data
