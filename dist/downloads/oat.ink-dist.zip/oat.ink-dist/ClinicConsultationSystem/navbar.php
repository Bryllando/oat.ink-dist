<?php
if (!isset($baseUrl)) {
    require_once __DIR__ . '/database.php';
}
$navBase = rtrim($baseUrl, '/');
$currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="<?php echo $baseUrl; ?>assets/css/oat.min.css">
        <link rel="stylesheet" href="<?php echo $baseUrl; ?>assets/css/app.css">
        <script src="<?php echo $baseUrl; ?>assets/js/oat.min.js" defer></script>
        <script src="<?php echo $baseUrl; ?>assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Clinic Consultation System</title>
  
  
    </head>
    <body>
        <nav class="app-nav mb-4">
            <div class="container-fluid container">
                <a class="app-brand nav-brand" href="<?php echo $navBase; ?>/index.php">Clinic Consultation</a>
    
                <div class="nav-region" id="navmenu">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link <?php echo (strpos($currentUri, '/doctors/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/doctors/index.php">Doctors</a></li>
                        <li><a class="nav-link <?php echo (strpos($currentUri, '/patients/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/patients/index.php">Patients</a></li>
                        <li><a class="nav-link <?php echo (strpos($currentUri, '/consultations/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/consultations/index.php">Consultations</a></li>
                        <li><a class="nav-link <?php echo (strpos($currentUri, '/monitoring/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/monitoring/index.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>
