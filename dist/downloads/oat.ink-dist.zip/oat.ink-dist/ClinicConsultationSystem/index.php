<?php
require_once __DIR__ . '/helpers.php';
?>
<?php include 'navbar.php'; ?>
<div class="container">
    <div class="page-heading">
        <h1 class="page-title">Clinic Consultation System</h1>
    </div>

    <div class="simple-panel mb-4">
        <ul class="simple-menu">
            <li><a href="doctors/index.php"><span>Doctors</span> </a></li>
            <li><a href="patients/index.php"><span>Patients</span> </a></li>
            <li><a href="consultations/index.php"><span>Consultations</span> </a></li>
            <li><a href="monitoring/index.php"><span>Monitoring & Inquiry (Aggregates)</span></a></li>
        </ul>
    </div>
</div>

</body>
</html>
