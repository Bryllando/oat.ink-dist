> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

Clinic Consultation Logging System
===================================

Project Summary
---------------
A compact clinic consultation logging system for XAMPP that supports doctor, patient, and consultation transaction management with queryable consultation history.

Why this is suitable
--------------------
Designed to meet the sample skills test scope: simple backend tables, working frontend CRUD operations, consultation logging, and search/inquiry functionality with COUNT aggregates.

Quick Description
-----------------
- PHP procedural + MySQLi (no frameworks)
- Local Oat UI assets only (offline-capable)
- Modules: Doctors, Patients, Consultations, Inquiry
- Core pages per module: index.php, add.php, edit.php, delete.php
-------------
1. Copy the project to `ClinicConsultationSystem` under XAMPP `htdocs`
2. Start Apache and MySQL in XAMPP
3. Import `database.sql` using phpMyAdmin or the MySQL CLI
4. Open `http://localhost/ClinicConsultationSystem/index.php`
-----------------------
Database: `clinicdb`

Doctors table
- `docID` INT PK
- `docFName` VARCHAR
- `docLName` VARCHAR
- `docAddress` VARCHAR
- `docSpecial` VARCHAR

Patients table
- `patID` INT PK
- `patFName` VARCHAR
- `patLName` VARCHAR
- `patBDate` DATE
- `patTelNo` VARCHAR

Consultations table
- `consulID` INT PK
- `patID` INT FK -> patients.patID
- `docID` INT FK -> doctors.docID
- `consulDate` DATETIME
- `diagnosis` TEXT
- `prescription` TEXT
----------------
- `index.php` — Homepage / menu
- `doctors/` — `index.php`, `add.php`, `edit.php`, `delete.php`
- `patients/` — `index.php`, `add.php`, `edit.php`, `delete.php`
- `consultations/` — `index.php`, `add.php`, `edit.php`, `delete.php`
- `monitoring/` — `index.php` (inquiry/filter + aggregate count)

What this implementation covers
--------------------------------
- Doctors: Add, List, Edit, Delete, Search
- Patients: Add, List, Edit, Delete, Search
- Consultations: Add new consultation, link patient and doctor, save date/time, diagnosis, and prescription
- Inquiry / Monitoring: Filter consultations by doctor, patient, date, or specialization and show result counts
----------------
- `database.php` — DB connection
- `helpers.php` — helper functions (`escape`, `flash`, `redirect`)
- `database.sql` — schema and sample rows
- `navbar.php` — shared navigation
- `assets/css/oat.min.css`, `assets/js/oat.min.js` — offline Oat assets

-------------------
- Include sample data so the reviewer can test: Add → Search → Edit → Delete → Consult → Inquiry
- Use clear UI labels such as “Add Doctor”, “Search Patient”, “New Consultation”, and “Inquiry Results”
- Keep menu links visible and actions obvious
- Show a compact monitoring/inquiry page with COUNT results

Maintenance notes
-----------------
- Keep `database.php` as the single database connection point
- Validate inputs server-side and escape output with `htmlspecialchars()`
- Keep sample data and update `database.sql` after schema changes

README summary
--------------
Clinic Consultation Logging System — PHP + MySQL (XAMPP)
Local setup: copy to `ClinicConsultationSystem`, import `database.sql`, start XAMPP, open `index.php`.
Modules: Doctors, Patients, Consultations, Inquiry.
Purpose: Working CRUD for doctors/patients, consultation transaction logging, and inquiry with aggregate counts.
Quick checks for grading: Add Doctor, Search Patient, Edit Consultation, Delete Record, Log Consultation, View Inquiry totals.