<?php
mysqli_report(MYSQLI_REPORT_OFF);
$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'clinicdb';

$mysqli = @mysqli_connect($DB_HOST, $DB_USER, $DB_PASS);
if (!$mysqli) {
    die('Database connection failed: ' . htmlspecialchars(mysqli_connect_error()));
}

// Auto-create database if not exists
$mysqli->query("CREATE DATABASE IF NOT EXISTS `{$DB_NAME}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci") or die('Database setup failed: ' . htmlspecialchars($mysqli->error));
$mysqli->select_db($DB_NAME) or die('Database setup failed: ' . htmlspecialchars($mysqli->error));
$mysqli->set_charset('utf8mb4') or die('Database setup failed: ' . htmlspecialchars($mysqli->error));

$tables = $mysqli->query("SHOW TABLES");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($mysqli->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/database.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $mysqli->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($mysqli->error));
    do {
        if ($result = $mysqli->store_result()) $result->free();
    } while ($mysqli->more_results() && $mysqli->next_result());
    if ($mysqli->errno) die('Database setup failed: ' . htmlspecialchars($mysqli->error));
}

// shortcut: project must be inside the web root; use an explicit URL for Apache aliases.
$docRoot = rtrim(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])), '/');
$projectDir = str_replace('\\', '/', __DIR__);
$baseUrl = substr($projectDir, strlen($docRoot)) . '/';

return $mysqli;
?>
