<?php
require_once 'database.php';

$alert_msg = '';
$alert_class = '';
$focus_element = '';

$medID = '';
$medName = '';
$category = '';
$unitPrice = '';
$stocks = '';

// Handle inline actions via GET
if (isset($_GET['edit_id'])) {
    $search_id = intval($_GET['edit_id']);
    $query = "SELECT * FROM Medicines WHERE medID = $search_id";
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $medID = $row['medID'];
        $medName = $row['medName'];
        $category = $row['category'];
        $unitPrice = $row['unitPrice'];
        $stocks = $row['stocks'];
        $alert_msg = 'ITEM IS FOUND';
        $alert_class = 'notice-success';
    } else {
        $alert_msg = 'ITEM NOT FOUND';
        $alert_class = 'notice-warning';
    }
}

if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    // Check if the record exists first
    $check_query = "SELECT * FROM Medicines WHERE medID = $delete_id";
    $check_res = mysqli_query($conn, $check_query);
    if ($check_res && mysqli_num_rows($check_res) > 0) {
        $query = "DELETE FROM Medicines WHERE medID = $delete_id";
        if (mysqli_query($conn, $query)) {
            $alert_msg = 'RECORD SUCCESSFULLY DELETED';
            $alert_class = 'notice-success';
        } else {
            $alert_msg = 'Error deleting record: ' . mysqli_error($conn);
            $alert_class = 'notice-warning';
        }
    } else {
        $alert_msg = 'ITEM NOT FOUND';
        $alert_class = 'notice-warning';
    }
}

// Handle Form Submissions via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    $medID_input = trim($_POST['medID'] ?? '');
    $medID = $medID_input !== '' ? intval($medID_input) : '';
    $medName = trim($_POST['medName'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $unitPrice_input = trim($_POST['unitPrice'] ?? '');
    $unitPrice = $unitPrice_input !== '' ? floatval($unitPrice_input) : '';
    $stocks_input = trim($_POST['stocks'] ?? '');
    $stocks = $stocks_input !== '' ? intval($stocks_input) : '';

    if ($action === 'search') {
        if (empty($medID_input)) {
            $medID = '';
            $medName = '';
            $category = '';
            $unitPrice = '';
            $stocks = '';
            $alert_msg = 'ITEM NOT FOUND';
            $alert_class = 'notice-warning';
        } else {
            $query = "SELECT * FROM Medicines WHERE medID = $medID";
            $result = mysqli_query($conn, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $medID = $row['medID'];
                $medName = $row['medName'];
                $category = $row['category'];
                $unitPrice = $row['unitPrice'];
                $stocks = $row['stocks'];
                $alert_msg = 'ITEM IS FOUND';
                $alert_class = 'notice-success';
            } else {
                $medID = '';
                $medName = '';
                $category = '';
                $unitPrice = '';
                $stocks = '';
                $alert_msg = 'ITEM NOT FOUND';
                $alert_class = 'notice-warning';
            }
        }
    } 
    elseif ($action === 'add') {
        if (empty($medName) && empty($category) && empty($unitPrice_input) && empty($stocks_input)) {
            $alert_msg = 'NO RECORD TO ADD';
            $alert_class = 'notice-warning';
            $focus_element = 'medName';
        } else {
            $escaped_medName = mysqli_real_escape_string($conn, $medName);
            $escaped_category = mysqli_real_escape_string($conn, $category);
            $escaped_unitPrice = floatval($unitPrice);
            $escaped_stocks = intval($stocks);

            $query = "INSERT INTO Medicines (medName, category, unitPrice, stocks) 
                      VALUES ('$escaped_medName', '$escaped_category', $escaped_unitPrice, $escaped_stocks)";
            if (mysqli_query($conn, $query)) {
                $alert_msg = 'RECORD SUCCESSFULLY SAVED';
                $alert_class = 'notice-success';
                // Clear fields after success
                $medID = '';
                $medName = '';
                $category = '';
                $unitPrice = '';
                $stocks = '';
            } else {
                $alert_msg = 'Error inserting record: ' . mysqli_error($conn);
                $alert_class = 'notice-warning';
            }
        }
    } 
    elseif ($action === 'edit') {
        if (empty($medID_input) || (empty($medName) && empty($category) && empty($unitPrice_input) && empty($stocks_input))) {
            $alert_msg = 'NO RECORD TO EDIT';
            $alert_class = 'notice-warning';
        } else {
            // Check if record exists
            $check_query = "SELECT * FROM Medicines WHERE medID = $medID";
            $check_res = mysqli_query($conn, $check_query);
            if ($check_res && mysqli_num_rows($check_res) > 0) {
                $escaped_medName = mysqli_real_escape_string($conn, $medName);
                $escaped_category = mysqli_real_escape_string($conn, $category);
                $escaped_unitPrice = floatval($unitPrice);
                $escaped_stocks = intval($stocks);

                $query = "UPDATE Medicines 
                          SET medName = '$escaped_medName', category = '$escaped_category', unitPrice = $escaped_unitPrice, stocks = $escaped_stocks 
                          WHERE medID = $medID";
                if (mysqli_query($conn, $query)) {
                    $alert_msg = 'RECORD SUCCESSFULLY UPDATED';
                    $alert_class = 'notice-success';
                } else {
                    $alert_msg = 'Error updating record: ' . mysqli_error($conn);
                    $alert_class = 'notice-warning';
                }
            } else {
                $alert_msg = 'ITEM NOT FOUND';
                $alert_class = 'notice-warning';
            }
        }
    } 
    elseif ($action === 'delete') {
        if (empty($medID_input)) {
            $alert_msg = 'ITEM NOT FOUND';
            $alert_class = 'notice-warning';
        } else {
            // Check if record exists
            $check_query = "SELECT * FROM Medicines WHERE medID = $medID";
            $check_res = mysqli_query($conn, $check_query);
            if ($check_res && mysqli_num_rows($check_res) > 0) {
                $query = "DELETE FROM Medicines WHERE medID = $medID";
                if (mysqli_query($conn, $query)) {
                    $alert_msg = 'RECORD SUCCESSFULLY DELETED';
                    $alert_class = 'notice-success';
                    $medID = '';
                    $medName = '';
                    $category = '';
                    $unitPrice = '';
                    $stocks = '';
                } else {
                    $alert_msg = 'Error deleting record: ' . mysqli_error($conn);
                    $alert_class = 'notice-warning';
                }
            } else {
                $alert_msg = 'ITEM NOT FOUND';
                $alert_class = 'notice-warning';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Medicines Management - Pharmacy System</title>
    
    </head>
    <body>

    <!-- Fixed Navigation Bar Module -->
        <nav class="app-nav">
            <a href="index.php" class="brand">PHARMACY SYSTEM</a>
            <ul class="nav-links">
                <li><a href="medicines.php" class="active">Medicines</a></li>
                <li><a href="customers.php">Customers</a></li>
                <li><a href="purchases.php">Purchases</a></li>
            </ul>
        </nav>

    <!-- Main Component Workspace Grid Container -->
        <div class="container">
        <!-- Sub-module Context View Title -->
            <h1 class="module-title page-title">Medicines Management</h1>

        <!-- Primary Entry Form Container Box -->
            <div class="card">
                <form action="medicines.php" method="POST" class="entry-form">
                    <p class="form-text">Enter an ID to search, update or delete an existing record.</p>
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="medID">Medicine ID</label>
                            <input type="number" id="medID" name="medID" placeholder="Enter Medicine ID" value="<?php echo htmlspecialchars($medID); ?>">
                        </div>

                        <div class="form-group">
                            <label for="medName">Medicine Name</label>
                            <input type="text" id="medName" name="medName" placeholder="Enter Medicine Name" value="<?php echo htmlspecialchars($medName); ?>">
                        </div>

                        <div class="form-group">
                            <label for="category">Category</label>
                            <input type="text" id="category" name="category" placeholder="Enter Category" value="<?php echo htmlspecialchars($category); ?>">
                        </div>

                        <div class="form-group">
                            <label for="unitPrice">Unit Price</label>
                            <input type="number" step="0.01" id="unitPrice" name="unitPrice" placeholder="Enter Unit Price" value="<?php echo htmlspecialchars($unitPrice); ?>">
                        </div>

                        <div class="form-group">
                            <label for="stocks">Stocks</label>
                            <input type="number" id="stocks" name="stocks" placeholder="Enter Available Stock Quantity" value="<?php echo htmlspecialchars($stocks); ?>">
                        </div>
                    </div>

                <!-- Dynamic System State PROMPT Zone -->
                <?php if ($alert_msg !== ''): ?>
                    <div class="prompt-zone">
                        <div role="alert" class="notice <?php echo $alert_class; ?>">
                            <?php echo htmlspecialchars($alert_msg); ?>
                        </div>
                    </div>
                <?php endif; ?>

                    <div class="form-actions">
                        <button type="submit" name="action" value="search" class="button outline">SEARCH</button>
                        <button type="submit" name="action" value="add" class="button">ADD</button>
                        <button type="submit" name="action" value="edit" class="button outline">EDIT / UPDATE</button>
                        <button type="submit" name="action" value="delete" class="button danger-action">DELETE</button>
                    </div>
                </form>
            </div>

        <!-- Tabular Matrix Data Grid -->
            <h2>Medicines</h2>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Medicine Name</th>
                            <th>Category</th>
                            <th>Unit Price</th>
                            <th>Stocks</th>
                            <th style="width: 150px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $query = "SELECT * FROM Medicines ORDER BY medID ASC";
                    $result = mysqli_query($conn, $query);

                    if ($result && mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['medID']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['medName']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['category']) . "</td>";
                            echo "<td>$" . number_format($row['unitPrice'], 2) . "</td>";
                            echo "<td>" . htmlspecialchars($row['stocks']) . "</td>";
                            echo "<td class='actions-cell'>";
                            echo "<a href='medicines.php?edit_id=" . $row['medID'] . "' class='button outline small'>Edit</a>";
                            echo "<a href='medicines.php?delete_id=" . $row['medID'] . "' class='button danger-action small' onclick='return confirm(\"Are you sure you want to delete this medicine?\");'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' class='align-center'>No medicine records mapped yet.</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>

    <!-- Script to handle focus highlights -->
    <?php if ($focus_element !== ''): ?>
        <script>
            document.getElementById("<?php echo $focus_element; ?>").focus();
        </script>
    <?php endif; ?>

    </body>
</html>
