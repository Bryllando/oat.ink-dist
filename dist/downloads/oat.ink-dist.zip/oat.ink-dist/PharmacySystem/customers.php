<?php
require_once 'database.php';

$alert_msg = '';
$alert_class = '';
$focus_element = '';

$customerID = '';
$fname = '';
$lname = '';
$contactNo = '';
$address = '';

// Handle inline actions via GET
if (isset($_GET['edit_id'])) {
    $search_id = intval($_GET['edit_id']);
    $query = "SELECT * FROM Customers WHERE customerID = $search_id";
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $customerID = $row['customerID'];
        $fname = $row['fname'];
        $lname = $row['lname'];
        $contactNo = $row['contactNo'];
        $address = $row['address'];
        $alert_msg = 'ITEM IS FOUND';
        $alert_class = 'notice-success';
    } else {
        $alert_msg = 'ITEM NOT FOUND';
        $alert_class = 'notice-warning';
    }
}

if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    // Check if the record exists first
    $check_query = "SELECT * FROM Customers WHERE customerID = $delete_id";
    $check_res = mysqli_query($conn, $check_query);
    if ($check_res && mysqli_num_rows($check_res) > 0) {
        $query = "DELETE FROM Customers WHERE customerID = $delete_id";
        if (mysqli_query($conn, $query)) {
            $alert_msg = 'RECORD SUCCESSFULLY DELETED';
            $alert_class = 'notice-success';
        } else {
            $alert_msg = 'Error deleting record: ' . mysqli_error($conn);
            $alert_class = 'notice-warning';
        }
    } else {
        $alert_msg = 'ITEM NOT FOUND';
        $alert_class = 'notice-warning';
    }
}

// Handle Form Submissions via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    $customerID_input = trim($_POST['customerID'] ?? '');
    $customerID = $customerID_input !== '' ? intval($customerID_input) : '';
    $fname = trim($_POST['fname'] ?? '');
    $lname = trim($_POST['lname'] ?? '');
    $contactNo = trim($_POST['contactNo'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if ($action === 'search') {
        if (empty($customerID_input)) {
            $customerID = '';
            $fname = '';
            $lname = '';
            $contactNo = '';
            $address = '';
            $alert_msg = 'ITEM NOT FOUND';
            $alert_class = 'notice-warning';
        } else {
            $query = "SELECT * FROM Customers WHERE customerID = $customerID";
            $result = mysqli_query($conn, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $customerID = $row['customerID'];
                $fname = $row['fname'];
                $lname = $row['lname'];
                $contactNo = $row['contactNo'];
                $address = $row['address'];
                $alert_msg = 'ITEM IS FOUND';
                $alert_class = 'notice-success';
            } else {
                $customerID = '';
                $fname = '';
                $lname = '';
                $contactNo = '';
                $address = '';
                $alert_msg = 'ITEM NOT FOUND';
                $alert_class = 'notice-warning';
            }
        }
    } 
    elseif ($action === 'add') {
        if (empty($fname) && empty($lname) && empty($contactNo) && empty($address)) {
            $alert_msg = 'NO RECORD TO ADD';
            $alert_class = 'notice-warning';
            $focus_element = 'fname';
        } else {
            $escaped_fname = mysqli_real_escape_string($conn, $fname);
            $escaped_lname = mysqli_real_escape_string($conn, $lname);
            $escaped_contactNo = mysqli_real_escape_string($conn, $contactNo);
            $escaped_address = mysqli_real_escape_string($conn, $address);

            $query = "INSERT INTO Customers (fname, lname, contactNo, address) 
                      VALUES ('$escaped_fname', '$escaped_lname', '$escaped_contactNo', '$escaped_address')";
            if (mysqli_query($conn, $query)) {
                $alert_msg = 'RECORD SUCCESSFULLY SAVED';
                $alert_class = 'notice-success';
                // Clear fields after success
                $customerID = '';
                $fname = '';
                $lname = '';
                $contactNo = '';
                $address = '';
            } else {
                $alert_msg = 'Error inserting record: ' . mysqli_error($conn);
                $alert_class = 'notice-warning';
            }
        }
    } 
    elseif ($action === 'edit') {
        if (empty($customerID_input) || (empty($fname) && empty($lname) && empty($contactNo) && empty($address))) {
            $alert_msg = 'NO RECORD TO EDIT';
            $alert_class = 'notice-warning';
        } else {
            // Check if record exists
            $check_query = "SELECT * FROM Customers WHERE customerID = $customerID";
            $check_res = mysqli_query($conn, $check_query);
            if ($check_res && mysqli_num_rows($check_res) > 0) {
                $escaped_fname = mysqli_real_escape_string($conn, $fname);
                $escaped_lname = mysqli_real_escape_string($conn, $lname);
                $escaped_contactNo = mysqli_real_escape_string($conn, $contactNo);
                $escaped_address = mysqli_real_escape_string($conn, $address);

                $query = "UPDATE Customers 
                          SET fname = '$escaped_fname', lname = '$escaped_lname', contactNo = '$escaped_contactNo', address = '$escaped_address' 
                          WHERE customerID = $customerID";
                if (mysqli_query($conn, $query)) {
                    $alert_msg = 'RECORD SUCCESSFULLY UPDATED';
                    $alert_class = 'notice-success';
                } else {
                    $alert_msg = 'Error updating record: ' . mysqli_error($conn);
                    $alert_class = 'notice-warning';
                }
            } else {
                $alert_msg = 'ITEM NOT FOUND';
                $alert_class = 'notice-warning';
            }
        }
    } 
    elseif ($action === 'delete') {
        if (empty($customerID_input)) {
            $alert_msg = 'ITEM NOT FOUND';
            $alert_class = 'notice-warning';
        } else {
            // Check if record exists
            $check_query = "SELECT * FROM Customers WHERE customerID = $customerID";
            $check_res = mysqli_query($conn, $check_query);
            if ($check_res && mysqli_num_rows($check_res) > 0) {
                $query = "DELETE FROM Customers WHERE customerID = $customerID";
                if (mysqli_query($conn, $query)) {
                    $alert_msg = 'RECORD SUCCESSFULLY DELETED';
                    $alert_class = 'notice-success';
                    $customerID = '';
                    $fname = '';
                    $lname = '';
                    $contactNo = '';
                    $address = '';
                } else {
                    $alert_msg = 'Error deleting record: ' . mysqli_error($conn);
                    $alert_class = 'notice-warning';
                }
            } else {
                $alert_msg = 'ITEM NOT FOUND';
                $alert_class = 'notice-warning';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Customers Management - Pharmacy System</title>
    
    </head>
    <body>

    <!-- Fixed Navigation Bar Module -->
        <nav class="app-nav">
            <a href="index.php" class="brand">PHARMACY SYSTEM</a>
            <ul class="nav-links">
                <li><a href="medicines.php">Medicines</a></li>
                <li><a href="customers.php" class="active">Customers</a></li>
                <li><a href="purchases.php">Purchases</a></li>
            </ul>
        </nav>

    <!-- Main Component Workspace Grid Container -->
        <div class="container">
        <!-- Sub-module Context View Title -->
            <h1 class="module-title page-title">Customers Management</h1>

        <!-- Primary Entry Form Container Box -->
            <div class="card">
                <form action="customers.php" method="POST" class="entry-form">
                    <p class="form-text">Enter an ID to search, update or delete an existing record.</p>
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="customerID">Customer ID</label>
                            <input type="number" id="customerID" name="customerID" placeholder="Enter Customer ID" value="<?php echo htmlspecialchars($customerID); ?>">
                        </div>

                        <div class="form-group">
                            <label for="fname">First Name</label>
                            <input type="text" id="fname" name="fname" placeholder="Enter First Name" value="<?php echo htmlspecialchars($fname); ?>">
                        </div>

                        <div class="form-group">
                            <label for="lname">Last Name</label>
                            <input type="text" id="lname" name="lname" placeholder="Enter Last Name" value="<?php echo htmlspecialchars($lname); ?>">
                        </div>

                        <div class="form-group">
                            <label for="contactNo">Contact Number</label>
                            <input type="text" id="contactNo" name="contactNo" placeholder="Enter Contact Number" value="<?php echo htmlspecialchars($contactNo); ?>">
                        </div>

                        <div class="form-group">
                            <label for="address">Address</label>
                            <textarea id="address" name="address" rows="3" placeholder="Enter Physical Address"><?php echo htmlspecialchars($address); ?></textarea>
                        </div>
                    </div>

                <!-- Dynamic System State PROMPT Zone -->
                <?php if ($alert_msg !== ''): ?>
                    <div class="prompt-zone">
                        <div role="alert" class="notice <?php echo $alert_class; ?>">
                            <?php echo htmlspecialchars($alert_msg); ?>
                        </div>
                    </div>
                <?php endif; ?>

                    <div class="form-actions">
                        <button type="submit" name="action" value="search" class="button outline">SEARCH</button>
                        <button type="submit" name="action" value="add" class="button">ADD</button>
                        <button type="submit" name="action" value="edit" class="button outline">EDIT / UPDATE</button>
                        <button type="submit" name="action" value="delete" class="button danger-action">DELETE</button>
                    </div>
                </form>
            </div>

        <!-- Tabular Matrix Data Grid -->
            <h2>Customer Records</h2>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Customer Name</th>
                            <th>Contact Info</th>
                            <th>Address</th>
                            <th style="width: 150px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $query = "SELECT * FROM Customers ORDER BY customerID ASC";
                    $result = mysqli_query($conn, $query);

                    if ($result && mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            // Concatenated full name (First Last)
                            $fullname = $row['fname'] . ' ' . $row['lname'];
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['customerID']) . "</td>";
                            echo "<td>" . htmlspecialchars($fullname) . "</td>";
                            echo "<td>" . htmlspecialchars($row['contactNo']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['address']) . "</td>";
                            echo "<td class='actions-cell'>";
                            echo "<a href='customers.php?edit_id=" . $row['customerID'] . "' class='button outline small'>Edit</a>";
                            echo "<a href='customers.php?delete_id=" . $row['customerID'] . "' class='button danger-action small' onclick='return confirm(\"Are you sure you want to delete this customer?\");'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' class='align-center'>No customer data recorded.</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>

    <!-- Script to handle focus highlights -->
    <?php if ($focus_element !== ''): ?>
        <script>
            document.getElementById("<?php echo $focus_element; ?>").focus();
        </script>
    <?php endif; ?>

    </body>
</html>
