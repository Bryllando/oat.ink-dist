<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pharmacy Management System - Dashboard</title>
    
    </head>
    <body>

    <!-- Fixed Navigation Bar Module -->
        <nav class="app-nav">
            <a href="index.php" class="brand">PHARMACY SYSTEM</a>
            <ul class="nav-links">
                <li><a href="medicines.php">Medicines</a></li>
                <li><a href="customers.php">Customers</a></li>
                <li><a href="purchases.php">Purchases</a></li>
            </ul>
        </nav>
        <main class="container">
            <h1 class="page-title">Pharmacy System</h1>
            <ul class="simple-menu">
                <li><a href="medicines.php">Medicines</a></li>
                <li><a href="customers.php">Customers</a></li>
                <li><a href="purchases.php">Purchases</a></li>
            </ul>
        </main>
    </body>
</html>
