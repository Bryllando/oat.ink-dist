<?php
require_once 'database.php';

$alert_msg = '';
$alert_class = '';
$focus_element = '';

$purchaseID = '';
$customerID = '';
$medID = '';
$quantity = '';
$discount = '';
$purchaseDate = '';

// Handle inline actions via GET
if (isset($_GET['edit_id'])) {
    $search_id = intval($_GET['edit_id']);
    $query = "SELECT * FROM Purchase WHERE purchaseID = $search_id";
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $purchaseID = $row['purchaseID'];
        $customerID = $row['customerID'];
        $medID = $row['medID'];
        $quantity = $row['quantity'];
        $discount = $row['discount'];
        $purchaseDate = $row['purchaseDate'];
        $alert_msg = 'ITEM IS FOUND';
        $alert_class = 'notice-success';
    } else {
        $alert_msg = 'ITEM NOT FOUND';
        $alert_class = 'notice-warning';
    }
}

if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    // Check if the record exists first
    $check_query = "SELECT * FROM Purchase WHERE purchaseID = $delete_id";
    $check_res = mysqli_query($conn, $check_query);
    if ($check_res && mysqli_num_rows($check_res) > 0) {
        $query = "DELETE FROM Purchase WHERE purchaseID = $delete_id";
        if (mysqli_query($conn, $query)) {
            $alert_msg = 'RECORD SUCCESSFULLY DELETED';
            $alert_class = 'notice-success';
        } else {
            $alert_msg = 'Error deleting record: ' . mysqli_error($conn);
            $alert_class = 'notice-warning';
        }
    } else {
        $alert_msg = 'ITEM NOT FOUND';
        $alert_class = 'notice-warning';
    }
}

// Handle Form Submissions via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    $purchaseID_input = trim($_POST['purchaseID'] ?? '');
    $purchaseID = $purchaseID_input !== '' ? intval($purchaseID_input) : '';
    
    $customerID = trim($_POST['customerID'] ?? '');
    $medID = trim($_POST['medID'] ?? '');
    $quantity_input = trim($_POST['quantity'] ?? '');
    $discount_input = trim($_POST['discount'] ?? '');
    $purchaseDate = trim($_POST['purchaseDate'] ?? '');

    if ($action === 'search') {
        if (empty($purchaseID_input)) {
            $purchaseID = '';
            $customerID = '';
            $medID = '';
            $quantity = '';
            $discount = '';
            $purchaseDate = '';
            $alert_msg = 'ITEM NOT FOUND';
            $alert_class = 'notice-warning';
        } else {
            $query = "SELECT * FROM Purchase WHERE purchaseID = $purchaseID";
            $result = mysqli_query($conn, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $purchaseID = $row['purchaseID'];
                $customerID = $row['customerID'];
                $medID = $row['medID'];
                $quantity = $row['quantity'];
                $discount = $row['discount'];
                $purchaseDate = $row['purchaseDate'];
                $alert_msg = 'ITEM IS FOUND';
                $alert_class = 'notice-success';
            } else {
                $purchaseID = '';
                $customerID = '';
                $medID = '';
                $quantity = '';
                $discount = '';
                $purchaseDate = '';
                $alert_msg = 'ITEM NOT FOUND';
                $alert_class = 'notice-warning';
            }
        }
    } 
    elseif ($action === 'add') {
        if (empty($customerID) || empty($medID) || empty($quantity_input) || empty($purchaseDate)) {
            $alert_msg = 'NO RECORD TO ADD';
            $alert_class = 'notice-warning';
            $focus_element = 'customerID';
        } else {
            $customerID = intval($customerID);
            $medID = intval($medID);
            $quantity = intval($quantity_input);
            $discount = $discount_input !== '' ? floatval($discount_input) : 0.00;
            
            // Get medicine price from DB
            $med_query = "SELECT unitPrice FROM Medicines WHERE medID = $medID";
            $med_result = mysqli_query($conn, $med_query);
            
            if ($med_result && mysqli_num_rows($med_result) > 0) {
                $med_row = mysqli_fetch_assoc($med_result);
                $unitPrice = floatval($med_row['unitPrice']);
                
                // Calculate using formula: totalAmount = (quantity * unitPrice) - discount
                $totalAmount = ($quantity * $unitPrice) - $discount;
                $escaped_date = mysqli_real_escape_string($conn, $purchaseDate);
                
                $query = "INSERT INTO Purchase (customerID, medID, quantity, discount, totalAmount, purchaseDate) 
                          VALUES ($customerID, $medID, $quantity, $discount, $totalAmount, '$escaped_date')";
                if (mysqli_query($conn, $query)) {
                    $alert_msg = 'RECORD SUCCESSFULLY SAVED';
                    $alert_class = 'notice-success';
                    // Clear fields after success
                    $purchaseID = '';
                    $customerID = '';
                    $medID = '';
                    $quantity = '';
                    $discount = '';
                    $purchaseDate = '';
                } else {
                    $alert_msg = 'Error inserting record: ' . mysqli_error($conn);
                    $alert_class = 'notice-warning';
                }
            } else {
                $alert_msg = 'Error: Selected medicine not found.';
                $alert_class = 'notice-warning';
            }
        }
    } 
    elseif ($action === 'edit') {
        if (empty($purchaseID_input) || empty($customerID) || empty($medID) || empty($quantity_input) || empty($purchaseDate)) {
            $alert_msg = 'NO RECORD TO EDIT';
            $alert_class = 'notice-warning';
        } else {
            // Check if record exists
            $check_query = "SELECT * FROM Purchase WHERE purchaseID = $purchaseID";
            $check_res = mysqli_query($conn, $check_query);
            if ($check_res && mysqli_num_rows($check_res) > 0) {
                $customerID = intval($customerID);
                $medID = intval($medID);
                $quantity = intval($quantity_input);
                $discount = $discount_input !== '' ? floatval($discount_input) : 0.00;
                
                // Get medicine price from DB
                $med_query = "SELECT unitPrice FROM Medicines WHERE medID = $medID";
                $med_result = mysqli_query($conn, $med_query);
                
                if ($med_result && mysqli_num_rows($med_result) > 0) {
                    $med_row = mysqli_fetch_assoc($med_result);
                    $unitPrice = floatval($med_row['unitPrice']);
                    
                    // Calculate totalAmount
                    $totalAmount = ($quantity * $unitPrice) - $discount;
                    $escaped_date = mysqli_real_escape_string($conn, $purchaseDate);
                    
                    $query = "UPDATE Purchase 
                              SET customerID = $customerID, medID = $medID, quantity = $quantity, discount = $discount, totalAmount = $totalAmount, purchaseDate = '$escaped_date' 
                              WHERE purchaseID = $purchaseID";
                    if (mysqli_query($conn, $query)) {
                        $alert_msg = 'RECORD SUCCESSFULLY UPDATED';
                        $alert_class = 'notice-success';
                    } else {
                        $alert_msg = 'Error updating record: ' . mysqli_error($conn);
                        $alert_class = 'notice-warning';
                    }
                } else {
                    $alert_msg = 'Error: Selected medicine not found.';
                    $alert_class = 'notice-warning';
                }
            } else {
                $alert_msg = 'ITEM NOT FOUND';
                $alert_class = 'notice-warning';
            }
        }
    } 
    elseif ($action === 'delete') {
        if (empty($purchaseID_input)) {
            $alert_msg = 'ITEM NOT FOUND';
            $alert_class = 'notice-warning';
        } else {
            // Check if record exists
            $check_query = "SELECT * FROM Purchase WHERE purchaseID = $purchaseID";
            $check_res = mysqli_query($conn, $check_query);
            if ($check_res && mysqli_num_rows($check_res) > 0) {
                $query = "DELETE FROM Purchase WHERE purchaseID = $purchaseID";
                if (mysqli_query($conn, $query)) {
                    $alert_msg = 'RECORD SUCCESSFULLY DELETED';
                    $alert_class = 'notice-success';
                    $purchaseID = '';
                    $customerID = '';
                    $medID = '';
                    $quantity = '';
                    $discount = '';
                    $purchaseDate = '';
                } else {
                    $alert_msg = 'Error deleting record: ' . mysqli_error($conn);
                    $alert_class = 'notice-warning';
                }
            } else {
                $alert_msg = 'ITEM NOT FOUND';
                $alert_class = 'notice-warning';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Purchase Transactions - Pharmacy System</title>
    
    </head>
    <body>

    <!-- Fixed Navigation Bar Module -->
        <nav class="app-nav">
            <a href="index.php" class="brand">PHARMACY SYSTEM</a>
            <ul class="nav-links">
                <li><a href="medicines.php">Medicines</a></li>
                <li><a href="customers.php">Customers</a></li>
                <li><a href="purchases.php" class="active">Purchases</a></li>
            </ul>
        </nav>

    <!-- Main Component Workspace Grid Container -->
        <div class="container">
        <!-- Sub-module Context View Title -->
            <h1 class="module-title page-title">Purchase Transaction Management</h1>

        <!-- Primary Entry Form Container Box -->
            <div class="card">
                <form action="purchases.php" method="POST" class="entry-form">
                    <p class="form-text">Enter an ID to search, update or delete an existing record.</p>
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="purchaseID">Purchase ID</label>
                            <input type="number" id="purchaseID" name="purchaseID" placeholder="Enter Purchase ID" value="<?php echo htmlspecialchars($purchaseID); ?>">
                        </div>

                        <div class="form-group">
                            <label for="customerID">Customer Profile</label>
                            <select id="customerID" name="customerID">
                                <option value="">-- Select Customer --</option>
                        <?php
                        $cust_query = "SELECT customerID, fname, lname FROM Customers ORDER BY fname ASC, lname ASC";
                        $cust_res = mysqli_query($conn, $cust_query);
                        if ($cust_res && mysqli_num_rows($cust_res) > 0) {
                            while ($cust_row = mysqli_fetch_assoc($cust_res)) {
                                $selected = (strval($cust_row['customerID']) === strval($customerID)) ? 'selected' : '';
                                $fullname = $cust_row['fname'] . ' ' . $cust_row['lname'];
                                echo "<option value='" . htmlspecialchars($cust_row['customerID']) . "' $selected>[" . htmlspecialchars($cust_row['customerID']) . "] " . htmlspecialchars($fullname) . "</option>";
                            }
                        }
                        ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="medID">Medicine Item</label>
                            <select id="medID" name="medID">
                                <option value="">-- Select Medicine --</option>
                        <?php
                        $med_query = "SELECT medID, medName, unitPrice FROM Medicines ORDER BY medName ASC";
                        $med_res = mysqli_query($conn, $med_query);
                        if ($med_res && mysqli_num_rows($med_res) > 0) {
                            while ($med_row = mysqli_fetch_assoc($med_res)) {
                                $selected = (strval($med_row['medID']) === strval($medID)) ? 'selected' : '';
                                echo "<option value='" . htmlspecialchars($med_row['medID']) . "' $selected>[" . htmlspecialchars($med_row['medID']) . "] " . htmlspecialchars($med_row['medName']) . " ($" . number_format($med_row['unitPrice'], 2) . ")</option>";
                            }
                        }
                        ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="quantity">Quantity</label>
                            <input type="number" min="1" id="quantity" name="quantity" placeholder="Enter Quantity" value="<?php echo htmlspecialchars($quantity); ?>">
                        </div>

                        <div class="form-group">
                            <label for="discount">Discount Amount</label>
                            <input type="number" step="0.01" min="0" id="discount" name="discount" placeholder="Enter Discount Amount" value="<?php echo htmlspecialchars($discount); ?>">
                        </div>

                        <div class="form-group">
                            <label for="purchaseDate">Purchase Date</label>
                            <input type="date" id="purchaseDate" name="purchaseDate" value="<?php echo htmlspecialchars($purchaseDate); ?>">
                        </div>
                    </div>

                <!-- Dynamic System State PROMPT Zone -->
                <?php if ($alert_msg !== ''): ?>
                    <div class="prompt-zone">
                        <div role="alert" class="notice <?php echo $alert_class; ?>">
                            <?php echo htmlspecialchars($alert_msg); ?>
                        </div>
                    </div>
                <?php endif; ?>

                    <div class="form-actions">
                        <button type="submit" name="action" value="search" class="button outline">SEARCH</button>
                        <button type="submit" name="action" value="add" class="button">ADD</button>
                        <button type="submit" name="action" value="edit" class="button outline">EDIT / UPDATE</button>
                        <button type="submit" name="action" value="delete" class="button danger-action">DELETE</button>
                    </div>
                </form>
            </div>

        <!-- Tabular Matrix Data Grid -->
            <h2>Purchase History</h2>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Purchase ID</th>
                            <th>Customer Name</th>
                            <th>Medicine Purchased</th>
                            <th>Quantity</th>
                            <th>Discount</th>
                            <th>Total Amount</th>
                            <th>Date</th>
                            <th style="width: 150px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $query = "SELECT p.*, c.fname, c.lname, m.medName 
                              FROM Purchase p
                              LEFT JOIN Customers c ON p.customerID = c.customerID 
                              LEFT JOIN Medicines m ON p.medID = m.medID 
                              ORDER BY p.purchaseID ASC";
                    $result = mysqli_query($conn, $query);

                    if ($result && mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $cust_name = $row['fname'] . ' ' . $row['lname'];
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['purchaseID']) . "</td>";
                            echo "<td>" . htmlspecialchars($cust_name) . "</td>";
                            echo "<td>" . htmlspecialchars($row['medName']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['quantity']) . "</td>";
                            echo "<td>$" . number_format($row['discount'], 2) . "</td>";
                            echo "<td>$" . number_format($row['totalAmount'], 2) . "</td>";
                            echo "<td>" . htmlspecialchars($row['purchaseDate']) . "</td>";
                            echo "<td class='actions-cell'>";
                            echo "<a href='purchases.php?edit_id=" . $row['purchaseID'] . "' class='button outline small'>Edit</a>";
                            echo "<a href='purchases.php?delete_id=" . $row['purchaseID'] . "' class='button danger-action small' onclick='return confirm(\"Are you sure you want to delete this purchase transaction?\");'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8' class='align-center'>No transaction entries saved yet.</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>

    <!-- Script to handle focus highlights -->
    <?php if ($focus_element !== ''): ?>
        <script>
            document.getElementById("<?php echo $focus_element; ?>").focus();
        </script>
    <?php endif; ?>

    </body>
</html>
