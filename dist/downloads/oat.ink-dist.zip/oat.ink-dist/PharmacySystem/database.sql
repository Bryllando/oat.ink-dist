CREATE DATABASE IF NOT EXISTS `pharmacy`;
USE `pharmacy`;

-- Table 1: Medicines
CREATE TABLE IF NOT EXISTS `Medicines` (
  `medID` INT AUTO_INCREMENT PRIMARY KEY,
  `medName` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `unitPrice` DECIMAL(10, 2) NOT NULL,
  `stocks` INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 2: Customers
CREATE TABLE IF NOT EXISTS `Customers` (
  `customerID` INT AUTO_INCREMENT PRIMARY KEY,
  `fname` VARCHAR(100) NOT NULL,
  `lname` VARCHAR(100) NOT NULL,
  `contactNo` VARCHAR(50) NOT NULL,
  `address` TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 3: Purchase
CREATE TABLE IF NOT EXISTS `Purchase` (
  `purchaseID` INT AUTO_INCREMENT PRIMARY KEY,
  `customerID` INT NOT NULL,
  `medID` INT NOT NULL,
  `quantity` INT NOT NULL,
  `discount` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
  `totalAmount` DECIMAL(10, 2) NOT NULL,
  `purchaseDate` DATE NOT NULL,
  CONSTRAINT `fk_purchase_customer` FOREIGN KEY (`customerID`) REFERENCES `Customers` (`customerID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_purchase_medicine` FOREIGN KEY (`medID`) REFERENCES `Medicines` (`medID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Optional initial seed records to ensure the tables are ready with example data
INSERT INTO `Medicines` (`medName`, `category`, `unitPrice`, `stocks`) VALUES
('Paracetamol 500mg', 'Analgesic', 5.50, 150),
('Amoxicillin 250mg', 'Antibiotic', 12.00, 80),
('Ibuprofen 400mg', 'NSAID', 8.25, 200);

INSERT INTO `Customers` (`fname`, `lname`, `contactNo`, `address`) VALUES
('John', 'Doe', '09123456789', '123 Rizal Street, Manila'),
('Jane', 'Smith', '09876543210', '456 Quezon Avenue, Quezon City');

INSERT INTO `Purchase` (`customerID`, `medID`, `quantity`, `discount`, `totalAmount`, `purchaseDate`) VALUES
(1, 1, 10, 5.00, 50.00, '2026-06-30'),
(2, 2, 5, 0.00, 60.00, '2026-06-30');
