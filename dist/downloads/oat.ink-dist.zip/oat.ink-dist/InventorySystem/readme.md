> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

📂 Project Architecture (Flat Structure)Create a single directory named after your family name (e.g., DelaCruz/) inside your XAMPP htdocs folder. Place all files flat in this directory:DelaCruz/
├── styles.css        ← Pure local layout, typography, and utility rules
├── db.php            ← Procedural MySQLi connection establishment
├── index.php         ← Module 1 & 2: Products & Dashboard Core (Strict Menu Hub)
├── suppliers.php     ← Module 2: Complete Supplier Profile Management Hub
├── inventory.php     ← Module 3: Inventory Transactions Tracking & Processing
└── reports.php       ← Module 4: Live Inventory Multi-Aggregate Analysis View
🗄️ Backend Setup (inventory_db.sql)Import this file into your local phpMyAdmin. It constructs the required structure and auto-hooks relation points:SQLCREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

CREATE TABLE IF NOT EXISTS suppliers (
    supplierID INT AUTO_INCREMENT PRIMARY KEY,
    supplierName VARCHAR(255) NOT NULL,
    supplierAddress TEXT NOT NULL,
    supplierContact VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    productID INT AUTO_INCREMENT PRIMARY KEY,
    productName VARCHAR(255) NOT NULL,
    productCategory VARCHAR(100) NOT NULL,
    unitPrice DECIMAL(10,2) NOT NULL,
    supplierID INT,
    FOREIGN KEY (supplierID) REFERENCES suppliers(supplierID) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS inventory (
    inventoryID INT AUTO_INCREMENT PRIMARY KEY,
    productID INT,
    stockIn INT NOT NULL,
    stockDate DATE NOT NULL,
    totalAmount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (productID) REFERENCES products(productID) ON DELETE CASCADE
);
🎨 Local Style System (styles.css)Save this code to control system presentation completely offline without rendering external network delays:CSS* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}
body {
    font-family: Arial, Helvetica, sans-serif;
    background-color: #f4f6f9;
    color: #333333;
    padding-top: 70px;
}
.navbar {
    background-color: #ffffff;
    border-bottom: 1px solid #ddd;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 30px;
    z-index: 1000;
}
.navbar-brand {
    font-size: 20px;
    font-weight: bold;
    color: #007bff;
    text-decoration: none;
}
.navbar-nav {
    display: flex;
    gap: 15px;
}
.nav-link {
    text-decoration: none;
    color: #555555;
    padding: 8px 12px;
    border-radius: 4px;
    font-size: 14px;
}
.nav-link:hover {
    background-color: #f1f1f1;
}
.nav-link.active {
    background-color: #007bff;
    color: #ffffff;
}
.page-container {
    max-width: 1100px;
    margin: 20px auto;
    padding: 0 20px;
}
.page-title {
    font-size: 28px;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333333;
}
.card {
    background-color: #ffffff;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 30px;
    margin-bottom: 25px;
}
.form-group {
    margin-bottom: 15px;
}
.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    font-size: 14px;
}
.form-control {
    width: 100%;
    padding: 8px 12px;
    font-size: 14px;
    border: 1px solid #ddd;
    border-radius: 4px;
}
.form-control:focus {
    border-color: #007bff;
    outline: none;
}
.form-inline {
    display: flex;
    gap: 15px;
    align-items: flex-end;
}
.btn {
    padding: 8px 16px;
    font-size: 14px;
    border-radius: 4px;
    cursor: pointer;
    border: 1px solid transparent;
    text-decoration: none;
    display: inline-block;
}
.btn-primary {
    background-color: #007bff;
    color: #ffffff;
}
.btn-secondary {
    background-color: #ffffff;
    border-color: #ddd;
    color: #333333;
}
.table-container {
    background-color: #ffffff;
    border: 1px solid #ddd;
    border-radius: 4px;
    overflow-x: auto;
    margin-top: 15px;
}
table {
    width: 100%;
    border-collapse: collapse;
    text-align: left;
    font-size: 14px;
}
th {
    background-color: #f1f1f1;
    color: #333333;
    padding: 12px;
    font-weight: bold;
    border-bottom: 1px solid #ddd;
}
td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
    color: #555555;
}
tr:hover {
    background-color: #f9f9f9;
}
.action-buttons {
    display: flex;
    gap: 5px;
}
.btn-action {
    padding: 4px 8px;
    font-size: 12px;
    border-radius: 4px;
    text-decoration: none;
    color: #333333;
}
.btn-edit {
    background-color: #ffc107;
}
.btn-delete {
    background-color: #dc3545;
    color: #ffffff;
}
.alert {
    padding: 12px;
    border-radius: 4px;
    margin-bottom: 20px;
    font-size: 14px;
}
.alert-success {
    background-color: #d4edda;
    color: #28a745;
    border: 1px solid #c3e6cb;
}
.alert-warning {
    background-color: #f8d7da;
    color: #dc3545;
    border: 1px solid #f5c6cb;
}
.summary-box {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
}
.summary-card {
    flex: 1;
    background: #ffffff;
    border: 1px solid #ddd;
    padding: 15px;
    border-radius: 4px;
    text-align: center;
}
.summary-card h3 {
    font-size: 24px;
    color: #007bff;
}
.summary-card p {
    font-size: 12px;
    color: #777;
    text-transform: uppercase;
}
🔌 Database Core (db.php)PHP<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "inventory_db";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Database Connection Failure: " . mysqli_connect_error());
}
?>
📦 Products Engine (index.php)PHP<?php
include('db.php');

$alert = "";
$edit_mode = false;
$edit_id = "";
$pName = ""; $pCat = ""; $pPrice = ""; $pSup = "";

// DELETE ROUTINE
if (isset($_GET['del'])) {
    $del_id = intval($_GET['del']);
    $query = "DELETE FROM products WHERE productID = $del_id";
    if (mysqli_query($conn, $query)) {
        $alert = "<div class='alert alert-success'>RECORD SUCCESSFULLY DELETED</div>";
    } else {
        $alert = "<div class='alert alert-warning'>ERROR: CANNOT DELETE PRODUCT (LINKED TO TRANSACTIONS)</div>";
    }
}

// EDIT CHOOSE ROUTINE
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = intval($_GET['edit']);
    $res = mysqli_query($conn, "SELECT * FROM products WHERE productID = $edit_id");
    if ($row = mysqli_fetch_assoc($res)) {
        $pName = $row['productName'];
        $pCat = $row['productCategory'];
        $pPrice = $row['unitPrice'];
        $pSup = $row['supplierID'];
        $alert = "<div class='alert alert-success'>ITEM IS FOUND. READY TO EDIT.</div>";
    }
}

// ADD OR UPDATE POST ROUTINE
if (isset($_POST['save_product'])) {
    $prodName = mysqli_real_escape_string($conn, $_POST['productName']);
    $prodCat  = mysqli_real_escape_string($conn, $_POST['productCategory']);
    $price    = floatval($_POST['unitPrice']);
    $supID    = intval($_POST['supplierID']);
    $id       = $_POST['productID'];

    if (empty($prodName) || empty($prodCat) || $price <= 0 || $supID <= 0) {
        $alert = "<div class='alert alert-warning'>NO RECORD TO ADD. PLEASE FILL OUT ALL VALUABLE FIELDS.</div>";
    } else {
        if (!empty($id)) {
            // Update
            $sql = "UPDATE products SET productName='$prodName', productCategory='$prodCat', unitPrice=$price, supplierID=$supID WHERE productID=$id";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div class='alert alert-success'>RECORD SUCCESSFULLY UPDATED</div>";
            }
        } else {
            // Add
            $sql = "INSERT INTO products (productName, productCategory, unitPrice, supplierID) VALUES ('$prodName', '$prodCat', $price, $supID)";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div class='alert alert-success'>RECORD SUCCESSFULLY SAVED</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory System - Products</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

  <nav class="navbar">
    <a href="index.php" class="navbar-brand">INVENTORY SYSTEM</a>
    <div class="navbar-nav">
      <a href="index.php" class="nav-link active">Products</a>
      <a href="suppliers.php" class="nav-link">Suppliers</a>
      <a href="inventory.php" class="nav-link">Inventory</a>
      <a href="reports.php" class="nav-link">Reports</a>
    </div>
  </nav>

  <div class="page-container">
    <div class="page-title">Products Management UI</div>
    
    <?php echo $alert; ?>

    <div class="card">
        <form method="POST" action="index.php">
            <input type="hidden" name="productID" value="<?php echo $edit_id; ?>">
            <div class="form-group">
                <label>Product Name</label>
                <input type="text" name="productName" class="form-control" value="<?php echo $pName; ?>" required>
            </div>
            <div class="form-group">
                <label>Product Category</label>
                <input type="text" name="productCategory" class="form-control" value="<?php echo $pCat; ?>" required>
            </div>
            <div class="form-group">
                <label>Unit Price</label>
                <input type="number" step="0.01" name="unitPrice" class="form-control" value="<?php echo $pPrice; ?>" required>
            </div>
            <div class="form-group">
                <label>Supplier Assignment</label>
                <select name="supplierID" class="form-control" required>
                    <option value="">-- Choose Supplier --</option>
                    <?php 
                    $sups = mysqli_query($conn, "SELECT * FROM suppliers");
                    while($s = mysqli_fetch_assoc($sups)) {
                        $sel = ($s['supplierID'] == $pSup) ? "selected" : "";
                        echo "<option value='".$s['supplierID']."' $sel>".$s['supplierName']."</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" name="save_product" class="btn btn-primary">
                <?php echo $edit_mode ? "Update Product Record" : "Add Product Record"; ?>
            </button>
            <?php if($edit_mode): ?>
                <a href="index.php" class="btn btn-secondary">Cancel Edit</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="page-title" style="font-size: 20px;">Active Product Records</div>
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Product Name</th>
            <th>Category</th>
            <th>Unit Price</th>
            <th>Supplier</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $res = mysqli_query($conn, "SELECT p.*, s.supplierName FROM products p LEFT JOIN suppliers s ON p.supplierID = s.supplierID");
          if(mysqli_num_rows($res) == 0) {
              echo "<tr><td colspan='6' style='text-align:center;'>No product records mapped yet.</td></tr>";
          }
          while ($row = mysqli_fetch_assoc($res)) {
              echo "<tr>";
              echo "<td>".$row['productID']."</td>";
              echo "<td>".$row['productName']."</td>";
              echo "<td>".$row['productCategory']."</td>";
              echo "<td>$".number_format($row['unitPrice'], 2)."</td>";
              echo "<td>".($row['supplierName'] ?? 'Unassigned')."</td>";
              echo "<td>
                      <div class='action-buttons'>
                        <a href='index.php?edit=".$row['productID']."' class='btn-action btn-edit'>Edit</a>
                        <a href='index.php?del=".$row['productID']."' class='btn-action btn-delete' onclick='return confirm(\"Delete record?\")'>Delete</a>
                      </div>
                    </td>";
              echo "</tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
🏢 Suppliers Engine (suppliers.php)PHP<?php
include('db.php');

$alert = "";
$edit_mode = false;
$edit_id = "";
$sName = ""; $sAddress = ""; $sContact = "";

// DELETE ROUTINE
if (isset($_GET['del'])) {
    $del_id = intval($_GET['del']);
    $query = "DELETE FROM suppliers WHERE supplierID = $del_id";
    if (mysqli_query($conn, $query)) {
        $alert = "<div class='alert alert-success'>RECORD SUCCESSFULLY DELETED</div>";
    } else {
        $alert = "<div class='alert alert-warning'>ERROR: UNABLE TO REMOVE SELECTED SUPPLIER RECORD</div>";
    }
}

// EDIT CHOOSE ROUTINE
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = intval($_GET['edit']);
    $res = mysqli_query($conn, "SELECT * FROM suppliers WHERE supplierID = $edit_id");
    if ($row = mysqli_fetch_assoc($res)) {
        $sName = $row['supplierName'];
        $sAddress = $row['supplierAddress'];
        $sContact = $row['supplierContact'];
        $alert = "<div class='alert alert-success'>ITEM IS FOUND. READY TO EDIT.</div>";
    }
}

// POST INTERACTION ADD OR UPDATE
if (isset($_POST['save_supplier'])) {
    $supName    = mysqli_real_escape_string($conn, $_POST['supplierName']);
    $supAddress = mysqli_real_escape_string($conn, $_POST['supplierAddress']);
    $supContact = mysqli_real_escape_string($conn, $_POST['supplierContact']);
    $id         = $_POST['supplierID'];

    if (empty($supName) || empty($supAddress) || empty($supContact)) {
        $alert = "<div class='alert alert-warning'>FIELDS CANNOT REMAIN EMPTY</div>";
    } else {
        if (!empty($id)) {
            $sql = "UPDATE suppliers SET supplierName='$supName', supplierAddress='$supAddress', supplierContact='$supContact' WHERE supplierID=$id";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div class='alert alert-success'>RECORD SUCCESSFULLY UPDATED</div>";
            }
        } else {
            $sql = "INSERT INTO suppliers (supplierName, supplierAddress, supplierContact) VALUES ('$supName', '$supAddress', '$supContact')";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div class='alert alert-success'>RECORD SUCCESSFULLY SAVED</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory System - Suppliers</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

  <nav class="navbar">
    <a href="index.php" class="navbar-brand">INVENTORY SYSTEM</a>
    <div class="navbar-nav">
      <a href="index.php" class="nav-link">Products</a>
      <a href="suppliers.php" class="nav-link active">Suppliers</a>
      <a href="inventory.php" class="nav-link">Inventory</a>
      <a href="reports.php" class="nav-link">Reports</a>
    </div>
  </nav>

  <div class="page-container">
    <div class="page-title">Suppliers Management UI</div>
    
    <?php echo $alert; ?>

    <div class="card">
        <form method="POST" action="suppliers.php">
            <input type="hidden" name="supplierID" value="<?php echo $edit_id; ?>">
            <div class="form-group">
                <label>Supplier Name</label>
                <input type="text" name="supplierName" class="form-control" value="<?php echo $sName; ?>" required>
            </div>
            <div class="form-group">
                <label>Supplier Address</label>
                <textarea name="supplierAddress" class="form-control" required><?php echo $sAddress; ?></textarea>
            </div>
            <div class="form-group">
                <label>Supplier Contact Number</label>
                <input type="text" name="supplierContact" class="form-control" value="<?php echo $sContact; ?>" required>
            </div>
            <button type="submit" name="save_supplier" class="btn btn-primary">
                <?php echo $edit_mode ? "Update Supplier Record" : "Add Supplier Record"; ?>
            </button>
            <?php if($edit_mode): ?>
                <a href="suppliers.php" class="btn btn-secondary">Cancel Edit</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="page-title" style="font-size: 20px;">Active Supplier Records</div>
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Supplier Name</th>
            <th>Address</th>
            <th>Contact Info</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $res = mysqli_query($conn, "SELECT * FROM suppliers");
          if(mysqli_num_rows($res) == 0) {
              echo "<tr><td colspan='5' style='text-align:center;'>No supplier data recorded.</td></tr>";
          }
          while ($row = mysqli_fetch_assoc($res)) {
              echo "<tr>";
              echo "<td>".$row['supplierID']."</td>";
              echo "<td>".$row['supplierName']."</td>";
              echo "<td>".$row['supplierAddress']."</td>";
              echo "<td>".$row['supplierContact']."</td>";
              echo "<td>
                      <div class='action-buttons'>
                        <a href='suppliers.php?edit=".$row['supplierID']."' class='btn-action btn-edit'>Edit</a>
                        <a href='suppliers.php?del=".$row['supplierID']."' class='btn-action btn-delete' onclick='return confirm(\"Delete row?\")'>Delete</a>
                      </div>
                    </td>";
              echo "</tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
💵 Inventory Stock Transactions (inventory.php)This module processes dynamic additions and handles formula math requirements seamlessly via procedural database transactions:$$\text{totalAmount} = \text{stockIn} \times \text{unitPrice}$$PHP<?php
include('db.php');
$alert = "";

if (isset($_POST['add_stock'])) {
    $prodID   = intval($_POST['productID']);
    $stockIn  = intval($_POST['stockIn']);
    $stockDate = mysqli_real_escape_string($conn, $_POST['stockDate']);

    if ($prodID <= 0 || $stockIn <= 0 || empty($stockDate)) {
        $alert = "<div class='alert alert-warning'>NO RECORD TO ADD. ARRANGE VALUES PROPERLY.</div>";
    } else {
        // Fetch target rate cleanly
        $p_res = mysqli_query($conn, "SELECT unitPrice FROM products WHERE productID = $prodID");
        if ($p_row = mysqli_fetch_assoc($p_res)) {
            $unitPrice = $p_row['unitPrice'];
            // Inline calculation fulfillment
            $totalAmount = $stockIn * $unitPrice;

            $sql = "INSERT INTO inventory (productID, stockIn, stockDate, totalAmount) VALUES ($prodID, $stockIn, '$stockDate', $totalAmount)";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div class='alert alert-success'>RECORD SUCCESSFULLY SAVED (Calculated Amount: $$totalAmount)</div>";
            }
        } else {
            $alert = "<div class='alert alert-warning'>PRODUCT PROFILE REFERENCE INVALID</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory System - Transactions</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

  <nav class="navbar">
    <a href="index.php" class="navbar-brand">INVENTORY SYSTEM</a>
    <div class="navbar-nav">
      <a href="index.php" class="nav-link">Products</a>
      <a href="suppliers.php" class="nav-link">Suppliers</a>
      <a href="inventory.php" class="nav-link active">Inventory</a>
      <a href="reports.php" class="nav-link">Reports</a>
    </div>
  </nav>

  <div class="page-container">
    <div class="page-title">Inventory Transaction Management UI</div>
    
    <?php echo $alert; ?>

    <div class="card">
        <form method="POST" action="inventory.php">
            <div class="form-group">
                <label>Select Product Profile</label>
                <select name="productID" class="form-control" required>
                    <option value="">-- Choose Target Item --</option>
                    <?php 
                    $prods = mysqli_query($conn, "SELECT * FROM products");
                    while($p = mysqli_fetch_assoc($prods)) {
                        echo "<option value='".$p['productID']."'>".$p['productName']." (Rate: $".$p['unitPrice'].")</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Stock Quantity Incoming</label>
                <input type="number" name="stockIn" class="form-control" min="1" required>
            </div>
            <div class="form-group">
                <label>Transaction Timestamp/Date</label>
                <input type="date" name="stockDate" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <button type="submit" name="add_stock" class="btn btn-primary">Process Inventory Addition</button>
        </form>
    </div>

    <div class="page-title" style="font-size: 20px;">Historical Inventory Stock Logs</div>
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>Tx ID</th>
            <th>Product Name</th>
            <th>Units Logged</th>
            <th>Processing Date</th>
            <th>Total Financial Amount</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $res = mysqli_query($conn, "SELECT i.*, p.productName FROM inventory i JOIN products p ON i.productID = p.productID ORDER BY i.inventoryID DESC");
          if(mysqli_num_rows($res) == 0) {
              echo "<tr><td colspan='5' style='text-align:center;'>No transaction entries saved yet.</td></tr>";
          }
          while ($row = mysqli_fetch_assoc($res)) {
              echo "<tr>";
              echo "<td>".$row['inventoryID']."</td>";
              echo "<td>".$row['productName']."</td>";
              echo "<td>".$row['stockIn']."</td>";
              echo "<td>".$row['stockDate']."</td>";
              echo "<td>$".number_format($row['totalAmount'], 2)."</td>";
              echo "</tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
📊 Inventory Monitoring & Live Aggregate Analysis View (reports.php)This module satisfies all requirement weights for aggregate evaluations (COUNT(*), SUM(stockIn), and SUM(totalAmount)) while offering responsive, real-time tracking:PHP<?php
include('db.php');

$category_filter = "";
$where_clause = "";

if (isset($_GET['category']) && !empty($_GET['category'])) {
    $category_filter = mysqli_real_escape_string($conn, $_GET['category']);
    $where_clause = " WHERE p.productCategory = '$category_filter' ";
}

// AGGREGATE EVALUATION MATRIX QUERIES
$count_query = "SELECT COUNT(*) as totalProducts FROM products";
$count_res   = mysqli_query($conn, $count_query);
$count_row   = mysqli_fetch_assoc($count_res);
$totalProductsCount = $count_row['totalProducts'] ?? 0;

$sum_stock_query = "SELECT SUM(i.stockIn) as totalStocks, SUM(i.totalAmount) as grandTotalAmount 
                    FROM inventory i
                    JOIN products p ON i.productID = p.productID
                    $where_clause";
$sum_res = mysqli_query($conn, $sum_stock_query);
$sum_row = mysqli_fetch_assoc($sum_res);

$totalStocksAvailable = $sum_row['totalStocks'] ?? 0;
$grandTotalAmountValue = $sum_row['grandTotalAmount'] ?? 0.00;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory System - Monitoring Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

  <nav class="navbar">
    <a href="index.php" class="navbar-brand">INVENTORY SYSTEM</a>
    <div class="navbar-nav">
      <a href="index.php" class="nav-link">Products</a>
      <a href="suppliers.php" class="nav-link">Suppliers</a>
      <a href="inventory.php" class="nav-link">Inventory</a>
      <a href="reports.php" class="nav-link active">Reports</a>
    </div>
  </nav>

  <div class="page-container">
    <div class="page-title">Inventory Monitoring UI</div>

    <div class="summary-box">
        <div class="summary-card">
            <h3><?php echo $totalProductsCount; ?></h3>
            <p>Total Number of Products (Global)</p>
        </div>
        <div class="summary-card">
            <h3><?php echo $totalStocksAvailable; ?></h3>
            <p>Total Stocks Available (Filtered)</p>
        </div>
        <div class="summary-card">
            <h3>$<?php echo number_format($grandTotalAmountValue, 2); ?></h3>
            <p>Total Inventory Amount (Filtered)</p>
        </div>
    </div>

    <div class="card">
        <form method="GET" action="reports.php" class="form-inline">
            <div class="form-group" style="flex: 1; margin-bottom: 0;">
                <label>Filter View By Product Category</label>
                <select name="category" class="form-control">
                    <option value="">-- View Comprehensive Logs (All Categories) --</option>
                    <?php 
                    $cats = mysqli_query($conn, "SELECT DISTINCT productCategory FROM products");
                    while($c = mysqli_fetch_assoc($cats)) {
                        $sel = ($c['productCategory'] == $category_filter) ? "selected" : "";
                        echo "<option value='".$c['productCategory']."' $sel>".$c['productCategory']."</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Apply View Filter</button>
            <?php if(!empty($category_filter)): ?>
                <a href="reports.php" class="btn btn-secondary">Clear Filter</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Supplier Name</th>
            <th>Stock Quantity</th>
            <th>Unit Price</th>
            <th>Total Amount</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $report_sql = "SELECT p.productName, s.supplierName, i.stockIn, p.unitPrice, i.totalAmount 
                         FROM inventory i
                         JOIN products p ON i.productID = p.productID
                         LEFT JOIN suppliers s ON p.supplierID = s.supplierID
                         $where_clause
                         ORDER BY p.productName ASC";
          
          $report_res = mysqli_query($conn, $report_sql);
          
          if(mysqli_num_rows($report_res) == 0) {
              echo "<tr><td colspan='5' style='text-align:center;'>No database metrics match the current category scope criteria.</td></tr>";
          }
          
          while ($row = mysqli_fetch_assoc($report_res)) {
              echo "<tr>";
              echo "<td>".$row['productName']."</td>";
              echo "<td>".($row['supplierName'] ?? 'N/A')."</td>";
              echo "<td>".$row['stockIn']."</td>";
              echo "<td>$".number_format($row['unitPrice'], 2)."</td>";
              echo "<td>$".number_format($row['totalAmount'], 2)."</td>";
              echo "</tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
🏁 Verification & Testing ChecklistTo secure full points, confirm the following workflow steps sequentially on your XAMPP installation:Step 1: Build the Supplier Base Open suppliers.php and create at least one entry.Step 2: Generate the Catalog Go to index.php (Products Management) and add items. Assign them to your newly created supplier profile.Step 3: Execute Stock Increases Open inventory.php, choose an item, and input a transaction quantity. The application will instantly multiply your entry by the item's stored base price to calculate totalAmount.Step 4: Verify Aggregate Reporting Calculations Open reports.php. Toggle your category dropdown menus. Watch your core totals calculate live across your target fields to verify complete compliance with the test framework rules.