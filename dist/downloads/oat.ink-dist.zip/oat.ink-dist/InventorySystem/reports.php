<?php
include('db.php');

$category_filter = "";
$where_clause = "";

if (isset($_GET['category']) && !empty($_GET['category'])) {
    $category_filter = mysqli_real_escape_string($conn, $_GET['category']);
    $where_clause = " WHERE p.productCategory = '$category_filter' ";
}

// AGGREGATE EVALUATION MATRIX QUERIES
$count_query = "SELECT COUNT(*) as totalProducts FROM products";
$count_res   = mysqli_query($conn, $count_query);
$count_row   = mysqli_fetch_assoc($count_res);
$totalProductsCount = $count_row['totalProducts'] ?? 0;

$sum_stock_query = "SELECT SUM(i.stockIn) as totalStocks, SUM(i.totalAmount) as grandTotalAmount 
                    FROM inventory i
                    JOIN products p ON i.productID = p.productID
                    $where_clause";
$sum_res = mysqli_query($conn, $sum_stock_query);
$sum_row = mysqli_fetch_assoc($sum_res);

$totalStocksAvailable = $sum_row['totalStocks'] ?? 0;
$grandTotalAmountValue = $sum_row['grandTotalAmount'] ?? 0.00;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Inventory System - Monitoring Dashboard</title>
    
    </head>
    <body>

        <nav class="app-nav">
            <a href="index.php" class="app-brand">INVENTORY SYSTEM</a>
            <div class="nav-links">
                <a href="index.php" class="nav-link">Products</a>
                <a href="suppliers.php" class="nav-link">Suppliers</a>
                <a href="inventory.php" class="nav-link">Inventory</a>
                <a href="reports.php" class="nav-link active">Reports</a>
            </div>
        </nav>

        <div class="page-container">
            <div class="page-title">Inventory Report</div>

            <div class="stats-grid">
                <div class="summary-card">
                    <h3><?php echo $totalProductsCount; ?></h3>
                    <p>Total Products</p>
                </div>
                <div class="summary-card">
                    <h3><?php echo $totalStocksAvailable; ?></h3>
                    <p>Available Stock</p>
                </div>
                <div class="summary-card">
                    <h3>$<?php echo number_format($grandTotalAmountValue, 2); ?></h3>
                    <p>Inventory Amount</p>
                </div>
            </div>

            <div class="card">
                <form method="GET" action="reports.php" class="form-inline filter-form">
                    <div class="form-group" style="flex: 1; margin-bottom: 0;">
                        <label>Filter View By Product Category</label>
                        <select name="category">
                            <option value="">-- View Comprehensive Logs (All Categories) --</option>
                    <?php 
                    $cats = mysqli_query($conn, "SELECT DISTINCT productCategory FROM products");
                    while($c = mysqli_fetch_assoc($cats)) {
                        $sel = ($c['productCategory'] == $category_filter) ? "selected" : "";
                        echo "<option value='".$c['productCategory']."' $sel>".$c['productCategory']."</option>";
                    }
                    ?>
                        </select>
                    </div>
                    <button type="submit" class="button">Apply View Filter</button>
            <?php if(!empty($category_filter)): ?>
                    <a href="reports.php" class="button outline">Clear Filter</a>
            <?php endif; ?>
                </form>
            </div>

            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Supplier Name</th>
                            <th>Stock Quantity</th>
                            <th>Unit Price</th>
                            <th>Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>
          <?php
          $report_sql = "SELECT p.productName, s.supplierName, i.stockIn, p.unitPrice, i.totalAmount 
                         FROM inventory i
                         JOIN products p ON i.productID = p.productID
                         LEFT JOIN suppliers s ON p.supplierID = s.supplierID
                         $where_clause
                         ORDER BY p.productName ASC";
          
          $report_res = mysqli_query($conn, $report_sql);
          
          if(mysqli_num_rows($report_res) == 0) {
              echo "<tr><td colspan='5' style='text-align:center;'>No records found for this category.</td></tr>";
          }
          
          while ($row = mysqli_fetch_assoc($report_res)) {
              echo "<tr>";
              echo "<td>".$row['productName']."</td>";
              echo "<td>".($row['supplierName'] ?? 'N/A')."</td>";
              echo "<td>".$row['stockIn']."</td>";
              echo "<td>$".number_format($row['unitPrice'], 2)."</td>";
              echo "<td>$".number_format($row['totalAmount'], 2)."</td>";
              echo "</tr>";
          }
          ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
