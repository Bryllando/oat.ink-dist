<?php
include('db.php');

$alert = "";
$edit_mode = false;
$edit_id = "";
$sName = ""; $sAddress = ""; $sContact = "";

// DELETE ROUTINE
if (isset($_GET['del'])) {
    $del_id = intval($_GET['del']);
    $query = "DELETE FROM suppliers WHERE supplierID = $del_id";
    if (mysqli_query($conn, $query)) {
        $alert = "<div role='alert' class='notice notice-success'>RECORD SUCCESSFULLY DELETED</div>";
    } else {
        $alert = "<div role='alert' class='notice notice-warning'>ERROR: UNABLE TO REMOVE SELECTED SUPPLIER RECORD</div>";
    }
}

// EDIT CHOOSE ROUTINE
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = intval($_GET['edit']);
    $res = mysqli_query($conn, "SELECT * FROM suppliers WHERE supplierID = $edit_id");
    if ($row = mysqli_fetch_assoc($res)) {
        $sName = $row['supplierName'];
        $sAddress = $row['supplierAddress'];
        $sContact = $row['supplierContact'];
        $alert = "<div role='alert' class='notice notice-success'>ITEM IS FOUND. READY TO EDIT.</div>";
    }
}

// POST INTERACTION ADD OR UPDATE
if (isset($_POST['save_supplier'])) {
    $supName    = mysqli_real_escape_string($conn, $_POST['supplierName']);
    $supAddress = mysqli_real_escape_string($conn, $_POST['supplierAddress']);
    $supContact = mysqli_real_escape_string($conn, $_POST['supplierContact']);
    $id         = $_POST['supplierID'];

    if (empty($supName) || empty($supAddress) || empty($supContact)) {
        $alert = "<div role='alert' class='notice notice-warning'>FIELDS CANNOT REMAIN EMPTY</div>";
    } else {
        if (!empty($id)) {
            $sql = "UPDATE suppliers SET supplierName='$supName', supplierAddress='$supAddress', supplierContact='$supContact' WHERE supplierID=$id";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div role='alert' class='notice notice-success'>RECORD SUCCESSFULLY UPDATED</div>";
            }
        } else {
            $sql = "INSERT INTO suppliers (supplierName, supplierAddress, supplierContact) VALUES ('$supName', '$supAddress', '$supContact')";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div role='alert' class='notice notice-success'>RECORD SUCCESSFULLY SAVED</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Inventory System - Suppliers</title>
    
    </head>
    <body>

        <nav class="app-nav">
            <a href="index.php" class="app-brand">INVENTORY SYSTEM</a>
            <div class="nav-links">
                <a href="index.php" class="nav-link">Products</a>
                <a href="suppliers.php" class="nav-link active">Suppliers</a>
                <a href="inventory.php" class="nav-link">Inventory</a>
                <a href="reports.php" class="nav-link">Reports</a>
            </div>
        </nav>

        <div class="page-container">
            <div class="page-title">Suppliers</div>
    
    <?php echo $alert; ?>

            <div class="card">
                <form method="POST" action="suppliers.php" class="entry-form">
                    <input type="hidden" name="supplierID" value="<?php echo $edit_id; ?>">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-supplierName">Supplier Name</label>
                            <input type="text" name="supplierName" value="<?php echo $sName; ?>" required id="input-supplierName">
                        </div>
                        <div class="form-group">
                            <label for="input-supplierAddress">Supplier Address</label>
                            <textarea name="supplierAddress" required id="input-supplierAddress"><?php echo $sAddress; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="input-supplierContact">Supplier Contact Number</label>
                            <input type="text" name="supplierContact" value="<?php echo $sContact; ?>" required id="input-supplierContact">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="save_supplier" class="button">
                <?php echo $edit_mode ? "Update Supplier Record" : "Add Supplier Record"; ?>
                        </button>
            <?php if($edit_mode): ?>
                        <a href="suppliers.php" class="button outline">Cancel Edit</a>
            <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="page-title" style="font-size: 20px;">Supplier Records</div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Supplier Name</th>
                            <th>Address</th>
                            <th>Contact Info</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
          <?php
          $res = mysqli_query($conn, "SELECT * FROM suppliers");
          if(mysqli_num_rows($res) == 0) {
              echo "<tr><td colspan='5' style='text-align:center;'>No supplier data recorded.</td></tr>";
          }
          while ($row = mysqli_fetch_assoc($res)) {
              echo "<tr>";
              echo "<td>".$row['supplierID']."</td>";
              echo "<td>".$row['supplierName']."</td>";
              echo "<td>".$row['supplierAddress']."</td>";
              echo "<td>".$row['supplierContact']."</td>";
              echo "<td>
                      <div class='action-buttons'>
                        <a href='suppliers.php?edit=".$row['supplierID']."' class='button small outline'>Edit</a>
                        <a href='suppliers.php?del=".$row['supplierID']."' class='button small danger-action' onclick='return confirm(\"Delete row?\")'>Delete</a>
                      </div>
                    </td>";
              echo "</tr>";
          }
          ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
