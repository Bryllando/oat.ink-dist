<?php
include('db.php');
$alert = "";

if (isset($_POST['add_stock'])) {
    $prodID   = intval($_POST['productID']);
    $stockIn  = intval($_POST['stockIn']);
    $stockDate = mysqli_real_escape_string($conn, $_POST['stockDate']);

    if ($prodID <= 0 || $stockIn <= 0 || empty($stockDate)) {
        $alert = "<div role='alert' class='notice notice-warning'>NO RECORD TO ADD. ARRANGE VALUES PROPERLY.</div>";
    } else {
        // Fetch target rate cleanly
        $p_res = mysqli_query($conn, "SELECT unitPrice FROM products WHERE productID = $prodID");
        if ($p_row = mysqli_fetch_assoc($p_res)) {
            $unitPrice = $p_row['unitPrice'];
            // Inline calculation fulfillment
            $totalAmount = $stockIn * $unitPrice;

            $sql = "INSERT INTO inventory (productID, stockIn, stockDate, totalAmount) VALUES ($prodID, $stockIn, '$stockDate', $totalAmount)";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div role='alert' class='notice notice-success'>RECORD SUCCESSFULLY SAVED (Calculated Amount: $$totalAmount)</div>";
            }
        } else {
            $alert = "<div role='alert' class='notice notice-warning'>PRODUCT PROFILE REFERENCE INVALID</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Inventory System - Transactions</title>
    
    </head>
    <body>

        <nav class="app-nav">
            <a href="index.php" class="app-brand">INVENTORY SYSTEM</a>
            <div class="nav-links">
                <a href="index.php" class="nav-link">Products</a>
                <a href="suppliers.php" class="nav-link">Suppliers</a>
                <a href="inventory.php" class="nav-link active">Inventory</a>
                <a href="reports.php" class="nav-link">Reports</a>
            </div>
        </nav>

        <div class="page-container">
            <div class="page-title">Stock Transactions</div>
    
    <?php echo $alert; ?>

            <div class="card">
                <form method="POST" action="inventory.php" class="entry-form">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-productID">Select Product Profile</label>
                            <select name="productID" required id="input-productID">
                                <option value="">-- Choose Target Item --</option>
                    <?php 
                    $prods = mysqli_query($conn, "SELECT * FROM products");
                    while($p = mysqli_fetch_assoc($prods)) {
                        echo "<option value='".$p['productID']."'>".$p['productName']." (Rate: $".$p['unitPrice'].")</option>";
                    }
                    ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="input-stockIn">Stock Quantity Incoming</label>
                            <input type="number" name="stockIn" min="1" required id="input-stockIn">
                        </div>
                        <div class="form-group">
                            <label for="input-stockDate">Transaction Timestamp/Date</label>
                            <input type="date" name="stockDate" value="<?php echo date('Y-m-d'); ?>" required id="input-stockDate">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="add_stock" class="button">Process Inventory Addition</button>
                    </div>
                </form>
            </div>

            <div class="page-title" style="font-size: 20px;">Stock History</div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Tx ID</th>
                            <th>Product Name</th>
                            <th>Units Logged</th>
                            <th>Processing Date</th>
                            <th>Total Financial Amount</th>
                        </tr>
                    </thead>
                    <tbody>
          <?php
          $res = mysqli_query($conn, "SELECT i.*, p.productName FROM inventory i JOIN products p ON i.productID = p.productID ORDER BY i.inventoryID DESC");
          if(mysqli_num_rows($res) == 0) {
              echo "<tr><td colspan='5' style='text-align:center;'>No transaction entries saved yet.</td></tr>";
          }
          while ($row = mysqli_fetch_assoc($res)) {
              echo "<tr>";
              echo "<td>".$row['inventoryID']."</td>";
              echo "<td>".$row['productName']."</td>";
              echo "<td>".$row['stockIn']."</td>";
              echo "<td>".$row['stockDate']."</td>";
              echo "<td>$".number_format($row['totalAmount'], 2)."</td>";
              echo "</tr>";
          }
          ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
