<?php
include('db.php');

$alert = "";
$edit_mode = false;
$edit_id = "";
$pName = ""; $pCat = ""; $pPrice = ""; $pSup = "";

// DELETE ROUTINE
if (isset($_GET['del'])) {
    $del_id = intval($_GET['del']);
    $query = "DELETE FROM products WHERE productID = $del_id";
    if (mysqli_query($conn, $query)) {
        $alert = "<div role='alert' class='notice notice-success'>RECORD SUCCESSFULLY DELETED</div>";
    } else {
        $alert = "<div role='alert' class='notice notice-warning'>ERROR: CANNOT DELETE PRODUCT (LINKED TO TRANSACTIONS)</div>";
    }
}

// EDIT CHOOSE ROUTINE
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = intval($_GET['edit']);
    $res = mysqli_query($conn, "SELECT * FROM products WHERE productID = $edit_id");
    if ($row = mysqli_fetch_assoc($res)) {
        $pName = $row['productName'];
        $pCat = $row['productCategory'];
        $pPrice = $row['unitPrice'];
        $pSup = $row['supplierID'];
        $alert = "<div role='alert' class='notice notice-success'>ITEM IS FOUND. READY TO EDIT.</div>";
    }
}

// ADD OR UPDATE POST ROUTINE
if (isset($_POST['save_product'])) {
    $prodName = mysqli_real_escape_string($conn, $_POST['productName']);
    $prodCat  = mysqli_real_escape_string($conn, $_POST['productCategory']);
    $price    = floatval($_POST['unitPrice']);
    $supID    = intval($_POST['supplierID']);
    $id       = $_POST['productID'];

    if (empty($prodName) || empty($prodCat) || $price <= 0 || $supID <= 0) {
        $alert = "<div role='alert' class='notice notice-warning'>NO RECORD TO ADD. PLEASE FILL OUT ALL VALUABLE FIELDS.</div>";
    } else {
        if (!empty($id)) {
            // Update
            $sql = "UPDATE products SET productName='$prodName', productCategory='$prodCat', unitPrice=$price, supplierID=$supID WHERE productID=$id";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div role='alert' class='notice notice-success'>RECORD SUCCESSFULLY UPDATED</div>";
            }
        } else {
            // Add
            $sql = "INSERT INTO products (productName, productCategory, unitPrice, supplierID) VALUES ('$prodName', '$prodCat', $price, $supID)";
            if (mysqli_query($conn, $sql)) {
                $alert = "<div role='alert' class='notice notice-success'>RECORD SUCCESSFULLY SAVED</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Inventory System - Products</title>
    
    </head>
    <body>

        <nav class="app-nav">
            <a href="index.php" class="app-brand">INVENTORY SYSTEM</a>
            <div class="nav-links">
                <a href="index.php" class="nav-link active">Products</a>
                <a href="suppliers.php" class="nav-link">Suppliers</a>
                <a href="inventory.php" class="nav-link">Inventory</a>
                <a href="reports.php" class="nav-link">Reports</a>
            </div>
        </nav>

        <div class="page-container">
            <div class="page-title">Products</div>
    
    <?php echo $alert; ?>

            <div class="card">
                <form method="POST" action="index.php" class="entry-form">
                    <input type="hidden" name="productID" value="<?php echo $edit_id; ?>">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-productName">Product Name</label>
                            <input type="text" name="productName" value="<?php echo $pName; ?>" required id="input-productName">
                        </div>
                        <div class="form-group">
                            <label for="input-productCategory">Product Category</label>
                            <input type="text" name="productCategory" value="<?php echo $pCat; ?>" required id="input-productCategory">
                        </div>
                        <div class="form-group">
                            <label for="input-unitPrice">Unit Price</label>
                            <input type="number" step="0.01" name="unitPrice" value="<?php echo $pPrice; ?>" required id="input-unitPrice">
                        </div>
                        <div class="form-group">
                            <label for="input-supplierID">Supplier Assignment</label>
                            <select name="supplierID" required id="input-supplierID">
                                <option value="">-- Choose Supplier --</option>
                    <?php 
                    $sups = mysqli_query($conn, "SELECT * FROM suppliers");
                    while($s = mysqli_fetch_assoc($sups)) {
                        $sel = ($s['supplierID'] == $pSup) ? "selected" : "";
                        echo "<option value='".$s['supplierID']."' $sel>".$s['supplierName']."</option>";
                    }
                    ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="save_product" class="button">
                <?php echo $edit_mode ? "Update Product Record" : "Add Product Record"; ?>
                        </button>
            <?php if($edit_mode): ?>
                        <a href="index.php" class="button outline">Cancel Edit</a>
            <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="page-title" style="font-size: 20px;">Product Records</div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Product Name</th>
                            <th>Category</th>
                            <th>Unit Price</th>
                            <th>Supplier</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
          <?php
          $res = mysqli_query($conn, "SELECT p.*, s.supplierName FROM products p LEFT JOIN suppliers s ON p.supplierID = s.supplierID");
          if(mysqli_num_rows($res) == 0) {
              echo "<tr><td colspan='6' style='text-align:center;'>No products found.</td></tr>";
          }
          while ($row = mysqli_fetch_assoc($res)) {
              echo "<tr>";
              echo "<td>".$row['productID']."</td>";
              echo "<td>".$row['productName']."</td>";
              echo "<td>".$row['productCategory']."</td>";
              echo "<td>$".number_format($row['unitPrice'], 2)."</td>";
              echo "<td>".($row['supplierName'] ?? 'Unassigned')."</td>";
              echo "<td>
                      <div class='action-buttons'>
                        <a href='index.php?edit=".$row['productID']."' class='button small outline'>Edit</a>
                        <a href='index.php?del=".$row['productID']."' class='button small danger-action' onclick='return confirm(\"Delete record?\")'>Delete</a>
                      </div>
                    </td>";
              echo "</tr>";
          }
          ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
