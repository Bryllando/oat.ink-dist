CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

CREATE TABLE IF NOT EXISTS suppliers (
    supplierID INT AUTO_INCREMENT PRIMARY KEY,
    supplierName VARCHAR(255) NOT NULL,
    supplierAddress TEXT NOT NULL,
    supplierContact VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    productID INT AUTO_INCREMENT PRIMARY KEY,
    productName VARCHAR(255) NOT NULL,
    productCategory VARCHAR(100) NOT NULL,
    unitPrice DECIMAL(10,2) NOT NULL,
    supplierID INT,
    FOREIGN KEY (supplierID) REFERENCES suppliers(supplierID) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS inventory (
    inventoryID INT AUTO_INCREMENT PRIMARY KEY,
    productID INT,
    stockIn INT NOT NULL,
    stockDate DATE NOT NULL,
    totalAmount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (productID) REFERENCES products(productID) ON DELETE CASCADE
);
