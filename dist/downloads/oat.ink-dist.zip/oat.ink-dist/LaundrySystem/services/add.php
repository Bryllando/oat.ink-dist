<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['serviceName']);
    $type = trim($_POST['serviceType']);
    $price = floatval($_POST['pricePerKilo']);

    if ($name && $price > 0) {
        $stmt = $conn->prepare("INSERT INTO services (serviceName, serviceType, pricePerKilo) VALUES (?, ?, ?)");
        $stmt->bind_param("ssd", $name, $type, $price);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Add Service</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 600px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Add New Laundry Service</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="field-grid">
                        <div class="mb-3">
                            <label for="input-serviceName">Service Name</label>
                            <input type="text" name="serviceName" required placeholder="e.g. Wash, Dry & Fold" id="input-serviceName">
                        </div>
                        <div class="mb-3">
                            <label for="input-serviceType">Service Type / Category</label>
                            <select name="serviceType" required id="input-serviceType">
                                <option value="Regular Wash">Regular Wash</option>
                                <option value="Heavy Wash">Heavy Wash (Comforters/Blankets)</option>
                                <option value="Dry-Cleaning">Dry-Cleaning</option>
                                <option value="Pressing">Pressing & Ironing</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="input-pricePerKilo">Price per Kilogram (₱)</label>
                            <input type="number" step="0.01" name="pricePerKilo" required placeholder="35.00" id="input-pricePerKilo">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button w-100">Save Service</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to List</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>