<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM services WHERE serviceID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$s = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['serviceName']);
    $type = trim($_POST['serviceType']);
    $price = floatval($_POST['pricePerKilo']);

    $stmt = $conn->prepare("UPDATE services SET serviceName=?, serviceType=?, pricePerKilo=? WHERE serviceID=?");
    $stmt->bind_param("ssdi", $name, $type, $price, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Edit Service</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 600px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Edit Laundry Service</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="field-grid">
                        <div class="mb-3">
                            <label for="input-serviceName">Service Name</label>
                            <input type="text" name="serviceName" required value="<?php echo htmlspecialchars($s['serviceName']); ?>" id="input-serviceName">
                        </div>
                        <div class="mb-3">
                            <label for="input-serviceType">Service Type / Category</label>
                            <select name="serviceType" required id="input-serviceType">
                        <?php foreach(['Regular Wash', 'Heavy Wash', 'Dry-Cleaning', 'Pressing'] as $t): ?>
                                <option value="<?php echo $t; ?>" <?php echo $s['serviceType'] === $t ? 'selected' : ''; ?>><?php echo $t; ?></option>
                        <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="input-pricePerKilo">Price per Kilogram (₱)</label>
                            <input type="number" step="0.01" name="pricePerKilo" required value="<?php echo $s['pricePerKilo']; ?>" id="input-pricePerKilo">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button outline w-100">Update Service</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to List</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>