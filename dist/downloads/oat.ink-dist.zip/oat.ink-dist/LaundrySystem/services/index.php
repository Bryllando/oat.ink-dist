<?php
require_once '../database.php';
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $stmt = $conn->prepare("SELECT * FROM services WHERE serviceName LIKE ? OR serviceType LIKE ? ORDER BY serviceID DESC");
    $param = "%$search%";
    $stmt->bind_param("ss", $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM services ORDER BY serviceID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Services Management</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Laundry Services Management</h1>
                <a href="add.php" class="button">Add New Service</a>
            </div>
            <div class="card p-3 card-surface mb-3">
                <form method="GET" class="row g-2 filter-form">
                    <div class="col-10">
                        <input type="text" name="search" placeholder="Search by service name or type..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-2 filter-actions">
                        <button type="submit" class="button outline ">Search</button>
                        <a class="button outline" href="index.php">Clear</a></div>
            
                </form>
            </div>
            <div class="card card-surface p-0">
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Service Name</th>
                            <th>Category / Type</th>
                            <th>Price per Kilo</th>
                            <th class="align-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['serviceID']; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['serviceName']); ?></strong></td>
                            <td><span class="badge surface-muted"><?php echo htmlspecialchars($row['serviceType']); ?></span></td>
                            <td>₱<?php echo number_format($row['pricePerKilo'], 2); ?> / kg</td>
                            <td class="align-right">
                                <a href="edit.php?id=<?php echo $row['serviceID']; ?>" class="button small outline">Edit</a>
                                <a href="delete.php?id=<?php echo $row['serviceID']; ?>" class="button small danger-action" onclick="return confirm('Delete service?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="align-center py-4 text-light">No services found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>