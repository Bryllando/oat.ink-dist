<?php
require_once 'database.php';

$totalServices = $conn->query("SELECT COUNT(*) FROM services")->fetch_row()[0];
$totalCustomers = $conn->query("SELECT COUNT(*) FROM customers")->fetch_row()[0];
$totalOrders = $conn->query("SELECT COUNT(*) FROM laundry_orders")->fetch_row()[0];
$totalRevenue = $conn->query("SELECT IFNULL(SUM(totalAmount), 0) FROM laundry_orders")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Laundry System - Dashboard</title>
    
    
    </head>
    <body>
    <?php include 'navbar.php'; ?>
        <main class="container">
            <h1 class="page-title">Laundry System</h1>
            <h2>Summary</h2>
            <div class="stats-grid">
                <div class="stat-card"><span class="stat-label">Services</span><strong class="stat-value"><?= $totalServices ?></strong></div>
                <div class="stat-card"><span class="stat-label">Customers</span><strong class="stat-value"><?= $totalCustomers ?></strong></div>
                <div class="stat-card"><span class="stat-label">Orders</span><strong class="stat-value"><?= $totalOrders ?></strong></div>
                <div class="stat-card"><span class="stat-label">Revenue</span><strong class="stat-value"><?= 'PHP ' . number_format($totalRevenue, 2) ?></strong></div>
            </div>
            <h2 class="mt-3">Menu</h2>
            <ul class="simple-menu">
                <li><a href="services/index.php">Services</a></li>
                <li><a href="customers/index.php">Customers</a></li>
                <li><a href="orders/index.php">Orders</a></li>
                <li><a href="monitoring/index.php">Reports</a></li>
            </ul>
        </main>
    </body>
</html>
