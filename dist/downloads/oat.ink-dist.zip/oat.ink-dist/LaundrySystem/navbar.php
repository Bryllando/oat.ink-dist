<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Laundry Service System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'services') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>services/index.php">Services</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'customers') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>customers/index.php">Customers</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'orders') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>orders/index.php">Laundry Orders</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>