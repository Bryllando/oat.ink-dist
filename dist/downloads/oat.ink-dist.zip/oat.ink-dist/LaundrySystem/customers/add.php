<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = trim($_POST['custFName']);
    $lname = trim($_POST['custLName']);
    $contact = trim($_POST['contactNumber']);
    $addr = trim($_POST['address']);

    if ($fname && $lname) {
        $stmt = $conn->prepare("INSERT INTO customers (custFName, custLName, contactNumber, address) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $fname, $lname, $contact, $addr);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Add Customer</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 600px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Add New Customer</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="input-custFName">First Name</label>
                            <input type="text" name="custFName" required id="input-custFName">
                        </div>
                        <div class="col-6">
                            <label for="input-custLName">Last Name</label>
                            <input type="text" name="custLName" required id="input-custLName">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="input-contactNumber">Contact Number</label>
                        <input type="text" name="contactNumber" required placeholder="0917-000-0000" id="input-contactNumber">
                    </div>
                    <div class="mb-3">
                        <label for="input-address">Address</label>
                        <input type="text" name="address" required placeholder="Barangay, City" id="input-address">
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button w-100">Save Customer</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to List</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>