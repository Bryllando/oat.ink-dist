<?php
require_once '../database.php';

$query = "SELECT o.*, s.serviceName, s.serviceType, s.pricePerKilo, c.custFName, c.custLName, c.contactNumber 
          FROM laundry_orders o
          JOIN services s ON o.serviceID = s.serviceID
          JOIN customers c ON o.customerID = c.customerID
          ORDER BY o.orderID DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Laundry Orders</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Laundry Orders & Processing</h1>
                <a href="add.php" class="button">New Laundry Order</a>
            </div>
            <div class="card card-surface p-0">
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Service</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Weight</th>
                            <th>Total Fee</th>
                            <th>Status</th>
                            <th class="align-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $row['orderID']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['serviceName']); ?></strong>
                                <small class="text-light block"><?php echo htmlspecialchars($row['serviceType']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><?php echo $row['orderDate']; ?></td>
                            <td><?php echo number_format($row['weightKilos'], 2); ?> kg</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalAmount'], 2); ?></strong></td>
                            <td>
                                <span class="badge <?php 
 if ($row['orderStatus'] === 'Claimed') echo 'status-success';
 elseif ($row['orderStatus'] === 'Ready') echo 'surface-muted text-dark';
 elseif ($row['orderStatus'] === 'Processing') echo 'status-warning text-dark';
 else echo 'surface-muted';
 ?>">
                                    <?php echo htmlspecialchars($row['orderStatus']); ?>
                                </span>
                            </td>
                            <td class="align-right">
                                <a href="delete.php?id=<?php echo $row['orderID']; ?>" class="button small danger-action" onclick="return confirm('Delete this order?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="align-center py-4 text-light">No laundry orders recorded yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>