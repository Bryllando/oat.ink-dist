<?php
require_once '../database.php';
$msg = '';

$services = $conn->query("SELECT * FROM services ORDER BY serviceName ASC");
$customers = $conn->query("SELECT * FROM customers ORDER BY custLName ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $servID = intval($_POST['serviceID']);
    $custID = intval($_POST['customerID']);
    $oDate = trim($_POST['orderDate']);
    $weight = floatval($_POST['weightKilos']);
    $status = trim($_POST['orderStatus']);

    // Fetch price per kilo
    $sRow = $conn->query("SELECT pricePerKilo FROM services WHERE serviceID = $servID")->fetch_assoc();
    $rate = $sRow ? floatval($sRow['pricePerKilo']) : 0;
    $totalAmount = $weight * $rate;

    if ($servID && $custID && $weight > 0) {
        $stmt = $conn->prepare("INSERT INTO laundry_orders (serviceID, customerID, orderDate, weightKilos, totalAmount, orderStatus) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisdds", $servID, $custID, $oDate, $weight, $totalAmount, $status);
        if ($stmt->execute()) {
            header("Location: index.php?msg=saved");
            exit;
        } else {
            $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>New Laundry Order</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 650px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Accept Laundry Order</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="mb-3">
                        <label for="input-serviceID">Select Service</label>
                        <select name="serviceID" required id="input-serviceID">
                            <option value="">-- Choose Service --</option>
                        <?php while($s = $services->fetch_assoc()): ?>
                            <option value="<?php echo $s['serviceID']; ?>">
                            <?php echo htmlspecialchars($s['serviceName'] . ' (' . $s['serviceType'] . ') - ₱' . number_format($s['pricePerKilo'], 2) . '/kg'); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="input-customerID">Select Customer</label>
                        <select name="customerID" required id="input-customerID">
                            <option value="">-- Choose Customer --</option>
                        <?php while($c = $customers->fetch_assoc()): ?>
                            <option value="<?php echo $c['customerID']; ?>">
                            <?php echo htmlspecialchars($c['custLName'] . ', ' . $c['custFName'] . ' (' . $c['contactNumber'] . ')'); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="input-orderDate">Order Date</label>
                            <input type="date" name="orderDate" required value="<?php echo date('Y-m-d'); ?>" id="input-orderDate">
                        </div>
                        <div class="col-6">
                            <label for="input-weightKilos">Weight in Kilograms (kg)</label>
                            <input type="number" step="0.01" name="weightKilos" required placeholder="5.5" id="input-weightKilos">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="input-orderStatus">Order Status</label>
                        <select name="orderStatus" id="input-orderStatus">
                            <option value="Pending">Pending</option>
                            <option value="Processing">Processing</option>
                            <option value="Ready">Ready for Pickup</option>
                            <option value="Claimed">Claimed</option>
                        </select>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button w-100">Submit Laundry Order</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to Orders</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>