<?php
require_once '../database.php';

$typeResult = $conn->query("SELECT DISTINCT serviceType FROM services ORDER BY serviceType ASC");
$filterType = trim($_GET['serviceType'] ?? '');

if ($filterType !== '') {
    $stmt = $conn->prepare("SELECT o.*, s.serviceName, s.serviceType, s.pricePerKilo, c.custFName, c.custLName 
                            FROM laundry_orders o
                            JOIN services s ON o.serviceID = s.serviceID
                            JOIN customers c ON o.customerID = c.customerID
                            WHERE s.serviceType = ?
                            ORDER BY o.orderDate DESC");
    $stmt->bind_param("s", $filterType);
    $stmt->execute();
    $records = $stmt->get_result();

    $aggStmt = $conn->prepare("SELECT COUNT(*) AS total_orders, IFNULL(SUM(weightKilos), 0) AS total_weight, IFNULL(SUM(totalAmount), 0) AS total_revenue 
                               FROM laundry_orders o
                               JOIN services s ON o.serviceID = s.serviceID
                               WHERE s.serviceType = ?");
    $aggStmt->bind_param("s", $filterType);
    $aggStmt->execute();
    $agg = $aggStmt->get_result()->fetch_assoc();
    $filterLabel = $filterType;
} else {
    $records = $conn->query("SELECT o.*, s.serviceName, s.serviceType, s.pricePerKilo, c.custFName, c.custLName 
                             FROM laundry_orders o
                             JOIN services s ON o.serviceID = s.serviceID
                             JOIN customers c ON o.customerID = c.customerID
                             ORDER BY o.orderDate DESC");
    $agg = $conn->query("SELECT COUNT(*) AS total_orders, IFNULL(SUM(weightKilos), 0) AS total_weight, IFNULL(SUM(totalAmount), 0) AS total_revenue FROM laundry_orders")->fetch_assoc();
    $filterLabel = "All Services";
}

$countOrders = $agg['total_orders'] ?? 0;
$totalWeight = $agg['total_weight'] ?? 0.0;
$sumRevenue = $agg['total_revenue'] ?? 0.00;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Laundry Monitoring Report</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <div>
                    <h1 class="mb-0 page-title">Laundry Monitoring Report</h1>
                </div>
                <a href="index.php" class="button outline small">Reset Filter</a>
            </div>

        <!-- Filter Card -->
            <div class="card p-3 card-surface mb-4">
                <form method="GET" class="row g-2 items-center filter-form">
                    <div class="auto-col">
                        <label class="mb-0 weight-semibold">Filter by Service Category:</label>
                    </div>
                    <div class="col-5">
                        <select name="serviceType" onchange="this.form.submit()">
                            <option value="">-- All Service Categories --</option>
                        <?php while($t = $typeResult->fetch_assoc()): ?>
                            <option value="<?php echo htmlspecialchars($t['serviceType']); ?>" <?php echo $filterType === $t['serviceType'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($t['serviceType']); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="auto-col filter-actions">
                        <button type="submit" class="button">Filter</button>
                        <a class="button outline" href="index.php">Clear</a></div>
            
                </form>
            </div>

        <!-- 3 Required KPI Cards -->
            <div class="row g-3 mb-4">
                <div class="col-4">
                    <div class="card p-3 card-surface stat-card">
                        <span class="text-light small weight-semibold">a. Total Orders Placed (count)</span>
                        <h2 class="text-primary mb-0"><?php echo $countOrders; ?> <small class="text-light fs-6">Orders</small></h2>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card p-3 card-surface stat-card success">
                        <span class="text-light small weight-semibold">b. Total Laundry Revenue (sum)</span>
                        <h2 class="text-success mb-0">₱<?php echo number_format($sumRevenue, 2); ?></h2>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card p-3 card-surface stat-card warning">
                        <span class="text-light small weight-semibold">c. Total Weight Washed (formula)</span>
                        <h2 class="text-warning mb-0"><?php echo number_format($totalWeight, 2); ?> <small class="text-light fs-6">Kilograms (kg)</small></h2>
                    </div>
                </div>
            </div>

        <!-- Table displaying filtered records -->
            <div class="card card-surface p-0">
                <div class="card-header py-3">
                    <h5 class="mb-0">Orders Filtered by: <span class="badge surface-muted"><?php echo htmlspecialchars($filterLabel); ?></span></h5>
                </div>
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>Service Name</th>
                            <th>Category</th>
                            <th>Customer Full Name</th>
                            <th>Order Date</th>
                            <th>Weight</th>
                            <th>Total Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($records && $records->num_rows > 0): ?>
                        <?php while($row = $records->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($row['serviceName']); ?></strong></td>
                            <td><span class="badge surface-muted"><?php echo htmlspecialchars($row['serviceType']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['custFName'] . ' ' . $row['custLName']); ?></td>
                            <td><?php echo $row['orderDate']; ?></td>
                            <td><?php echo number_format($row['weightKilos'], 2); ?> kg</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalAmount'], 2); ?></strong></td>
                            <td>
                                <span class="badge <?php 
 if ($row['orderStatus'] === 'Claimed') echo 'status-success';
 elseif ($row['orderStatus'] === 'Ready') echo 'surface-muted text-dark';
 elseif ($row['orderStatus'] === 'Processing') echo 'status-warning text-dark';
 else echo 'surface-muted';
 ?>">
                                    <?php echo htmlspecialchars($row['orderStatus']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="align-center py-4 text-light">No laundry orders found for this category.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>