<?php
include 'db.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
if (!in_array($action, ['list', 'create', 'edit'], true)) $action = 'list';
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $petid = intval($_POST['petid']);
        $serviceid = intval($_POST['serviceid']);
        $resdate = $conn->real_escape_string($_POST['reservationdate']);
        $restime = $conn->real_escape_string($_POST['reservationtime']);
        $request = $conn->real_escape_string($_POST['specialrequest']);
        $service_result = $conn->query("SELECT price FROM grooming_services WHERE serviceID=$serviceid");
        $service_row = $service_result->fetch_assoc();
        $total = $service_row['price'];
        $sql = "INSERT INTO reservations (petID, serviceID, reservationDate, reservationTime, specialRequest, totalAmount, status) VALUES ($petid, $serviceid, '$resdate', '$restime', '$request', $total, 'Pending')";
        if ($conn->query($sql)) { $message = 'Reservation created successfully.'; $message_type = 'success'; $action = 'list'; }
        else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'update') {
        $id = intval($_POST['id']);
        $status = $conn->real_escape_string($_POST['status']);
        $request = $conn->real_escape_string($_POST['specialrequest']);
        $sql = "UPDATE reservations SET status='$status', specialRequest='$request' WHERE reservationID=$id";
        if ($conn->query($sql)) { $message = 'Reservation updated successfully.'; $message_type = 'success'; $action = 'list'; }
        else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $sql = "DELETE FROM reservations WHERE reservationID=$id";
    if ($conn->query($sql)) { $message = 'Reservation deleted successfully.'; $message_type = 'success'; }
    else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    $action = 'list';
}

$reservation = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM reservations WHERE reservationID=$id");
    $reservation = $result->fetch_assoc();
    if (!$reservation) { $message = 'Reservation not found.'; $message_type = 'danger'; $action = 'list'; }
}
if ($action === 'edit' && !$reservation) $action = 'list';

$filter_status = isset($_GET['filter_status']) ? $conn->real_escape_string($_GET['filter_status']) : '';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Reservations</title>
    
    </head>
    <body>
        <div class="container">
            <header>
                <h1>Pet Grooming System</h1>
                <nav>
                    <a href="index.php">Dashboard</a>
                    <a href="petowners.php">Pet Owners</a>
                    <a href="pets.php">Pets</a>
                    <a href="services.php">Services</a>
                    <a class="active" href="reservations.php">Reservations</a>
                    <a href="reports.php">Reports</a>
                </nav>
            </header>

    <?php if ($message): ?><div role="alert" class="notice notice-<?php echo $message_type; ?>"><?php echo $message; ?></div><?php endif; ?>

    <?php if ($action === 'list'): ?>
            <div class="box">
                <h1 class="page-title">Reservations</h1>
                <p><a class="button" href="reservations.php?action=create">Create Reservation</a></p>
                <form method="get" style="margin-top:12px;" class="filter-form">
                    <div class="row">
                        <div class="col">
                            <select name="filter_status" onchange="this.form.submit()">
                                <option value="">All Status</option>
                                <option value="Pending" <?php if ($filter_status === 'Pending') echo 'selected'; ?>>Pending</option>
                                <option value="Confirmed" <?php if ($filter_status === 'Confirmed') echo 'selected'; ?>>Confirmed</option>
                                <option value="Completed" <?php if ($filter_status === 'Completed') echo 'selected'; ?>>Completed</option>
                                <option value="Cancelled" <?php if ($filter_status === 'Cancelled') echo 'selected'; ?>>Cancelled</option>
                            </select>
                        </div>
                    </div>
                    <a class="button outline" href="reservations.php">Clear</a>
                </form>
                <table style="margin-top:12px;">
                    <tr><th>ID</th><th>Date</th><th>Time</th><th>Pet</th><th>Owner</th><th>Service</th><th>Amount</th><th>Status</th><th>Action</th></tr>
            <?php
            $where = '';
            if ($filter_status) { $where = " WHERE r.status = '$filter_status'"; }
            $result = $conn->query("SELECT r.*, p.petName, CONCAT(o.ownerFName, ' ', o.ownerLName) as owner, gs.serviceName FROM reservations r JOIN pets p ON r.petID = p.petID JOIN petowners o ON p.ownerID = o.ownerID JOIN grooming_services gs ON r.serviceID = gs.serviceID $where ORDER BY r.reservationDate DESC, r.reservationTime DESC");
            if ($result->num_rows > 0): while ($row = $result->fetch_assoc()):
            ?>
                    <tr>
                        <td><?php echo $row['reservationID']; ?></td>
                        <td><?php echo date('M d, Y', strtotime($row['reservationDate'])); ?></td>
                        <td><?php echo date('h:i A', strtotime($row['reservationTime'])); ?></td>
                        <td><?php echo $row['petName']; ?></td>
                        <td><?php echo $row['owner']; ?></td>
                        <td><?php echo $row['serviceName']; ?></td>
                        <td>$<?php echo number_format($row['totalAmount'], 2); ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td class="actions"><a class="button outline" href="reservations.php?action=edit&id=<?php echo $row['reservationID']; ?>">Edit</a> <a class="button danger-action" href="reservations.php?delete=<?php echo $row['reservationID']; ?>" onclick="return confirm('Delete this reservation?')">Delete</a></td>
                    </tr>
            <?php endwhile; else: ?><tr><td colspan="9">No reservations found.</td></tr><?php endif; ?>
                </table>
            </div>
    <?php else: ?>
            <div class="box">
                <h2><?php echo $action === 'create' ? 'Create Reservation' : 'Edit Reservation'; ?></h2>
                <form method="post" class="entry-form">
                    <input type="hidden" name="action" value="<?php echo $action === 'create' ? 'add' : 'update'; ?>">
            <?php if ($action === 'edit'): ?><input type="hidden" name="id" value="<?php echo $reservation['reservationID']; ?>"><?php endif; ?>
            <?php if ($action === 'create'): ?>
                    <div class="row">
                        <div class="col"><label for="input-petid">Pet</label><select name="petid" required id="input-petid"><option value="">Select pet</option><?php $pets_result = $conn->query("SELECT p.petID, p.petName, CONCAT(o.ownerFName, ' ', o.ownerLName) as owner FROM pets p JOIN petowners o ON p.ownerID = o.ownerID ORDER BY p.petName"); while ($pet = $pets_result->fetch_assoc()): ?><option value="<?php echo $pet['petID']; ?>"><?php echo $pet['petName']; ?> (<?php echo $pet['owner']; ?>)</option><?php endwhile; ?></select></div>
                        <div class="col"><label for="input-serviceid">Service</label><select name="serviceid" required id="input-serviceid"><option value="">Select service</option><?php $services_result = $conn->query("SELECT * FROM grooming_services ORDER BY serviceName"); while ($service = $services_result->fetch_assoc()): ?><option value="<?php echo $service['serviceID']; ?>"><?php echo $service['serviceName']; ?> - $<?php echo number_format($service['price'], 2); ?></option><?php endwhile; ?></select></div>
                    </div>
                    <div class="row">
                        <div class="col"><label for="input-reservationdate">Date</label><input type="date" name="reservationdate" required id="input-reservationdate"></div>
                        <div class="col"><label for="input-reservationtime">Time</label><input type="time" name="reservationtime" required id="input-reservationtime"></div>
                    </div>
                    <div class="row"><div class="col"><label for="input-specialrequest">Special Request</label><textarea name="specialrequest" rows="3" id="input-specialrequest"></textarea></div></div>
            <?php else: ?>
                    <div class="row"><div class="col"><label for="input-status">Status</label><select name="status" required id="input-status"><option value="Pending" <?php if ($reservation['status'] === 'Pending') echo 'selected'; ?>>Pending</option><option value="Confirmed" <?php if ($reservation['status'] === 'Confirmed') echo 'selected'; ?>>Confirmed</option><option value="Completed" <?php if ($reservation['status'] === 'Completed') echo 'selected'; ?>>Completed</option><option value="Cancelled" <?php if ($reservation['status'] === 'Cancelled') echo 'selected'; ?>>Cancelled</option></select></div></div>
                    <div class="row"><div class="col"><label for="input-specialrequest-field">Special Request</label><textarea name="specialrequest" rows="3" id="input-specialrequest-field"><?php echo $reservation['specialRequest']; ?></textarea></div></div>
            <?php endif; ?>
                    <p class="form-actions"><button class="button" type="submit">Save</button> <a class="button outline" href="reservations.php">Cancel</a></p>
                </form>
            </div>
    <?php endif; ?>
        </div>
    </body>
</html>
