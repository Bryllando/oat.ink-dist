<?php
include 'db.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $name = $conn->real_escape_string($_POST['name']);
        $desc = $conn->real_escape_string($_POST['description']);
        $price = floatval($_POST['price']);
        $duration = intval($_POST['duration']);
        $sql = "INSERT INTO grooming_services (serviceName, description, price, duration) VALUES ('$name', '$desc', $price, $duration)";
        if ($conn->query($sql)) { $message = 'Service added successfully.'; $message_type = 'success'; $action = 'list'; }
        else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'update') {
        $id = intval($_POST['id']);
        $name = $conn->real_escape_string($_POST['name']);
        $desc = $conn->real_escape_string($_POST['description']);
        $price = floatval($_POST['price']);
        $duration = intval($_POST['duration']);
        $sql = "UPDATE grooming_services SET serviceName='$name', description='$desc', price=$price, duration=$duration WHERE serviceID=$id";
        if ($conn->query($sql)) { $message = 'Service updated successfully.'; $message_type = 'success'; $action = 'list'; }
        else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $sql = "DELETE FROM grooming_services WHERE serviceID=$id";
    if ($conn->query($sql)) { $message = 'Service deleted successfully.'; $message_type = 'success'; }
    else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    $action = 'list';
}

$service = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM grooming_services WHERE serviceID=$id");
    $service = $result->fetch_assoc();
    if (!$service) { $message = 'Service not found.'; $message_type = 'danger'; $action = 'list'; }
}

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Services</title>
    
    </head>
    <body>
        <div class="container">
            <header>
                <h1>Pet Grooming System</h1>
                <nav>
                    <a href="index.php">Dashboard</a>
                    <a href="petowners.php">Pet Owners</a>
                    <a href="pets.php">Pets</a>
                    <a class="active" href="services.php">Services</a>
                    <a href="reservations.php">Reservations</a>
                    <a href="reports.php">Reports</a>
                </nav>
            </header>

    <?php if ($message): ?><div role="alert" class="notice notice-<?php echo $message_type; ?>"><?php echo $message; ?></div><?php endif; ?>

    <?php if ($action === 'list'): ?>
            <div class="box">
                <h1 class="page-title">Grooming Services</h1>
                <p><a class="button" href="services.php?action=add">Add Service</a></p>
                <form method="get" style="margin-top:12px;" class="filter-form">
                    <div class="row">
                        <div class="col"><input type="text" name="search" value="<?php echo $search; ?>" placeholder="Search by service name"></div>
                        <div class="col filter-actions"><button class="button" type="submit">Search</button><a class="button outline" href="services.php">Clear</a></div>
                    </div>
        
                </form>
                <table style="margin-top:12px;">
                    <tr><th>ID</th><th>Service Name</th><th>Description</th><th>Price</th><th>Duration</th><th>Action</th></tr>
            <?php
            $where = '';
            if ($search) { $where = " WHERE serviceName LIKE '%$search%'"; }
            $result = $conn->query("SELECT * FROM grooming_services $where ORDER BY serviceName");
            if ($result->num_rows > 0): while ($row = $result->fetch_assoc()):
            ?>
                    <tr>
                        <td><?php echo $row['serviceID']; ?></td>
                        <td><?php echo $row['serviceName']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td>$<?php echo number_format($row['price'], 2); ?></td>
                        <td><?php echo $row['duration']; ?> min</td>
                        <td class="actions"><a class="button outline" href="services.php?action=edit&id=<?php echo $row['serviceID']; ?>">Edit</a> <a class="button danger-action" href="services.php?delete=<?php echo $row['serviceID']; ?>" onclick="return confirm('Delete this service?')">Delete</a></td>
                    </tr>
            <?php endwhile; else: ?><tr><td colspan="6">No services found.</td></tr><?php endif; ?>
                </table>
            </div>
    <?php else: ?>
            <div class="box">
                <h2><?php echo $action === 'add' ? 'Add Service' : 'Edit Service'; ?></h2>
                <form method="post" class="entry-form">
                    <input type="hidden" name="action" value="<?php echo $action === 'add' ? 'add' : 'update'; ?>">
            <?php if ($action === 'edit'): ?><input type="hidden" name="id" value="<?php echo $service['serviceID']; ?>"><?php endif; ?>
                    <div class="row"><div class="col"><label for="input-name">Service Name</label><input type="text" name="name" value="<?php echo $service ? $service['serviceName'] : ''; ?>" required id="input-name"></div></div>
                    <div class="row"><div class="col"><label for="input-description">Description</label><textarea name="description" rows="3" id="input-description"><?php echo $service ? $service['description'] : ''; ?></textarea></div></div>
                    <div class="row"><div class="col"><label for="input-price">Price</label><input type="number" step="0.01" name="price" value="<?php echo $service ? $service['price'] : ''; ?>" required id="input-price"></div><div class="col"><label for="input-duration">Duration (minutes)</label><input type="number" name="duration" value="<?php echo $service ? $service['duration'] : ''; ?>" required id="input-duration"></div></div>
                    <p class="form-actions"><button class="button" type="submit">Save</button> <a class="button outline" href="services.php">Cancel</a></p>
                </form>
            </div>
    <?php endif; ?>
        </div>
    </body>
</html>
