<?php
include 'db.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $fname = $conn->real_escape_string($_POST['fname']);
        $lname = $conn->real_escape_string($_POST['lname']);
        $contact = $conn->real_escape_string($_POST['contact']);
        $address = $conn->real_escape_string($_POST['address']);
        $sql = "INSERT INTO petowners (ownerFName, ownerLName, contactNo, address) VALUES ('$fname', '$lname', '$contact', '$address')";
        if ($conn->query($sql)) { $message = 'Pet owner added successfully.'; $message_type = 'success'; $action = 'list'; }
        else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'update') {
        $id = intval($_POST['id']);
        $fname = $conn->real_escape_string($_POST['fname']);
        $lname = $conn->real_escape_string($_POST['lname']);
        $contact = $conn->real_escape_string($_POST['contact']);
        $address = $conn->real_escape_string($_POST['address']);
        $sql = "UPDATE petowners SET ownerFName='$fname', ownerLName='$lname', contactNo='$contact', address='$address' WHERE ownerID=$id";
        if ($conn->query($sql)) { $message = 'Pet owner updated successfully.'; $message_type = 'success'; $action = 'list'; }
        else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $sql = "DELETE FROM petowners WHERE ownerID=$id";
    if ($conn->query($sql)) { $message = 'Pet owner deleted successfully.'; $message_type = 'success'; }
    else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    $action = 'list';
}

$owner = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM petowners WHERE ownerID=$id");
    $owner = $result->fetch_assoc();
    if (!$owner) { $message = 'Owner not found.'; $message_type = 'danger'; $action = 'list'; }
}

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Pet Owners</title>
    
    </head>
    <body>
        <div class="container">
            <header>
                <h1>Pet Grooming System</h1>
                <nav>
                    <a href="index.php">Dashboard</a>
                    <a class="active" href="petowners.php">Pet Owners</a>
                    <a href="pets.php">Pets</a>
                    <a href="services.php">Services</a>
                    <a href="reservations.php">Reservations</a>
                    <a href="reports.php">Reports</a>
                </nav>
            </header>

    <?php if ($message): ?><div role="alert" class="notice notice-<?php echo $message_type; ?>"><?php echo $message; ?></div><?php endif; ?>

    <?php if ($action === 'list'): ?>
            <div class="box">
                <h1 class="page-title">Pet Owners</h1>
                <p><a class="button" href="petowners.php?action=add">Add Pet Owner</a></p>
                <form method="get" style="margin-top:12px;" class="filter-form">
                    <div class="row">
                        <div class="col"><input type="text" name="search" value="<?php echo $search; ?>" placeholder="Search by name"></div>
                        <div class="col filter-actions"><button class="button" type="submit">Search</button><a class="button outline" href="petowners.php">Clear</a></div>
                    </div>
        
                </form>
                <table style="margin-top:12px;">
                    <tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Contact</th><th>Address</th><th>Action</th></tr>
            <?php
            $where = '';
            if ($search) { $where = " WHERE ownerFName LIKE '%$search%' OR ownerLName LIKE '%$search%'"; }
            $result = $conn->query("SELECT * FROM petowners $where ORDER BY ownerLName, ownerFName");
            if ($result->num_rows > 0): while ($row = $result->fetch_assoc()):
            ?>
                    <tr>
                        <td><?php echo $row['ownerID']; ?></td>
                        <td><?php echo $row['ownerFName']; ?></td>
                        <td><?php echo $row['ownerLName']; ?></td>
                        <td><?php echo $row['contactNo']; ?></td>
                        <td><?php echo $row['address']; ?></td>
                        <td class="actions"><a class="button outline" href="petowners.php?action=edit&id=<?php echo $row['ownerID']; ?>">Edit</a> <a class="button danger-action" href="petowners.php?delete=<?php echo $row['ownerID']; ?>" onclick="return confirm('Delete this owner?')">Delete</a></td>
                    </tr>
            <?php endwhile; else: ?><tr><td colspan="6">No pet owners found.</td></tr><?php endif; ?>
                </table>
            </div>
    <?php else: ?>
            <div class="box">
                <h2><?php echo $action === 'add' ? 'Add Pet Owner' : 'Edit Pet Owner'; ?></h2>
                <form method="post" class="entry-form">
                    <input type="hidden" name="action" value="<?php echo $action === 'add' ? 'add' : 'update'; ?>">
            <?php if ($action === 'edit'): ?><input type="hidden" name="id" value="<?php echo $owner['ownerID']; ?>"><?php endif; ?>
                    <div class="row">
                        <div class="col"><label for="input-fname">First Name</label><input type="text" name="fname" value="<?php echo $owner ? $owner['ownerFName'] : ''; ?>" required id="input-fname"></div>
                        <div class="col"><label for="input-lname">Last Name</label><input type="text" name="lname" value="<?php echo $owner ? $owner['ownerLName'] : ''; ?>" required id="input-lname"></div>
                    </div>
                    <div class="row">
                        <div class="col"><label for="input-contact">Contact Number</label><input type="text" name="contact" value="<?php echo $owner ? $owner['contactNo'] : ''; ?>" required id="input-contact"></div>
                    </div>
                    <div class="row"><div class="col"><label for="input-address">Address</label><textarea name="address" rows="3" required id="input-address"><?php echo $owner ? $owner['address'] : ''; ?></textarea></div></div>
                    <p class="form-actions"><button class="button" type="submit">Save</button> <a class="button outline" href="petowners.php">Cancel</a></p>
                </form>
            </div>
    <?php endif; ?>
        </div>
