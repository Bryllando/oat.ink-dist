<?php
include 'db.php';

$stats = [];
$result = $conn->query("SELECT COUNT(*) as count FROM reservations");
$stats['total'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE status='Pending'");
$stats['pending'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE status='Confirmed'");
$stats['confirmed'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE status='Completed'");
$stats['completed'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT SUM(totalAmount) as revenue FROM reservations");
$stats['revenue'] = $result->fetch_assoc()['revenue'] ?? 0;

$result = $conn->query("SELECT COUNT(*) as count FROM petowners");
$stats['owners'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM pets");
$stats['pets'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM grooming_services");
$stats['services'] = $result->fetch_assoc()['count'];

$recent_sql = "SELECT r.reservationID, r.reservationDate, r.reservationTime,
                CONCAT(p.ownerFName, ' ', p.ownerLName) as ownerName,
                pt.petName, gs.serviceName, r.status
                FROM reservations r
                JOIN pets pt ON r.petID = pt.petID
                JOIN petowners p ON pt.ownerID = p.ownerID
                JOIN grooming_services gs ON r.serviceID = gs.serviceID
                ORDER BY r.reservationDate DESC, r.reservationTime DESC
                LIMIT 10";
$recent_result = $conn->query($recent_sql);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Dashboard</title>
    
    </head>
    <body>
        <div class="container">
            <header>
                <h1>Pet Grooming System</h1>
                <p class="small">Simple reservation system for local use</p>
                <nav>
                    <a class="active" href="index.php">Dashboard</a>
                    <a href="petowners.php">Pet Owners</a>
                    <a href="pets.php">Pets</a>
                    <a href="services.php">Services</a>
                    <a href="reservations.php">Reservations</a>
                    <a href="reports.php">Reports</a>
                </nav>
            </header>

            <div class="box">
                <h1 class="page-title">Dashboard</h1>
                <div class="row">
                    <div class="col box"><h3><?php echo $stats['total']; ?></h3><p>Total Reservations</p></div>
                    <div class="col box"><h3><?php echo $stats['pending']; ?></h3><p>Pending</p></div>
                    <div class="col box"><h3><?php echo $stats['confirmed']; ?></h3><p>Confirmed</p></div>
                    <div class="col box"><h3><?php echo $stats['completed']; ?></h3><p>Completed</p></div>
                </div>
                <div class="row">
                    <div class="col box"><h3>$<?php echo number_format($stats['revenue'], 2); ?></h3><p>Total Revenue</p></div>
                    <div class="col box"><h3><?php echo $stats['owners']; ?></h3><p>Pet Owners</p></div>
                    <div class="col box"><h3><?php echo $stats['pets']; ?></h3><p>Pets</p></div>
                    <div class="col box"><h3><?php echo $stats['services']; ?></h3><p>Services</p></div>
                </div>
            </div>

            <div class="box">
                <h2>Recent Reservations</h2>
                <table>
                    <tr><th>Date</th><th>Time</th><th>Owner</th><th>Pet</th><th>Service</th><th>Status</th><th>Action</th></tr>
            <?php if ($recent_result->num_rows > 0): while ($row = $recent_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo date('M d, Y', strtotime($row['reservationDate'])); ?></td>
                        <td><?php echo date('h:i A', strtotime($row['reservationTime'])); ?></td>
                        <td><?php echo $row['ownerName']; ?></td>
                        <td><?php echo $row['petName']; ?></td>
                        <td><?php echo $row['serviceName']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><a class="button outline" href="reservations.php?action=edit&id=<?php echo $row['reservationID']; ?>">Edit</a></td>
                    </tr>
            <?php endwhile; else: ?>
                    <tr><td colspan="7">No reservations found.</td></tr>
            <?php endif; ?>
                </table>
            </div>

            <div class="box">
                <h2>Quick Links</h2>
                <p><a class="button" href="petowners.php">Add Pet Owner</a> <a class="button outline" href="pets.php">Add Pet</a> <a class="button" href="reservations.php?action=create">Create Reservation</a></p>
            </div>
        </div>
    </body>
</html>
