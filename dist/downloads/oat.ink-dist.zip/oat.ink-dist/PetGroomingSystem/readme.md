> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

# Pet Grooming Reservation System

This project is a simple offline Pet Grooming Reservation System built for XAMPP localhost using **minimal, clean code**.

## Features

- PHP procedural mysqli
- MySQL database: `pet_grooming`
- **Minimal custom CSS (no Bootstrap)**
- Offline ready
- No OOP
- No MVC
- No AJAX
- No Composer
- Beginner-friendly CRUD
- Reservation Management
- Reports using COUNT() and SUM()

---

## Setup

1. Project location:

```text
C:\xampp\htdocs\LibradillaPetGrooming
```

2. Start Apache and MySQL in XAMPP.

3. Import the database:

```sql
mysql -u root < "C:\xampp\htdocs\LibradillaPetGrooming\pet_grooming.sql"
```

4. Open:

```text
http://localhost/LibradillaPetGrooming/index.php
```

---

# Database

Database name:

```text
pet_grooming
```

### petowners

- ownerID (PK)
- ownerFName
- ownerLName
- contactNo
- address

### pets

- petID (PK)
- ownerID (FK)
- petName
- petType
- breed
- age

### grooming_services

- serviceID (PK)
- serviceName
- description
- price
- duration

### reservations

- reservationID (PK)
- petID (FK)
- serviceID (FK)
- reservationDate
- reservationTime
- specialRequest
- totalAmount
- status
- dateCreated

---

# Modules

## Dashboard

- index.php

## Pet Owners

- Add
- Search
- Edit
- Delete
- View

## Pets

- Add
- Search
- Edit
- Delete
- View

## Grooming Services

- Add
- Search
- Edit
- Delete
- View

## Reservations

- Create Reservation
- Select Pet
- Select Grooming Service
- Select Reservation Date
- Select Reservation Time
- Input Special Request
- Compute Total Amount
- Save Reservation
- Edit Reservation
- Delete Reservation
- View Reservations

## Reports

Filter by:

- Status
- Grooming Service
- Pet Owner
- Date From – Date To

Display:

- Owner Name
- Pet Name
- Pet Type
- Breed
- Grooming Service
- Reservation Date
- Reservation Time
- Total Amount
- Status

---

# Formula

```text
totalAmount = price
```

> Since one reservation corresponds to one grooming service, the total amount is simply the selected service price.

---

# Project Structure

```text
LibradillaPetGrooming/
├── pet_grooming.sql      (Database schema + sample data)
├── readme.md             (This file)
├── db.php                (Database connection)
├── index.php             (Dashboard - Home page)
├── petowners.php         (Pet owners CRUD)
├── pets.php              (Pets CRUD)
├── services.php          (Grooming services CRUD)
├── reservations.php      (Reservations management)
├── reports.php           (Reports and statistics)
└── styles.css            (Minimal custom CSS)
```

---

# Files Description

| File | Purpose |
|------|---------|
| `pet_grooming.sql` | Database schema, tables, sample data |
| `db.php` | Database connection and mysqli setup |
| `index.php` | Dashboard with statistics |
| `petowners.php` | Add/Edit/Delete/View pet owners |
| `pets.php` | Manage pets for each owner |
| `services.php` | Manage grooming services |
| `reservations.php` | Create and manage reservations |
| `reports.php` | View reports with filters |
| `assets/css/app.css` | Minimal custom CSS styling |

---

# UI Style (Minimal & Clean)

## Colors

| Purpose | Color |
|---------|--------|
| Primary / Blue | `#007bff` |
| Success / Green | `#28a745` |
| Warning / Yellow | `#ffc107` |
| Danger / Red | `#dc3545` |
| Light Gray | `#f1f1f1` |
| White | `#ffffff` |

## Typography

- Font: Arial, Helvetica, sans-serif
- Body Background: `#f4f6f9`
- Cards/Tables: `#ffffff`
- Text: `#333333`
- Muted Text: `#555555`

## Components

- All borders: `1px solid #ddd` with `border-radius: 4px`
- Forms: Clean input fields with focus states
- Buttons: Flat design with hover effects
- Alerts: Color-coded status messages
- Tables: Responsive with hover effects
- Navigation: Simple horizontal layout

---

# Step-by-Step Usage

1. **Add Pet Owners** - Enter owner contact information and address
2. **Add Pets** - Register pets and link to owners
3. **Add Grooming Services** - Define available services and pricing
4. **Create Reservations** - Book services for pets
5. **View & Edit Reservations** - Manage reservation statuses
6. **Generate Reports** - View statistics and filtered data

---

# Key Features

✓ **Database**: 4 normalized tables with proper relationships  
✓ **CRUD Operations**: Full Create, Read, Update, Delete for all entities  
✓ **Reservations**: Complete booking management with status tracking  
✓ **Reports**: Multiple filtered reports with COUNT() and SUM() aggregations  
✓ **Sample Data**: Pre-loaded data for immediate testing  
✓ **Offline Ready**: No external dependencies or internet required  
✓ **Beginner-Friendly**: Simple procedural PHP with clear structure  
✓ **Minimal CSS**: Clean, readable custom stylesheet (no frameworks)  

---

# Project Constraints (College Skills Test)

This project follows these specific requirements:

- ✓ PHP **procedural** style (no OOP)
- ✓ **mysqli** database extension
- ✓ **MySQL** database
- ✓ **Custom minimal CSS** (no Bootstrap)
- ✓ **Offline ready** (no internet required)
- ✓ **No frameworks** (pure PHP)
- ✓ **No MVC** (simple procedural structure)
- ✓ **No AJAX** (traditional form submissions)
- ✓ **No Composer** (no dependency management)
- ✓ **Beginner-friendly** (easy to understand and modify)

---

# Troubleshooting

**Issue**: Database import fails  
**Solution**: Ensure MySQL is running, use correct path, verify user is `root`

**Issue**: Pages return 404  
**Solution**: Check Apache is running, verify URL is `http://localhost/LibradillaPetGrooming/`

**Issue**: Cannot connect to database  
**Solution**: Check `db.php` connection settings, verify MySQL credentials

---

# Future Enhancement Ideas

- User authentication and login system
- Email notifications for reservations
- SMS reminders
- Payment processing integration
- Customer ratings and reviews
- Multi-user support (Admin, Groomer, Receptionist roles)

---