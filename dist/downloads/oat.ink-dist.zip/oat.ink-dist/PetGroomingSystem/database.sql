-- Pet Grooming Reservation System Database
-- MySQL Database Schema with Sample Data and Useful Queries

-- ============================================
-- DATABASE SETUP
-- ============================================

-- Create Database
CREATE DATABASE IF NOT EXISTS pet_grooming;
USE pet_grooming;

-- ============================================
-- TABLE DEFINITIONS
-- ============================================

-- Table: petowners
CREATE TABLE IF NOT EXISTS petowners (
    ownerID INT AUTO_INCREMENT PRIMARY KEY,
    ownerFName VARCHAR(100) NOT NULL,
    ownerLName VARCHAR(100) NOT NULL,
    contactNo VARCHAR(20) NOT NULL,
    address TEXT NOT NULL
);

-- Table: pets
CREATE TABLE IF NOT EXISTS pets (
    petID INT AUTO_INCREMENT PRIMARY KEY,
    ownerID INT NOT NULL,
    petName VARCHAR(100) NOT NULL,
    petType VARCHAR(50) NOT NULL,
    breed VARCHAR(100),
    age INT,
    FOREIGN KEY (ownerID) REFERENCES petowners(ownerID) ON DELETE CASCADE
);

-- Table: grooming_services
CREATE TABLE IF NOT EXISTS grooming_services (
    serviceID INT AUTO_INCREMENT PRIMARY KEY,
    serviceName VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    duration INT NOT NULL COMMENT 'Duration in minutes'
);

-- Table: reservations
CREATE TABLE IF NOT EXISTS reservations (
    reservationID INT AUTO_INCREMENT PRIMARY KEY,
    petID INT NOT NULL,
    serviceID INT NOT NULL,
    reservationDate DATE NOT NULL,
    reservationTime TIME NOT NULL,
    specialRequest TEXT,
    totalAmount DECIMAL(10, 2) NOT NULL,
    status ENUM('Pending', 'Confirmed', 'Completed', 'Cancelled') DEFAULT 'Pending',
    dateCreated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (petID) REFERENCES pets(petID) ON DELETE CASCADE,
    FOREIGN KEY (serviceID) REFERENCES grooming_services(serviceID) ON DELETE RESTRICT
);

-- Indexes for better query performance
CREATE INDEX idx_reservations_status ON reservations(status);
CREATE INDEX idx_reservations_date ON reservations(reservationDate);
CREATE INDEX idx_pets_owner ON pets(ownerID);

-- ============================================
-- SAMPLE DATA
-- ============================================

-- Insert Sample Pet Owners
INSERT INTO petowners (ownerFName, ownerLName, contactNo, address) VALUES
('John', 'Smith', '555-0101', '123 Main Street, Springfield'),
('Mary', 'Johnson', '555-0102', '456 Oak Avenue, Springfield'),
('Robert', 'Williams', '555-0103', '789 Pine Road, Springfield'),
('Patricia', 'Brown', '555-0104', '321 Elm Street, Springfield'),
('Michael', 'Davis', '555-0105', '654 Maple Drive, Springfield');

-- Insert Sample Pets
INSERT INTO pets (ownerID, petName, petType, breed, age) VALUES
(1, 'Buddy', 'Dog', 'Golden Retriever', 3),
(1, 'Whiskers', 'Cat', 'Siamese', 2),
(2, 'Max', 'Dog', 'Labrador', 5),
(2, 'Luna', 'Cat', 'Persian', 4),
(3, 'Rocky', 'Dog', 'German Shepherd', 6),
(3, 'Charlie', 'Dog', 'Beagle', 2),
(4, 'Bella', 'Dog', 'Poodle', 3),
(5, 'Mittens', 'Cat', 'Tabby', 1);

-- Insert Sample Grooming Services
INSERT INTO grooming_services (serviceName, description, price, duration) VALUES
('Basic Bath', 'Standard bath and dry', 25.00, 30),
('Full Grooming', 'Bath, dry, trim, and styling', 75.00, 90),
('Premium Grooming', 'Full grooming with nail trim and ear cleaning', 100.00, 120),
('Cat Grooming', 'Bath and grooming for cats', 40.00, 60),
('Nail Trim Only', 'Nail trimming service', 15.00, 15),
('Ear Cleaning', 'Professional ear cleaning', 20.00, 20);

-- Insert Sample Reservations
INSERT INTO reservations (petID, serviceID, reservationDate, reservationTime, specialRequest, totalAmount, status) VALUES
(1, 2, '2026-07-05', '10:00:00', 'Hypoallergenic shampoo preferred', 75.00, 'Confirmed'),
(2, 4, '2026-07-05', '11:00:00', 'Handle with care - anxious cat', 40.00, 'Pending'),
(3, 2, '2026-07-06', '14:00:00', NULL, 75.00, 'Completed'),
(4, 1, '2026-07-06', '15:00:00', 'Extra conditioning', 25.00, 'Completed'),
(5, 3, '2026-07-07', '09:00:00', 'Check for skin issues', 100.00, 'Confirmed'),
(6, 2, '2026-07-07', '10:30:00', NULL, 75.00, 'Pending'),
(7, 3, '2026-07-08', '13:00:00', 'Make it fluffy', 100.00, 'Confirmed'),
(8, 1, '2026-07-08', '14:00:00', NULL, 40.00, 'Cancelled');
