<?php
include 'db.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $ownerid = intval($_POST['ownerid']);
        $petname = $conn->real_escape_string($_POST['petname']);
        $pettype = $conn->real_escape_string($_POST['pettype']);
        $breed = $conn->real_escape_string($_POST['breed']);
        $age = intval($_POST['age']);
        $sql = "INSERT INTO pets (ownerID, petName, petType, breed, age) VALUES ($ownerid, '$petname', '$pettype', '$breed', $age)";
        if ($conn->query($sql)) { $message = 'Pet added successfully.'; $message_type = 'success'; $action = 'list'; }
        else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'update') {
        $id = intval($_POST['id']);
        $ownerid = intval($_POST['ownerid']);
        $petname = $conn->real_escape_string($_POST['petname']);
        $pettype = $conn->real_escape_string($_POST['pettype']);
        $breed = $conn->real_escape_string($_POST['breed']);
        $age = intval($_POST['age']);
        $sql = "UPDATE pets SET ownerID=$ownerid, petName='$petname', petType='$pettype', breed='$breed', age=$age WHERE petID=$id";
        if ($conn->query($sql)) { $message = 'Pet updated successfully.'; $message_type = 'success'; $action = 'list'; }
        else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $sql = "DELETE FROM pets WHERE petID=$id";
    if ($conn->query($sql)) { $message = 'Pet deleted successfully.'; $message_type = 'success'; }
    else { $message = 'Error: ' . $conn->error; $message_type = 'danger'; }
    $action = 'list';
}

$pet = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM pets WHERE petID=$id");
    $pet = $result->fetch_assoc();
    if (!$pet) { $message = 'Pet not found.'; $message_type = 'danger'; $action = 'list'; }
}

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$owners_result = $conn->query("SELECT * FROM petowners ORDER BY ownerLName, ownerFName");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Pets</title>
    
    </head>
    <body>
        <div class="container">
            <header>
                <h1>Pet Grooming System</h1>
                <nav>
                    <a href="index.php">Dashboard</a>
                    <a href="petowners.php">Pet Owners</a>
                    <a class="active" href="pets.php">Pets</a>
                    <a href="services.php">Services</a>
                    <a href="reservations.php">Reservations</a>
                    <a href="reports.php">Reports</a>
                </nav>
            </header>

    <?php if ($message): ?><div role="alert" class="notice notice-<?php echo $message_type; ?>"><?php echo $message; ?></div><?php endif; ?>

    <?php if ($action === 'list'): ?>
            <div class="box">
                <h1 class="page-title">Pets</h1>
                <p><a class="button" href="pets.php?action=add">Add Pet</a></p>
                <form method="get" style="margin-top:12px;" class="filter-form">
                    <div class="row">
                        <div class="col"><input type="text" name="search" value="<?php echo $search; ?>" placeholder="Search by pet name"></div>
                        <div class="col filter-actions"><button class="button" type="submit">Search</button><a class="button outline" href="pets.php">Clear</a></div>
                    </div>
        
                </form>
                <table style="margin-top:12px;">
                    <tr><th>ID</th><th>Pet Name</th><th>Type</th><th>Breed</th><th>Age</th><th>Owner</th><th>Action</th></tr>
            <?php
            $where = '';
            if ($search) { $where = " WHERE p.petName LIKE '%$search%'"; }
            $result = $conn->query("SELECT p.*, o.ownerFName, o.ownerLName FROM pets p JOIN petowners o ON p.ownerID = o.ownerID $where ORDER BY p.petName");
            if ($result->num_rows > 0): while ($row = $result->fetch_assoc()):
            ?>
                    <tr>
                        <td><?php echo $row['petID']; ?></td>
                        <td><?php echo $row['petName']; ?></td>
                        <td><?php echo $row['petType']; ?></td>
                        <td><?php echo $row['breed']; ?></td>
                        <td><?php echo $row['age']; ?> year(s)</td>
                        <td><?php echo $row['ownerFName']; ?> <?php echo $row['ownerLName']; ?></td>
                        <td class="actions"><a class="button outline" href="pets.php?action=edit&id=<?php echo $row['petID']; ?>">Edit</a> <a class="button danger-action" href="pets.php?delete=<?php echo $row['petID']; ?>" onclick="return confirm('Delete this pet?')">Delete</a></td>
                    </tr>
            <?php endwhile; else: ?><tr><td colspan="7">No pets found.</td></tr><?php endif; ?>
                </table>
            </div>
    <?php else: ?>
            <div class="box">
                <h2><?php echo $action === 'add' ? 'Add Pet' : 'Edit Pet'; ?></h2>
                <form method="post" class="entry-form">
                    <input type="hidden" name="action" value="<?php echo $action === 'add' ? 'add' : 'update'; ?>">
            <?php if ($action === 'edit'): ?><input type="hidden" name="id" value="<?php echo $pet['petID']; ?>"><?php endif; ?>
                    <div class="row">
                        <div class="col"><label for="input-ownerid">Owner</label><select name="ownerid" required id="input-ownerid"><option value="">Select owner</option><?php while ($owner = $owners_result->fetch_assoc()): $selected = ($pet && $pet['ownerID'] == $owner['ownerID']) ? 'selected' : ''; ?><option value="<?php echo $owner['ownerID']; ?>" <?php echo $selected; ?>><?php echo $owner['ownerFName']; ?> <?php echo $owner['ownerLName']; ?></option><?php endwhile; ?></select></div>
                        <div class="col"><label for="input-petname">Pet Name</label><input type="text" name="petname" value="<?php echo $pet ? $pet['petName'] : ''; ?>" required id="input-petname"></div>
                    </div>
                    <div class="row">
                        <div class="col"><label for="input-pettype">Type</label><select name="pettype" required id="input-pettype"><option value="">Select type</option><option value="Dog" <?php if ($pet && $pet['petType'] === 'Dog') echo 'selected'; ?>>Dog</option><option value="Cat" <?php if ($pet && $pet['petType'] === 'Cat') echo 'selected'; ?>>Cat</option><option value="Bird" <?php if ($pet && $pet['petType'] === 'Bird') echo 'selected'; ?>>Bird</option><option value="Rabbit" <?php if ($pet && $pet['petType'] === 'Rabbit') echo 'selected'; ?>>Rabbit</option><option value="Other" <?php if ($pet && $pet['petType'] === 'Other') echo 'selected'; ?>>Other</option></select></div>
                        <div class="col"><label for="input-breed">Breed</label><input type="text" name="breed" value="<?php echo $pet ? $pet['breed'] : ''; ?>" id="input-breed"></div>
                    </div>
                    <div class="row"><div class="col"><label for="input-age">Age</label><input type="number" name="age" min="0" value="<?php echo $pet ? $pet['age'] : ''; ?>" id="input-age"></div></div>
                    <p class="form-actions"><button class="button" type="submit">Save</button> <a class="button outline" href="pets.php">Cancel</a></p>
                </form>
            </div>
    <?php endif; ?>
        </div>
    </body>
</html>
