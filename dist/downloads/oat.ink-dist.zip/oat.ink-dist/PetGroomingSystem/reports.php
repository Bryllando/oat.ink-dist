<?php
include 'db.php';

$summary = [];
$result = $conn->query("SELECT COUNT(*) as count FROM reservations");
$summary['reservations'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM petowners");
$summary['owners'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM pets");
$summary['pets'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT COUNT(*) as count FROM grooming_services");
$summary['services'] = $result->fetch_assoc()['count'];

$result = $conn->query("SELECT SUM(totalAmount) as revenue FROM reservations");
$summary['revenue'] = $result->fetch_assoc()['revenue'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Reports</title>
    
    </head>
    <body>
        <div class="container">
            <header>
                <h1>Pet Grooming System</h1>
                <nav>
                    <a href="index.php">Dashboard</a>
                    <a href="petowners.php">Pet Owners</a>
                    <a href="pets.php">Pets</a>
                    <a href="services.php">Services</a>
                    <a href="reservations.php">Reservations</a>
                    <a class="active" href="reports.php">Reports</a>
                </nav>
            </header>

            <div class="box">
                <h1 class="page-title">Reports</h1>
                <div class="row">
                    <div class="col box"><h3><?php echo $summary['reservations']; ?></h3><p>Total Reservations</p></div>
                    <div class="col box"><h3><?php echo $summary['owners']; ?></h3><p>Pet Owners</p></div>
                    <div class="col box"><h3><?php echo $summary['pets']; ?></h3><p>Pets</p></div>
                    <div class="col box"><h3><?php echo $summary['services']; ?></h3><p>Services</p></div>
                </div>
                <div class="row">
                    <div class="col box"><h3>$<?php echo number_format($summary['revenue'], 2); ?></h3><p>Total Revenue</p></div>
                </div>
            </div>
        </div>
    </body>
</html>
