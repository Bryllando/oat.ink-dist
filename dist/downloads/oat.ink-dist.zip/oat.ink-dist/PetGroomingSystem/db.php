<?php
/**
 * Database Connection File
 * Establishes mysqli connection to pet_grooming database
 */

$db_host = '127.0.0.1';
$db_user = 'root';
$db_password = '';
$db_name = 'pet_grooming';

// Disable default mysqli exception throwing for auto-setup routines
mysqli_report(MYSQLI_REPORT_OFF);

$conn = @mysqli_connect($db_host, $db_user, $db_password);
if (!$conn) {
    die('Database connection failed: ' . htmlspecialchars(mysqli_connect_error()));
}

// Auto-create database if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS `{$db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci") or die('Database setup failed: ' . htmlspecialchars($conn->error));
$conn->select_db($db_name) or die('Database setup failed: ' . htmlspecialchars($conn->error));
$conn->set_charset("utf8mb4") or die('Database setup failed: ' . htmlspecialchars($conn->error));

$tables = $conn->query("SHOW TABLES");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($conn->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/pet_grooming.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $conn->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($conn->error));
    do {
        if ($result = $conn->store_result()) $result->free();
    } while ($conn->more_results() && $conn->next_result());
    if ($conn->errno) die('Database setup failed: ' . htmlspecialchars($conn->error));
}
?>
