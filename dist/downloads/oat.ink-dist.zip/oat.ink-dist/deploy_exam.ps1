﻿param(
    [string]$SystemName,
    [string]$FolderName,
    [string]$WebRoot = 'C:\xampp\htdocs',
    [switch]$NoBrowser
)
$ErrorActionPreference = 'Stop'
$interactive = -not $SystemName
try {
    $groups = [ordered]@{
        'RENTALS and BOOKINGS' = [ordered]@{
            CarRentalSystem = 'Car Rental System (Vehicles + Customers -> Rentals)'
            HotelReservationSystem = 'Hotel Reservation System (Rooms + Guests -> Reservations)'
            MovieBookingSystem = 'Cinema / Movie Booking System (Movies + Customers -> Bookings)'
            EquipmentBorrowingSystem = 'Equipment Borrowing System (Equipment + Borrowers -> Borrow Logs)'
        }
        'CLINICAL and HEALTHCARE SERVICES' = [ordered]@{
            ClinicConsultationSystem = 'Clinic Consultation System (Doctors + Patients -> Consultations)'
            DentalClinicSystem = 'Dental Clinic System (Dentists + Patients -> Appointments)'
            VeterinarySystem = 'Veterinary Clinic System (Vets + Pets -> Treatments)'
            PetGroomingSystem = 'Pet Grooming System (Services + Pets -> Bookings)'
            AppointmentSystem = 'Professional Appointment System (Services + Clients -> Appointments)'
        }
        'RETAIL, POS and FOOD' = [ordered]@{
            RestaurantOrderingSystem = 'Restaurant Ordering System (Menu Items + Customers -> Orders)'
            CoffeeShopSystem = 'Coffee Shop POS System (Menu Items + Customers -> Orders)'
            PharmacySystem = 'Pharmacy Inventory and Sales System (Medicines + Customers -> Purchases)'
            SalesOrderSystem = 'Sales and Order Management System (Products + Customers -> Orders)'
            BookSystem = 'Bookstore Sales System (Books + Customers -> Orders)'
            InventorySystem = 'Warehouse Inventory System (Suppliers + Products -> Stock Movements)'
        }
        'SERVICE, REPAIR and FITNESS' = [ordered]@{
            LaundrySystem = 'Laundry Service System (Services + Customers -> Laundry Orders)'
            RepairServiceSystem = 'Repair Service System (Technicians + Appliances -> Repairs)'
            GymMembershipSystem = 'Gym Membership System (Packages + Members -> Memberships)'
        }
        'ACADEMIC, CAMPUS and INSTITUTIONAL' = [ordered]@{
            EventRegistrationSystem = 'Event Registration System (Events + Participants -> Registrations)'
            IctCongress = 'ICT Congress Registration System (Workshops + Participants -> Registrations)'
            StudentEnrollmentSystem = 'Student Enrollment System (Subjects + Students -> Enrollments)'
            StudentScholarshipSystem = 'Student Scholarship System (Scholarships + Students -> Applications)'
            StudentRecordsSystem = 'Student Academic Records System (Courses + Students -> Grades)'
            LibraryManagementSystem = 'Library Management System (Books + Borrowers -> Borrowed Books)'
            PayrollSystem = 'Payroll Management System (Positions + Employees -> Payroll)'
            UserRoleSystem = 'User Role and Access System (Roles + Users -> Assignments)'
            UcIntramuralsSystem = 'UC Intramurals Tournament System (Departments + Athletes -> Tournaments)'
        }
        'COMMUNITY, UTILITIES, LOGISTICS and COMMERCIAL' = [ordered]@{
            BarangayClearanceSystem = 'Barangay Clearance and Certification System (Residents + Clearance Types -> Clearances)'
            WaterBillingSystem = 'Water Billing and Meter Reading System (Consumers + Rate Plans -> Water Bills)'
            ElectricBillingSystem = 'Electric Power and Utility Billing System (Accounts + Tariff Classes -> Electric Bills)'
            HospitalAdmissionSystem = 'Hospital Patient Admission System (Patients + Wards -> Admissions)'
            TuitionPaymentSystem = 'School Tuition and Fee Assessment System (Students + Fee Categories -> Tuition Payments)'
            ApartmentRentalSystem = 'Apartment and Boarding House Rental System (Tenants + Units -> Leases)'
            CarWashSystem = 'Car Wash and Auto Detailing Service System (Car Owners + Wash Packages -> Wash Orders)'
            CourierDeliverySystem = 'Courier Logistics and Parcel Shipping System (Clients + Routes -> Shipments)'
            ParkingSystem = 'Smart Parking Slot and Ticketing System (Vehicles + Parking Slots -> Parking Tickets)'
            BloodBankSystem = 'Red Cross Blood Bank Management System (Donors + Blood Types -> Blood Donations)'
            JobApplicationSystem = 'Corporate Job Recruitment System (Job Openings + Applicants -> Job Applications)'
            TricycleFranchiseSystem = 'LGU Tricycle Franchise Permitting System (Operators + Vehicles -> Franchise Permits)'
            AlumniTracerSystem = 'University Alumni Employment Tracer System (Degree Programs + Alumni -> Employment Records)'
        }
        'UNIVERSAL GENERATORS and TEMPLATES' = [ordered]@{
            UniversalTemplate = 'Universal Master Template (Items + Clients -> Transactions + Monitoring)'
            SystemMorpher = 'Launch SystemMorpher GUI (Interactive Web Generator - Custom Systems on Demand)'
        }
        'PRACTICE TEMPLATES' = [ordered]@{
            BasicCrudSystem = 'Basic CRUD System (General record management)'
            CompleteCrudSystem = 'Complete CRUD Practice (Records + Search + Validation + Oat UI)'
        }
    }
    $folders = @(Get-ChildItem -LiteralPath $PSScriptRoot -Directory |
        Where-Object { (Test-Path -LiteralPath (Join-Path $_.FullName 'database.sql')) -or ($_.Name -eq 'SystemMorpher' -and (Test-Path -LiteralPath (Join-Path $_.FullName 'index.php'))) } |
        Sort-Object Name)
    $systems = @(
        foreach ($group in $groups.GetEnumerator()) {
            foreach ($entry in $group.Value.GetEnumerator()) {
                $folder = $folders | Where-Object Name -eq $entry.Key
                if ($folder) {
                    [PSCustomObject]@{ Name = $folder.Name; FullName = $folder.FullName; Group = $group.Key; Label = $entry.Value }
                }
            }
        }
    )
    foreach ($folder in $folders) {
        if ($folder.Name -notin $systems.Name) {
            $systems += [PSCustomObject]@{ Name = $folder.Name; FullName = $folder.FullName; Group = 'OTHER SYSTEMS'; Label = $folder.Name }
        }
    }
    if ($systems.Count -eq 0) { throw 'No system folders were found beside this script.' }
    if ($interactive) { Clear-Host }
    Write-Host ''
    Write-Host '  +--------------------------------------------------------------------+' -ForegroundColor DarkCyan
    Write-Host ('  |  {0,-64}  |' -f 'PHP & MYSQL PROJECT DEPLOYER') -ForegroundColor Cyan
    Write-Host ('  |  {0,-64}  |' -f "ALL $($systems.Count) SYSTEMS AND TOOLS") -ForegroundColor White
    Write-Host '  +--------------------------------------------------------------------+' -ForegroundColor DarkCyan
    Write-Host '   Offline assets included  /  Existing folders are preserved' -ForegroundColor Gray
    Write-Host ''

    if ($interactive) {
        Write-Host '   STEP 1  Choose a system' -ForegroundColor Cyan
        Write-Host '   --------------------------------------------------------------------' -ForegroundColor DarkGray
        $currentGroup = ''
        for ($i = 0; $i -lt $systems.Count; $i++) {
            if ($systems[$i].Group -ne $currentGroup) {
                $currentGroup = $systems[$i].Group
                Write-Host ''
                Write-Host "   --- $currentGroup ---" -ForegroundColor Cyan
            }
            Write-Host ('   [{0,2}] {1}' -f ($i + 1), $systems[$i].Label)
        }
        Write-Host ''
        while ($true) {
            $choice = (Read-Host "   System number [1-$($systems.Count)] or Q to exit").Trim()
            if ($choice -eq 'Q') { Write-Host '   Closed. No files copied.' -ForegroundColor Gray; exit 0 }
            $selection = 0
            if ([int]::TryParse($choice, [ref]$selection) -and $selection -ge 1 -and $selection -le $systems.Count) { break }
            Write-Host "   Enter a number from 1 to $($systems.Count), or Q to exit." -ForegroundColor Yellow
        }
        $SystemName = $systems[$selection - 1].Name
    }
    $source = $systems | Where-Object Name -eq $SystemName
    if (-not $source) { throw 'System not found.' }
    if (-not (Test-Path -LiteralPath $WebRoot -PathType Container)) { throw "Web root not found: $WebRoot. Use -WebRoot for your XAMPP htdocs folder." }
    $rootPath = (Resolve-Path -LiteralPath $WebRoot).Path
    $launchGenerator = $source.Name -eq 'SystemMorpher' -and -not $FolderName
    if ($launchGenerator) { $FolderName = 'SystemMorpher' }
    $promptForFolder = -not $FolderName
    Write-Host ''
    if ($launchGenerator) { Write-Host '   Opening SystemMorpher' -ForegroundColor Cyan }
    else { Write-Host '   STEP 2  Set the destination' -ForegroundColor Cyan }
    Write-Host "   System : $($source.Name)"
    Write-Host "   Web root: $rootPath" -ForegroundColor Gray
    if ($promptForFolder) { Write-Host '   Use your surname or a short folder name. Enter Q to exit.' -ForegroundColor Gray }
    while ($true) {
        if ($promptForFolder) {
            $FolderName = (Read-Host '   New folder name').Trim()
            if ($FolderName -eq 'Q') { Write-Host '   Closed. No files copied.' -ForegroundColor Gray; exit 0 }
        }
        $problem = ''
        if ($FolderName -notmatch '^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$' -or $FolderName -match '^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$') {
            $problem = 'Use 1-64 letters, numbers, hyphens or underscores.'
        } else {
            $targetPath = Join-Path $rootPath $FolderName
            if ((Test-Path -LiteralPath $targetPath) -and -not $launchGenerator) { $problem = 'That folder already exists. Choose another name to preserve its files.' }
        }
        if (-not $problem) { break }
        if (-not $promptForFolder) { throw $problem }
        Write-Host "   $problem" -ForegroundColor Yellow
    }
    if ($launchGenerator -and (Test-Path -LiteralPath $targetPath)) {
        $currentBundle = $true
        $fingerprint = @(
            foreach ($file in (Get-ChildItem -LiteralPath $source.FullName -Recurse -File | Sort-Object FullName)) {
                $relative = $file.FullName.Substring($source.FullName.Length + 1)
                $sourceHash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
                $installedFile = Join-Path $targetPath $relative
                if (-not (Test-Path -LiteralPath $installedFile -PathType Leaf) -or (Get-FileHash -LiteralPath $installedFile -Algorithm SHA256).Hash -ne $sourceHash) { $currentBundle = $false }
                "$relative=$sourceHash"
            }
        )
        if (-not $currentBundle) {
            $hasher = [System.Security.Cryptography.SHA256]::Create()
            try { $version = [BitConverter]::ToString($hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($fingerprint -join "`n"))).Replace('-', '').Substring(0, 12).ToLowerInvariant() }
            finally { $hasher.Dispose() }
            $FolderName = "SystemMorpher_$version"
            $targetPath = Join-Path $rootPath $FolderName
            Write-Host '   Keeping the older installation. Opening the current Skilltest generator copy.' -ForegroundColor Gray
        }
    }
    $reuseGenerator = $launchGenerator -and (Test-Path -LiteralPath $targetPath)
    $bundlePath = $source.FullName
    if ($reuseGenerator) { $bundlePath = $targetPath }
    foreach ($asset in @('css\oat.min.css', 'css\app.css', 'js\oat.min.js', 'js\app.js')) {
        if (-not (Test-Path -LiteralPath (Join-Path $bundlePath "assets\$asset") -PathType Leaf)) { throw "Missing offline asset: $asset in $bundlePath. Existing folders are preserved; use -FolderName to deploy a fresh copy elsewhere." }
    }
    if ($source.Name -eq 'SystemMorpher') {
        foreach ($required in @('index.php', 'guided.php', 'script.js', 'builder.php', 'builder.js', 'presets.json', 'assets\css\generator.css', 'multi_engine.php', 'multi_templates\dashboard.tpl', 'multi_templates\navbar.tpl', 'multi_templates\form.tpl', 'multi_templates\listing.tpl', 'multi_templates\delete.tpl', 'template\index.php', 'template\database.php', 'template\database.sql')) {
            if (-not (Test-Path -LiteralPath (Join-Path $bundlePath $required) -PathType Leaf)) { throw "Missing generator file: $required in $bundlePath. Existing folders are preserved; use -FolderName to deploy a fresh copy elsewhere." }
        }
    }
    Write-Host ''
    if ($reuseGenerator) {
        Write-Host '   Using the existing SystemMorpher installation.' -ForegroundColor Gray
    } else {
        if (-not $launchGenerator) { Write-Host '   STEP 3  Copy the system' -ForegroundColor Cyan }
        Write-Host "   Copying files to $targetPath ..." -ForegroundColor Gray
        Copy-Item -LiteralPath $source.FullName -Destination $targetPath -Recurse
    }
    $url = "http://localhost/$FolderName/"
    Write-Host ''
    if ($launchGenerator) { Write-Host '   GENERATOR READY' -ForegroundColor Green }
    else { Write-Host '   DEPLOYMENT COMPLETE' -ForegroundColor Green }
    Write-Host '   --------------------------------------------------------------------' -ForegroundColor DarkGray
    Write-Host "   Folder : $targetPath"
    Write-Host "   Open   : $url" -ForegroundColor Cyan
    Write-Host ''
    Write-Host '   Start Apache and MySQL in XAMPP before using the system.' -ForegroundColor Gray
    if ($source.Name -eq 'SystemMorpher') {
        Write-Host '   Enter the new project folder and database name inside the generator.' -ForegroundColor Gray
        Write-Host '   Generated projects use offline Oat assets and require a new folder.' -ForegroundColor Gray
    } else {
        Write-Host '   Database names stay the same; renamed copies share their data.' -ForegroundColor Gray
    }
    Write-Host ''
    if (-not $NoBrowser) {
        try { Start-Process $url -WindowStyle Hidden }
        catch { Write-Host '   Open the URL above manually in your browser.' -ForegroundColor Yellow }
    }
} catch {
    Write-Host ''
    Write-Host '   DEPLOYMENT FAILED' -ForegroundColor Red
    Write-Host "   $($_.Exception.Message)" -ForegroundColor Yellow
    Write-Host ''
    exit 1
}
