<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $programCode = is_string($_POST['programCode'] ?? null) ? trim($_POST['programCode']) : '';
    $programName = is_string($_POST['programName'] ?? null) ? trim($_POST['programName']) : '';
    $collegeDepartment = is_string($_POST['collegeDepartment'] ?? null) ? trim($_POST['collegeDepartment']) : '';
    $accreditationLevel = is_string($_POST['accreditationLevel'] ?? null) ? trim($_POST['accreditationLevel']) : '';

    if ($programCode === '' ||
        $programName === '' ||
        $collegeDepartment === '' ||
        $accreditationLevel === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `degree_programs` (`programCode`, `programName`, `collegeDepartment`, `accreditationLevel`) VALUES ('" . $conn->real_escape_string($programCode) . "', '" . $conn->real_escape_string($programName) . "', '" . $conn->real_escape_string($collegeDepartment) . "', '" . $conn->real_escape_string($accreditationLevel) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Academic Program - University Alumni Tracking & Employment Tracer System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Add New Academic Program</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="programCode" class="weight-semibold">Program Code</label>
                <input type="text" id="programCode" name="programCode" class=""  required value="<?= htmlspecialchars($programCode ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="programName" class="weight-semibold">Degree Title</label>
                <input type="text" id="programName" name="programName" class=""  required value="<?= htmlspecialchars($programName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="collegeDepartment" class="weight-semibold">College Department</label>
                <input type="text" id="collegeDepartment" name="collegeDepartment" class=""  required value="<?= htmlspecialchars($collegeDepartment ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="accreditationLevel" class="weight-semibold">Accreditation Level</label>
                <input type="text" id="accreditationLevel" name="accreditationLevel" class=""  required value="<?= htmlspecialchars($accreditationLevel ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Save Academic Program</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
