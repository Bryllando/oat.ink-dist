<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `programID`, `programCode` FROM `degree_programs` ORDER BY `programCode` ASC");
$e2List = $conn->query("SELECT `alumniID`, `fullName` FROM `alumni` ORDER BY `fullName` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['programID'] ?? 0);
    $id2 = (int)($_POST['alumniID'] ?? 0);
    $companyName = is_string($_POST['companyName'] ?? null) ? trim($_POST['companyName']) : '';
    $jobTitle = is_string($_POST['jobTitle'] ?? null) ? trim($_POST['jobTitle']) : '';
    $monthlySalary = is_string($_POST['monthlySalary'] ?? null) ? trim($_POST['monthlySalary']) : '';
    $workLocation = is_string($_POST['workLocation'] ?? null) ? trim($_POST['workLocation']) : '';
    $employmentStatus = is_string($_POST['employmentStatus'] ?? null) ? trim($_POST['employmentStatus']) : '';

    if ($companyName === '' ||
        $jobTitle === '' ||
        $monthlySalary === '' ||
        !is_numeric($monthlySalary) ||
        !is_finite((float)$monthlySalary) ||
        (float)$monthlySalary < 0 ||
        $workLocation === '' ||
        $employmentStatus === '' ||
        $id1 <= 0 ||
        $id2 <= 0) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `employment_records` (`programID`, `alumniID`, `companyName`, `jobTitle`, `monthlySalary`, `workLocation`, `employmentStatus`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($companyName) . "', '" . $conn->real_escape_string($jobTitle) . "', '" . $conn->real_escape_string($monthlySalary) . "', '" . $conn->real_escape_string($workLocation) . "', '" . $conn->real_escape_string($employmentStatus) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Employment Record - University Alumni Tracking & Employment Tracer System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Employment Record</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="programID" class="weight-semibold">Select Academic Program</label>
                        <select id="programID" name="programID" class="" required>
                            <option value="">-- Choose Academic Program --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['programID'] ?>" <?= ((int)($_POST['programID'] ?? 0) === (int)$r['programID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['programCode']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="alumniID" class="weight-semibold">Select Alumni</label>
                        <select id="alumniID" name="alumniID" class="" required>
                            <option value="">-- Choose Alumni --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['alumniID'] ?>" <?= ((int)($_POST['alumniID'] ?? 0) === (int)$r['alumniID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['fullName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="companyName" class="weight-semibold">Hiring Company</label>
                <input type="text" id="companyName" name="companyName" class=""  required value="<?= htmlspecialchars($companyName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="jobTitle" class="weight-semibold">Current Job Title</label>
                <input type="text" id="jobTitle" name="jobTitle" class=""  required value="<?= htmlspecialchars($jobTitle ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="monthlySalary" class="weight-semibold">Estimated Monthly Salary</label>
                <input type="number" id="monthlySalary" name="monthlySalary" min="0" class="" step="0.01" required value="<?= htmlspecialchars($monthlySalary ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="workLocation" class="weight-semibold">Work Setup / Location</label>
                <input type="text" id="workLocation" name="workLocation" class=""  required value="<?= htmlspecialchars($workLocation ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="employmentStatus" class="weight-semibold">Status</label>
                <input type="text" id="employmentStatus" name="employmentStatus" class=""  required value="<?= htmlspecialchars($employmentStatus ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Employment Record</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
