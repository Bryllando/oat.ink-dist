<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">University Alumni Tracking & Employment Tracer System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'degree_programs') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>degree_programs/index.php">Academic Programs</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'alumni') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>alumni/index.php">Graduated Alumni</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'employment_records') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>employment_records/index.php">Employment Records</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
