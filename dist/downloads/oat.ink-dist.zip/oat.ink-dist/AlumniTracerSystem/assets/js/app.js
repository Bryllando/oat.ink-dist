document.addEventListener('DOMContentLoaded', () => {
  const current = new URL(location.href);
  const links = [...document.querySelectorAll('.nav-links a, .app-nav > a:not(.app-brand):not(.brand), header nav a, .container > nav a')];
  let selected = links.find(link => link.classList.contains('active'));
  let bestMatch = selected ? Infinity : 0;
  links.forEach(link => {
    const url = new URL(link.href);
    const samePage = url.pathname === current.pathname && url.search === current.search;
    const sameModule = !url.search && url.pathname.endsWith('/index.php') &&
      current.pathname.startsWith(url.pathname.slice(0, -9));
    const score = samePage ? Infinity : sameModule ? url.pathname.length : 0;
    if (samePage || score > bestMatch) {
      selected = link;
      bestMatch = score;
    }
  });
  links.forEach(link => {
    link.classList.toggle('active', link === selected);
    if (link === selected) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  });

  document.querySelectorAll('table').forEach(table => {
    const headers = [...table.querySelectorAll('th')];
    headers.forEach(header => header.setAttribute('scope', header.parentElement.querySelector('td') ? 'row' : 'col'));
    if (!table.querySelector('td')) {
      const body = table.tBodies[0] || table.createTBody();
      const cell = body.insertRow().insertCell();
      cell.colSpan = headers.length || 1;
      cell.className = 'empty-state';
      cell.textContent = 'No records found.';
    }
    if (!table.parentElement.matches('.table-responsive, .table-container, .table-wrap')) {
      const wrapper = document.createElement('div');
      wrapper.className = 'table-responsive';
      table.before(wrapper);
      wrapper.append(table);
    }
    const wrapper = table.parentElement;
    wrapper.tabIndex = 0;
    wrapper.setAttribute('role', 'region');
    wrapper.setAttribute('aria-label', 'Records table — scroll to view all columns');
  });

  document.querySelectorAll('label').forEach((label, index) => {
    if (label.querySelector('input, select, textarea')) return;
    const field = label.nextElementSibling;
    if (!field?.matches('input, select, textarea')) return;
    if (!field.id) field.id = label.htmlFor && !document.getElementById(label.htmlFor) ? label.htmlFor : `field-${index}`;
    label.htmlFor = field.id;
  });

  document.querySelectorAll('[data-dismiss-alert]').forEach(button => {
    button.addEventListener('click', () => button.closest('[role="alert"], .notice')?.remove());
  });

  document.querySelectorAll('input:not([type="hidden"]), select, textarea').forEach(field => {
    if (!field.labels?.length && !field.hasAttribute('aria-label')) {
      field.setAttribute('aria-label', field.placeholder || field.name.replace(/([a-z])([A-Z])/g, '$1 $2').replaceAll('_', ' '));
    }
  });
});
