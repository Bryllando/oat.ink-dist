CREATE DATABASE IF NOT EXISTS `alumni_tracer_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `alumni_tracer_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `degree_programs` (
  `programID` INT AUTO_INCREMENT PRIMARY KEY,
  `programCode` VARCHAR(50) NOT NULL,
  `programName` VARCHAR(150) NOT NULL,
  `collegeDepartment` VARCHAR(100) NOT NULL,
  `accreditationLevel` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `alumni` (
  `alumniID` INT AUTO_INCREMENT PRIMARY KEY,
  `studentNumber` VARCHAR(50) NOT NULL,
  `fullName` VARCHAR(100) NOT NULL,
  `graduationYear` INT NOT NULL,
  `contactEmail` VARCHAR(100) NOT NULL,
  `contactPhone` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `employment_records` (
  `recordID` INT AUTO_INCREMENT PRIMARY KEY,
  `programID` INT NOT NULL,
  `alumniID` INT NOT NULL,
  `companyName` VARCHAR(100) NOT NULL,
  `jobTitle` VARCHAR(100) NOT NULL,
  `monthlySalary` DECIMAL(10,2) NOT NULL,
  `workLocation` VARCHAR(100) NOT NULL,
  `employmentStatus` VARCHAR(50) DEFAULT 'Employed',
  FOREIGN KEY (`programID`) REFERENCES `degree_programs`(`programID`) ON DELETE CASCADE,
  FOREIGN KEY (`alumniID`) REFERENCES `alumni`(`alumniID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `degree_programs` (`programCode`, `programName`, `collegeDepartment`, `accreditationLevel`) VALUES
('BSIT', 'Bachelor of Science in Information Technology', 'College of Computer Studies', 'Level IV Accredited'),
('BSCS', 'Bachelor of Science in Computer Science', 'College of Computer Studies', 'Level III Accredited'),
('BSIS', 'Bachelor of Science in Information Systems', 'College of Computer Studies', 'Level II Accredited');

INSERT INTO `alumni` (`studentNumber`, `fullName`, `graduationYear`, `contactEmail`, `contactPhone`) VALUES
('2020-00812', 'Engr. Patrick John Cañizares', 2024, 'pj.canizares@techcorp.ph', '09171114455'),
('2021-01490', 'Sheena Marie Labastida', 2025, 'sheena.labastida@cloudsolutions.com', '09182225566'),
('2020-00334', 'Dexter Jay Villarante', 2024, 'dexter.villarante@fintech.io', '09223336677');

INSERT INTO `employment_records` (`programID`, `alumniID`, `companyName`, `jobTitle`, `monthlySalary`, `workLocation`, `employmentStatus`) VALUES
(1, 1, 'Lexmark Research & Development', 'Software Test Automation Engineer', 38000.0, 'Cebu IT Park (Hybrid)', 'Employed'),
(2, 2, 'Accenture Philippines', 'Cloud DevOps Analyst', 44000.0, 'Cebu Business Park (Onsite)', 'Employed'),
(1, 3, 'Seven Seven Global Services', 'Backend PHP / Node Engineer', 35000.0, 'Remote Philippines', 'Employed');

SET FOREIGN_KEY_CHECKS=1;
