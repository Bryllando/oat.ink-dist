<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `alumni` WHERE `alumniID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentNumber = is_string($_POST['studentNumber'] ?? null) ? trim($_POST['studentNumber']) : '';
    $fullName = is_string($_POST['fullName'] ?? null) ? trim($_POST['fullName']) : '';
    $graduationYear = is_string($_POST['graduationYear'] ?? null) ? trim($_POST['graduationYear']) : '';
    $contactEmail = is_string($_POST['contactEmail'] ?? null) ? trim($_POST['contactEmail']) : '';
    $contactPhone = is_string($_POST['contactPhone'] ?? null) ? trim($_POST['contactPhone']) : '';

    if ($studentNumber === '' ||
        $fullName === '' ||
        $graduationYear === '' ||
        !is_numeric($graduationYear) ||
        !is_finite((float)$graduationYear) ||
        (float)$graduationYear < 0 ||
        filter_var($graduationYear, FILTER_VALIDATE_INT) === false ||
        $contactEmail === '' ||
        !filter_var($contactEmail, FILTER_VALIDATE_EMAIL) ||
        $contactPhone === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `alumni` SET `studentNumber` = '" . $conn->real_escape_string($studentNumber) . "', `fullName` = '" . $conn->real_escape_string($fullName) . "', `graduationYear` = '" . $conn->real_escape_string($graduationYear) . "', `contactEmail` = '" . $conn->real_escape_string($contactEmail) . "', `contactPhone` = '" . $conn->real_escape_string($contactPhone) . "' WHERE `alumniID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Alumni - University Alumni Tracking & Employment Tracer System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Alumni</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="studentNumber" class="weight-semibold">Alumni Student No.</label>
                <input type="text" id="studentNumber" name="studentNumber" class=""  required value="<?= htmlspecialchars($record['studentNumber'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="fullName" class="weight-semibold">Graduate Full Name</label>
                <input type="text" id="fullName" name="fullName" class=""  required value="<?= htmlspecialchars($record['fullName'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="graduationYear" class="weight-semibold">Batch Year</label>
                <input type="number" id="graduationYear" name="graduationYear" min="0" class="" step="1" required value="<?= htmlspecialchars($record['graduationYear'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactEmail" class="weight-semibold">Email Address</label>
                <input type="email" id="contactEmail" name="contactEmail" class=""  required value="<?= htmlspecialchars($record['contactEmail'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactPhone" class="weight-semibold">Contact Number</label>
                <input type="text" id="contactPhone" name="contactPhone" class=""  required value="<?= htmlspecialchars($record['contactPhone'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Alumni</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
