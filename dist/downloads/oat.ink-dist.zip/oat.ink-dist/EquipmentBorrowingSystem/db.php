<?php
mysqli_report(MYSQLI_REPORT_OFF);
$host = '127.0.0.1';
$user = 'root';
$pass = '';
$dbname = 'equipment_borrowing';

// Connect to MySQL server first (without database name)
$conn = @mysqli_connect($host, $user, $pass);
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Auto-create database if not exists
mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS `{$dbname}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci") or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));
mysqli_select_db($conn, $dbname) or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));
mysqli_set_charset($conn, 'utf8mb4') or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));

$tables = $conn->query("SHOW TABLES");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($conn->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/equipment_borrowing.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $conn->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($conn->error));
    do {
        if ($result = $conn->store_result()) $result->free();
    } while ($conn->more_results() && $conn->next_result());
    if ($conn->errno) die('Database setup failed: ' . htmlspecialchars($conn->error));
}

function escape_input($conn, $value)
{
    return mysqli_real_escape_string($conn, trim($value));
}

function redirect($page)
{
    header('Location: ' . $page);
    exit;
}
