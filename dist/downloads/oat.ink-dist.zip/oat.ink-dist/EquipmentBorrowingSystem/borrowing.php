<?php
require_once 'db.php';

$pageTitle = 'Borrowing Transactions';
$message = '';
$messageType = 'notice-success';

$borrowerID = '';
$equipmentID = '';
$quantityBorrowed = 1;
$borrowDate = date('Y-m-d');
$returnDate = '';
$status = 'Borrowed';
$remarks = '';
$editTransaction = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $borrowID = isset($_POST['borrowID']) ? (int) $_POST['borrowID'] : 0;
    $borrowerID = (int) ($_POST['borrowerID'] ?? 0);
    $equipmentID = (int) ($_POST['equipmentID'] ?? 0);
    $quantityBorrowed = max(1, (int) ($_POST['quantityBorrowed'] ?? 1));
    $borrowDate = escape_input($conn, $_POST['borrowDate'] ?? date('Y-m-d'));
    $returnDate = escape_input($conn, $_POST['returnDate'] ?? '');
    $status = escape_input($conn, $_POST['status'] ?? 'Borrowed');
    $remarks = escape_input($conn, $_POST['remarks'] ?? '');

    if ($borrowerID > 0 && $equipmentID > 0) {
        $equipmentCheck = mysqli_query($conn, "SELECT quantityAvailable FROM equipment WHERE equipmentID=$equipmentID");
        $equipmentRow = mysqli_fetch_assoc($equipmentCheck);

        if ($borrowID > 0) {
            $existingResult = mysqli_query($conn, "SELECT * FROM borrowing WHERE borrowID=$borrowID");
            $existing = mysqli_fetch_assoc($existingResult);

            if ($existing) {
                $oldStatus = $existing['status'];
                $oldQty = (int) $existing['quantityBorrowed'];

                if ($oldStatus === 'Borrowed' && $status === 'Borrowed') {
                    $diff = $oldQty - $quantityBorrowed;
                    if ($diff > 0) {
                        mysqli_query($conn, "UPDATE equipment SET quantityAvailable = quantityAvailable + $diff WHERE equipmentID=$equipmentID");
                    } elseif ($diff < 0) {
                        $needed = abs($diff);
                        if ($equipmentRow && ((int) $equipmentRow['quantityAvailable'] - $needed) < 0) {
                            $message = 'Not enough available stock for the updated quantity.';
                            $messageType = 'notice-danger';
                        } else {
                            mysqli_query($conn, "UPDATE equipment SET quantityAvailable = quantityAvailable - $needed WHERE equipmentID=$equipmentID");
                        }
                    }
                } elseif ($oldStatus === 'Borrowed' && $status === 'Returned') {
                    mysqli_query($conn, "UPDATE equipment SET quantityAvailable = quantityAvailable + $oldQty WHERE equipmentID=$equipmentID");
                } elseif ($oldStatus === 'Returned' && $status === 'Borrowed') {
                    if ($equipmentRow && ((int) $equipmentRow['quantityAvailable'] - $quantityBorrowed) < 0) {
                        $message = 'Not enough available stock for the updated quantity.';
                        $messageType = 'notice-danger';
                    } else {
                        mysqli_query($conn, "UPDATE equipment SET quantityAvailable = quantityAvailable - $quantityBorrowed WHERE equipmentID=$equipmentID");
                    }
                }

                if (!$message) {
                    $sql = "UPDATE borrowing SET borrowerID=$borrowerID, equipmentID=$equipmentID, quantityBorrowed=$quantityBorrowed, borrowDate='$borrowDate', returnDate='$returnDate', status='$status', remarks='$remarks' WHERE borrowID=$borrowID";
                    if (mysqli_query($conn, $sql)) {
                        redirect('borrowing.php');
                    } else {
                        $message = 'Unable to update transaction.';
                        $messageType = 'notice-danger';
                    }
                }
            }
        } else {
            if ($equipmentRow && ((int) $equipmentRow['quantityAvailable'] - $quantityBorrowed) < 0) {
                $message = 'Not enough equipment available for borrowing.';
                $messageType = 'notice-danger';
            } else {
                $sql = "INSERT INTO borrowing (borrowerID, equipmentID, quantityBorrowed, borrowDate, returnDate, status, remarks) VALUES ($borrowerID, $equipmentID, $quantityBorrowed, '$borrowDate', '$returnDate', '$status', '$remarks')";
                if (mysqli_query($conn, $sql)) {
                    mysqli_query($conn, "UPDATE equipment SET quantityAvailable = quantityAvailable - $quantityBorrowed WHERE equipmentID=$equipmentID");
                    redirect('borrowing.php');
                } else {
                    $message = 'Unable to save transaction.';
                    $messageType = 'notice-danger';
                }
            }
        }
    } else {
        $message = 'Please select a borrower and equipment.';
        $messageType = 'notice-danger';
    }
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $existingResult = mysqli_query($conn, "SELECT * FROM borrowing WHERE borrowID=$id");
    $existing = mysqli_fetch_assoc($existingResult);
    if ($existing && $existing['status'] === 'Borrowed') {
        mysqli_query($conn, "UPDATE equipment SET quantityAvailable = quantityAvailable + " . (int) $existing['quantityBorrowed'] . " WHERE equipmentID=" . (int) $existing['equipmentID']);
    }
    if (mysqli_query($conn, "DELETE FROM borrowing WHERE borrowID=$id")) {
        redirect('borrowing.php');
    }
}

if (isset($_GET['return'])) {
    $id = (int) $_GET['return'];
    $existingResult = mysqli_query($conn, "SELECT * FROM borrowing WHERE borrowID=$id");
    $existing = mysqli_fetch_assoc($existingResult);
    if ($existing && $existing['status'] === 'Borrowed') {
        $qty = (int) $existing['quantityBorrowed'];
        mysqli_query($conn, "UPDATE equipment SET quantityAvailable = quantityAvailable + $qty WHERE equipmentID=" . (int) $existing['equipmentID']);
        mysqli_query($conn, "UPDATE borrowing SET status='Returned', returnDate='" . date('Y-m-d') . "' WHERE borrowID=$id");
        redirect('borrowing.php');
    }
}

if (isset($_GET['edit'])) {
    $id = (int) $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM borrowing WHERE borrowID=$id");
    $editTransaction = mysqli_fetch_assoc($result);
    if ($editTransaction) {
        $borrowerID = (int) $editTransaction['borrowerID'];
        $equipmentID = (int) $editTransaction['equipmentID'];
        $quantityBorrowed = (int) $editTransaction['quantityBorrowed'];
        $borrowDate = $editTransaction['borrowDate'];
        $returnDate = $editTransaction['returnDate'] ?? '';
        $status = $editTransaction['status'];
        $remarks = $editTransaction['remarks'] ?? '';
    }
}

$borrowersResult = mysqli_query($conn, 'SELECT * FROM borrowers ORDER BY borrowerFName');
$equipmentResult = mysqli_query($conn, 'SELECT * FROM equipment ORDER BY equipmentName');
$transactionsQuery = "
    SELECT b.borrowID, bo.borrowerFName, bo.borrowerLName, e.equipmentName, b.quantityBorrowed, b.borrowDate, b.returnDate, b.status, b.remarks
    FROM borrowing b
    JOIN borrowers bo ON b.borrowerID = bo.borrowerID
    JOIN equipment e ON b.equipmentID = e.equipmentID
    ORDER BY b.borrowID DESC
";
$transactionsResult = mysqli_query($conn, $transactionsQuery);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($pageTitle); ?></title>
    
    </head>
    <body>
        <nav class="app-nav">
            <strong>Equipment Borrowing System</strong>
            <a href="index.php">Dashboard</a>
            <a href="borrowers.php">Borrowers</a>
            <a href="equipment.php">Equipment</a>
            <a class="active" href="borrowing.php">Borrowing</a>
            <a href="reports.php">Reports</a>
        </nav>

        <div class="container">
            <div class="card">
                <h1 class="page-title">Borrowing Transactions</h1>
                <p>Create, edit, return, and remove borrowing records.</p>
            </div>

        <?php if ($message): ?>
            <div role="alert" class="notice <?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

            <div class="card">
                <h2><?php echo $editTransaction ? 'Edit Transaction' : 'Create Transaction'; ?></h2>
                <form method="post" class="entry-form">
                    <input type="hidden" name="borrowID" value="<?php echo $editTransaction ? (int) $editTransaction['borrowID'] : 0; ?>">
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="borrowerID">Borrower</label>
                                <select id="borrowerID" name="borrowerID" required>
                                    <option value="">Select borrower</option>
                                <?php while ($borrower = mysqli_fetch_assoc($borrowersResult)): ?>
                                    <option value="<?php echo (int) $borrower['borrowerID']; ?>" <?php echo ((int) $borrower['borrowerID'] === (int) $borrowerID) ? 'selected' : ''; ?>><?php echo htmlspecialchars($borrower['borrowerFName'] . ' ' . $borrower['borrowerLName']); ?></option>
                                <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="equipmentID">Equipment</label>
                                <select id="equipmentID" name="equipmentID" required>
                                    <option value="">Select equipment</option>
                                <?php mysqli_data_seek($equipmentResult, 0); while ($item = mysqli_fetch_assoc($equipmentResult)): ?>
                                    <option value="<?php echo (int) $item['equipmentID']; ?>" <?php echo ((int) $item['equipmentID'] === (int) $equipmentID) ? 'selected' : ''; ?>><?php echo htmlspecialchars($item['equipmentName'] . ' (' . $item['quantityAvailable'] . ' available)'); ?></option>
                                <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="quantityBorrowed">Quantity Borrowed</label>
                                <input id="quantityBorrowed" type="number" min="1" name="quantityBorrowed" value="<?php echo (int) $quantityBorrowed; ?>" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select id="status" name="status">
                                    <option value="Borrowed" <?php echo $status === 'Borrowed' ? 'selected' : ''; ?>>Borrowed</option>
                                    <option value="Returned" <?php echo $status === 'Returned' ? 'selected' : ''; ?>>Returned</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="borrowDate">Borrow Date</label>
                                <input id="borrowDate" type="date" name="borrowDate" value="<?php echo htmlspecialchars($borrowDate); ?>" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="returnDate">Return Date</label>
                                <input id="returnDate" type="date" name="returnDate" value="<?php echo htmlspecialchars($returnDate); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="remarks">Remarks</label>
                        <textarea id="remarks" name="remarks" rows="3"><?php echo htmlspecialchars($remarks); ?></textarea>
                    </div>
                    <div class="button-row form-actions">
                        <button type="submit">Save</button>
                    <?php if ($editTransaction): ?>
                        <a href="borrowing.php" class="button outline">Cancel</a>
                    <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Transaction List</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Borrower</th>
                            <th>Equipment</th>
                            <th>Qty</th>
                            <th>Borrow Date</th>
                            <th>Return Date</th>
                            <th>Status</th>
                            <th>Remarks</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (mysqli_num_rows($transactionsResult) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($transactionsResult)): ?>
                        <tr>
                            <td><?php echo (int) $row['borrowID']; ?></td>
                            <td><?php echo htmlspecialchars($row['borrowerFName'] . ' ' . $row['borrowerLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['equipmentName']); ?></td>
                            <td><?php echo (int) $row['quantityBorrowed']; ?></td>
                            <td><?php echo htmlspecialchars($row['borrowDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['returnDate'] ?? ''); ?></td>
                            <td><span class="badge <?php echo $row['status'] === 'Borrowed' ? 'badge-borrowed' : 'badge-returned'; ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['remarks'] ?? ''); ?></td>
                            <td>
                                <a href="borrowing.php?edit=<?php echo (int) $row['borrowID']; ?>" class="button small outline">Edit</a>
                                <a href="borrowing.php?return=<?php echo (int) $row['borrowID']; ?>" class="button small outline">Return</a>
                                <a href="borrowing.php?delete=<?php echo (int) $row['borrowID']; ?>" onclick="return confirm('Delete this transaction?');" class="button small danger-action">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="9">No transactions found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
