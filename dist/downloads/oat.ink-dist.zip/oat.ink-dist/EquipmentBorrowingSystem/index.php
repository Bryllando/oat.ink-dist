<?php
require_once 'db.php';

$pageTitle = 'Dashboard';

$borrowersResult = mysqli_query($conn, 'SELECT COUNT(*) AS totalBorrowers FROM borrowers');
$borrowersCount = mysqli_fetch_assoc($borrowersResult)['totalBorrowers'];

$equipmentResult = mysqli_query($conn, 'SELECT COUNT(*) AS totalEquipment FROM equipment');
$equipmentCount = mysqli_fetch_assoc($equipmentResult)['totalEquipment'];

$borrowedResult = mysqli_query($conn, "SELECT COUNT(*) AS totalBorrowed FROM borrowing WHERE status = 'Borrowed'");
$borrowedCount = mysqli_fetch_assoc($borrowedResult)['totalBorrowed'];

$summaryResult = mysqli_query($conn, 'SELECT COUNT(*) AS totalTransactions, SUM(quantityBorrowed) AS totalQuantity FROM borrowing');
$summary = mysqli_fetch_assoc($summaryResult);

$transactionsQuery = "
    SELECT b.borrowID, bo.borrowerFName, bo.borrowerLName, e.equipmentName, b.quantityBorrowed, b.status
    FROM borrowing b
    JOIN borrowers bo ON b.borrowerID = bo.borrowerID
    JOIN equipment e ON b.equipmentID = e.equipmentID
    ORDER BY b.borrowID DESC
    LIMIT 8
";
$transactionsResult = mysqli_query($conn, $transactionsQuery);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($pageTitle); ?></title>
    
    </head>
    <body>
        <nav class="app-nav">
            <strong>Equipment Borrowing System</strong>
            <a class="active" href="index.php">Dashboard</a>
            <a href="borrowers.php">Borrowers</a>
            <a href="equipment.php">Equipment</a>
            <a href="borrowing.php">Borrowing</a>
            <a href="reports.php">Reports</a>
        </nav>

        <div class="container">
            <div class="card">
                <h1 class="page-title">Dashboard</h1>
                <p>Manage borrower records, equipment inventory, borrowing transactions, and reports from one place.</p>
            </div>

            <div class="row">
                <div class="col">
                    <div class="stat-box">
                        <h3><?php echo $borrowersCount; ?></h3>
                        <p>Borrowers</p>
                    </div>
                </div>
                <div class="col">
                    <div class="stat-box">
                        <h3><?php echo $equipmentCount; ?></h3>
                        <p>Equipment Items</p>
                    </div>
                </div>
                <div class="col">
                    <div class="stat-box">
                        <h3><?php echo $borrowedCount; ?></h3>
                        <p>Currently Borrowed</p>
                    </div>
                </div>
                <div class="col">
                    <div class="stat-box">
                        <h3><?php echo $summary['totalTransactions']; ?></h3>
                        <p>Total Transactions</p>
                    </div>
                </div>
            </div>

            <div class="card">
                <h2>Recent Transactions</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Borrower</th>
                            <th>Equipment</th>
                            <th>Quantity</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (mysqli_num_rows($transactionsResult) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($transactionsResult)): ?>
                        <tr>
                            <td><?php echo (int) $row['borrowID']; ?></td>
                            <td><?php echo htmlspecialchars($row['borrowerFName'] . ' ' . $row['borrowerLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['equipmentName']); ?></td>
                            <td><?php echo (int) $row['quantityBorrowed']; ?></td>
                            <td><span class="badge <?php echo $row['status'] === 'Borrowed' ? 'badge-borrowed' : 'badge-returned'; ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5">No transactions yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
