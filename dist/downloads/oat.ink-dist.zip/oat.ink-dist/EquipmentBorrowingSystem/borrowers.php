<?php
require_once 'db.php';

$pageTitle = 'Borrowers';
$message = '';
$messageType = 'notice-success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $borrowerID = isset($_POST['borrowerID']) ? (int) $_POST['borrowerID'] : 0;
    $firstName = escape_input($conn, $_POST['borrowerFName'] ?? '');
    $lastName = escape_input($conn, $_POST['borrowerLName'] ?? '');
    $department = escape_input($conn, $_POST['department'] ?? '');
    $contactNo = escape_input($conn, $_POST['contactNo'] ?? '');

    if ($borrowerID > 0) {
        $sql = "UPDATE borrowers SET borrowerFName='$firstName', borrowerLName='$lastName', department='$department', contactNo='$contactNo' WHERE borrowerID=$borrowerID";
        $message = 'Borrower updated successfully.';
    } else {
        $sql = "INSERT INTO borrowers (borrowerFName, borrowerLName, department, contactNo) VALUES ('$firstName', '$lastName', '$department', '$contactNo')";
        $message = 'Borrower added successfully.';
    }

    if (mysqli_query($conn, $sql)) {
        redirect('borrowers.php');
    } else {
        $message = 'Unable to save borrower.';
        $messageType = 'notice-danger';
    }
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    if (mysqli_query($conn, "DELETE FROM borrowers WHERE borrowerID=$id")) {
        redirect('borrowers.php');
    }
}

$editBorrower = null;
if (isset($_GET['edit'])) {
    $id = (int) $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM borrowers WHERE borrowerID=$id");
    $editBorrower = mysqli_fetch_assoc($result);
}

$borrowersResult = mysqli_query($conn, 'SELECT * FROM borrowers ORDER BY borrowerID DESC');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($pageTitle); ?></title>
    
    </head>
    <body>
        <nav class="app-nav">
            <strong>Equipment Borrowing System</strong>
            <a href="index.php">Dashboard</a>
            <a class="active" href="borrowers.php">Borrowers</a>
            <a href="equipment.php">Equipment</a>
            <a href="borrowing.php">Borrowing</a>
            <a href="reports.php">Reports</a>
        </nav>

        <div class="container">
            <div class="card">
                <h1 class="page-title">Borrowers</h1>
                <p>Add, edit, and remove borrower records.</p>
            </div>

        <?php if ($message): ?>
            <div role="alert" class="notice <?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

            <div class="card">
                <h2><?php echo $editBorrower ? 'Edit Borrower' : 'Add Borrower'; ?></h2>
                <form method="post" class="entry-form">
                    <input type="hidden" name="borrowerID" value="<?php echo $editBorrower ? (int) $editBorrower['borrowerID'] : 0; ?>">
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="borrowerFName">First Name</label>
                                <input id="borrowerFName" name="borrowerFName" value="<?php echo htmlspecialchars($editBorrower['borrowerFName'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="borrowerLName">Last Name</label>
                                <input id="borrowerLName" name="borrowerLName" value="<?php echo htmlspecialchars($editBorrower['borrowerLName'] ?? ''); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="department">Department</label>
                                <input id="department" name="department" value="<?php echo htmlspecialchars($editBorrower['department'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="contactNo">Contact Number</label>
                                <input id="contactNo" name="contactNo" value="<?php echo htmlspecialchars($editBorrower['contactNo'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="button-row form-actions">
                        <button type="submit">Save</button>
                    <?php if ($editBorrower): ?>
                        <a href="borrowers.php" class="button outline">Cancel</a>
                    <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Borrower List</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Contact</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (mysqli_num_rows($borrowersResult) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($borrowersResult)): ?>
                        <tr>
                            <td><?php echo (int) $row['borrowerID']; ?></td>
                            <td><?php echo htmlspecialchars($row['borrowerFName'] . ' ' . $row['borrowerLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['department']); ?></td>
                            <td><?php echo htmlspecialchars($row['contactNo']); ?></td>
                            <td>
                                <a href="borrowers.php?edit=<?php echo (int) $row['borrowerID']; ?>" class="button small outline">Edit</a>
                                <a href="borrowers.php?delete=<?php echo (int) $row['borrowerID']; ?>" onclick="return confirm('Delete this borrower?');" class="button small danger-action">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5">No borrowers found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
