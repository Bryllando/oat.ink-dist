> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

# Equipment Borrowing System

This project is a simple offline Equipment Borrowing System built for XAMPP localhost.

## Features

- PHP procedural mysqli
- MySQL database: `equipment_borrowing`
- Oat UI (Local CSS & JS)
- Offline ready
- No OOP
- No MVC
- No AJAX
- No Composer
- Beginner-friendly CRUD
- Equipment Borrowing Transaction
- Reports using COUNT() and SUM()

---

## Setup

1. Copy the project to:

```text
C:\xampp\htdocs\EquipmentBorrowingSystem
```

2. Start Apache and MySQL in XAMPP.

3. Import the database:

```sql
mysql -u root < "C:/xampp/htdocs/EquipmentBorrowingSystem/equipment_borrowing.sql"
```

4. Open:

```text
http://localhost/EquipmentBorrowingSystem/index.php
```

---

# Database

Database name:

```text
equipment_borrowing
```

### borrowers

- borrowerID (PK)
- borrowerFName
- borrowerLName
- department
- contactNo

### equipment

- equipmentID (PK)
- equipmentName
- category
- quantityAvailable
- conditionStatus

### borrowing

- borrowID (PK)
- borrowerID (FK)
- equipmentID (FK)
- quantityBorrowed
- borrowDate
- returnDate
- status
- remarks

---

# Modules

## Dashboard

- index.php

## Borrowers

- Add
- Search
- Edit
- Delete
- View

## Equipment

- Add
- Search
- Edit
- Delete
- View

## Borrowing Transactions

- Create Borrow Transaction
- Select Borrower
- Select Equipment
- Input Quantity Borrowed
- Borrow Date
- Return Date
- Status
- Remarks
- Save Transaction
- Edit Transaction
- Delete Transaction
- View Transactions

## Reports

Filter by:

- Equipment Category
- Borrower
- Status
- Date From – Date To

Display:

- Borrower Name
- Equipment Name
- Category
- Quantity Borrowed
- Borrow Date
- Return Date
- Status

---

# Business Rules

- Quantity Borrowed must not exceed Quantity Available.
- When borrowing is saved, deduct Quantity Borrowed from Quantity Available.
- When equipment is returned, add the borrowed quantity back to Quantity Available.

---

# Aggregate Functions

```sql
COUNT(*) AS totalBorrowTransactions
```

```sql
COUNT(CASE WHEN status='Borrowed' THEN 1 END)
```

```sql
COUNT(CASE WHEN status='Returned' THEN 1 END)
```

```sql
SUM(quantityBorrowed)
```

---

# Project Structure

```text
EquipmentBorrowingSystem/

styles.css
db.php
index.php
borrowers.php
equipment.php
borrowing.php
reports.php
equipment_borrowing.sql
README.md
```

---

# Verification Checklist

- [x] Database Connection
- [x] Borrowers CRUD
- [x] Equipment CRUD
- [x] Borrowing Transaction
- [x] Equipment Availability Update
- [x] Reports
- [x] COUNT()
- [x] SUM()
- [x] Bootstrap Local
- [x] Offline Ready

---

# How to Use

1. Add Borrowers.
2. Add Equipment.
3. Create Borrowing Transactions.
4. Return Borrowed Equipment.
5. Generate Reports.

---

# IMPORTANT (Copilot Prompt)

This is a college skills test project.

Requirements:

- PHP procedural mysqli only
- XAMPP localhost
- MySQL
- Bootstrap local CSS & JS only
- Offline ready
- No internet required
- No frameworks
- No OOP
- No MVC
- No AJAX
- No Composer
- Beginner-friendly
- Easy to understand
- Prioritize passing the skills test rather than enterprise architecture

---

# UI Style Guide

## General

- Font: Arial, Helvetica, sans-serif
- Body: `#f4f6f9`
- Cards/Tables/Navbar: `#ffffff`
- Text: `#333333`
- Border: `1px solid #ddd`
- Border Radius: `4px`

## Colors

| Purpose | Color |
|---------|--------|
| Primary | `#007bff` |
| Success | `#28a745` |
| Warning | `#ffc107` |
| Danger | `#dc3545` |
| Gray | `#f1f1f1` |
| White | `#ffffff` |

## Buttons

| Class | Use |
|------|------|
| `btn btn-primary` | Save / Add |
| `btn btn-secondary` | Back / Cancel |
| `btn-action btn-edit` | Edit |
| `btn-action btn-delete` | Delete |

## Alerts

| Class | Use |
|------|------|
| `alert alert-success` | Success |
| `alert alert-warning` | Error / Not Found |

## Layout

- Fixed Navbar
- Page Title
- Card Container
- Bootstrap Forms
- Bootstrap Tables

## Rules

- PHP Procedural mysqli only
- XAMPP localhost
- Bootstrap Local CSS & JS
- Offline Ready
- Flat Folder Structure
- Simple CRUD
- Easy Navigation
- College Skills Test Ready