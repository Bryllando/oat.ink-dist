CREATE DATABASE IF NOT EXISTS equipment_borrowing;
USE equipment_borrowing;

CREATE TABLE IF NOT EXISTS borrowers (
    borrowerID INT AUTO_INCREMENT PRIMARY KEY,
    borrowerFName VARCHAR(100) NOT NULL,
    borrowerLName VARCHAR(100) NOT NULL,
    department VARCHAR(100),
    contactNo VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS equipment (
    equipmentID INT AUTO_INCREMENT PRIMARY KEY,
    equipmentName VARCHAR(150) NOT NULL,
    category VARCHAR(100) NOT NULL,
    quantityAvailable INT NOT NULL DEFAULT 0,
    conditionStatus VARCHAR(50) NOT NULL DEFAULT 'Good'
);

CREATE TABLE IF NOT EXISTS borrowing (
    borrowID INT AUTO_INCREMENT PRIMARY KEY,
    borrowerID INT NOT NULL,
    equipmentID INT NOT NULL,
    quantityBorrowed INT NOT NULL DEFAULT 1,
    borrowDate DATE NOT NULL,
    returnDate DATE NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Borrowed',
    remarks VARCHAR(255),
    FOREIGN KEY (borrowerID) REFERENCES borrowers(borrowerID),
    FOREIGN KEY (equipmentID) REFERENCES equipment(equipmentID)
);

INSERT INTO borrowers (borrowerFName, borrowerLName, department, contactNo) VALUES
('Maria', 'Cruz', 'ICT', '09171234567'),
('Jose', 'Ramos', 'Engineering', '09181234567'),
('Ana', 'Lopez', 'Library', '09191234567');

INSERT INTO equipment (equipmentName, category, quantityAvailable, conditionStatus) VALUES
('Laptop', 'IT', 5, 'Good'),
('Projector', 'AV', 3, 'Good'),
('Microscope', 'Science', 2, 'Needs Repair');

INSERT INTO borrowing (borrowerID, equipmentID, quantityBorrowed, borrowDate, returnDate, status, remarks) VALUES
(1, 1, 1, '2026-07-01', NULL, 'Borrowed', 'For class demo');
