<?php
require_once 'db.php';

$pageTitle = 'Reports';

$categoryFilter = $_GET['category'] ?? '';
$borrowerFilter = (int) ($_GET['borrower'] ?? 0);
$statusFilter = $_GET['status'] ?? '';
$dateFrom = $_GET['dateFrom'] ?? '';
$dateTo = $_GET['dateTo'] ?? '';

$where = ['1=1'];
if ($categoryFilter !== '') {
    $where[] = "e.category = '" . escape_input($conn, $categoryFilter) . "'";
}
if ($borrowerFilter > 0) {
    $where[] = 'b.borrowerID = ' . $borrowerFilter;
}
if ($statusFilter !== '') {
    $where[] = "b.status = '" . escape_input($conn, $statusFilter) . "'";
}
if ($dateFrom !== '') {
    $where[] = "b.borrowDate >= '" . escape_input($conn, $dateFrom) . "'";
}
if ($dateTo !== '') {
    $where[] = "b.returnDate <= '" . escape_input($conn, $dateTo) . "'";
}

$whereSql = implode(' AND ', $where);

$reportQuery = "
    SELECT b.borrowID, bo.borrowerFName, bo.borrowerLName, e.equipmentName, e.category, b.quantityBorrowed, b.borrowDate, b.returnDate, b.status
    FROM borrowing b
    JOIN borrowers bo ON b.borrowerID = bo.borrowerID
    JOIN equipment e ON b.equipmentID = e.equipmentID
    WHERE $whereSql
    ORDER BY b.borrowID DESC
";

$reportResult = mysqli_query($conn, $reportQuery);

$summaryQuery = "
    SELECT COUNT(*) AS totalTransactions, SUM(quantityBorrowed) AS totalBorrowedQty
    FROM borrowing b
    JOIN borrowers bo ON b.borrowerID = bo.borrowerID
    JOIN equipment e ON b.equipmentID = e.equipmentID
    WHERE $whereSql
";
$summaryResult = mysqli_fetch_assoc(mysqli_query($conn, $summaryQuery));

$borrowersResult = mysqli_query($conn, 'SELECT * FROM borrowers ORDER BY borrowerFName');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($pageTitle); ?></title>
    
    </head>
    <body>
        <nav class="app-nav">
            <strong>Equipment Borrowing System</strong>
            <a href="index.php">Dashboard</a>
            <a href="borrowers.php">Borrowers</a>
            <a href="equipment.php">Equipment</a>
            <a href="borrowing.php">Borrowing</a>
            <a class="active" href="reports.php">Reports</a>
        </nav>

        <div class="container">
            <div class="card">
                <h1 class="page-title">Reports</h1>
                <p>Filter borrowing activity and review summary totals.</p>
            </div>

            <div class="card">
                <h2>Filter Reports</h2>
                <form method="get" class="filter-form">
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="category">Category</label>
                                <input id="category" name="category" value="<?php echo htmlspecialchars($categoryFilter); ?>">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="borrower">Borrower</label>
                                <select id="borrower" name="borrower">
                                    <option value="0">All borrowers</option>
                                <?php while ($borrower = mysqli_fetch_assoc($borrowersResult)): ?>
                                    <option value="<?php echo (int) $borrower['borrowerID']; ?>" <?php echo $borrowerFilter === (int) $borrower['borrowerID'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($borrower['borrowerFName'] . ' ' . $borrower['borrowerLName']); ?></option>
                                <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select id="status" name="status">
                                    <option value="">All statuses</option>
                                    <option value="Borrowed" <?php echo $statusFilter === 'Borrowed' ? 'selected' : ''; ?>>Borrowed</option>
                                    <option value="Returned" <?php echo $statusFilter === 'Returned' ? 'selected' : ''; ?>>Returned</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="dateFrom">Date From</label>
                                <input id="dateFrom" type="date" name="dateFrom" value="<?php echo htmlspecialchars($dateFrom); ?>">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="dateTo">Date To</label>
                                <input id="dateTo" type="date" name="dateTo" value="<?php echo htmlspecialchars($dateTo); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="button-row">
                        <button type="submit">Show Report</button>
                        <a href="reports.php" class="button outline">Reset</a>
                    </div>
                </form>
            </div>

            <div class="row">
                <div class="col">
                    <div class="stat-box">
                        <h3><?php echo (int) $summaryResult['totalTransactions']; ?></h3>
                        <p>Matching Transactions</p>
                    </div>
                </div>
                <div class="col">
                    <div class="stat-box">
                        <h3><?php echo (int) $summaryResult['totalBorrowedQty']; ?></h3>
                        <p>Total Borrowed Quantity</p>
                    </div>
                </div>
            </div>

            <div class="card">
                <h2>Report Results</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Borrower</th>
                            <th>Equipment</th>
                            <th>Category</th>
                            <th>Qty</th>
                            <th>Borrow Date</th>
                            <th>Return Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (mysqli_num_rows($reportResult) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($reportResult)): ?>
                        <tr>
                            <td><?php echo (int) $row['borrowID']; ?></td>
                            <td><?php echo htmlspecialchars($row['borrowerFName'] . ' ' . $row['borrowerLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['equipmentName']); ?></td>
                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                            <td><?php echo (int) $row['quantityBorrowed']; ?></td>
                            <td><?php echo htmlspecialchars($row['borrowDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['returnDate'] ?? ''); ?></td>
                            <td><span class="badge <?php echo $row['status'] === 'Borrowed' ? 'badge-borrowed' : 'badge-returned'; ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8">No matching transactions found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
