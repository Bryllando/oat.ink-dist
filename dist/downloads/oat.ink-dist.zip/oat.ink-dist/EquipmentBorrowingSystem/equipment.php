<?php
require_once 'db.php';

$pageTitle = 'Equipment';
$message = '';
$messageType = 'notice-success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipmentID = isset($_POST['equipmentID']) ? (int) $_POST['equipmentID'] : 0;
    $equipmentName = escape_input($conn, $_POST['equipmentName'] ?? '');
    $category = escape_input($conn, $_POST['category'] ?? '');
    $quantityAvailable = (int) ($_POST['quantityAvailable'] ?? 0);
    $conditionStatus = escape_input($conn, $_POST['conditionStatus'] ?? 'Good');

    if ($equipmentID > 0) {
        $sql = "UPDATE equipment SET equipmentName='$equipmentName', category='$category', quantityAvailable=$quantityAvailable, conditionStatus='$conditionStatus' WHERE equipmentID=$equipmentID";
        $message = 'Equipment updated successfully.';
    } else {
        $sql = "INSERT INTO equipment (equipmentName, category, quantityAvailable, conditionStatus) VALUES ('$equipmentName', '$category', $quantityAvailable, '$conditionStatus')";
        $message = 'Equipment added successfully.';
    }

    if (mysqli_query($conn, $sql)) {
        redirect('equipment.php');
    } else {
        $message = 'Unable to save equipment.';
        $messageType = 'notice-danger';
    }
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    if (mysqli_query($conn, "DELETE FROM equipment WHERE equipmentID=$id")) {
        redirect('equipment.php');
    }
}

$editEquipment = null;
if (isset($_GET['edit'])) {
    $id = (int) $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM equipment WHERE equipmentID=$id");
    $editEquipment = mysqli_fetch_assoc($result);
}

$equipmentResult = mysqli_query($conn, 'SELECT * FROM equipment ORDER BY equipmentID DESC');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($pageTitle); ?></title>
    
    </head>
    <body>
        <nav class="app-nav">
            <strong>Equipment Borrowing System</strong>
            <a href="index.php">Dashboard</a>
            <a href="borrowers.php">Borrowers</a>
            <a class="active" href="equipment.php">Equipment</a>
            <a href="borrowing.php">Borrowing</a>
            <a href="reports.php">Reports</a>
        </nav>

        <div class="container">
            <div class="card">
                <h1 class="page-title">Equipment</h1>
                <p>Add, edit, and remove equipment inventory.</p>
            </div>

        <?php if ($message): ?>
            <div role="alert" class="notice <?php echo $messageType; ?>"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

            <div class="card">
                <h2><?php echo $editEquipment ? 'Edit Equipment' : 'Add Equipment'; ?></h2>
                <form method="post" class="entry-form">
                    <input type="hidden" name="equipmentID" value="<?php echo $editEquipment ? (int) $editEquipment['equipmentID'] : 0; ?>">
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="equipmentName">Equipment Name</label>
                                <input id="equipmentName" name="equipmentName" value="<?php echo htmlspecialchars($editEquipment['equipmentName'] ?? ''); ?>" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="category">Category</label>
                                <input id="category" name="category" value="<?php echo htmlspecialchars($editEquipment['category'] ?? ''); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="quantityAvailable">Quantity Available</label>
                                <input id="quantityAvailable" type="number" min="0" name="quantityAvailable" value="<?php echo (int) ($editEquipment['quantityAvailable'] ?? 0); ?>" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="conditionStatus">Condition</label>
                                <select id="conditionStatus" name="conditionStatus">
                                    <option value="Good" <?php echo (($editEquipment['conditionStatus'] ?? 'Good') === 'Good') ? 'selected' : ''; ?>>Good</option>
                                    <option value="Needs Repair" <?php echo (($editEquipment['conditionStatus'] ?? 'Good') === 'Needs Repair') ? 'selected' : ''; ?>>Needs Repair</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="button-row form-actions">
                        <button type="submit">Save</button>
                    <?php if ($editEquipment): ?>
                        <a href="equipment.php" class="button outline">Cancel</a>
                    <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Equipment List</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Available</th>
                            <th>Condition</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (mysqli_num_rows($equipmentResult) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($equipmentResult)): ?>
                        <tr>
                            <td><?php echo (int) $row['equipmentID']; ?></td>
                            <td><?php echo htmlspecialchars($row['equipmentName']); ?></td>
                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                            <td><?php echo (int) $row['quantityAvailable']; ?></td>
                            <td><?php echo htmlspecialchars($row['conditionStatus']); ?></td>
                            <td>
                                <a href="equipment.php?edit=<?php echo (int) $row['equipmentID']; ?>" class="button small outline">Edit</a>
                                <a href="equipment.php?delete=<?php echo (int) $row['equipmentID']; ?>" onclick="return confirm('Delete this equipment?');" class="button small danger-action">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6">No equipment found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
