<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `donorID`, `donorName` FROM `donors` ORDER BY `donorName` ASC");
$e2List = $conn->query("SELECT `typeID`, `typeName` FROM `blood_types` ORDER BY `typeName` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['donorID'] ?? 0);
    $id2 = (int)($_POST['typeID'] ?? 0);
    $donationDate = is_string($_POST['donationDate'] ?? null) ? trim($_POST['donationDate']) : '';
    $volumeMl = is_string($_POST['volumeMl'] ?? null) ? trim($_POST['volumeMl']) : '';
    $hemoglobinLevel = is_string($_POST['hemoglobinLevel'] ?? null) ? trim($_POST['hemoglobinLevel']) : '';
    $attendingPhlebotomist = is_string($_POST['attendingPhlebotomist'] ?? null) ? trim($_POST['attendingPhlebotomist']) : '';
    $screeningStatus = is_string($_POST['screeningStatus'] ?? null) ? trim($_POST['screeningStatus']) : '';

    if ($donationDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $donationDate) ||
        date('Y-m-d', strtotime($donationDate) ?: 0) !== $donationDate ||
        $volumeMl === '' ||
        !is_numeric($volumeMl) ||
        !is_finite((float)$volumeMl) ||
        (float)$volumeMl < 0 ||
        filter_var($volumeMl, FILTER_VALIDATE_INT) === false ||
        $hemoglobinLevel === '' ||
        $attendingPhlebotomist === '' ||
        $screeningStatus === '' ||
        $id1 <= 0 ||
        $id2 <= 0) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `blood_donations` (`donorID`, `typeID`, `donationDate`, `volumeMl`, `hemoglobinLevel`, `attendingPhlebotomist`, `screeningStatus`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($donationDate) . "', '" . $conn->real_escape_string($volumeMl) . "', '" . $conn->real_escape_string($hemoglobinLevel) . "', '" . $conn->real_escape_string($attendingPhlebotomist) . "', '" . $conn->real_escape_string($screeningStatus) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Donation Log - Red Cross Blood Bank & Donation Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Donation Log</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="donorID" class="weight-semibold">Select Donor</label>
                        <select id="donorID" name="donorID" class="" required>
                            <option value="">-- Choose Donor --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['donorID'] ?>" <?= ((int)($_POST['donorID'] ?? 0) === (int)$r['donorID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['donorName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="typeID" class="weight-semibold">Select Blood Category</label>
                        <select id="typeID" name="typeID" class="" required>
                            <option value="">-- Choose Blood Category --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['typeID'] ?>" <?= ((int)($_POST['typeID'] ?? 0) === (int)$r['typeID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['typeName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="donationDate" class="weight-semibold">Date of Donation</label>
                <input type="date" id="donationDate" name="donationDate" class=""  required value="<?= htmlspecialchars($donationDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="volumeMl" class="weight-semibold">Volume Collected (mL)</label>
                <input type="number" id="volumeMl" name="volumeMl" min="0" class="" step="1" required value="<?= htmlspecialchars($volumeMl ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="hemoglobinLevel" class="weight-semibold">Hemoglobin g/dL</label>
                <input type="text" id="hemoglobinLevel" name="hemoglobinLevel" class=""  required value="<?= htmlspecialchars($hemoglobinLevel ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="attendingPhlebotomist" class="weight-semibold">Medical Technologist</label>
                <input type="text" id="attendingPhlebotomist" name="attendingPhlebotomist" class=""  required value="<?= htmlspecialchars($attendingPhlebotomist ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="screeningStatus" class="weight-semibold">Screening Status</label>
                <input type="text" id="screeningStatus" name="screeningStatus" class=""  required value="<?= htmlspecialchars($screeningStatus ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Donation Log</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
