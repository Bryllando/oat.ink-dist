CREATE DATABASE IF NOT EXISTS `blood_bank_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `blood_bank_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `donors` (
  `donorID` INT AUTO_INCREMENT PRIMARY KEY,
  `donorName` VARCHAR(100) NOT NULL,
  `birthDate` DATE NOT NULL,
  `gender` VARCHAR(20) NOT NULL,
  `bloodGroup` VARCHAR(20) NOT NULL,
  `contactNumber` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `blood_types` (
  `typeID` INT AUTO_INCREMENT PRIMARY KEY,
  `typeName` VARCHAR(100) NOT NULL,
  `rhFactor` VARCHAR(20) NOT NULL,
  `storageTemp` VARCHAR(50) NOT NULL,
  `shelfLifeDays` INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `blood_donations` (
  `donationID` INT AUTO_INCREMENT PRIMARY KEY,
  `donorID` INT NOT NULL,
  `typeID` INT NOT NULL,
  `donationDate` DATE NOT NULL,
  `volumeMl` INT NOT NULL,
  `hemoglobinLevel` VARCHAR(50) NOT NULL,
  `attendingPhlebotomist` VARCHAR(100) NOT NULL,
  `screeningStatus` VARCHAR(50) DEFAULT 'Approved',
  FOREIGN KEY (`donorID`) REFERENCES `donors`(`donorID`) ON DELETE CASCADE,
  FOREIGN KEY (`typeID`) REFERENCES `blood_types`(`typeID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `donors` (`donorName`, `birthDate`, `gender`, `bloodGroup`, `contactNumber`) VALUES
('SPO2 Christopher Bato', '1989-05-16', 'Male', 'O+', '09172223344'),
('Dr. Katrina Ocampo', '1994-11-20', 'Female', 'A+', '09183334455'),
('Mark Jayson Cimafranca', '2001-03-08', 'Male', 'AB+', '09224445566');

INSERT INTO `blood_types` (`typeName`, `rhFactor`, `storageTemp`, `shelfLifeDays`) VALUES
('Whole Blood Type O Positive', 'Positive', '2°C to 6°C', 35),
('Packed Red Blood Cells A Positive', 'Positive', '2°C to 6°C', 42),
('Fresh Frozen Plasma AB Positive', 'Positive', '-18°C or below', 365);

INSERT INTO `blood_donations` (`donorID`, `typeID`, `donationDate`, `volumeMl`, `hemoglobinLevel`, `attendingPhlebotomist`, `screeningStatus`) VALUES
(1, 1, '2026-10-15', 450, '14.5 g/dL', 'MedTech Sarah Lim', 'Approved'),
(2, 2, '2026-10-22', 450, '13.2 g/dL', 'MedTech Sarah Lim', 'Approved'),
(3, 3, '2026-11-01', 500, '15.1 g/dL', 'MedTech Ryan Go', 'Approved');

SET FOREIGN_KEY_CHECKS=1;
