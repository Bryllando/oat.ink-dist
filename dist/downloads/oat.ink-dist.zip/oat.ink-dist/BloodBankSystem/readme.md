# Red Cross Blood Bank & Donation Management System

An academic, student-level PHP & MySQL web application implementing a complete 4-module architecture:
1. **Blood Donors Module**: Master Entity 1 management (CRUD).
2. **Blood Stocks & Specs Module**: Master Entity 2 management (CRUD).
3. **Donation Logs Module**: Relational transaction linking with foreign key constraints.
4. **Monitoring Report Module**: Real-time analytical dashboard with dynamic filters and aggregate functions (`COUNT`, `SUM`).

## Database Configuration
- **Database Name**: `blood_bank_db`
- **Database Connection**: `database.php`
- **Initial Schema & Seed Data**: `database.sql`


## Local Oat copy

Uses offline `assets` from Skilltest. Copy the complete folder into XAMPP htdocs and start Apache/MySQL. The first visit imports `database.sql` only when the database is empty. Set credentials in `database.php` when needed. Renamed copies share the same database. Master records support add/edit/delete; transactions support add/list/delete and filtered monitoring. Amounts are entered manually. Keep this academic practice app local.
