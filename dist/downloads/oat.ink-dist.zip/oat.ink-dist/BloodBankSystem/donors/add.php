<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donorName = is_string($_POST['donorName'] ?? null) ? trim($_POST['donorName']) : '';
    $birthDate = is_string($_POST['birthDate'] ?? null) ? trim($_POST['birthDate']) : '';
    $gender = is_string($_POST['gender'] ?? null) ? trim($_POST['gender']) : '';
    $bloodGroup = is_string($_POST['bloodGroup'] ?? null) ? trim($_POST['bloodGroup']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($donorName === '' ||
        $birthDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $birthDate) ||
        date('Y-m-d', strtotime($birthDate) ?: 0) !== $birthDate ||
        $gender === '' ||
        $bloodGroup === '' ||
        $contactNumber === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `donors` (`donorName`, `birthDate`, `gender`, `bloodGroup`, `contactNumber`) VALUES ('" . $conn->real_escape_string($donorName) . "', '" . $conn->real_escape_string($birthDate) . "', '" . $conn->real_escape_string($gender) . "', '" . $conn->real_escape_string($bloodGroup) . "', '" . $conn->real_escape_string($contactNumber) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Donor - Red Cross Blood Bank & Donation Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Add New Donor</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="donorName" class="weight-semibold">Donor Full Name</label>
                <input type="text" id="donorName" name="donorName" class=""  required value="<?= htmlspecialchars($donorName ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="birthDate" class="weight-semibold">Birth Date</label>
                <input type="date" id="birthDate" name="birthDate" class=""  required value="<?= htmlspecialchars($birthDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="gender" class="weight-semibold">Gender</label>
                <input type="text" id="gender" name="gender" class=""  required value="<?= htmlspecialchars($gender ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="bloodGroup" class="weight-semibold">Blood Group</label>
                <input type="text" id="bloodGroup" name="bloodGroup" class=""  required value="<?= htmlspecialchars($bloodGroup ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactNumber" class="weight-semibold">Phone Number</label>
                <input type="text" id="contactNumber" name="contactNumber" class=""  required value="<?= htmlspecialchars($contactNumber ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Save Donor</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
