<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `blood_types` WHERE `typeID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $typeName = is_string($_POST['typeName'] ?? null) ? trim($_POST['typeName']) : '';
    $rhFactor = is_string($_POST['rhFactor'] ?? null) ? trim($_POST['rhFactor']) : '';
    $storageTemp = is_string($_POST['storageTemp'] ?? null) ? trim($_POST['storageTemp']) : '';
    $shelfLifeDays = is_string($_POST['shelfLifeDays'] ?? null) ? trim($_POST['shelfLifeDays']) : '';

    if ($typeName === '' ||
        $rhFactor === '' ||
        $storageTemp === '' ||
        $shelfLifeDays === '' ||
        !is_numeric($shelfLifeDays) ||
        !is_finite((float)$shelfLifeDays) ||
        (float)$shelfLifeDays < 0 ||
        filter_var($shelfLifeDays, FILTER_VALIDATE_INT) === false) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `blood_types` SET `typeName` = '" . $conn->real_escape_string($typeName) . "', `rhFactor` = '" . $conn->real_escape_string($rhFactor) . "', `storageTemp` = '" . $conn->real_escape_string($storageTemp) . "', `shelfLifeDays` = '" . $conn->real_escape_string($shelfLifeDays) . "' WHERE `typeID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Blood Category - Red Cross Blood Bank & Donation Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Blood Category</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="typeName" class="weight-semibold">Blood Classification</label>
                <input type="text" id="typeName" name="typeName" class=""  required value="<?= htmlspecialchars($record['typeName'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="rhFactor" class="weight-semibold">Rh Factor</label>
                <input type="text" id="rhFactor" name="rhFactor" class=""  required value="<?= htmlspecialchars($record['rhFactor'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="storageTemp" class="weight-semibold">Storage Temp</label>
                <input type="text" id="storageTemp" name="storageTemp" class=""  required value="<?= htmlspecialchars($record['storageTemp'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="shelfLifeDays" class="weight-semibold">Shelf Life (Days)</label>
                <input type="number" id="shelfLifeDays" name="shelfLifeDays" min="0" class="" step="1" required value="<?= htmlspecialchars($record['shelfLifeDays'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Blood Category</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
