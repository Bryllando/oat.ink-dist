<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Red Cross Blood Bank & Donation Management System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'donors') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>donors/index.php">Blood Donors</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'blood_types') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>blood_types/index.php">Blood Stocks & Specs</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'blood_donations') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>blood_donations/index.php">Donation Logs</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
