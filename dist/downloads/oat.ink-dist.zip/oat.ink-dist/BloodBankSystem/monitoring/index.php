<?php
require_once __DIR__ . '/../database.php';

$filterVal = is_string($_GET['filter'] ?? null) ? trim($_GET['filter']) : '';

$where = "1=1";
if ($filterVal !== '') {
    $esc = $conn->real_escape_string($filterVal);
    $where .= " AND t.typeID = '$esc'";
}

// Total Count aggregate
$totalCount = $conn->query("SELECT COUNT(*) AS total FROM `blood_donations` t WHERE $where")->fetch_assoc()['total'] ?? 0;

// Total Sum aggregate
$totalAmount = $conn->query("SELECT IFNULL(SUM(volumeMl), 0) AS total FROM `blood_donations` t WHERE $where")->fetch_assoc()['total'] ?? 0;

// Average / Metric computation
$avgValue = ($totalCount > 0) ? ($totalAmount / $totalCount) : 0;

// Filter dropdown options
$filterOptions = $conn->query("SELECT `typeID`, `typeName` FROM `blood_types` ORDER BY `typeName` ASC");

// Transactions query
$sql = "SELECT t.*, e1.donorName AS e1_title, e2.typeName AS e2_title 
        FROM `blood_donations` t
        JOIN `donors` e1 ON t.donorID = e1.donorID
        JOIN `blood_types` e2 ON t.typeID = e2.typeID
        WHERE $where
        ORDER BY t.donationID DESC";
$records = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoring & Reports - Red Cross Blood Bank & Donation Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">System Monitoring & Analytical Summary</h3>
        </div>

        <div class="card p-3 mb-4">
            <form method="GET" class="row g-2 items-center">
                <div class="col-9">
                    <label for="report-filter">Filter records</label><select id="report-filter" name="filter" class="">
                        <option value="">-- All Blood Stocks & Specs (Entire System) --</option>
                        <?php while ($opt = $filterOptions->fetch_assoc()): ?>
                            <option value="<?= $opt['typeID'] ?>" <?= ($filterVal === (string)$opt['typeID']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($opt['typeName']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-3 flex gap-2">
                    <button type="submit" class="button outline w-100">Filter Records</button>
                    <?php if ($filterVal !== ''): ?>
                        <a href="index.php" class="button outline">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-4">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Total Transaction Count</span>
                    <h2 class="weight-bold text-primary mb-0"><?= $totalCount ?></h2>
                </div>
            </div>
            <div class="col-4">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Total Blood Volume Collected (mL)</span>
                    <h2 class="weight-bold text-success mb-0">₱<?= number_format((float)$totalAmount, 2) ?></h2>
                </div>
            </div>
            <div class="col-4">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Average per Transaction</span>
                    <h2 class="weight-bold mb-0">₱<?= number_format((float)$avgValue, 2) ?></h2>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header py-3">
                <h5 class="weight-bold mb-0">Detailed Transaction Ledger</h5>
            </div>
            <div class="table-responsive">
                <table class="mb-0">
                    <thead class="">
                        <tr>
                            <th>#</th>
                            <th>Donor</th>
                            <th>Blood Category</th>
                            <th>Date of Donation</th>
<th>Volume Collected (mL)</th>
<th>Hemoglobin g/dL</th>
<th>Medical Technologist</th>
<th>Screening Status</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['donationID'] ?></td>
                                    <td class="weight-bold"><?= htmlspecialchars($r['e1_title']) ?></td>
                                    <td><?= htmlspecialchars($r['e2_title']) ?></td>
                                    <td><?= htmlspecialchars($r['donationDate']) ?></td>
<td><?= htmlspecialchars($r['volumeMl']) ?></td>
<td><?= htmlspecialchars($r['hemoglobinLevel']) ?></td>
<td><?= htmlspecialchars($r['attendingPhlebotomist']) ?></td>
<td><?= htmlspecialchars($r['screeningStatus']) ?></td>

                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="align-center py-4 text-light">No records found matching the specified filter criteria.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
</body>
</html>
