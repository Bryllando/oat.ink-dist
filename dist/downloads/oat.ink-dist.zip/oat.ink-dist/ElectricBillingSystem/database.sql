CREATE DATABASE IF NOT EXISTS `electric_billing_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `electric_billing_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `accounts` (
  `accountID` INT AUTO_INCREMENT PRIMARY KEY,
  `accountNumber` VARCHAR(50) NOT NULL,
  `customerName` VARCHAR(100) NOT NULL,
  `meterSerial` VARCHAR(50) NOT NULL,
  `serviceAddress` VARCHAR(150) NOT NULL,
  `contactNumber` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `tariff_classes` (
  `tariffID` INT AUTO_INCREMENT PRIMARY KEY,
  `className` VARCHAR(100) NOT NULL,
  `generationRate` DECIMAL(10,2) NOT NULL,
  `distributionRate` DECIMAL(10,2) NOT NULL,
  `systemLossCharge` DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `electric_bills` (
  `billID` INT AUTO_INCREMENT PRIMARY KEY,
  `accountID` INT NOT NULL,
  `tariffID` INT NOT NULL,
  `billDate` DATE NOT NULL,
  `kwhConsumed` DECIMAL(10,2) NOT NULL,
  `totalDue` DECIMAL(10,2) NOT NULL,
  `dueDate` DATE NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Unpaid',
  FOREIGN KEY (`accountID`) REFERENCES `accounts`(`accountID`) ON DELETE CASCADE,
  FOREIGN KEY (`tariffID`) REFERENCES `tariff_classes`(`tariffID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `accounts` (`accountNumber`, `customerName`, `meterSerial`, `serviceAddress`, `contactNumber`) VALUES
('ELEC-8801', 'Benedicto Tan', 'SN-44120', 'Sitio Laray, Talisay City', '09175556677'),
('ELEC-8802', 'Esperanza Lim', 'SN-44121', 'Banilad, Cebu City', '09186667788'),
('ELEC-8803', 'Rodolfo Suico', 'SN-44122', 'Basak, Mandaue City', '09227778899');

INSERT INTO `tariff_classes` (`className`, `generationRate`, `distributionRate`, `systemLossCharge`) VALUES
('Residential Lifeline', 6.5, 2.2, 0.85),
('Commercial General', 8.2, 3.1, 1.15),
('Industrial High Voltage', 7.8, 2.6, 0.95);

INSERT INTO `electric_bills` (`accountID`, `tariffID`, `billDate`, `kwhConsumed`, `totalDue`, `dueDate`, `status`) VALUES
(1, 1, '2026-10-25', 145.0, 1384.75, '2026-11-10', 'Paid'),
(2, 2, '2026-10-26', 320.0, 3984.0, '2026-11-11', 'Unpaid'),
(3, 3, '2026-10-27', 185.0, 1766.75, '2026-11-12', 'Paid');

SET FOREIGN_KEY_CHECKS=1;
