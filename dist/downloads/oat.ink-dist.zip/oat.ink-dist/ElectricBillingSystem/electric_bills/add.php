<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `accountID`, `customerName` FROM `accounts` ORDER BY `customerName` ASC");
$e2List = $conn->query("SELECT `tariffID`, `className` FROM `tariff_classes` ORDER BY `className` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['accountID'] ?? 0);
    $id2 = (int)($_POST['tariffID'] ?? 0);
    $billDate = is_string($_POST['billDate'] ?? null) ? trim($_POST['billDate']) : '';
    $kwhConsumed = is_string($_POST['kwhConsumed'] ?? null) ? trim($_POST['kwhConsumed']) : '';
    $totalDue = is_string($_POST['totalDue'] ?? null) ? trim($_POST['totalDue']) : '';
    $dueDate = is_string($_POST['dueDate'] ?? null) ? trim($_POST['dueDate']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($billDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $billDate) ||
        date('Y-m-d', strtotime($billDate) ?: 0) !== $billDate ||
        $kwhConsumed === '' ||
        !is_numeric($kwhConsumed) ||
        !is_finite((float)$kwhConsumed) ||
        (float)$kwhConsumed < 0 ||
        $totalDue === '' ||
        !is_numeric($totalDue) ||
        !is_finite((float)$totalDue) ||
        (float)$totalDue < 0 ||
        $dueDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $dueDate) ||
        date('Y-m-d', strtotime($dueDate) ?: 0) !== $dueDate ||
        $status === '' ||
        $id1 <= 0 ||
        $id2 <= 0 ||
        $dueDate < $billDate) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `electric_bills` (`accountID`, `tariffID`, `billDate`, `kwhConsumed`, `totalDue`, `dueDate`, `status`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($billDate) . "', '" . $conn->real_escape_string($kwhConsumed) . "', '" . $conn->real_escape_string($totalDue) . "', '" . $conn->real_escape_string($dueDate) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Electric Invoice - Electric Power & Utility Billing System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Electric Invoice</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="accountID" class="weight-semibold">Select Account</label>
                        <select id="accountID" name="accountID" class="" required>
                            <option value="">-- Choose Account --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['accountID'] ?>" <?= ((int)($_POST['accountID'] ?? 0) === (int)$r['accountID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['customerName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="tariffID" class="weight-semibold">Select Tariff Class</label>
                        <select id="tariffID" name="tariffID" class="" required>
                            <option value="">-- Choose Tariff Class --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['tariffID'] ?>" <?= ((int)($_POST['tariffID'] ?? 0) === (int)$r['tariffID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['className']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="billDate" class="weight-semibold">Bill Date</label>
                <input type="date" id="billDate" name="billDate" class=""  required value="<?= htmlspecialchars($billDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="kwhConsumed" class="weight-semibold">kWh Consumed</label>
                <input type="number" id="kwhConsumed" name="kwhConsumed" min="0" class="" step="0.01" required value="<?= htmlspecialchars($kwhConsumed ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="totalDue" class="weight-semibold">Total Amount Due</label>
                <input type="number" id="totalDue" name="totalDue" min="0" class="" step="0.01" required value="<?= htmlspecialchars($totalDue ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="dueDate" class="weight-semibold">Due Date</label>
                <input type="date" id="dueDate" name="dueDate" class=""  required value="<?= htmlspecialchars($dueDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="status" class="weight-semibold">Status</label>
                <input type="text" id="status" name="status" class=""  required value="<?= htmlspecialchars($status ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Electric Invoice</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
