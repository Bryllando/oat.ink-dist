<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Electric Power & Utility Billing System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'accounts') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>accounts/index.php">Consumer Accounts</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'tariff_classes') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>tariff_classes/index.php">Tariff Classes</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'electric_bills') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>electric_bills/index.php">Electric Invoices</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
