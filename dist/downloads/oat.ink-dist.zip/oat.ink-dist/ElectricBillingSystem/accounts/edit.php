<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `accounts` WHERE `accountID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accountNumber = is_string($_POST['accountNumber'] ?? null) ? trim($_POST['accountNumber']) : '';
    $customerName = is_string($_POST['customerName'] ?? null) ? trim($_POST['customerName']) : '';
    $meterSerial = is_string($_POST['meterSerial'] ?? null) ? trim($_POST['meterSerial']) : '';
    $serviceAddress = is_string($_POST['serviceAddress'] ?? null) ? trim($_POST['serviceAddress']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';

    if ($accountNumber === '' ||
        $customerName === '' ||
        $meterSerial === '' ||
        $serviceAddress === '' ||
        $contactNumber === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `accounts` SET `accountNumber` = '" . $conn->real_escape_string($accountNumber) . "', `customerName` = '" . $conn->real_escape_string($customerName) . "', `meterSerial` = '" . $conn->real_escape_string($meterSerial) . "', `serviceAddress` = '" . $conn->real_escape_string($serviceAddress) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "' WHERE `accountID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Account - Electric Power & Utility Billing System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Account</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="accountNumber" class="weight-semibold">Account Number</label>
                <input type="text" id="accountNumber" name="accountNumber" class=""  required value="<?= htmlspecialchars($record['accountNumber'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="customerName" class="weight-semibold">Customer Name</label>
                <input type="text" id="customerName" name="customerName" class=""  required value="<?= htmlspecialchars($record['customerName'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="meterSerial" class="weight-semibold">Meter Serial</label>
                <input type="text" id="meterSerial" name="meterSerial" class=""  required value="<?= htmlspecialchars($record['meterSerial'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="serviceAddress" class="weight-semibold">Address</label>
                <input type="text" id="serviceAddress" name="serviceAddress" class=""  required value="<?= htmlspecialchars($record['serviceAddress'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactNumber" class="weight-semibold">Contact Number</label>
                <input type="text" id="contactNumber" name="contactNumber" class=""  required value="<?= htmlspecialchars($record['contactNumber'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Account</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
