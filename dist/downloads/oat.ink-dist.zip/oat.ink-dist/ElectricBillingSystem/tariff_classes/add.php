<?php
require_once __DIR__ . '/../database.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $className = is_string($_POST['className'] ?? null) ? trim($_POST['className']) : '';
    $generationRate = is_string($_POST['generationRate'] ?? null) ? trim($_POST['generationRate']) : '';
    $distributionRate = is_string($_POST['distributionRate'] ?? null) ? trim($_POST['distributionRate']) : '';
    $systemLossCharge = is_string($_POST['systemLossCharge'] ?? null) ? trim($_POST['systemLossCharge']) : '';

    if ($className === '' ||
        $generationRate === '' ||
        !is_numeric($generationRate) ||
        !is_finite((float)$generationRate) ||
        (float)$generationRate < 0 ||
        $distributionRate === '' ||
        !is_numeric($distributionRate) ||
        !is_finite((float)$distributionRate) ||
        (float)$distributionRate < 0 ||
        $systemLossCharge === '' ||
        !is_numeric($systemLossCharge) ||
        !is_finite((float)$systemLossCharge) ||
        (float)$systemLossCharge < 0) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `tariff_classes` (`className`, `generationRate`, `distributionRate`, `systemLossCharge`) VALUES ('" . $conn->real_escape_string($className) . "', '" . $conn->real_escape_string($generationRate) . "', '" . $conn->real_escape_string($distributionRate) . "', '" . $conn->real_escape_string($systemLossCharge) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to save record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Tariff Class - Electric Power & Utility Billing System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Add New Tariff Class</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="className" class="weight-semibold">Class Name</label>
                <input type="text" id="className" name="className" class=""  required value="<?= htmlspecialchars($className ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="generationRate" class="weight-semibold">Gen Rate / kWh</label>
                <input type="number" id="generationRate" name="generationRate" min="0" class="" step="0.01" required value="<?= htmlspecialchars($generationRate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="distributionRate" class="weight-semibold">Dist Rate / kWh</label>
                <input type="number" id="distributionRate" name="distributionRate" min="0" class="" step="0.01" required value="<?= htmlspecialchars($distributionRate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="systemLossCharge" class="weight-semibold">System Loss Rate</label>
                <input type="number" id="systemLossCharge" name="systemLossCharge" min="0" class="" step="0.01" required value="<?= htmlspecialchars($systemLossCharge ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Save Tariff Class</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
