<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `units` WHERE `unitID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $unitNumber = is_string($_POST['unitNumber'] ?? null) ? trim($_POST['unitNumber']) : '';
    $unitType = is_string($_POST['unitType'] ?? null) ? trim($_POST['unitType']) : '';
    $monthlyRent = is_string($_POST['monthlyRent'] ?? null) ? trim($_POST['monthlyRent']) : '';
    $floorLevel = is_string($_POST['floorLevel'] ?? null) ? trim($_POST['floorLevel']) : '';

    if ($unitNumber === '' ||
        $unitType === '' ||
        $monthlyRent === '' ||
        !is_numeric($monthlyRent) ||
        !is_finite((float)$monthlyRent) ||
        (float)$monthlyRent < 0 ||
        $floorLevel === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `units` SET `unitNumber` = '" . $conn->real_escape_string($unitNumber) . "', `unitType` = '" . $conn->real_escape_string($unitType) . "', `monthlyRent` = '" . $conn->real_escape_string($monthlyRent) . "', `floorLevel` = '" . $conn->real_escape_string($floorLevel) . "' WHERE `unitID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Apartment Unit - Apartment & Boarding House Rental System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Apartment Unit</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="unitNumber" class="weight-semibold">Unit Number</label>
                <input type="text" id="unitNumber" name="unitNumber" class=""  required value="<?= htmlspecialchars($record['unitNumber'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="unitType" class="weight-semibold">Unit Model</label>
                <input type="text" id="unitType" name="unitType" class=""  required value="<?= htmlspecialchars($record['unitType'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="monthlyRent" class="weight-semibold">Monthly Rent</label>
                <input type="number" id="monthlyRent" name="monthlyRent" min="0" class="" step="0.01" required value="<?= htmlspecialchars($record['monthlyRent'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="floorLevel" class="weight-semibold">Floor Level</label>
                <input type="text" id="floorLevel" name="floorLevel" class=""  required value="<?= htmlspecialchars($record['floorLevel'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Apartment Unit</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
