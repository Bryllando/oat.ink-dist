<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `tenants` WHERE `tenantID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tenantName = is_string($_POST['tenantName'] ?? null) ? trim($_POST['tenantName']) : '';
    $contactNumber = is_string($_POST['contactNumber'] ?? null) ? trim($_POST['contactNumber']) : '';
    $occupation = is_string($_POST['occupation'] ?? null) ? trim($_POST['occupation']) : '';
    $emergencyContact = is_string($_POST['emergencyContact'] ?? null) ? trim($_POST['emergencyContact']) : '';

    if ($tenantName === '' ||
        $contactNumber === '' ||
        $occupation === '' ||
        $emergencyContact === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `tenants` SET `tenantName` = '" . $conn->real_escape_string($tenantName) . "', `contactNumber` = '" . $conn->real_escape_string($contactNumber) . "', `occupation` = '" . $conn->real_escape_string($occupation) . "', `emergencyContact` = '" . $conn->real_escape_string($emergencyContact) . "' WHERE `tenantID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Tenant - Apartment & Boarding House Rental System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Tenant</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="tenantName" class="weight-semibold">Tenant Name</label>
                <input type="text" id="tenantName" name="tenantName" class=""  required value="<?= htmlspecialchars($record['tenantName'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="contactNumber" class="weight-semibold">Phone Number</label>
                <input type="text" id="contactNumber" name="contactNumber" class=""  required value="<?= htmlspecialchars($record['contactNumber'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="occupation" class="weight-semibold">Occupation</label>
                <input type="text" id="occupation" name="occupation" class=""  required value="<?= htmlspecialchars($record['occupation'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="emergencyContact" class="weight-semibold">Emergency Contact</label>
                <input type="text" id="emergencyContact" name="emergencyContact" class=""  required value="<?= htmlspecialchars($record['emergencyContact'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Tenant</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
