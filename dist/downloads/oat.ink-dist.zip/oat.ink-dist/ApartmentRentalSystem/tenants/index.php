<?php
require_once __DIR__ . '/../database.php';

$search = is_string($_GET['search'] ?? null) ? trim($_GET['search']) : '';
$where = "1=1";
if ($search !== '') {
    $esc = $conn->real_escape_string($search);
    $where .= " AND (`tenantName` LIKE '%$esc%')";
}

$records = $conn->query("SELECT * FROM `tenants` WHERE $where ORDER BY `tenantID` DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Tenants - Apartment & Boarding House Rental System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Manage Tenants</h3>
            <a href="add.php" class="button">+ Add New Tenant</a>
        </div>

        <div class="card p-3 mb-3">
            <form method="GET" class="row g-2">
                <div class="col-10">
                    <input type="text" name="search" class="" placeholder="Search by Tenant Name..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div class="col-2 flex gap-2">
                    <button type="submit" class="button outline w-100">Search</button>
                    <?php if ($search !== ''): ?>
                        <a href="index.php" class="button outline">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="mb-0">
                    <thead class="">
                        <tr>
                            <th>#</th>
                            <th>Tenant Name</th>
<th>Phone Number</th>
<th>Occupation</th>
<th>Emergency Contact</th>

                            <th class="align-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['tenantID'] ?></td>
                                    <td><?= htmlspecialchars($r['tenantName']) ?></td>
<td><?= htmlspecialchars($r['contactNumber']) ?></td>
<td><?= htmlspecialchars($r['occupation']) ?></td>
<td><?= htmlspecialchars($r['emergencyContact']) ?></td>

                                    <td class="align-right">
                                        <a href="edit.php?id=<?= $r['tenantID'] ?>" class="button small outline">Edit</a>
                                        <form method="POST" action="delete.php" class="inline-block" onsubmit="return confirm('Delete this record and any linked transactions?');">
                                            <input type="hidden" name="id" value="<?= $r['tenantID'] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                                            <button type="submit" class="button small outline danger-action">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="align-center py-4 text-light">No records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
</body>
</html>
