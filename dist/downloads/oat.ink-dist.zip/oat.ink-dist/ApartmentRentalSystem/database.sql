CREATE DATABASE IF NOT EXISTS `apartment_rental_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `apartment_rental_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `tenants` (
  `tenantID` INT AUTO_INCREMENT PRIMARY KEY,
  `tenantName` VARCHAR(100) NOT NULL,
  `contactNumber` VARCHAR(50) NOT NULL,
  `occupation` VARCHAR(100) NOT NULL,
  `emergencyContact` VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `units` (
  `unitID` INT AUTO_INCREMENT PRIMARY KEY,
  `unitNumber` VARCHAR(50) NOT NULL,
  `unitType` VARCHAR(100) NOT NULL,
  `monthlyRent` DECIMAL(10,2) NOT NULL,
  `floorLevel` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `leases` (
  `leaseID` INT AUTO_INCREMENT PRIMARY KEY,
  `tenantID` INT NOT NULL,
  `unitID` INT NOT NULL,
  `startDate` DATE NOT NULL,
  `endDate` DATE NOT NULL,
  `depositPaid` DECIMAL(10,2) NOT NULL,
  `status` VARCHAR(50) DEFAULT 'Active',
  FOREIGN KEY (`tenantID`) REFERENCES `tenants`(`tenantID`) ON DELETE CASCADE,
  FOREIGN KEY (`unitID`) REFERENCES `units`(`unitID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tenants` (`tenantName`, `contactNumber`, `occupation`, `emergencyContact`) VALUES
('Renato Albarracin', '09173331122', 'Software QA Engineer', 'Elena Albarracin (09181112233)'),
('Cynthia Villacastin', '09184442233', 'Registered Nurse', 'Eduardo Villacastin (09222223344)'),
('Melchor Magbanua', '09225553344', 'Accountant', 'Nelia Magbanua (09233334455)');

INSERT INTO `units` (`unitNumber`, `unitType`, `monthlyRent`, `floorLevel`) VALUES
('Apt-101', 'Studio Type with Kitchenette', 7500.0, '1st Floor'),
('Apt-204', '1-Bedroom Suite Balcony', 11000.0, '2nd Floor'),
('Apt-302', '2-Bedroom Family Flat', 16500.0, '3rd Floor');

INSERT INTO `leases` (`tenantID`, `unitID`, `startDate`, `endDate`, `depositPaid`, `status`) VALUES
(1, 1, '2026-06-01', '2027-05-31', 15000.0, 'Active'),
(2, 2, '2026-08-15', '2027-08-14', 22000.0, 'Active'),
(3, 3, '2026-01-10', '2026-12-31', 33000.0, 'Active');

SET FOREIGN_KEY_CHECKS=1;
