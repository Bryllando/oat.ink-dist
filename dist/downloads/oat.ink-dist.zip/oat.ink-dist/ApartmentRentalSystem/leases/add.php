<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `tenantID`, `tenantName` FROM `tenants` ORDER BY `tenantName` ASC");
$e2List = $conn->query("SELECT `unitID`, `unitNumber` FROM `units` ORDER BY `unitNumber` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['tenantID'] ?? 0);
    $id2 = (int)($_POST['unitID'] ?? 0);
    $startDate = is_string($_POST['startDate'] ?? null) ? trim($_POST['startDate']) : '';
    $endDate = is_string($_POST['endDate'] ?? null) ? trim($_POST['endDate']) : '';
    $depositPaid = is_string($_POST['depositPaid'] ?? null) ? trim($_POST['depositPaid']) : '';
    $status = is_string($_POST['status'] ?? null) ? trim($_POST['status']) : '';

    if ($startDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $startDate) ||
        date('Y-m-d', strtotime($startDate) ?: 0) !== $startDate ||
        $endDate === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $endDate) ||
        date('Y-m-d', strtotime($endDate) ?: 0) !== $endDate ||
        $depositPaid === '' ||
        !is_numeric($depositPaid) ||
        !is_finite((float)$depositPaid) ||
        (float)$depositPaid < 0 ||
        $status === '' ||
        $id1 <= 0 ||
        $id2 <= 0 ||
        $endDate < $startDate) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `leases` (`tenantID`, `unitID`, `startDate`, `endDate`, `depositPaid`, `status`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($startDate) . "', '" . $conn->real_escape_string($endDate) . "', '" . $conn->real_escape_string($depositPaid) . "', '" . $conn->real_escape_string($status) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Lease Contract - Apartment & Boarding House Rental System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Lease Contract</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="tenantID" class="weight-semibold">Select Tenant</label>
                        <select id="tenantID" name="tenantID" class="" required>
                            <option value="">-- Choose Tenant --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['tenantID'] ?>" <?= ((int)($_POST['tenantID'] ?? 0) === (int)$r['tenantID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['tenantName']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="unitID" class="weight-semibold">Select Apartment Unit</label>
                        <select id="unitID" name="unitID" class="" required>
                            <option value="">-- Choose Apartment Unit --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['unitID'] ?>" <?= ((int)($_POST['unitID'] ?? 0) === (int)$r['unitID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['unitNumber']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="startDate" class="weight-semibold">Contract Start</label>
                <input type="date" id="startDate" name="startDate" class=""  required value="<?= htmlspecialchars($startDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="endDate" class="weight-semibold">Contract End</label>
                <input type="date" id="endDate" name="endDate" class=""  required value="<?= htmlspecialchars($endDate ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="depositPaid" class="weight-semibold">Security Deposit Paid</label>
                <input type="number" id="depositPaid" name="depositPaid" min="0" class="" step="0.01" required value="<?= htmlspecialchars($depositPaid ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="status" class="weight-semibold">Lease Status</label>
                <input type="text" id="status" name="status" class=""  required value="<?= htmlspecialchars($status ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Lease Contract</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
