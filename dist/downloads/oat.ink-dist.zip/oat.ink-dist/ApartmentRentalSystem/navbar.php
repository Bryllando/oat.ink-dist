<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Apartment & Boarding House Rental System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'tenants') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>tenants/index.php">Tenants</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'units') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>units/index.php">Apartment Units</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'leases') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>leases/index.php">Lease Contracts</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
