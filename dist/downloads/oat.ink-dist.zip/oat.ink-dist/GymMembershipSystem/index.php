<?php
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/helpers.php';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Gym Membership System</title>
    </head>
    <body>
    <?php include __DIR__ . '/navbar.php'; ?>
        <div class="container">
            <div class="page-heading">
                <h1 class="page-title">Gym Membership Management System</h1>
            </div>

            <div class="simple-panel mb-4">
                <ul class="simple-menu">
                    <li><a href="<?php echo $baseUrl; ?>members/index.php"><span>Members</span> </a></li>
                    <li><a href="<?php echo $baseUrl; ?>packages/index.php"><span>Packages</span> </a></li>
                    <li><a href="<?php echo $baseUrl; ?>memberships/index.php"><span>Memberships</span> </a></li>
                    <li><a href="<?php echo $baseUrl; ?>monitoring/index.php"><span>Reports</span></a></li>
                </ul>
            </div>
        </div>
    
    </body>
</html>
