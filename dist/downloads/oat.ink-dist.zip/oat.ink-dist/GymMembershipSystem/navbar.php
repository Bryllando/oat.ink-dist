<?php
if (!isset($baseUrl)) {
    require_once __DIR__ . '/database.php';
}
$navBase = rtrim($baseUrl, '/');
$currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
?>

<nav class="app-nav mb-4">
    <div class="container-fluid container">
        <a class="app-brand nav-brand" href="<?php echo $navBase; ?>/index.php">Gym Membership</a>
        
        <div class="nav-region" id="navbarNav">
            <ul class="nav-links ms-auto">
                <li><a class="nav-link <?php echo (strpos($currentUri, '/members/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/members/index.php">Members</a></li>
                <li><a class="nav-link <?php echo (strpos($currentUri, '/packages/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/packages/index.php">Packages</a></li>
                <li><a class="nav-link <?php echo (strpos($currentUri, '/memberships/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/memberships/index.php">Memberships</a></li>
                <li><a class="nav-link <?php echo (strpos($currentUri, '/monitoring/') !== false) ? 'active' : ''; ?>" href="<?php echo $navBase; ?>/monitoring/index.php">Monitoring</a></li>
            </ul>
        </div>
    </div>
</nav>
