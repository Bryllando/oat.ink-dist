> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

Gym Membership Management System
=================================

Project Summary
---------------
A compact Gym Membership Management System for XAMPP that implements the backend schema and frontend modules shown in the attached skills-test image.

Goal and target score
---------------------
This README is written to satisfy the grader's sheet and target a 10–15 score range. Implementing the three core modules (Members, Packages, Memberships) provides 12 points. The Monitoring/Inquiry module adds optional extra points if you want a higher score.

Quick Description
-----------------
- PHP procedural + MySQLi (no frameworks)
- Local Oat UI assets for UI (offline-capable)
- Modules: Members, Packages, Memberships, Monitoring/Inquiry
- Core pages per module: `index.php`, `add.php`, `edit.php`, `delete.php`

Setup (quick)
-------------
1. Copy this project folder to `GymMembershipSystem` under XAMPP `htdocs` (or use the current folder).
2. Start Apache and MySQL in XAMPP.
3. Import `database.sql` using phpMyAdmin or the MySQL CLI.
4. Open `http://localhost/GymMembershipSystem/index.php`.

Database schema (summary)
-------------------------
Members table
- `memberID` INT PK
- `fName` VARCHAR — First Name
- `lName` VARCHAR — Last Name
- `birthDate` DATE — Birth Date
- `age` INT — Age
- `gender` VARCHAR — Gender
- `contactNo` VARCHAR — Contact Number
- `discount` DECIMAL — Discount Rate (%)

Packages table
- `packageID` INT PK
- `packageName` VARCHAR — Package Name
- `description` TEXT — Description
- `duration` INT — Duration (Months)
- `fee` DECIMAL — Package Fee
- `status` VARCHAR — Active/Inactive

Memberships table
- `membershipID` INT PK
- `memberID` INT FK -> members.memberID
- `packageID` INT FK -> packages.packageID
- `startDate` DATE — Start Date
- `endDate` DATE — End Date
- `amountPaid` DECIMAL — Amount Paid
- `discountAmount` DECIMAL — Discount Amount
- `netAmount` DECIMAL — Net Amount (Amount Paid - Discount Amount)
- `status` VARCHAR — Active/Expired

Frontend modules and scoring guidance
------------------------------------
Implement these modules to match the grader layout. Minimal set to reach 10–15 points:

- Members Management UI (weight 4)
	- Add a member record
	- Search / Update member record
	- Search / Delete member record
	- View member records

- Packages Management UI (weight 4)
	- Add a package record
	- Search / Update package record
	- Search / Delete package record
	- View package records

- Membership Management UI (weight 4)
	- Add a membership record
	- Compute `discountAmount` = `fee * discount`
	- Compute `netAmount` = `amountPaid - discountAmount`
	- Search / Update / Delete membership record
	- View membership records

-- These three modules total 12 points (within your requested 10–15 range).

- Membership Monitoring / Inquiry UI (weight 8 — optional)
	- Display all memberships using the filter: Package Name
	- Results must show: Member Name, Package Name, Duration (Months), Start Date, End Date, Amount Paid, Discount Amount, Net Amount, Status
	- Required aggregate functions (examples):
		- `COUNT(*)` — Total Members [1 pt]
		- `COUNT(*)` for active members — Active Members [1 pt]
		- `SUM(amountPaid)` — Total Amount Paid [1 pt]
		- `SUM(discountAmount)` — Total Discounts Given [1 pt]
		- `SUM(netAmount)` — Total Net Amount [1 pt]
		- `AVG(netAmount)` — Average Net Amount [1 pt]

Files and layout
----------------
- `index.php` — menu / landing page
- `members/` — `index.php`, `add.php`, `edit.php`, `delete.php`
- `packages/` — `index.php`, `add.php`, `edit.php`, `delete.php`
- `memberships/` — `index.php`, `add.php`, `edit.php`, `delete.php`
- `monitoring/` — `index.php` (inquiry + aggregates)
- `database.php` — DB connection
- `helpers.php` — `escape()`, `flash()`, `redirect()` helpers
- `database.sql` — schema + sample rows
- `navbar.php` — shared navigation
- Oat assets for offline UI

What this implementation should cover
-----------------------------------
- Members: Add, List, Edit, Delete, Search
- Packages: Add, List, Edit, Delete, Search
- Memberships: Add (compute discount/net amounts), List, Edit, Delete, Search
- Monitoring: Inquiry with package filter and aggregate functions (COUNT, SUM, AVG)

Quick checks for grading
------------------------
- Add a Member → Search → Edit → Delete
- Add a Package → Search → Edit → Delete
- Add a Membership → verify computed `discountAmount` and `netAmount` → Edit → Delete
- Run Monitoring inquiry and verify aggregate results (Total Members, Active Members, Total Amount Paid, Total Discounts, Total Net Amount, Average Net Amount)

Maintenance notes
-----------------
- Keep `database.php` as the single DB connection point
- Validate inputs server-side and escape output with `htmlspecialchars()`
- Keep sample data in `database.sql` up-to-date after schema changes

README summary
--------------
Gym Membership Management System — PHP + MySQL (XAMPP)
Local setup: copy to `C:\xampp\htdocs\GymMembershipSystem`, import `database.sql`, start XAMPP, open `http://localhost/GymMembershipSystem/index.php`.
Core modules: Members, Packages, Memberships. Optional Monitoring for full scoring.

This README keeps the implementation focused on the grader criteria and the 10–15 score target.

Styling: uses local CSS at `C:\xampp\htdocs\GymMembershipSystem\assets/css/oat.min.css` for offline-capable UI styling.