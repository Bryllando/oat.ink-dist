<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$filter = $_GET['package'] ?? '';
$query = 'SELECT m.*, mem.fName, mem.lName, p.packageName, p.duration FROM memberships m JOIN members mem ON m.memberID = mem.memberID JOIN packages p ON m.packageID = p.packageID';
$params = [];
if ($filter !== '') {
    $query .= ' WHERE p.packageName = ?';
    $params[] = $filter;
}
$stmt = mysqli_prepare($conn, $query);
if ($params) {
    mysqli_stmt_bind_param($stmt, 's', ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$packages = mysqli_query($conn, 'SELECT DISTINCT packageName FROM packages ORDER BY packageName');

$totals = [
    'count' => 0,
    'active' => 0,
    'amountPaid' => 0.00,
    'discountAmount' => 0.00,
    'netAmount' => 0.00,
];
$memberships = [];
while ($row = mysqli_fetch_assoc($result)) {
    $memberships[] = $row;
    $totals['count']++;
    if (strtolower($row['status']) === 'active') {
        $totals['active']++;
    }
    $totals['amountPaid'] += floatval($row['amountPaid']);
    $totals['discountAmount'] += floatval($row['discountAmount']);
    $totals['netAmount'] += floatval($row['netAmount']);
}
$totals['averageNet'] = $totals['count'] ? round($totals['netAmount'] / $totals['count'], 2) : 0.00;
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Monitoring - Gym Membership</title>
    
    </head>
    <body>
    <?php include __DIR__ . '/../navbar.php'; ?>
        <div class="container">
            <div class="py-3">
                <h1 class="page-title">Monitoring / Inquiry</h1>
                <form class="row g-3 mb-3 filter-form filter-panel" method="get" action="index.php">
                    <div class="col-8">
                        <select name="package">
                            <option value="">All Packages</option>
                        <?php while ($pkg = mysqli_fetch_assoc($packages)): ?>
                            <option value="<?php echo escape($pkg['packageName']); ?>" <?php echo ($filter === $pkg['packageName']) ? 'selected' : ''; ?>><?php echo escape($pkg['packageName']); ?></option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-4 filter-actions"><button type="submit" class="button ">Filter</button><a class="button outline" href="index.php">Clear</a></div>
            
                </form>
                <div class="row g-3 mb-4">
                    <div class="col-4"><div class="card surface-muted p-3"><strong>Total Applications</strong><div><?php echo escape($totals['count']); ?></div></div></div>
                    <div class="col-4"><div class="card surface-muted p-3"><strong>Active Applications</strong><div><?php echo escape($totals['active']); ?></div></div></div>
                    <div class="col-4"><div class="card surface-muted p-3"><strong>Average Net Amount</strong><div><?php echo escape(number_format($totals['averageNet'], 2)); ?></div></div></div>
                    <div class="col-4"><div class="card surface-muted p-3"><strong>Total Amount Paid</strong><div><?php echo escape(number_format($totals['amountPaid'], 2)); ?></div></div></div>
                    <div class="col-4"><div class="card surface-muted p-3"><strong>Total Discounts Given</strong><div><?php echo escape(number_format($totals['discountAmount'], 2)); ?></div></div></div>
                    <div class="col-4"><div class="card surface-muted p-3"><strong>Total Net Amount</strong><div><?php echo escape(number_format($totals['netAmount'], 2)); ?></div></div></div>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Member</th>
                                <th>Package</th>
                                <th>Duration</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Amount Paid</th>
                                <th>Discount Amount</th>
                                <th>Net Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($memberships)): ?>
                            <tr><td colspan="9" class="align-center">No memberships found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($memberships as $membership): ?>
                            <tr>
                                <td><?php echo escape($membership['fName'] . ' ' . $membership['lName']); ?></td>
                                <td><?php echo escape($membership['packageName']); ?></td>
                                <td><?php echo escape($membership['duration']); ?></td>
                                <td><?php echo escape($membership['startDate']); ?></td>
                                <td><?php echo escape($membership['endDate']); ?></td>
                                <td><?php echo escape($membership['amountPaid']); ?></td>
                                <td><?php echo escape($membership['discountAmount']); ?></td>
                                <td><?php echo escape($membership['netAmount']); ?></td>
                                <td><?php echo escape($membership['status']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
</html>
