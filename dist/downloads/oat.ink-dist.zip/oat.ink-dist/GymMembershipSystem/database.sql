-- Gym Membership Management System schema and sample data
CREATE DATABASE IF NOT EXISTS gym_membership_system;
USE gym_membership_system;

CREATE TABLE IF NOT EXISTS members (
    memberID INT AUTO_INCREMENT PRIMARY KEY,
    fName VARCHAR(100) NOT NULL,
    lName VARCHAR(100) NOT NULL,
    birthDate DATE NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(20) NOT NULL,
    contactNo VARCHAR(50) NOT NULL,
    discount DECIMAL(5,2) NOT NULL DEFAULT 0.00
);

CREATE TABLE IF NOT EXISTS packages (
    packageID INT AUTO_INCREMENT PRIMARY KEY,
    packageName VARCHAR(150) NOT NULL,
    description TEXT,
    duration INT NOT NULL,
    fee DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Active'
);

CREATE TABLE IF NOT EXISTS memberships (
    membershipID INT AUTO_INCREMENT PRIMARY KEY,
    memberID INT NOT NULL,
    packageID INT NOT NULL,
    startDate DATE NOT NULL,
    endDate DATE NOT NULL,
    amountPaid DECIMAL(10,2) NOT NULL,
    discountAmount DECIMAL(10,2) NOT NULL,
    netAmount DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Active',
    FOREIGN KEY (memberID) REFERENCES members(memberID) ON DELETE CASCADE,
    FOREIGN KEY (packageID) REFERENCES packages(packageID) ON DELETE CASCADE
);

INSERT INTO members (fName, lName, birthDate, age, gender, contactNo, discount)
VALUES
('Anna', 'Santos', '1995-04-12', 29, 'Female', '09171234567', 0.10),
('Mark', 'Delgado', '1988-09-04', 35, 'Male', '09181234567', 0.05);

INSERT INTO packages (packageName, description, duration, fee, status)
VALUES
('Standard Monthly', 'Access to gym equipment and locker rooms.', 1, 1200.00, 'Active'),
('Annual Premium', 'Full membership with classes and pool access.', 12, 12000.00, 'Active');

INSERT INTO memberships (memberID, packageID, startDate, endDate, amountPaid, discountAmount, netAmount, status)
VALUES
(1, 1, '2024-07-01', '2024-08-01', 1200.00, 120.00, 1080.00, 'Active'),
(2, 2, '2024-01-01', '2025-01-01', 12000.00, 600.00, 11400.00, 'Active');
