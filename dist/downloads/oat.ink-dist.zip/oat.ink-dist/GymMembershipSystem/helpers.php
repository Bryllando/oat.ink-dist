<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function escape($value)
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function flash($message = '', $type = 'success')
{
    if ($message === '') {
        if (!empty($_SESSION['flash'])) {
            $flash = $_SESSION['flash'];
            unset($_SESSION['flash']);
            if (!is_array($flash)) {
                return ['message' => (string)$flash, 'type' => 'success'];
            }
            return $flash + ['message' => '', 'type' => 'success'];
        }
        return null;
    }

    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}

function redirect($url)
{
    header('Location: ' . $url);
    exit;
}
