<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$search = $_GET['search'] ?? '';
$query = 'SELECT m.*, mem.fName, mem.lName, p.packageName, p.fee, p.duration FROM memberships m JOIN members mem ON m.memberID = mem.memberID JOIN packages p ON m.packageID = p.packageID';
$params = [];
if ($search !== '') {
    $query .= ' WHERE mem.fName LIKE ? OR mem.lName LIKE ? OR p.packageName LIKE ?';
    $params = ["%{$search}%", "%{$search}%", "%{$search}%"];
}
$stmt = mysqli_prepare($conn, $query);
if ($params) {
    mysqli_stmt_bind_param($stmt, 'sss', ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Memberships - Gym Membership</title>
    
    </head>
    <body>
    <?php include __DIR__ . '/../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Memberships</h1>
                <a href="add.php" class="button success-action">Add Membership</a>
            </div>
        <?php if ($flash = flash()): ?>
            <div role="alert" class="notice notice-<?php echo escape($flash['type']); ?>"><?php echo escape($flash['message']); ?></div>
        <?php endif; ?>
            <form class="row g-2 mb-3 filter-form filter-panel" method="get" action="index.php">
                <div class="col-10">
                    <input type="search" name="search" placeholder="Search memberships by member or package" value="<?php echo escape($search); ?>">
                </div>
                <div class="col-2 filter-actions">
                    <button type="submit" class="button ">Search</button>
                    <a class="button outline" href="index.php">Clear</a></div>
        
            </form>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Member</th>
                            <th>Package</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Amount Paid</th>
                            <th>Discount Amount</th>
                            <th>Net Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($membership = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo escape($membership['membershipID']); ?></td>
                            <td><?php echo escape($membership['fName'] . ' ' . $membership['lName']); ?></td>
                            <td><?php echo escape($membership['packageName']); ?></td>
                            <td><?php echo escape($membership['startDate']); ?></td>
                            <td><?php echo escape($membership['endDate']); ?></td>
                            <td><?php echo escape($membership['amountPaid']); ?></td>
                            <td><?php echo escape($membership['discountAmount']); ?></td>
                            <td><?php echo escape($membership['netAmount']); ?></td>
                            <td><?php echo escape($membership['status']); ?></td>
                            <td>
                                <a href="edit.php?id=<?php echo escape($membership['membershipID']); ?>" class="button small">Edit</a>
                                <a href="delete.php?id=<?php echo escape($membership['membershipID']); ?>" class="button small danger-action">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
