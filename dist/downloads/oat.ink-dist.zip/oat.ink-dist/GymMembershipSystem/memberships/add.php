<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$errors = [];
$members = mysqli_query($conn, 'SELECT memberID, fName, lName, discount FROM members ORDER BY fName, lName');
$packages = mysqli_query($conn, 'SELECT packageID, packageName, fee, duration FROM packages WHERE status = "Active" ORDER BY packageName');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $memberID = intval($_POST['memberID'] ?? 0);
    $packageID = intval($_POST['packageID'] ?? 0);
    $startDate = $_POST['startDate'] ?? '';
    $endDate = $_POST['endDate'] ?? '';
    $amountPaid = floatval($_POST['amountPaid'] ?? 0);
    $status = $_POST['status'] ?? 'Active';

    if ($memberID <= 0 || $packageID <= 0 || $startDate === '' || $endDate === '' || $amountPaid <= 0) {
        $errors[] = 'Please select a member, package, and enter valid amounts.';
    }

    if (!$errors) {
        $memberStmt = mysqli_prepare($conn, 'SELECT discount FROM members WHERE memberID = ?');
        mysqli_stmt_bind_param($memberStmt, 'i', $memberID);
        mysqli_stmt_execute($memberStmt);
        $memberResult = mysqli_stmt_get_result($memberStmt);
        $member = mysqli_fetch_assoc($memberResult);

        $packageStmt = mysqli_prepare($conn, 'SELECT fee FROM packages WHERE packageID = ?');
        mysqli_stmt_bind_param($packageStmt, 'i', $packageID);
        mysqli_stmt_execute($packageStmt);
        $packageResult = mysqli_stmt_get_result($packageStmt);
        $package = mysqli_fetch_assoc($packageResult);

        if (!$member || !$package) {
            $errors[] = 'Selected member or package is invalid.';
        }
    }

    if (!$errors) {
        $discountRate = floatval($member['discount']);
        $fee = floatval($package['fee']);
        $discountAmount = round($fee * $discountRate, 2);
        $netAmount = round($amountPaid - $discountAmount, 2);

        $stmt = mysqli_prepare($conn, 'INSERT INTO memberships (memberID, packageID, startDate, endDate, amountPaid, discountAmount, netAmount, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        mysqli_stmt_bind_param($stmt, 'iissddds', $memberID, $packageID, $startDate, $endDate, $amountPaid, $discountAmount, $netAmount, $status);
        mysqli_stmt_execute($stmt);
        flash('Membership added successfully.');
        redirect('index.php');
    }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add Membership - Gym Membership</title>
    
    </head>
    <body>
    <?php include __DIR__ . '/../navbar.php'; ?>
        <div class="container form-page">
            <div class="py-3">
                <h1 class="page-title">Add Membership</h1>
            <?php if ($errors): ?>
                <div role="alert" class="notice notice-danger"><ul><?php foreach ($errors as $error): ?><li><?php echo escape($error); ?></li><?php endforeach; ?></ul></div>
            <?php endif; ?>
                <form method="post" action="add.php" class="entry-form form-panel">
                    <div class="row g-3 mb-3">
                        <div class="col-6"><label for="input-memberID">Member</label><select name="memberID" id="input-memberID"><option value="">Select Member</option><?php while ($member = mysqli_fetch_assoc($members)): ?><option value="<?php echo escape($member['memberID']); ?>" data-discount="<?php echo escape($member['discount']); ?>" <?php echo ((int)($_POST['memberID'] ?? 0) === (int)$member['memberID']) ? 'selected' : ''; ?>><?php echo escape($member['fName'] . ' ' . $member['lName']); ?></option><?php endwhile; ?></select></div>
                        <div class="col-6"><label for="input-packageID">Package</label><select name="packageID" id="input-packageID"><option value="">Select Package</option><?php mysqli_data_seek($packages, 0); while ($package = mysqli_fetch_assoc($packages)): ?><option value="<?php echo escape($package['packageID']); ?>" data-fee="<?php echo escape($package['fee']); ?>" data-duration="<?php echo escape($package['duration']); ?>" <?php echo ((int)($_POST['packageID'] ?? 0) === (int)$package['packageID']) ? 'selected' : ''; ?>><?php echo escape($package['packageName']); ?></option><?php endwhile; ?></select></div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-4"><label for="input-startDate">Start Date</label><input type="date" name="startDate" value="<?php echo escape($_POST['startDate'] ?? ''); ?>" id="input-startDate"></div>
                        <div class="col-4"><label for="input-endDate">End Date</label><input type="date" name="endDate" value="<?php echo escape($_POST['endDate'] ?? ''); ?>" id="input-endDate"></div>
                        <div class="col-4"><label for="input-amountPaid">Amount Paid</label><input type="number" step="0.01" name="amountPaid" value="<?php echo escape($_POST['amountPaid'] ?? ''); ?>" id="input-amountPaid"></div>
                    </div>
                    <div class="row g-3 mb-3">
                        <div class="col-4"><label for="input-discountAmount">Discount Amount</label><input type="number" step="0.01" name="discountAmount" value="<?php echo escape($_POST['discountAmount'] ?? '0.00'); ?>" id="input-discountAmount"></div>
                        <div class="col-4"><label for="input-netAmount">Net Amount</label><input type="number" step="0.01" name="netAmount" value="<?php echo escape($_POST['netAmount'] ?? '0.00'); ?>" id="input-netAmount"></div>
                        <div class="col-4"><label for="input-status">Status</label><select name="status" id="input-status"><option value="Active" <?php echo (($_POST['status'] ?? '') === 'Active') ? 'selected' : ''; ?>>Active</option><option value="Expired" <?php echo (($_POST['status'] ?? '') === 'Expired') ? 'selected' : ''; ?>>Expired</option></select></div>
                    </div>
                    <div class="mb-3 form-actions">
                        <button type="button" class="button outline" id="calculateButton">Calculate Discount / Net</button>
                    </div>
                    <div><button type="submit" class="button">Save Membership</button> <a href="index.php" class="button outline">Cancel</a></div>
                </form>
            </div>
        </div>
        <script>
        const memberOptions = Array.from(document.querySelectorAll('select[name="memberID"] option')).slice(1).map(option => ({
            id: option.value,
            discount: parseFloat(option.dataset.discount || '0')
        }));
        const packageOptions = Array.from(document.querySelectorAll('select[name="packageID"] option')).slice(1).map(option => ({
            id: option.value,
            fee: parseFloat(option.dataset.fee || '0')
        }));
        const memberSelect = document.querySelector('select[name="memberID"]');
        const packageSelect = document.querySelector('select[name="packageID"]');
        const amountPaidInput = document.querySelector('input[name="amountPaid"]');
        const discountInput = document.querySelector('input[name="discountAmount"]');
        const netInput = document.querySelector('input[name="netAmount"]');
        const calculateButton = document.getElementById('calculateButton');

        calculateButton.addEventListener('click', () => {
            const member = memberOptions.find(m => m.id === memberSelect.value);
            const selectedPackage = packageOptions.find(pkg => pkg.id === packageSelect.value);
            const amountPaid = parseFloat(amountPaidInput.value) || 0;
            if (!member || !selectedPackage || amountPaid <= 0) {
                alert('Select member/package and enter amount paid first.');
                return;
            }
            const discountAmount = (selectedPackage.fee * member.discount).toFixed(2);
            discountInput.value = discountAmount;
            netInput.value = (amountPaid - discountAmount).toFixed(2);
        });
        </script>
    </body>
</html>
