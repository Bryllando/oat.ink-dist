<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
    $stmt = mysqli_prepare($conn, 'DELETE FROM memberships WHERE membershipID = ?');
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    flash('Membership deleted successfully.', 'danger');
}
redirect('index.php');
