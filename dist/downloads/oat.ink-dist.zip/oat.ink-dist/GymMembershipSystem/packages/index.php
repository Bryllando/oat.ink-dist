<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$search = $_GET['search'] ?? '';
$query = 'SELECT * FROM packages';
$params = [];
if ($search !== '') {
    $query .= ' WHERE packageName LIKE ? OR description LIKE ?';
    $params = ["%{$search}%", "%{$search}%"];
}
$stmt = mysqli_prepare($conn, $query);
if ($params) {
    mysqli_stmt_bind_param($stmt, 'ss', ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Packages - Gym Membership</title>
    
    </head>
    <body>
    <?php include __DIR__ . '/../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Packages</h1>
                <a href="add.php" class="button success-action">Add Package</a>
            </div>
        <?php if ($flash = flash()): ?>
            <div role="alert" class="notice notice-<?php echo escape($flash['type'] ?? 'success'); ?>"><?php echo escape($flash['message'] ?? ''); ?></div>
        <?php endif; ?>
            <form class="row g-2 mb-3 filter-form filter-panel" method="get" action="index.php">
                <div class="col-10">
                    <input type="search" name="search" placeholder="Search packages by name or description" value="<?php echo escape($search); ?>">
                </div>
                <div class="col-2 filter-actions">
                    <button type="submit" class="button ">Search</button>
                    <a class="button outline" href="index.php">Clear</a></div>
        
            </form>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Package Name</th>
                            <th>Description</th>
                            <th>Duration (Months)</th>
                            <th>Fee</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($package = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo escape($package['packageID']); ?></td>
                            <td><?php echo escape($package['packageName']); ?></td>
                            <td><?php echo escape($package['description']); ?></td>
                            <td><?php echo escape($package['duration']); ?></td>
                            <td><?php echo escape($package['fee']); ?></td>
                            <td><?php echo escape($package['status']); ?></td>
                            <td>
                                <a href="edit.php?id=<?php echo escape($package['packageID']); ?>" class="button small">Edit</a>
                                <a href="delete.php?id=<?php echo escape($package['packageID']); ?>" class="button small danger-action">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
