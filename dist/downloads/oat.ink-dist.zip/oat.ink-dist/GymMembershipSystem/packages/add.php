<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $packageName = trim($_POST['packageName'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $duration = intval($_POST['duration'] ?? 0);
    $fee = floatval($_POST['fee'] ?? 0);
    $status = $_POST['status'] ?? 'Active';

    if ($packageName === '' || $duration <= 0 || $fee <= 0) {
        $errors[] = 'Please provide the package name, duration, and fee.';
    }

    if (!$errors) {
        $stmt = mysqli_prepare($conn, 'INSERT INTO packages (packageName, description, duration, fee, status) VALUES (?, ?, ?, ?, ?)');
        mysqli_stmt_bind_param($stmt, 'ssids', $packageName, $description, $duration, $fee, $status);
        mysqli_stmt_execute($stmt);
        flash('Package added successfully.');
        redirect('index.php');
    }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add Package - Gym Membership</title>
    
    </head>
    <body>
    <?php include __DIR__ . '/../navbar.php'; ?>
        <div class="container form-page">
            <div class="py-3">
                <h1 class="page-title">Add Package</h1>
            <?php if ($errors): ?>
                <div role="alert" class="notice notice-danger"><ul><?php foreach ($errors as $error): ?><li><?php echo escape($error); ?></li><?php endforeach; ?></ul></div>
            <?php endif; ?>
                <form method="post" action="add.php" class="entry-form form-panel">
                    <div class="mb-3"><label for="input-packageName">Package Name</label><input type="text" name="packageName" value="<?php echo escape($_POST['packageName'] ?? ''); ?>" id="input-packageName"></div>
                    <div class="mb-3"><label for="input-description">Description</label><textarea name="description" id="input-description"><?php echo escape($_POST['description'] ?? ''); ?></textarea></div>
                    <div class="row g-3">
                        <div class="col-4"><label for="input-duration">Duration (Months)</label><input type="number" name="duration" value="<?php echo escape($_POST['duration'] ?? ''); ?>" id="input-duration"></div>
                        <div class="col-4"><label for="input-fee">Fee</label><input type="number" step="0.01" name="fee" value="<?php echo escape($_POST['fee'] ?? ''); ?>" id="input-fee"></div>
                        <div class="col-4"><label for="input-status">Status</label><select name="status" id="input-status"><option value="Active" <?php echo (($_POST['status'] ?? '') === 'Active') ? 'selected' : ''; ?>>Active</option><option value="Inactive" <?php echo (($_POST['status'] ?? '') === 'Inactive') ? 'selected' : ''; ?>>Inactive</option></select></div>
                    </div>
                    <div class="mt-4 form-actions"><button type="submit" class="button">Save Package</button> <a href="index.php" class="button outline">Cancel</a></div>
                </form>
            </div>
        </div>
    </body>
</html>
