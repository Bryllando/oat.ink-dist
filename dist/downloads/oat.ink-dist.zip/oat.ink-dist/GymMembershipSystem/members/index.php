<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$search = $_GET['search'] ?? '';
$query = 'SELECT * FROM members';
$params = [];
if ($search !== '') {
    $query .= ' WHERE fName LIKE ? OR lName LIKE ? OR contactNo LIKE ?';
    $params = ["%{$search}%", "%{$search}%", "%{$search}%"];
}
$stmt = mysqli_prepare($conn, $query);
if ($params) {
    mysqli_stmt_bind_param($stmt, 'sss', ...$params);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Members - Gym Membership</title>
    
    </head>
    <body>
    <?php include __DIR__ . '/../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Members</h1>
                <a href="add.php" class="button success-action">Add Member</a>
            </div>
        <?php if ($flash = flash()): ?>
            <div role="alert" class="notice notice-<?php echo escape($flash['type']); ?>"><?php echo escape($flash['message']); ?></div>
        <?php endif; ?>
            <form class="row g-2 mb-3 filter-form filter-panel" method="get" action="index.php">
                <div class="col-10">
                    <input type="search" name="search" placeholder="Search members by name or contact" value="<?php echo escape($search); ?>">
                </div>
                <div class="col-2 filter-actions">
                    <button type="submit" class="button ">Search</button>
                    <a class="button outline" href="index.php">Clear</a></div>
        
            </form>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Birth Date</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Contact</th>
                            <th>Discount (%)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($member = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo escape($member['memberID']); ?></td>
                            <td><?php echo escape($member['fName']); ?></td>
                            <td><?php echo escape($member['lName']); ?></td>
                            <td><?php echo escape($member['birthDate']); ?></td>
                            <td><?php echo escape($member['age']); ?></td>
                            <td><?php echo escape($member['gender']); ?></td>
                            <td><?php echo escape($member['contactNo']); ?></td>
                            <td><?php echo escape($member['discount']); ?></td>
                            <td>
                                <a href="edit.php?id=<?php echo escape($member['memberID']); ?>" class="button small">Edit</a>
                                <a href="delete.php?id=<?php echo escape($member['memberID']); ?>" class="button small danger-action">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
