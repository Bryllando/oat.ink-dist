<?php
require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../helpers.php';

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    redirect('index.php');
}

$stmt = mysqli_prepare($conn, 'SELECT * FROM members WHERE memberID = ?');
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$member = mysqli_fetch_assoc($result);
if (!$member) {
    redirect('index.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fName = trim($_POST['fName'] ?? '');
    $lName = trim($_POST['lName'] ?? '');
    $birthDate = $_POST['birthDate'] ?? '';
    $age = intval($_POST['age'] ?? 0);
    $gender = $_POST['gender'] ?? '';
    $contactNo = trim($_POST['contactNo'] ?? '');
    $discount = floatval($_POST['discount'] ?? 0);

    if ($fName === '' || $lName === '' || $birthDate === '' || $age <= 0 || $gender === '' || $contactNo === '') {
        $errors[] = 'Please fill all required fields correctly.';
    }

    if (!$errors) {
        $stmt = mysqli_prepare($conn, 'UPDATE members SET fName = ?, lName = ?, birthDate = ?, age = ?, gender = ?, contactNo = ?, discount = ? WHERE memberID = ?');
        mysqli_stmt_bind_param($stmt, 'sssissdi', $fName, $lName, $birthDate, $age, $gender, $contactNo, $discount, $id);
        mysqli_stmt_execute($stmt);
        flash('Member updated successfully.');
        redirect('index.php');
    }
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Edit Member - Gym Membership</title>
    
    </head>
    <body>
    <?php include __DIR__ . '/../navbar.php'; ?>
        <div class="container form-page">
            <div class="py-3">
                <h1 class="page-title">Edit Member</h1>
            <?php if ($errors): ?>
                <div role="alert" class="notice notice-danger"><ul><?php foreach ($errors as $error): ?><li><?php echo escape($error); ?></li><?php endforeach; ?></ul></div>
            <?php endif; ?>
                <form method="post" action="edit.php?id=<?php echo escape($id); ?>" class="entry-form form-panel">
                    <div class="row g-3">
                        <div class="col-6"><label for="input-fName">First Name</label><input type="text" name="fName" value="<?php echo escape($_POST['fName'] ?? $member['fName']); ?>" id="input-fName"></div>
                        <div class="col-6"><label for="input-lName">Last Name</label><input type="text" name="lName" value="<?php echo escape($_POST['lName'] ?? $member['lName']); ?>" id="input-lName"></div>
                        <div class="col-4"><label for="input-birthDate">Birth Date</label><input type="date" name="birthDate" value="<?php echo escape($_POST['birthDate'] ?? $member['birthDate']); ?>" id="input-birthDate"></div>
                        <div class="col-4"><label for="input-age">Age</label><input type="number" name="age" value="<?php echo escape($_POST['age'] ?? $member['age']); ?>" id="input-age"></div>
                        <div class="col-4"><label for="input-gender">Gender</label><select name="gender" id="input-gender"><option value="">Select</option><option value="Male" <?php echo ((($_POST['gender'] ?? $member['gender']) === 'Male') ? 'selected' : ''); ?>>Male</option><option value="Female" <?php echo ((($_POST['gender'] ?? $member['gender']) === 'Female') ? 'selected' : ''); ?>>Female</option></select></div>
                        <div class="col-6"><label for="input-contactNo">Contact Number</label><input type="text" name="contactNo" value="<?php echo escape($_POST['contactNo'] ?? $member['contactNo']); ?>" id="input-contactNo"></div>
                        <div class="col-6"><label for="input-discount">Discount Rate (%)</label><input type="number" step="0.01" name="discount" value="<?php echo escape($_POST['discount'] ?? $member['discount']); ?>" id="input-discount"></div>
                    </div>
                    <div class="mt-4 form-actions">
                        <button type="submit" class="button">Update Member</button>
                        <a href="index.php" class="button outline">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>
