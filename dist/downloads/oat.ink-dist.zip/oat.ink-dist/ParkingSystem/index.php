<?php
require_once __DIR__ . '/database.php';

$countE1 = $conn->query("SELECT COUNT(*) AS total FROM `vehicles`")->fetch_assoc()['total'] ?? 0;
$countE2 = $conn->query("SELECT COUNT(*) AS total FROM `parking_slots`")->fetch_assoc()['total'] ?? 0;
$countTr = $conn->query("SELECT COUNT(*) AS total FROM `parking_tickets`")->fetch_assoc()['total'] ?? 0;
$sumTotal = $conn->query("SELECT IFNULL(SUM(parkingFee), 0) AS total FROM `parking_tickets`")->fetch_assoc()['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Parking Slot & Ticketing Management System - Dashboard</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/navbar.php'; ?>

    <div class="container my-4">
        <div class="p-4 mb-4 rounded border">
            <h1 class="display-6 weight-bold mb-2">Smart Parking Slot & Ticketing Management System</h1>
            <p class="lead text-light mb-0">Universal College Capstone & Skills Test Management System</p>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Registered Vehicles</span>
                    <h2 class="weight-bold text-primary mb-2"><?= $countE1 ?></h2>
                    <a href="<?= $baseUrl ?>vehicles/index.php" class="button outline small">Manage Registered Vehicles </a>
                </div>
            </div>
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Parking Slots</span>
                    <h2 class="weight-bold text-success mb-2"><?= $countE2 ?></h2>
                    <a href="<?= $baseUrl ?>parking_slots/index.php" class="button outline success-action small">Manage Parking Slots </a>
                </div>
            </div>
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Parking Tickets</span>
                    <h2 class="weight-bold mb-2"><?= $countTr ?></h2>
                    <a href="<?= $baseUrl ?>parking_tickets/index.php" class="button outline small">View Parking Tickets </a>
                </div>
            </div>
            <div class="col-3">
                <div class="card p-3">
                    <span class="text-light small weight-semibold uppercase">Total Parking Revenue Collected</span>
                    <h2 class="weight-bold text-warning mb-2">₱<?= number_format((float)$sumTotal, 2) ?></h2>
                    <a href="<?= $baseUrl ?>monitoring/index.php" class="button outline small">View Analytics </a>
                </div>
            </div>
        </div>

        <div class="card p-4">
            <h4 class="weight-bold mb-3">Quick Actions</h4>
            <div class="form-actions">
                <a href="<?= $baseUrl ?>vehicles/add.php" class="button">+ Add New Vehicle</a>
                <a href="<?= $baseUrl ?>parking_slots/add.php" class="button success-action">+ Add New Parking Slot</a>
                <a href="<?= $baseUrl ?>parking_tickets/add.php" class="button outline">+ Record New Parking Ticket</a>
                <a href="<?= $baseUrl ?>monitoring/index.php" class="button outline">Generate Monitoring Report</a>
            </div>
        </div>
    </div>

    
</body>
</html>
