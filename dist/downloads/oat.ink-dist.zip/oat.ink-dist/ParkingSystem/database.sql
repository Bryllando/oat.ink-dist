CREATE DATABASE IF NOT EXISTS `parking_system_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `parking_system_db`;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `vehicles` (
  `vehicleID` INT AUTO_INCREMENT PRIMARY KEY,
  `plateNumber` VARCHAR(50) NOT NULL,
  `vehicleType` VARCHAR(50) NOT NULL,
  `ownerName` VARCHAR(100) NOT NULL,
  `contactNumber` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `parking_slots` (
  `slotID` INT AUTO_INCREMENT PRIMARY KEY,
  `slotNumber` VARCHAR(50) NOT NULL,
  `slotType` VARCHAR(100) NOT NULL,
  `hourlyRate` DECIMAL(10,2) NOT NULL,
  `floorLocation` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `parking_tickets` (
  `ticketID` INT AUTO_INCREMENT PRIMARY KEY,
  `vehicleID` INT NOT NULL,
  `slotID` INT NOT NULL,
  `timeIn` VARCHAR(50) NOT NULL,
  `timeOut` VARCHAR(50) NOT NULL,
  `hoursParked` DECIMAL(10,2) NOT NULL,
  `parkingFee` DECIMAL(10,2) NOT NULL,
  `paymentStatus` VARCHAR(50) DEFAULT 'Paid',
  FOREIGN KEY (`vehicleID`) REFERENCES `vehicles`(`vehicleID`) ON DELETE CASCADE,
  FOREIGN KEY (`slotID`) REFERENCES `parking_slots`(`slotID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `vehicles` (`plateNumber`, `vehicleType`, `ownerName`, `contactNumber`) VALUES
('NDG-8192', 'Sedan Car', 'Geraldine Santos', '09179988112'),
('MC-40112', 'Motorcycle', 'Raymund Cañeda', '09188877223'),
('TAB-7731', 'SUV / 4x4', 'Demetrio Villar', '09227766334');

INSERT INTO `parking_slots` (`slotNumber`, `slotType`, `hourlyRate`, `floorLocation`) VALUES
('SLOT-A01', 'Standard Car Covered', 40.0, 'Basement 1 Zone A'),
('SLOT-M05', 'Motorcycle Bay', 20.0, 'Ground Floor Zone C'),
('SLOT-VIP', 'VIP Reserved Wide', 80.0, 'Ground Floor Zone A');

INSERT INTO `parking_tickets` (`vehicleID`, `slotID`, `timeIn`, `timeOut`, `hoursParked`, `parkingFee`, `paymentStatus`) VALUES
(1, 1, '08:30 AM', '12:30 PM', 4.0, 160.0, 'Paid'),
(2, 2, '09:00 AM', '05:00 PM', 8.0, 160.0, 'Paid'),
(3, 3, '01:00 PM', '04:30 PM', 3.5, 280.0, 'Paid');

SET FOREIGN_KEY_CHECKS=1;
