<?php
require_once __DIR__ . '/../database.php';

$e1List = $conn->query("SELECT `vehicleID`, `plateNumber` FROM `vehicles` ORDER BY `plateNumber` ASC");
$e2List = $conn->query("SELECT `slotID`, `slotNumber` FROM `parking_slots` ORDER BY `slotNumber` ASC");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id1 = (int)($_POST['vehicleID'] ?? 0);
    $id2 = (int)($_POST['slotID'] ?? 0);
    $timeIn = is_string($_POST['timeIn'] ?? null) ? trim($_POST['timeIn']) : '';
    $timeOut = is_string($_POST['timeOut'] ?? null) ? trim($_POST['timeOut']) : '';
    $hoursParked = is_string($_POST['hoursParked'] ?? null) ? trim($_POST['hoursParked']) : '';
    $parkingFee = is_string($_POST['parkingFee'] ?? null) ? trim($_POST['parkingFee']) : '';
    $paymentStatus = is_string($_POST['paymentStatus'] ?? null) ? trim($_POST['paymentStatus']) : '';

    if ($timeIn === '' ||
        $timeOut === '' ||
        $hoursParked === '' ||
        !is_numeric($hoursParked) ||
        !is_finite((float)$hoursParked) ||
        (float)$hoursParked < 0 ||
        $parkingFee === '' ||
        !is_numeric($parkingFee) ||
        !is_finite((float)$parkingFee) ||
        (float)$parkingFee < 0 ||
        $paymentStatus === '' ||
        $id1 <= 0 ||
        $id2 <= 0) {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "INSERT INTO `parking_tickets` (`vehicleID`, `slotID`, `timeIn`, `timeOut`, `hoursParked`, `parkingFee`, `paymentStatus`) VALUES ('" . $conn->real_escape_string($id1) . "', '" . $conn->real_escape_string($id2) . "', '" . $conn->real_escape_string($timeIn) . "', '" . $conn->real_escape_string($timeOut) . "', '" . $conn->real_escape_string($hoursParked) . "', '" . $conn->real_escape_string($parkingFee) . "', '" . $conn->real_escape_string($paymentStatus) . "')";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to record transaction: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Parking Ticket - Smart Parking Slot & Ticketing Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 700px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Record New Parking Ticket</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                <div class="row g-3 mb-3">
                    <div class="col-6">
                        <label for="vehicleID" class="weight-semibold">Select Vehicle</label>
                        <select id="vehicleID" name="vehicleID" class="" required>
                            <option value="">-- Choose Vehicle --</option>
                            <?php while ($r = $e1List->fetch_assoc()): ?>
                                <option value="<?= $r['vehicleID'] ?>" <?= ((int)($_POST['vehicleID'] ?? 0) === (int)$r['vehicleID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['plateNumber']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-6">
                        <label for="slotID" class="weight-semibold">Select Parking Slot</label>
                        <select id="slotID" name="slotID" class="" required>
                            <option value="">-- Choose Parking Slot --</option>
                            <?php while ($r = $e2List->fetch_assoc()): ?>
                                <option value="<?= $r['slotID'] ?>" <?= ((int)($_POST['slotID'] ?? 0) === (int)$r['slotID']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r['slotNumber']) ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>

                
            <div class="mb-3">
                <label for="timeIn" class="weight-semibold">Time In</label>
                <input type="text" id="timeIn" name="timeIn" class=""  required value="<?= htmlspecialchars($timeIn ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="timeOut" class="weight-semibold">Time Out</label>
                <input type="text" id="timeOut" name="timeOut" class=""  required value="<?= htmlspecialchars($timeOut ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="hoursParked" class="weight-semibold">Total Hours</label>
                <input type="number" id="hoursParked" name="hoursParked" min="0" class="" step="0.01" required value="<?= htmlspecialchars($hoursParked ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="parkingFee" class="weight-semibold">Total Parking Fee</label>
                <input type="number" id="parkingFee" name="parkingFee" min="0" class="" step="0.01" required value="<?= htmlspecialchars($parkingFee ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="paymentStatus" class="weight-semibold">Payment Status</label>
                <input type="text" id="paymentStatus" name="paymentStatus" class=""  required value="<?= htmlspecialchars($paymentStatus ?? '') ?>">
            </div>


                <div class="form-actions">
                    <button type="submit" class="button">Save Parking Ticket</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
