<?php
require_once __DIR__ . '/../database.php';

$sql = "SELECT t.*, e1.plateNumber AS e1_title, e2.slotNumber AS e2_title 
        FROM `parking_tickets` t 
        JOIN `vehicles` e1 ON t.vehicleID = e1.vehicleID 
        JOIN `parking_slots` e2 ON t.slotID = e2.slotID 
        ORDER BY t.ticketID DESC";
$records = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Parking Tickets - Smart Parking Slot & Ticketing Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Manage Parking Tickets</h3>
            <a href="add.php" class="button">+ Record New Parking Ticket</a>
        </div>

        <div class="card">
            <div class="table-responsive">
                <table class="mb-0">
                    <thead class="">
                        <tr>
                            <th>#</th>
                            <th>Vehicle</th>
                            <th>Parking Slot</th>
                            <th>Time In</th>
<th>Time Out</th>
<th>Total Hours</th>
<th>Total Parking Fee</th>
<th>Payment Status</th>

                            <th class="align-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($records && $records->num_rows > 0): ?>
                            <?php while ($r = $records->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $r['ticketID'] ?></td>
                                    <td class="weight-bold"><?= htmlspecialchars($r['e1_title']) ?></td>
                                    <td><?= htmlspecialchars($r['e2_title']) ?></td>
                                    <td><?= htmlspecialchars($r['timeIn']) ?></td>
<td><?= htmlspecialchars($r['timeOut']) ?></td>
<td><?= htmlspecialchars($r['hoursParked']) ?></td>
<td><?= htmlspecialchars($r['parkingFee']) ?></td>
<td><?= htmlspecialchars($r['paymentStatus']) ?></td>

                                    <td class="align-right">
                                        <form method="POST" action="delete.php" class="inline-block" onsubmit="return confirm('Delete this record and any linked transactions?');">
                                            <input type="hidden" name="id" value="<?= $r['ticketID'] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                                            <button type="submit" class="button small outline danger-action">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" class="align-center py-4 text-light">No transaction records found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    
</body>
</html>
