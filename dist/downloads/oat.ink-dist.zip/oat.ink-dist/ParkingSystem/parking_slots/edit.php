<?php
require_once __DIR__ . '/../database.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: index.php");
    exit;
}

$res = $conn->query("SELECT * FROM `parking_slots` WHERE `slotID` = $id");
$record = $res ? $res->fetch_assoc() : null;
if (!$record) {
    die("Record not found.");
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $slotNumber = is_string($_POST['slotNumber'] ?? null) ? trim($_POST['slotNumber']) : '';
    $slotType = is_string($_POST['slotType'] ?? null) ? trim($_POST['slotType']) : '';
    $hourlyRate = is_string($_POST['hourlyRate'] ?? null) ? trim($_POST['hourlyRate']) : '';
    $floorLocation = is_string($_POST['floorLocation'] ?? null) ? trim($_POST['floorLocation']) : '';

    if ($slotNumber === '' ||
        $slotType === '' ||
        $hourlyRate === '' ||
        !is_numeric($hourlyRate) ||
        !is_finite((float)$hourlyRate) ||
        (float)$hourlyRate < 0 ||
        $floorLocation === '') {
        $error = "Check required fields, non-negative numbers, email addresses and date order.";
    } else {
        $sql = "UPDATE `parking_slots` SET `slotNumber` = '" . $conn->real_escape_string($slotNumber) . "', `slotType` = '" . $conn->real_escape_string($slotType) . "', `hourlyRate` = '" . $conn->real_escape_string($hourlyRate) . "', `floorLocation` = '" . $conn->real_escape_string($floorLocation) . "' WHERE `slotID` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php");
            exit;
        } else {
            $error = "Failed to update record: " . htmlspecialchars($conn->error);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/oat.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>assets/css/app.css">
    <script src="<?= $baseUrl ?>assets/js/oat.min.js" defer></script>
    <script src="<?= $baseUrl ?>assets/js/app.js" defer></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Parking Slot - Smart Parking Slot & Ticketing Management System</title>
    
    
</head>
<body>
    <?php include __DIR__ . '/../navbar.php'; ?>

    <div class="container my-4" style="max-width: 650px;">
        <div class="flex justify-between items-center mb-3">
            <h3 class="weight-bold mb-0">Edit Parking Slot</h3>
            <a href="index.php" class="button outline small"> Back to List</a>
        </div>

        <?php if ($error): ?>
            <div role="alert" class="notice notice-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="card p-4">
            <form method="POST" class="entry-form">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                
            <div class="mb-3">
                <label for="slotNumber" class="weight-semibold">Slot Code</label>
                <input type="text" id="slotNumber" name="slotNumber" class=""  required value="<?= htmlspecialchars($record['slotNumber'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="slotType" class="weight-semibold">Slot Classification</label>
                <input type="text" id="slotType" name="slotType" class=""  required value="<?= htmlspecialchars($record['slotType'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="hourlyRate" class="weight-semibold">Hourly Rate</label>
                <input type="number" id="hourlyRate" name="hourlyRate" min="0" class="" step="0.01" required value="<?= htmlspecialchars($record['hourlyRate'] ?? '') ?>">
            </div>

            <div class="mb-3">
                <label for="floorLocation" class="weight-semibold">Floor / Zone</label>
                <input type="text" id="floorLocation" name="floorLocation" class=""  required value="<?= htmlspecialchars($record['floorLocation'] ?? '') ?>">
            </div>

                <div class="form-actions">
                    <button type="submit" class="button">Update Parking Slot</button>
                    <a href="index.php" class="button outline">Cancel</a>
                </div>
            </form>
        </div>
    </div>

    
</body>
</html>
