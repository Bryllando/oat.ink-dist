<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav surface-muted mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Smart Parking Slot & Ticketing Management System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'vehicles') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>vehicles/index.php">Registered Vehicles</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'parking_slots') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>parking_slots/index.php">Parking Slots</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'parking_tickets') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>parking_tickets/index.php">Parking Tickets</a>
                </li>
                <li class="">
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Monitoring Report</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
