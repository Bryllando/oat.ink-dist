<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM customers WHERE customerID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$c = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['customerName']);
    $table = trim($_POST['tableNumber']);
    $contact = trim($_POST['customerContact']);

    $stmt = $conn->prepare("UPDATE customers SET customerName=?, tableNumber=?, customerContact=? WHERE customerID=?");
    $stmt->bind_param("sssi", $name, $table, $contact, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Edit Customer</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 600px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Edit Customer / Table</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="field-grid">
                        <div class="mb-3">
                            <label for="input-customerName">Customer Name</label>
                            <input type="text" name="customerName" required value="<?php echo htmlspecialchars($c['customerName']); ?>" id="input-customerName">
                        </div>
                        <div class="mb-3">
                            <label for="input-tableNumber">Table Number / Dining Mode</label>
                            <input type="text" name="tableNumber" required value="<?php echo htmlspecialchars($c['tableNumber']); ?>" id="input-tableNumber">
                        </div>
                        <div class="mb-3">
                            <label for="input-customerContact">Contact Number</label>
                            <input type="text" name="customerContact" value="<?php echo htmlspecialchars($c['customerContact']); ?>" id="input-customerContact">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button outline w-100">Update Record</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to List</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>