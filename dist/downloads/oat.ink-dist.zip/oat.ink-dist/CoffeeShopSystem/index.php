<?php
require_once 'database.php';

$totalItems = $conn->query("SELECT COUNT(*) FROM menu_items")->fetch_row()[0];
$totalCustomers = $conn->query("SELECT COUNT(*) FROM customers")->fetch_row()[0];
$totalOrders = $conn->query("SELECT COUNT(*) FROM orders")->fetch_row()[0];
$totalSales = $conn->query("SELECT IFNULL(SUM(totalAmount), 0) FROM orders")->fetch_row()[0];
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Coffee Shop Order System - Dashboard</title>
    
    
    </head>
    <body>
    <?php include 'navbar.php'; ?>
        <main class="container">
            <h1 class="page-title">Coffee Shop System</h1>
            <h2>Summary</h2>
            <div class="stats-grid">
                <div class="stat-card"><span class="stat-label">Menu items</span><strong class="stat-value"><?= $totalItems ?></strong></div>
                <div class="stat-card"><span class="stat-label">Customers</span><strong class="stat-value"><?= $totalCustomers ?></strong></div>
                <div class="stat-card"><span class="stat-label">Orders</span><strong class="stat-value"><?= $totalOrders ?></strong></div>
                <div class="stat-card"><span class="stat-label">Sales</span><strong class="stat-value"><?= 'PHP ' . number_format($totalSales, 2) ?></strong></div>
            </div>
            <h2 class="mt-3">Menu</h2>
            <ul class="simple-menu">
                <li><a href="menu_items/index.php">Menu Items</a></li>
                <li><a href="customers/index.php">Customers</a></li>
                <li><a href="orders/index.php">Orders</a></li>
                <li><a href="monitoring/index.php">Reports</a></li>
            </ul>
        </main>
    </body>
</html>
