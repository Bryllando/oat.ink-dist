<?php
require_once '../database.php';
$msg = '';

$items = $conn->query("SELECT * FROM menu_items WHERE status = 'Available' ORDER BY itemName ASC");
$customers = $conn->query("SELECT * FROM customers ORDER BY customerName ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemID = intval($_POST['itemID']);
    $custID = intval($_POST['customerID']);
    $oDate = trim($_POST['orderDate']);
    $qty = intval($_POST['quantity']);
    $mode = trim($_POST['paymentMode']);

    // Fetch unit price
    $iRow = $conn->query("SELECT unitPrice FROM menu_items WHERE itemID = $itemID")->fetch_assoc();
    $price = $iRow ? floatval($iRow['unitPrice']) : 0;
    $totalAmount = $qty * $price;

    if ($itemID && $custID && $qty > 0) {
        $stmt = $conn->prepare("INSERT INTO orders (itemID, customerID, orderDate, quantity, totalAmount, paymentMode) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisids", $itemID, $custID, $oDate, $qty, $totalAmount, $mode);
        if ($stmt->execute()) {
            header("Location: index.php?msg=ordered");
            exit;
        } else {
            $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Place Order</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 650px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Place New Cafe Order</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="mb-3">
                        <label for="input-itemID">Select Menu Item</label>
                        <select name="itemID" required id="input-itemID">
                            <option value="">-- Choose Item --</option>
                        <?php while($item = $items->fetch_assoc()): ?>
                            <option value="<?php echo $item['itemID']; ?>">
                            <?php echo htmlspecialchars($item['itemName'] . ' (' . $item['itemCategory'] . ') - ₱' . number_format($item['unitPrice'], 2)); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="input-customerID">Select Customer / Table</label>
                        <select name="customerID" required id="input-customerID">
                            <option value="">-- Choose Customer / Table --</option>
                        <?php while($c = $customers->fetch_assoc()): ?>
                            <option value="<?php echo $c['customerID']; ?>">
                            <?php echo htmlspecialchars($c['customerName'] . ' [' . $c['tableNumber'] . ']'); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6">
                            <label for="input-orderDate">Order Date</label>
                            <input type="date" name="orderDate" required value="<?php echo date('Y-m-d'); ?>" id="input-orderDate">
                        </div>
                        <div class="col-6">
                            <label for="input-quantity">Quantity</label>
                            <input type="number" name="quantity" required min="1" value="1" id="input-quantity">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="input-paymentMode">Payment Mode</label>
                        <select name="paymentMode" id="input-paymentMode">
                            <option value="Cash">Cash</option>
                            <option value="GCash">GCash</option>
                            <option value="Credit Card">Credit Card</option>
                        </select>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button w-100">Charge Order</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to Orders</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>