<?php
require_once '../database.php';

$query = "SELECT o.*, m.itemName, m.itemCategory, m.unitPrice, c.customerName, c.tableNumber 
          FROM orders o
          JOIN menu_items m ON o.itemID = m.itemID
          JOIN customers c ON o.customerID = c.customerID
          ORDER BY o.orderID DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Customer Orders</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Customer Orders (Point of Sale)</h1>
                <a href="add.php" class="button">+ Place New Order</a>
            </div>
            <div class="card card-surface p-0">
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Menu Item</th>
                            <th>Customer / Table</th>
                            <th>Date</th>
                            <th>Qty</th>
                            <th>Total Paid</th>
                            <th>Payment Mode</th>
                            <th class="align-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $row['orderID']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($row['itemName']); ?></strong>
                                <small class="text-light block"><?php echo htmlspecialchars($row['itemCategory']); ?> (₱<?php echo number_format($row['unitPrice'], 2); ?>)</small>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($row['customerName']); ?>
                                <span class="badge text-dark border block"><?php echo htmlspecialchars($row['tableNumber']); ?></span>
                            </td>
                            <td><?php echo $row['orderDate']; ?></td>
                            <td><?php echo $row['quantity']; ?> pc(s)</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalAmount'], 2); ?></strong></td>
                            <td><span class="badge surface-muted text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                            <td class="align-right">
                                <a href="delete.php?id=<?php echo $row['orderID']; ?>" class="button small danger-action" onclick="return confirm('Cancel/Void order?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="8" class="align-center py-4 text-light">No orders processed yet.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>