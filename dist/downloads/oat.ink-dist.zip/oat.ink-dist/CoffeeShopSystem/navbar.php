<?php
$currentUri = $_SERVER['REQUEST_URI'];
?>
<nav class="app-nav mb-4">
    <div class="container">
        <a class="app-brand weight-bold" href="<?php echo $baseUrl; ?>index.php">Coffee Shop Order System</a>
        
        <div class="nav-region" id="navMenu">
            <ul class="nav-links ms-auto mb-2">
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'menu_items') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>menu_items/index.php">Menu Items</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'customers') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>customers/index.php">Customers & Tables</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'orders') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>orders/index.php">Point of Sale (Orders)</a>
                </li>
                <li>
                    <a class="nav-link <?php echo (strpos($currentUri, 'monitoring') !== false) ? 'active' : ''; ?>" href="<?php echo $baseUrl; ?>monitoring/index.php">Sales Monitoring</a>
                </li>
            </ul>
        </div>
    </div>
</nav>