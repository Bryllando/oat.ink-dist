<?php
require_once '../database.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['itemName']);
    $cat = trim($_POST['itemCategory']);
    $price = floatval($_POST['unitPrice']);
    $status = trim($_POST['status']);

    if ($name && $price > 0) {
        $stmt = $conn->prepare("INSERT INTO menu_items (itemName, itemCategory, unitPrice, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssds", $name, $cat, $price, $status);
        if ($stmt->execute()) {
            header("Location: index.php?msg=added");
            exit;
        } else {
            $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Add Menu Item</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 600px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Add New Menu Item</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="field-grid">
                        <div class="mb-3">
                            <label for="input-itemName">Item Name</label>
                            <input type="text" name="itemName" required placeholder="e.g. Vanilla Cold Brew" id="input-itemName">
                        </div>
                        <div class="mb-3">
                            <label for="input-itemCategory">Category</label>
                            <select name="itemCategory" required id="input-itemCategory">
                                <option value="Hot Coffee">Hot Coffee</option>
                                <option value="Iced Drinks">Iced Drinks</option>
                                <option value="Pastries">Pastries</option>
                                <option value="Sandwiches & Snacks">Sandwiches & Snacks</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="input-unitPrice">Retail Unit Price (₱)</label>
                            <input type="number" step="0.01" name="unitPrice" required placeholder="140.00" id="input-unitPrice">
                        </div>
                        <div class="mb-3">
                            <label for="input-status">Availability Status</label>
                            <select name="status" id="input-status">
                                <option value="Available">Available</option>
                                <option value="Out of Stock">Out of Stock</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button w-100">Save Item</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to List</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>