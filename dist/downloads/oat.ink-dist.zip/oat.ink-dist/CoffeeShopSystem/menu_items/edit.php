<?php
require_once '../database.php';
$id = intval($_GET['id'] ?? 0);
$res = $conn->query("SELECT * FROM menu_items WHERE itemID = $id");
if (!$res || $res->num_rows === 0) {
    header("Location: index.php");
    exit;
}
$item = $res->fetch_assoc();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['itemName']);
    $cat = trim($_POST['itemCategory']);
    $price = floatval($_POST['unitPrice']);
    $status = trim($_POST['status']);

    $stmt = $conn->prepare("UPDATE menu_items SET itemName=?, itemCategory=?, unitPrice=?, status=? WHERE itemID=?");
    $stmt->bind_param("ssdsi", $name, $cat, $price, $status, $id);
    if ($stmt->execute()) {
        header("Location: index.php?msg=updated");
        exit;
    } else {
        $msg = "<div role='alert' class='notice notice-danger'>Error: " . $stmt->error . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Edit Menu Item</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container form-page" style="max-width: 600px;">
            <div class="card p-4 card-surface">
                <h1 class="page-title">Edit Menu Item</h1>
            <?php echo $msg; ?>
                <form method="POST" class="entry-form">
                    <div class="field-grid">
                        <div class="mb-3">
                            <label for="input-itemName">Item Name</label>
                            <input type="text" name="itemName" required value="<?php echo htmlspecialchars($item['itemName']); ?>" id="input-itemName">
                        </div>
                        <div class="mb-3">
                            <label for="input-itemCategory">Category</label>
                            <select name="itemCategory" required id="input-itemCategory">
                        <?php foreach(['Hot Coffee', 'Iced Drinks', 'Pastries', 'Sandwiches & Snacks'] as $c): ?>
                                <option value="<?php echo $c; ?>" <?php echo $item['itemCategory'] === $c ? 'selected' : ''; ?>><?php echo $c; ?></option>
                        <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="input-unitPrice">Retail Unit Price (₱)</label>
                            <input type="number" step="0.01" name="unitPrice" required value="<?php echo $item['unitPrice']; ?>" id="input-unitPrice">
                        </div>
                        <div class="mb-3">
                            <label for="input-status">Availability Status</label>
                            <select name="status" id="input-status">
                                <option value="Available" <?php echo $item['status'] === 'Available' ? 'selected' : ''; ?>>Available</option>
                                <option value="Out of Stock" <?php echo $item['status'] === 'Out of Stock' ? 'selected' : ''; ?>>Out of Stock</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="button outline w-100">Update Item</button>
                        <a href="index.php" class="button ghost w-100 text-light mt-2">Back to List</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>