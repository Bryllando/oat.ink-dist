<?php
require_once '../database.php';
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $stmt = $conn->prepare("SELECT * FROM menu_items WHERE itemName LIKE ? OR itemCategory LIKE ? ORDER BY itemID DESC");
    $param = "%$search%";
    $stmt->bind_param("ss", $param, $param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM menu_items ORDER BY itemID DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Menu Items</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <h1 class="page-title">Menu Item Management</h1>
                <a href="add.php" class="button">Add New Item</a>
            </div>
            <div class="card p-3 card-surface mb-3">
                <form method="GET" class="row g-2 filter-form">
                    <div class="col-10">
                        <input type="text" name="search" placeholder="Search by item name or category..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="col-2 filter-actions">
                        <button type="submit" class="button outline ">Search</button>
                        <a class="button outline" href="index.php">Clear</a></div>
            
                </form>
            </div>
            <div class="card card-surface p-0">
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Item Name</th>
                            <th>Category</th>
                            <th>Unit Price</th>
                            <th>Status</th>
                            <th class="align-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['itemID']; ?></td>
                            <td><strong><?php echo htmlspecialchars($row['itemName']); ?></strong></td>
                            <td><span class="badge surface-muted"><?php echo htmlspecialchars($row['itemCategory']); ?></span></td>
                            <td>₱<?php echo number_format($row['unitPrice'], 2); ?></td>
                            <td><span class="badge <?php echo $row['status'] === 'Available' ? 'status-success' : 'status-danger'; ?>"><?php echo htmlspecialchars($row['status']); ?></span></td>
                            <td class="align-right">
                                <a href="edit.php?id=<?php echo $row['itemID']; ?>" class="button small outline">Edit</a>
                                <a href="delete.php?id=<?php echo $row['itemID']; ?>" class="button small danger-action" onclick="return confirm('Delete item?');">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="align-center py-4 text-light">No menu items found.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>