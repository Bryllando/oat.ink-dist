<?php
require_once '../database.php';

$catResult = $conn->query("SELECT DISTINCT itemCategory FROM menu_items ORDER BY itemCategory ASC");
$filterCat = trim($_GET['category'] ?? '');

if ($filterCat !== '') {
    $stmt = $conn->prepare("SELECT o.*, m.itemName, m.itemCategory, m.unitPrice, c.customerName, c.tableNumber 
                            FROM orders o
                            JOIN menu_items m ON o.itemID = m.itemID
                            JOIN customers c ON o.customerID = c.customerID
                            WHERE m.itemCategory = ?
                            ORDER BY o.orderDate DESC");
    $stmt->bind_param("s", $filterCat);
    $stmt->execute();
    $records = $stmt->get_result();

    $aggStmt = $conn->prepare("SELECT COUNT(*) AS total_orders, IFNULL(SUM(quantity), 0) AS total_items, IFNULL(SUM(totalAmount), 0) AS total_revenue 
                               FROM orders o
                               JOIN menu_items m ON o.itemID = m.itemID
                               WHERE m.itemCategory = ?");
    $aggStmt->bind_param("s", $filterCat);
    $aggStmt->execute();
    $agg = $aggStmt->get_result()->fetch_assoc();
    $filterLabel = $filterCat;
} else {
    $records = $conn->query("SELECT o.*, m.itemName, m.itemCategory, m.unitPrice, c.customerName, c.tableNumber 
                             FROM orders o
                             JOIN menu_items m ON o.itemID = m.itemID
                             JOIN customers c ON o.customerID = c.customerID
                             ORDER BY o.orderDate DESC");
    $agg = $conn->query("SELECT COUNT(*) AS total_orders, IFNULL(SUM(quantity), 0) AS total_items, IFNULL(SUM(totalAmount), 0) AS total_revenue FROM orders")->fetch_assoc();
    $filterLabel = "All Categories";
}

$countOrders = $agg['total_orders'] ?? 0;
$totalItemsSold = $agg['total_items'] ?? 0;
$sumRevenue = $agg['total_revenue'] ?? 0.00;
$avgTicket = ($countOrders > 0) ? round($sumRevenue / $countOrders, 2) : 0.00;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title>Sales Monitoring Report</title>
    
    
    </head>
    <body>
    <?php include '../navbar.php'; ?>
        <div class="container">
            <div class="flex justify-between items-center mb-3">
                <div>
                    <h1 class="mb-0 page-title">Category Sales Monitoring Report</h1>
                </div>
                <a href="index.php" class="button outline small">Reset Filter</a>
            </div>

        <!-- Filter Card -->
            <div class="card p-3 card-surface mb-4">
                <form method="GET" class="row g-2 items-center filter-form">
                    <div class="auto-col">
                        <label class="mb-0 weight-semibold">Filter by Category:</label>
                    </div>
                    <div class="col-5">
                        <select name="category" onchange="this.form.submit()">
                            <option value="">-- All Categories --</option>
                        <?php while($cat = $catResult->fetch_assoc()): ?>
                            <option value="<?php echo htmlspecialchars($cat['itemCategory']); ?>" <?php echo $filterCat === $cat['itemCategory'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['itemCategory']); ?>
                            </option>
                        <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="auto-col filter-actions">
                        <button type="submit" class="button">Filter</button>
                        <a class="button outline" href="index.php">Clear</a></div>
            
                </form>
            </div>

        <!-- 3 Required KPI Cards -->
            <div class="row g-3 mb-4">
                <div class="col-4">
                    <div class="card p-3 card-surface stat-card">
                        <span class="text-light small weight-semibold">a. Total Orders Placed (count)</span>
                        <h2 class="text-primary mb-0"><?php echo $countOrders; ?> <small class="text-light fs-6">Orders (<?php echo $totalItemsSold; ?> Items)</small></h2>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card p-3 card-surface stat-card success">
                        <span class="text-light small weight-semibold">b. Total Sales Revenue (sum)</span>
                        <h2 class="text-success mb-0">₱<?php echo number_format($sumRevenue, 2); ?></h2>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card p-3 card-surface stat-card warning">
                        <span class="text-light small weight-semibold">c. Average Spend per Order (formula)</span>
                        <h2 class="text-warning mb-0">₱<?php echo number_format($avgTicket, 2); ?> <small class="text-light fs-6">Avg / Table</small></h2>
                    </div>
                </div>
            </div>

        <!-- Table displaying filtered records -->
            <div class="card card-surface p-0">
                <div class="card-header py-3">
                    <h5 class="mb-0">Sales Orders for: <span class="badge surface-muted"><?php echo htmlspecialchars($filterLabel); ?></span></h5>
                </div>
                <table class="mb-0">
                    <thead>
                        <tr>
                            <th>Menu Item</th>
                            <th>Category</th>
                            <th>Customer / Table</th>
                            <th>Date</th>
                            <th>Qty</th>
                            <th>Total Paid</th>
                            <th>Payment Mode</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($records && $records->num_rows > 0): ?>
                        <?php while($row = $records->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($row['itemName']); ?></strong></td>
                            <td><span class="badge surface-muted"><?php echo htmlspecialchars($row['itemCategory']); ?></span></td>
                            <td><?php echo htmlspecialchars($row['customerName']); ?> (<?php echo htmlspecialchars($row['tableNumber']); ?>)</td>
                            <td><?php echo $row['orderDate']; ?></td>
                            <td><?php echo $row['quantity']; ?> pc(s)</td>
                            <td><strong class="text-success">₱<?php echo number_format($row['totalAmount'], 2); ?></strong></td>
                            <td><span class="badge surface-muted text-dark"><?php echo htmlspecialchars($row['paymentMode']); ?></span></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="align-center py-4 text-light">No sales orders found for this category.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    </body>
</html>