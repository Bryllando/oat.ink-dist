<?php
mysqli_report(MYSQLI_REPORT_OFF);
$db_host = '127.0.0.1';
$db_user = 'root';
$db_pass = '';
$db_name = 'event_registration';

$conn = @mysqli_connect($db_host, $db_user, $db_pass);
if (!$conn) {
    die('Database connection failed: ' . htmlspecialchars(mysqli_connect_error()));
}

// Auto-create database if not exists
mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS `{$db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci") or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));
mysqli_select_db($conn, $db_name) or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));
mysqli_set_charset($conn, 'utf8mb4') or die('Database setup failed: ' . htmlspecialchars(mysqli_error($conn)));

// Auto-create tables and sample data if tables don't exist yet
$tables = $conn->query("SHOW TABLES");
if (!$tables) die('Database setup failed: ' . htmlspecialchars($conn->error));

// Import sample data only into an empty installation; existing records stay intact.
if ($tables->num_rows === 0) {
    $schemaFile = __DIR__ . '/../database/event_registration.sql';
    $sql = @file_get_contents($schemaFile);
    if ($sql === false) die('Database setup failed: cannot read the SQL file.');
    $conn->multi_query("SET FOREIGN_KEY_CHECKS=0;\n" . $sql . "\nSET FOREIGN_KEY_CHECKS=1;") or die('Database setup failed: ' . htmlspecialchars($conn->error));
    do {
        if ($result = $conn->store_result()) $result->free();
    } while ($conn->more_results() && $conn->next_result());
    if ($conn->errno) die('Database setup failed: ' . htmlspecialchars($conn->error));
}

// shortcut: project must be inside the web root; use an explicit URL for Apache aliases.
$docRoot = rtrim(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'])), '/');
$projectDir = str_replace('\\', '/', dirname(__DIR__));
$base_url = substr($projectDir, strlen($docRoot)) . '/';
?>
