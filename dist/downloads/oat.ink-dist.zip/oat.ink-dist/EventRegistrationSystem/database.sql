-- Event Registration database schema
CREATE DATABASE IF NOT EXISTS `event_registration` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `event_registration`;

CREATE TABLE IF NOT EXISTS `events` (
  `evCode` INT NOT NULL AUTO_INCREMENT,
  `evName` VARCHAR(255) NOT NULL,
  `evDate` DATE NOT NULL,
  `evVenue` VARCHAR(255) NOT NULL,
  `evRFee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`evCode`)
);

CREATE TABLE IF NOT EXISTS `participants` (
  `partID` INT NOT NULL AUTO_INCREMENT,
  `evCode` INT NOT NULL,
  `partFName` VARCHAR(100) NOT NULL,
  `partLName` VARCHAR(100) NOT NULL,
  `partDRate` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`partID`),
  KEY `fk_part_event` (`evCode`),
  CONSTRAINT `fk_part_event` FOREIGN KEY (`evCode`) REFERENCES `events` (`evCode`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS `registration` (
  `regCode` INT NOT NULL AUTO_INCREMENT,
  `partID` INT NOT NULL,
  `regDate` DATE NOT NULL,
  `regFeePaid` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `regPMode` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`regCode`),
  KEY `fk_reg_part` (`partID`),
  CONSTRAINT `fk_reg_part` FOREIGN KEY (`partID`) REFERENCES `participants` (`partID`) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Sample data
INSERT INTO `events` (`evName`,`evDate`,`evVenue`,`evRFee`) VALUES
('Web Dev Workshop','2024-10-29','Main Hall',100.00),
('Mobile Apps Seminar','2024-11-10','Auditorium',150.00);

INSERT INTO `participants` (`evCode`,`partFName`,`partLName`,`partDRate`) VALUES
(1,'Alice','Garcia',10.00),
(1,'Bob','Santos',0.00),
(2,'Carol','Reyes',5.00);
