<?php
require_once __DIR__ . '/../config/database.php';
$partID = isset($_GET['partID']) ? intval($_GET['partID']) : 0;
if ($partID) {
    mysqli_query($conn, "DELETE FROM participants WHERE partID={$partID}");
}
header('Location: index.php');
exit;
