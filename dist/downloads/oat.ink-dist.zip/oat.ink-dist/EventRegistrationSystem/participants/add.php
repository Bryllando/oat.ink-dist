<?php
require_once __DIR__ . '/../config/database.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $evCode = intval($_POST['evCode']);
    $partFName = mysqli_real_escape_string($conn, $_POST['partFName']);
    $partLName = mysqli_real_escape_string($conn, $_POST['partLName']);
    $partDRate = floatval($_POST['partDRate']);
    $sql = "INSERT INTO participants (evCode,partFName,partLName,partDRate) VALUES ({$evCode},'{$partFName}','{$partLName}',{$partDRate})";
    mysqli_query($conn, $sql);
    header('Location: index.php');
    exit;
}
$events = mysqli_query($conn, "SELECT evCode, evName FROM events ORDER BY evName");
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Add Participant</title>
    </head>
    <body>
        <nav class="app-nav">
            <div class="container-fluid">
                <a class="app-brand nav-brand" href="<?php echo $base_url; ?>index.php">Event Registration</a>
      
                <div class="nav-region" id="navbarNav">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link" href="<?php echo $base_url; ?>events/index.php">Events</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>participants/index.php">Participants</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>registration/index.php">Registrations</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>reports/monitoring.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container form-page">
            <div class="site-hero mt-3 mb-4 p-3">
                <h1 class="page-title">Add Participant</h1>
                <p class="muted">Add a participant to an event.</p>
            </div>

            <div class="card-surface">
                <form method="post" class="entry-form">
                    <div class="field-grid">
                        <div class="mb-3">
                            <label for="input-evCode">Event</label>
                            <select name="evCode" required id="input-evCode">
            <?php while ($e = mysqli_fetch_assoc($events)) echo '<option value="'.$e['evCode'].'">'.$e['evName'].'</option>'; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="input-partFName">First Name</label>
                            <input name="partFName" required id="input-partFName">
                        </div>
                        <div class="mb-3">
                            <label for="input-partLName">Last Name</label>
                            <input name="partLName" required id="input-partLName">
                        </div>
                        <div class="mb-3">
                            <label for="input-partDRate">Discount Rate</label>
                            <input type="number" step="0.01" name="partDRate" required id="input-partDRate">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button class="button">Save</button>
                        <a href="index.php" class="button outline ms-2">Cancel</a>
                    </div>
                </form>
            </div>

            <div class="app-footer">Use the navigation above to move between screens.</div>
        </div>

  
    </body>
</html>
