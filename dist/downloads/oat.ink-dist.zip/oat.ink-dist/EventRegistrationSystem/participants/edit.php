<?php
require_once __DIR__ . '/../config/database.php';
$partID = isset($_GET['partID']) ? intval($_GET['partID']) : 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $evCode = intval($_POST['evCode']);
    $partFName = mysqli_real_escape_string($conn, $_POST['partFName']);
    $partLName = mysqli_real_escape_string($conn, $_POST['partLName']);
    $partDRate = floatval($_POST['partDRate']);
    $sql = "UPDATE participants SET evCode={$evCode}, partFName='{$partFName}', partLName='{$partLName}', partDRate={$partDRate} WHERE partID={$partID}";
    mysqli_query($conn, $sql);
    header('Location: index.php');
    exit;
}
$res = mysqli_query($conn, "SELECT * FROM participants WHERE partID={$partID}");
$participant = mysqli_fetch_assoc($res);
$events = mysqli_query($conn, "SELECT evCode, evName FROM events ORDER BY evName");
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Edit Participant</title>
    </head>
    <body>
        <nav class="app-nav">
            <div class="container-fluid">
                <a class="app-brand nav-brand" href="<?php echo $base_url; ?>index.php">Event Registration</a>
      
                <div class="nav-region" id="navbarNav">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link" href="<?php echo $base_url; ?>events/index.php">Events</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>participants/index.php">Participants</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>registration/index.php">Registrations</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>reports/monitoring.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container form-page">
            <div class="site-hero mt-3 mb-4 p-3">
                <h1 class="page-title">Edit Participant</h1>
                <p class="muted">Modify participant details.</p>
            </div>

            <div class="card-surface">
      <?php if ($participant): ?>
                <form method="post" class="entry-form">
                    <div class="field-grid">
                        <div class="mb-3">
                            <label for="input-evCode">Event</label>
                            <select name="evCode" required id="input-evCode">
            <?php while ($e = mysqli_fetch_assoc($events)) {
              $sel = ($e['evCode']==$participant['evCode'])? ' selected':'';
              echo '<option value="'.$e['evCode'].'"'.$sel.'>'.$e['evName'].'</option>';
            } ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="input-partFName">First Name</label>
                            <input name="partFName" value="<?php echo htmlspecialchars($participant['partFName']); ?>" required id="input-partFName">
                        </div>
                        <div class="mb-3">
                            <label for="input-partLName">Last Name</label>
                            <input name="partLName" value="<?php echo htmlspecialchars($participant['partLName']); ?>" required id="input-partLName">
                        </div>
                        <div class="mb-3">
                            <label for="input-partDRate">Discount Rate</label>
                            <input type="number" step="0.01" name="partDRate" value="<?php echo $participant['partDRate']; ?>" required id="input-partDRate">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button class="button">Update</button>
                        <a href="index.php" class="button outline ms-2">Cancel</a>
                    </div>
                </form>
      <?php else: ?>
                <div role="alert" class="notice notice-warning">Participant not found.</div>
      <?php endif; ?>
            </div>

            <div class="app-footer">Use the navigation above to move between screens.</div>
        </div>

  
    </body>
</html>
