<?php
require_once __DIR__ . '/../config/database.php';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Participants</title>
    </head>
    <body>
        <nav class="app-nav">
            <div class="container-fluid">
                <a class="app-brand nav-brand" href="<?php echo $base_url; ?>index.php">Event Registration</a>
      
                <div class="nav-region" id="navbarNav">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link" href="<?php echo $base_url; ?>events/index.php">Events</a></li>
                        <li><a class="nav-link active" href="<?php echo $base_url; ?>participants/index.php">Participants</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>registration/index.php">Registrations</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>reports/monitoring.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="site-hero mt-3 mb-4 p-3">
                <h1 class="page-title">Participants</h1>
            </div>

            <div class="card-surface mb-3">
                <a href="add.php" class="button mb-3">Add Participant</a>
                <a href="search.php" class="button outline mb-3 ms-2">Search</a>
  <?php
  $res = mysqli_query($conn, "SELECT p.*, e.evName FROM participants p LEFT JOIN events e USING(evCode) ORDER BY partID DESC");
  if ($res && mysqli_num_rows($res) > 0) {
    echo '<table><thead><tr><th>ID</th><th>Event</th><th>First</th><th>Last</th><th>Discount</th><th>Actions</th></tr></thead><tbody>';
    while ($row = mysqli_fetch_assoc($res)) {
      echo '<tr>';
      echo '<td>'.$row['partID'].'</td>';
      echo '<td>'.$row['evName'].'</td>';
      echo '<td>'.$row['partFName'].'</td>';
      echo '<td>'.$row['partLName'].'</td>';
      echo '<td>'.$row['partDRate'].'</td>';
      echo '<td><a class="button small outline me-1" href="edit.php?partID='.$row['partID'].'">Edit</a>';
      echo '<a class="button small danger-action" href="delete.php?partID='.$row['partID'].'" onclick="return confirm(\'Delete this participant?\')">Delete</a></td>';
      echo '</tr>';
    }
    echo '</tbody></table>';
  } else {
    echo '<div role="alert" class="notice notice-info">No participants found.</div>';
  }
  ?>
            </div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
