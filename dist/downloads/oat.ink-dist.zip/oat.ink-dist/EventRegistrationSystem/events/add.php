<?php
require_once __DIR__ . '/../config/database.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $evName = mysqli_real_escape_string($conn, $_POST['evName']);
    $evDate = mysqli_real_escape_string($conn, $_POST['evDate']);
    $evVenue = mysqli_real_escape_string($conn, $_POST['evVenue']);
    $evRFee = floatval($_POST['evRFee']);
    $sql = "INSERT INTO events (evName,evDate,evVenue,evRFee) VALUES ('{$evName}','{$evDate}','{$evVenue}',{$evRFee})";
    mysqli_query($conn, $sql);
    header('Location: index.php');
    exit;
}
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Add Event</title>
    </head>
    <body>
        <nav class="app-nav">
            <div class="container-fluid">
                <a class="app-brand nav-brand" href="<?php echo $base_url; ?>index.php">Event Registration</a>
      
                <div class="nav-region" id="navbarNav">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link" href="<?php echo $base_url; ?>events/index.php">Events</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>participants/index.php">Participants</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>registration/index.php">Registrations</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>reports/monitoring.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container form-page">
            <div class="site-hero mt-3 mb-4 p-3">
                <h1 class="page-title">Add Event</h1>
                <p class="muted">Create a new event record.</p>
            </div>

            <div class="card-surface">
                <form method="post" class="entry-form">
                    <div class="field-grid">
                        <div class="mb-3">
                            <label for="input-evName">Event Name</label>
                            <input name="evName" required id="input-evName">
                        </div>
                        <div class="mb-3">
                            <label for="input-evDate">Event Date</label>
                            <input type="date" name="evDate" required id="input-evDate">
                        </div>
                        <div class="mb-3">
                            <label for="input-evVenue">Venue</label>
                            <input name="evVenue" required id="input-evVenue">
                        </div>
                        <div class="mb-3">
                            <label for="input-evRFee">Registration Fee</label>
                            <input type="number" step="0.01" name="evRFee" required id="input-evRFee">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button class="button">Save</button>
                        <a href="index.php" class="button outline ms-2">Cancel</a>
                    </div>
                </form>
            </div>

            <div class="app-footer">Use the navigation above to move between screens.</div>
        </div>

  
    </body>
</html>
