<?php
require_once __DIR__ . '/../config/database.php';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Events</title>
    </head>
    <body>
        <nav class="app-nav">
            <div class="container-fluid">
                <a class="app-brand nav-brand" href="<?php echo $base_url; ?>index.php">Event Registration</a>
      
                <div class="nav-region" id="navbarNav">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link active" href="<?php echo $base_url; ?>events/index.php">Events</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>participants/index.php">Participants</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>registration/index.php">Registrations</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>reports/monitoring.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="site-hero mt-3 mb-4 p-3">
                <h1 class="page-title">Events</h1>
            </div>

            <div class="card-surface mb-3">
                <div class="flex justify-between items-center mb-3">
                    <div>
                        <a href="add.php" class="button">Add Event</a>
                        <a href="search.php" class="button outline ms-2">Search</a>
                    </div>
                </div>
  <?php
  $res = mysqli_query($conn, "SELECT * FROM events ORDER BY evCode DESC");
  if ($res && mysqli_num_rows($res) > 0) {
    echo '<table><thead><tr><th>Code</th><th>Name</th><th>Date</th><th>Venue</th><th>Fee</th><th>Actions</th></tr></thead><tbody>';
    while ($row = mysqli_fetch_assoc($res)) {
      echo '<tr>';
      echo '<td>'.$row['evCode'].'</td>';
      echo '<td>'.$row['evName'].'</td>';
      echo '<td>'.$row['evDate'].'</td>';
      echo '<td>'.$row['evVenue'].'</td>';
      echo '<td>'.$row['evRFee'].'</td>';
      echo '<td><a class="button small outline me-1" href="edit.php?evCode='.$row['evCode'].'">Edit</a>';
      echo '<a class="button small danger-action" href="delete.php?evCode='.$row['evCode'].'" onclick="return confirm(\'Delete this event?\')">Delete</a></td>';
      echo '</tr>';
    }
    echo '</tbody></table>';
    } else {
      echo '<div role="alert" class="notice notice-info">No events found.</div>';
    }
    ?>
            </div>

    
        </div>

  
    </body>
</html>
