<?php
require_once __DIR__ . '/../config/database.php';
$evCode = isset($_GET['evCode']) ? intval($_GET['evCode']) : 0;
if ($evCode) {
    mysqli_query($conn, "DELETE FROM events WHERE evCode={$evCode}");
}
header('Location: index.php');
exit;
