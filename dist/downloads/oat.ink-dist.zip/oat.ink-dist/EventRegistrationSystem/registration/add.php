<?php
require_once __DIR__ . '/../config/database.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['partID'])) {
    $partID = intval($_POST['partID']);
    $regDate = mysqli_real_escape_string($conn, $_POST['regDate']);
    $regFeePaid = floatval($_POST['regFeePaid']);
    $regPMode = mysqli_real_escape_string($conn, $_POST['regPMode']);
    $sql = "INSERT INTO registration (partID, regDate, regFeePaid, regPMode) VALUES ({$partID}, '{$regDate}', {$regFeePaid}, '{$regPMode}')";
    mysqli_query($conn, $sql);
    header('Location: index.php');
    exit;
}
$participants = mysqli_query($conn, "SELECT p.partID, p.partFName, p.partLName, e.evName, e.evRFee, p.partDRate FROM participants p JOIN events e USING(evCode) ORDER BY p.partID DESC");
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Register Participant</title>
    </head>
    <body>
        <nav class="app-nav">
            <div class="container-fluid">
                <a class="app-brand nav-brand" href="<?php echo $base_url; ?>index.php">Event Registration</a>
      
                <div class="nav-region" id="navbarNav">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link" href="<?php echo $base_url; ?>events/index.php">Events</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>participants/index.php">Participants</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>registration/index.php">Registrations</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>reports/monitoring.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container form-page">
            <div class="site-hero mt-3 mb-4 p-3">
                <h1 class="page-title">Register Participant</h1>
                <p class="muted">Compute fee and register selected participant.</p>
            </div>

            <div class="card-surface">
                <form method="post" action="compute.php" class="entry-form">
                    <div class="field-grid">
                        <div class="mb-3">
                            <label for="input-partID">Participant</label>
                            <select name="partID" required id="input-partID">
            <?php while ($p = mysqli_fetch_assoc($participants)) {
              echo '<option value="'.$p['partID'].'" data-fee="'.$p['evRFee'].'" data-discount="'.$p['partDRate'].'">'.$p['partFName'].' '.$p['partLName'].' - '.$p['evName'].'</option>';
            } ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="input-regDate">Registration Date</label>
                            <input type="date" name="regDate" value="<?php echo date('Y-m-d'); ?>" required id="input-regDate">
                        </div>
                        <div class="mb-3">
                            <label for="input-regPMode">Payment Mode</label>
                            <select name="regPMode" id="input-regPMode">
                                <option>Cash</option>
                                <option>Card</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button class="button">Compute Fee</button>
                        <a href="index.php" class="button outline ms-2">Cancel</a>
                    </div>
                </form>
            </div>

            <div class="app-footer">Use the navigation above to move between screens.</div>
        </div>

  
    </body>
</html>
