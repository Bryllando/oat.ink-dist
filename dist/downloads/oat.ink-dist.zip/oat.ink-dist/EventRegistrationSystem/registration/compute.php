<?php
require_once __DIR__ . '/../config/database.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $partID = intval($_POST['partID']);
    $regDate = mysqli_real_escape_string($conn, $_POST['regDate']);
    $regPMode = mysqli_real_escape_string($conn, $_POST['regPMode']);
    // get event fee and participant discount
    $sql = "SELECT e.evRFee, p.partDRate FROM participants p JOIN events e USING(evCode) WHERE p.partID={$partID} LIMIT 1";
    $res = mysqli_query($conn, $sql);
    if ($res && mysqli_num_rows($res) > 0) {
      $row = mysqli_fetch_assoc($res);
      $evRFee = floatval($row['evRFee']);
      $partDRate = floatval($row['partDRate']);
      $regFeePaid = $evRFee - $partDRate; // formula
      if ($regFeePaid < 0) $regFeePaid = 0;
      $regFeePaid = number_format($regFeePaid,2,'.','');
      $ins = "INSERT INTO registration (partID, regDate, regFeePaid, regPMode) VALUES ({$partID}, '{$regDate}', {$regFeePaid}, '{$regPMode}')";
      mysqli_query($conn, $ins);
      header('Location: index.php');
      exit;
    }
}
header('Location: add.php');
exit;
