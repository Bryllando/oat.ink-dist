<?php
require_once __DIR__ . '/../config/database.php';
$regCode = isset($_GET['regCode']) ? intval($_GET['regCode']) : 0;
if ($regCode) {
    mysqli_query($conn, "DELETE FROM registration WHERE regCode={$regCode}");
}
header('Location: index.php');
exit;
