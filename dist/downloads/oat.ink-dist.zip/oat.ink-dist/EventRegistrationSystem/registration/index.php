<?php
require_once __DIR__ . '/../config/database.php';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Registration</title>
    </head>
    <body>
        <nav class="app-nav">
            <div class="container-fluid">
                <a class="app-brand nav-brand" href="<?php echo $base_url; ?>index.php">Event Registration</a>
      
                <div class="nav-region" id="navbarNav">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link" href="<?php echo $base_url; ?>events/index.php">Events</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>participants/index.php">Participants</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>registration/index.php">Registrations</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>reports/monitoring.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="site-hero mt-3 mb-4 p-3">
                <h1 class="page-title">Registrations</h1>
            </div>

            <div class="card-surface mb-3">
                <a href="add.php" class="button mb-3">Register Participant</a>
      <?php
      $sql = "SELECT r.*, p.partFName, p.partLName, e.evName FROM registration r JOIN participants p USING(partID) JOIN events e ON p.evCode = e.evCode ORDER BY regDate DESC";
      $res = mysqli_query($conn, $sql);
      if ($res && mysqli_num_rows($res) > 0) {
        echo '<table><thead><tr><th>Code</th><th>Participant</th><th>Event</th><th>Date</th><th>Fee Paid</th><th>Mode</th><th>Actions</th></tr></thead><tbody>';
        while ($row = mysqli_fetch_assoc($res)) {
          echo '<tr>';
          echo '<td>'.$row['regCode'].'</td>';
          echo '<td>'.$row['partFName'].' '.$row['partLName'].'</td>';
          echo '<td>'.$row['evName'].'</td>';
          echo '<td>'.$row['regDate'].'</td>';
          echo '<td>'.$row['regFeePaid'].'</td>';
          echo '<td>'.$row['regPMode'].'</td>';
          echo '<td><a class="button small danger-action" href="delete.php?regCode='.$row['regCode'].'" onclick="return confirm(\'Delete this registration?\')">Delete</a></td>';
          echo '</tr>';
        }
        echo '</tbody></table>';
      } else {
        echo '<div role="alert" class="notice notice-info">No registrations yet.</div>';
      }
      ?>
            </div>
            <div class="app-footer">Use the navigation above to move between screens.</div>
        </div>

  
    </body>
</html>
