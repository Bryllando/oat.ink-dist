<?php
require_once __DIR__ . '/../config/database.php';
$filter = isset($_GET['evName']) ? mysqli_real_escape_string($conn, $_GET['evName']) : '';
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="../assets/css/oat.min.css">
        <link rel="stylesheet" href="../assets/css/app.css">
        <script src="../assets/js/oat.min.js" defer></script>
        <script src="../assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Monitoring Report</title>
    </head>
    <body>
        <nav class="app-nav">
            <div class="container-fluid">
                <a class="app-brand nav-brand" href="<?php echo $base_url; ?>index.php">Event Registration</a>
      
                <div class="nav-region" id="navbarNav">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link" href="<?php echo $base_url; ?>events/index.php">Events</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>participants/index.php">Participants</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>registration/index.php">Registrations</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>reports/monitoring.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            <div class="site-hero mt-3 mb-4 p-3">
                <h1 class="page-title">Monitoring Report</h1>
            </div>

            <div class="card-surface mb-3">
                <form class="mb-3 filter-form">
                    <div class="input-group">
                        <input name="evName" value="<?php echo htmlspecialchars($filter); ?>" placeholder="Filter by Event Name">
                        <button class="button">Filter</button>
                        <a class="button outline" href="monitoring.php">Clear</a></div>
      
                </form>
      <?php
      $where = '';
      if ($filter !== '') $where = "WHERE e.evName LIKE '%{$filter}%'";
      $sql = "SELECT e.evName, CONCAT(p.partFName,' ',p.partLName) AS participantName, r.regDate, r.regFeePaid, e.evRFee FROM registration r JOIN participants p USING(partID) JOIN events e ON p.evCode = e.evCode {$where} ORDER BY r.regDate DESC";
      $res = mysqli_query($conn, $sql);
      echo '<table><thead><tr><th>Event Name</th><th>Participant</th><th>Registration Date</th><th>Fee Paid</th></tr></thead><tbody>';
      while ($row = mysqli_fetch_assoc($res)) {
        echo '<tr>';
        echo '<td>'.$row['evName'].'</td>';
        echo '<td>'.$row['participantName'].'</td>';
        echo '<td>'.$row['regDate'].'</td>';
        echo '<td>'.$row['regFeePaid'].'</td>';
        echo '</tr>';
      }
      echo '</tbody></table>';

      // aggregates
      $aggSql = "SELECT COUNT(*) AS totalRegistrations, COALESCE(SUM(r.regFeePaid), 0) AS totalFees, COALESCE(SUM(e.evRFee - r.regFeePaid), 0) AS totalDiscounts FROM registration r JOIN participants p USING(partID) JOIN events e ON p.evCode = e.evCode {$where}";
      $aggRes = mysqli_query($conn, $aggSql);
      $agg = mysqli_fetch_assoc($aggRes);
      ?>
                <div class="mt-3">
                    <strong>Total Registrations:</strong> <?php echo $agg['totalRegistrations']; ?><br>
                    <strong>Total Fees:</strong> <?php echo number_format($agg['totalFees'],2); ?><br>
                    <strong>Total Discounts:</strong> <?php echo number_format($agg['totalDiscounts'],2); ?><br>
                </div>
            </div>
            <div class="app-footer">Use the navigation above to move between screens.</div>
        </div>

  
    </body>
</html>
