> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

# Event Registration System

This project is a simple offline Event Registration System built for XAMPP localhost.

## Features
- PHP procedural code with mysqli
- Local MySQL database: `event_registration`
- Local Oat UI assets only
- No OOP, no MVC, no AJAX, no Composer
- Simple CRUD modules for Events, Participants, Registrations, and Monitoring
- Beginner-friendly, easy to navigate layout

## Setup
1. Copy this folder to `C:\xampp\htdocs\EventRegistrationSystem`
2. Start Apache and MySQL in XAMPP
3. Import the database file into phpMyAdmin or use CLI:

```sql
mysql -u root < "C:/xampp/htdocs/EventRegistrationSystem/database/event_registration.sql"
```

4. Open the app in your browser:

```
http://localhost/EventRegistrationSystem/index.php
```

## Database schema
The system uses a single database named `event_registration` with these tables:

- `events`
  - `evCode` INT PK
  - `evName` VARCHAR
  - `evDate` DATE
  - `evVenue` VARCHAR
  - `evRFee` DECIMAL
- `participants`
  - `partID` INT PK
  - `evCode` INT FK -> `events.evCode`
  - `partFName` VARCHAR
  - `partLName` VARCHAR
  - `partDRate` DECIMAL
- `registration`
  - `regCode` INT PK
  - `partID` INT FK -> `participants.partID`
  - `regDate` DATE
  - `regFeePaid` DECIMAL
  - `regPMode` VARCHAR

## Modules and pages
- `index.php` — Homepage with module navigation
- `events/` — Events CRUD
  - `index.php`, `add.php`, `edit.php`, `delete.php`, `search.php`
- `participants/` — Participants CRUD
  - `index.php`, `add.php`, `edit.php`, `delete.php`, `search.php`
- `registration/` — Registration flow
  - `index.php`, `add.php`, `compute.php`, `delete.php`
- `reports/` — Monitoring report
  - `monitoring.php`

## What is implemented
- Events module: add, search, edit, delete, view list
- Participants module: add, search, edit, delete, view list
- Registration module: select participant, compute fee, save registration, view records, delete
- Monitoring report: filter by event name, list registration details, show totals
- Fee calculation uses `event fee - discount rate`
- Monitoring aggregates use:
  - `COUNT(*)` for total registrations
  - `SUM(regFeePaid)` for total fees
  - `SUM(evRFee - regFeePaid)` for total discounts

## Important files
- `config/database.php` — database connection
- `database/event_registration.sql` — schema and sample data
- `includes/header.php` / `includes/footer.php` — shared page layout
- `assets/css/app.css` — local custom styles
- `assets/css/oat.min.css` and `assets/js/oat.min.js` — local Oat assets

## Notes
- You can remove `database/event_registration.sql` after importing if you do not need it anymore.
- Keep all code procedural and beginner-friendly.
- The app is designed to be simple and easy to use.

## Verification checklist
- [x] Database schema created for events, participants, registration
- [x] Events module with CRUD and search
- [x] Participants module with CRUD and search
- [x] Registration fee calculated correctly
- [x] Monitoring report with filter and aggregates
- [x] Local Oat assets used for offline operation

## How to use
1. Open `index.php`
2. Choose `Events`, `Participants`, `Registrations`, or `Monitoring`
3. Use add/search/edit/delete from each module
4. For registrations, select a participant and register using the computed fee
5. Use Monitoring to review registration records and totals
✗ Responsive perfection
✗ Security perfection
✗ Professional architecture
The most important prompt to put at the top of EVERY Copilot request:
IMPORTANT:

This is a college skills test project.

Requirements:
- PHP procedural mysqli only
- XAMPP localhost
- MySQL
- Bootstrap local files only
- Offline ready
- No internet required
- No frameworks
- No OOP
- No Composer
- No AJAX
- Beginner-friendly code
- Easy to understand
- Prioritize passing the skills test rather than enterprise architecture

## ⭐ Project Structure Philosophy — Apply to ALL Future Projects

**Keep the folder structure minimal and flat.** This is the preferred approach for all future PHP projects, same as the styling below. Do NOT over-engineer with subfolders, config layers, includes, or assets directories unless the project truly demands it.

### ✅ Preferred: Minimal Flat Structure (use this)
```
ProjectName/
├── styles.css          ← single shared stylesheet
├── db.php              ← single DB connection file
├── index.php           ← dashboard / home
├── [feature].php       ← one file per feature/module
└── [feature].sql       ← database schema
```

### ❌ Avoid: Over-engineered Structure (unnecessary for small projects)
```
ProjectName/
├── assets/css/app.css
├── config/database.php
├── includes/header.php
├── includes/footer.php
├── events/index.php
├── participants/index.php
└── ...
```

### Why Minimal?
- ✅ Faster to build and navigate
- ✅ Easier to understand at a glance
- ✅ No unnecessary abstraction
- ✅ Less chance of path/include errors

> The complex nested structure is only useful for large enterprise apps with many developers. For capstone tests, skills tests, and small projects — **flat is always better.**

---

## UI Style Guide

> **⭐ Preferred Style — Apply to ALL future PHP projects.**
> This is the standard look and layout the developer prefers. When starting any new PHP/HTML project, replicate this structure, color palette, and CSS classes. Copy `assets/css/app.css` into the project root and link it in every page's `<head>` with `<link rel="stylesheet" href="styles.css">`.

### General Rules
- **Font:** `Arial, Helvetica, sans-serif` — standard system font, no Google Fonts import needed.
- **Background:** Light gray `#f4f6f9` on `body`, white `#ffffff` for all cards/tables.
- **Text:** Dark gray `#333333` for headings, `#555555` for secondary/muted text.
- **Border:** All borders use `1px solid #ddd` with `border-radius: 4px` for a flat, non-rounded look.

### Color Palette (Basic Colors Only)

| Purpose       | Color        | Hex Code  |
|---------------|--------------|-----------|
| Primary / Blue | Links, Buttons, Focus | `#007bff` |
| Success / Green | Attendance confirmed | `#28a745` |
| Warning / Yellow | Edit buttons | `#ffc107` |
| Danger / Red | Delete buttons, Error alerts | `#dc3545` |
| Light Gray | Table headers, Badges, Hover | `#f1f1f1` / `#f9f9f9` |
| White | Cards, Navbar, Inputs | `#ffffff` |

### Layout Pattern (Every Page)
Every page must follow this exact structure. The `<nav>` is a **direct child of `<body>`** (NOT inside `.page-container`) so that `position: fixed` spans the full browser width:

```html
<body>
  <!-- Navbar: OUTSIDE page-container so it spans full width -->
  <nav class="navbar">
    <a href="index.php" class="navbar-brand">App Name</a>
    <div class="navbar-nav">
      <a href="page.php" class="nav-link active">Page</a>  <!-- active = blue highlight -->
    </div>
  </nav>

  <!-- All page content goes inside page-container -->
  <div class="page-container">           <!-- max-width: 1000px, centered via margin:auto -->

    <div class="page-title">...</div>    <!-- bold 28px heading -->

    <div class="card">...</div>          <!-- white box with gray border, padding: 30px -->

    <div class="table-container">        <!-- wraps <table>, adds border + rounding -->
      <table>...</table>
    </div>

  </div>
</body>
```

### Form Inputs
- Use class `form-control` on all `<input>`, `<select>`.
- Wrap multiple inputs side-by-side in a `<form class="form-inline">` (uses `display: flex; gap: 15px;`).
- For stacked labeled fields (e.g. Edit page), use `<div class="form-group">` with a `<label>` above.

### Buttons

| Class | Color | Use |
|---|---|---|
| `btn btn-primary` | Blue `#007bff` | Main submit/save actions |
| `btn btn-secondary` | White + gray border | Cancel / back actions |
| `btn-action btn-edit` | Yellow `#ffc107` | Inline table Edit action |
| `btn-action btn-delete` | Red `#dc3545` | Inline table Delete action |

### Alerts

| Class | Color | When to use |
|---|---|---|
| `alert alert-success` | Green background | Successful operation |
| `alert alert-warning` | Red/pink background | Error or already-exists warning |

### Table Structure
```html
<div class="table-container">
  <table>
    <thead>
      <tr>
        <th>Column</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Data</td>
        <td>
          <div class="action-buttons">
            <a href="edit.php?id=..." class="btn-action btn-edit">Edit</a>
            <a href="?del=..."      class="btn-action btn-delete">Delete</a>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
</div>
```

### Active Nav Link
Add `class="nav-link active"` to the link matching the current page. This makes the nav pill highlight blue.

```php
<!-- Example in registration.php -->
<a href="registration.php" class="nav-link active">Registration</a>
<a href="attendance.php"   class="nav-link">Attendance</a>
<a href="raffle.php"       class="nav-link">Raffle</a>
```
