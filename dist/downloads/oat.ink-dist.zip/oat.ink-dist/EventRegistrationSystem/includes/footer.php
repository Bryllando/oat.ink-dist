<?php
// Shared footer.
?>
  
</body>
</html>
