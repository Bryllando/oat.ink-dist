<?php
// Shared header and navbar
?>
<!doctype html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="<?php echo $base_url; ?>assets/css/oat.min.css">
        <link rel="stylesheet" href="<?php echo $base_url; ?>assets/css/app.css">
        <script src="<?php echo $base_url; ?>assets/js/oat.min.js" defer></script>
        <script src="<?php echo $base_url; ?>assets/js/app.js" defer></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
  
  
        <title>Event Registration System</title>
    </head>
    <body>
        <nav class="app-nav">
            <div class="container-fluid">
                <a class="app-brand" href="<?php echo $base_url; ?>index.php">Event Registration</a>
      
                <div class="nav-region" id="navbarNav">
                    <ul class="nav-links ms-auto">
                        <li><a class="nav-link" href="<?php echo $base_url; ?>events/index.php">Events</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>participants/index.php">Participants</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>registration/index.php">Registrations</a></li>
                        <li><a class="nav-link" href="<?php echo $base_url; ?>reports/monitoring.php">Monitoring</a></li>
                    </ul>
                </div>
            </div>
        </nav>
