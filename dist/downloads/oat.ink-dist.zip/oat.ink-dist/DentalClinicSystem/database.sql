CREATE DATABASE IF NOT EXISTS dental_clinic;
USE dental_clinic;

CREATE TABLE IF NOT EXISTS dentists (
  dentistID INT AUTO_INCREMENT PRIMARY KEY,
  dentistFName VARCHAR(100) NOT NULL,
  dentistLName VARCHAR(100) NOT NULL,
  specialization VARCHAR(100) NOT NULL,
  contactNo VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS patients (
  patientID INT AUTO_INCREMENT PRIMARY KEY,
  patientFName VARCHAR(100) NOT NULL,
  patientLName VARCHAR(100) NOT NULL,
  birthDate DATE NOT NULL,
  contactNo VARCHAR(50) NOT NULL,
  address VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS appointments (
  appointmentID INT AUTO_INCREMENT PRIMARY KEY,
  patientID INT NOT NULL,
  dentistID INT NOT NULL,
  appointmentDate DATETIME NOT NULL,
  purpose VARCHAR(255) NOT NULL,
  status VARCHAR(30) NOT NULL,
  notes TEXT,
  FOREIGN KEY (patientID) REFERENCES patients(patientID) ON DELETE CASCADE,
  FOREIGN KEY (dentistID) REFERENCES dentists(dentistID) ON DELETE CASCADE
);

DELETE a1 FROM appointments a1
JOIN appointments a2
ON a1.appointmentID > a2.appointmentID
AND a1.patientID = a2.patientID
AND a1.dentistID = a2.dentistID
AND a1.appointmentDate = a2.appointmentDate
AND a1.purpose = a2.purpose
AND a1.status = a2.status
AND COALESCE(a1.notes, '') = COALESCE(a2.notes, '');

INSERT INTO dentists (dentistFName, dentistLName, specialization, contactNo)
SELECT 'Maria', 'Santos', 'Orthodontics', '09171234567'
WHERE NOT EXISTS (SELECT 1 FROM dentists WHERE dentistFName = 'Maria' AND dentistLName = 'Santos' AND specialization = 'Orthodontics' AND contactNo = '09171234567');

INSERT INTO dentists (dentistFName, dentistLName, specialization, contactNo)
SELECT 'Jose', 'Reyes', 'General Dentistry', '09181234567'
WHERE NOT EXISTS (SELECT 1 FROM dentists WHERE dentistFName = 'Jose' AND dentistLName = 'Reyes' AND specialization = 'General Dentistry' AND contactNo = '09181234567');

INSERT INTO patients (patientFName, patientLName, birthDate, contactNo, address)
SELECT 'Ana', 'Dela Cruz', '1998-04-12', '09161234567', 'Quezon City'
WHERE NOT EXISTS (SELECT 1 FROM patients WHERE patientFName = 'Ana' AND patientLName = 'Dela Cruz' AND birthDate = '1998-04-12' AND contactNo = '09161234567' AND address = 'Quezon City');

INSERT INTO patients (patientFName, patientLName, birthDate, contactNo, address)
SELECT 'Luis', 'Mendoza', '2001-09-03', '09151234567', 'Makati City'
WHERE NOT EXISTS (SELECT 1 FROM patients WHERE patientFName = 'Luis' AND patientLName = 'Mendoza' AND birthDate = '2001-09-03' AND contactNo = '09151234567' AND address = 'Makati City');

INSERT INTO appointments (patientID, dentistID, appointmentDate, purpose, status, notes)
SELECT 1, 1, '2026-07-10 09:00:00', 'Teeth cleaning', 'Scheduled', 'Bring dental records'
WHERE NOT EXISTS (SELECT 1 FROM appointments WHERE patientID = 1 AND dentistID = 1 AND appointmentDate = '2026-07-10 09:00:00' AND purpose = 'Teeth cleaning' AND status = 'Scheduled' AND COALESCE(notes, '') = 'Bring dental records');

INSERT INTO appointments (patientID, dentistID, appointmentDate, purpose, status, notes)
SELECT 2, 2, '2026-07-11 14:30:00', 'Tooth extraction', 'Completed', 'Follow-up next week'
WHERE NOT EXISTS (SELECT 1 FROM appointments WHERE patientID = 2 AND dentistID = 2 AND appointmentDate = '2026-07-11 14:30:00' AND purpose = 'Tooth extraction' AND status = 'Completed' AND COALESCE(notes, '') = 'Follow-up next week');
