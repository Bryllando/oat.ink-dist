<?php
require_once 'db.php';
$conn = getConnection();

$message = '';
$type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $patientID = intval($_POST['patientID']);
    $dentistID = intval($_POST['dentistID']);
    $appointmentDate = trim($_POST['appointmentDate']);
    $purpose = trim($_POST['purpose']);
    $status = trim($_POST['status']);
    $notes = trim($_POST['notes']);

    if ($patientID <= 0 || $dentistID <= 0 || $appointmentDate === '' || $purpose === '' || $status === '') {
        $message = 'Please fill in all required fields.';
        $type = 'danger';
    } else {
        $id = intval($_POST['appointmentID'] ?? 0);
        if ($id > 0) {
            $stmt = $conn->prepare('UPDATE appointments SET patientID=?, dentistID=?, appointmentDate=?, purpose=?, status=?, notes=? WHERE appointmentID=?');
            $stmt->bind_param('iissssi', $patientID, $dentistID, $appointmentDate, $purpose, $status, $notes, $id);
            $stmt->execute();
            $message = 'Appointment updated successfully.';
        } else {
            $stmt = $conn->prepare('INSERT INTO appointments (patientID, dentistID, appointmentDate, purpose, status, notes) VALUES (?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('iissss', $patientID, $dentistID, $appointmentDate, $purpose, $status, $notes);
            $stmt->execute();
            $message = 'Appointment added successfully.';
        }
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare('DELETE FROM appointments WHERE appointmentID=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $message = 'Appointment deleted successfully.';
}

$edit = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $edit = $conn->query("SELECT * FROM appointments WHERE appointmentID=$id")->fetch_assoc();
}

$patients = $conn->query('SELECT * FROM patients ORDER BY patientLName, patientFName');
$dentists = $conn->query('SELECT * FROM dentists ORDER BY dentistLName, dentistFName');
$appointments = $conn->query("SELECT a.*, p.patientFName, p.patientLName, d.dentistFName, d.dentistLName
    FROM appointments a
    JOIN patients p ON p.patientID = a.patientID
    JOIN dentists d ON d.dentistID = a.dentistID
    ORDER BY a.appointmentDate DESC");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Appointments</title>
    
    </head>
    <body>
        <nav class="app-nav">
            <a class="app-brand" href="index.php">Dental Clinic</a>
            <a href="index.php">Dashboard</a>
            <a href="dentists.php">Dentists</a>
            <a href="patients.php">Patients</a>
            <a class="active" href="appointments.php">Appointments</a>
            <a href="reports.php">Reports</a>
        </nav>

        <div class="container">
        <?php if ($message !== ''): ?>
            <div role="alert" class="notice notice-<?php echo htmlspecialchars($type); ?>"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

            <div class="card">
                <h1 class="page-title"><?php echo $edit ? 'Edit Appointment' : 'Create Appointment'; ?></h1>
                <form method="post" class="entry-form">
                    <input type="hidden" name="appointmentID" value="<?php echo $edit ? (int) $edit['appointmentID'] : 0; ?>">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-patientID">Patient</label>
                            <select name="patientID" required id="input-patientID">
                                <option value="">Select Patient</option>
                        <?php while ($row = $patients->fetch_assoc()): ?>
                                <option value="<?php echo $row['patientID']; ?>" <?php echo (($edit['patientID'] ?? '') == $row['patientID']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($row['patientFName'] . ' ' . $row['patientLName']); ?></option>
                        <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="input-dentistID">Dentist</label>
                            <select name="dentistID" required id="input-dentistID">
                                <option value="">Select Dentist</option>
                        <?php while ($row = $dentists->fetch_assoc()): ?>
                                <option value="<?php echo $row['dentistID']; ?>" <?php echo (($edit['dentistID'] ?? '') == $row['dentistID']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($row['dentistFName'] . ' ' . $row['dentistLName']); ?></option>
                        <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="input-appointmentDate">Appointment Date and Time</label>
                            <input type="datetime-local" name="appointmentDate" value="<?php echo htmlspecialchars($edit['appointmentDate'] ?? ''); ?>" required id="input-appointmentDate">
                        </div>
                        <div class="form-group">
                            <label for="input-purpose">Purpose</label>
                            <input type="text" name="purpose" value="<?php echo htmlspecialchars($edit['purpose'] ?? ''); ?>" required id="input-purpose">
                        </div>
                        <div class="form-group">
                            <label for="input-status">Status</label>
                            <select name="status" required id="input-status">
                                <option value="Scheduled" <?php echo (($edit['status'] ?? '') === 'Scheduled') ? 'selected' : ''; ?>>Scheduled</option>
                                <option value="Completed" <?php echo (($edit['status'] ?? '') === 'Completed') ? 'selected' : ''; ?>>Completed</option>
                                <option value="Cancelled" <?php echo (($edit['status'] ?? '') === 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="input-notes">Notes</label>
                            <textarea name="notes" id="input-notes"><?php echo htmlspecialchars($edit['notes'] ?? ''); ?></textarea>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="save">Save</button>
                <?php if ($edit): ?>
                        <a href="appointments.php" class="button outline">Cancel</a>
                <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Appointment Records</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Patient</th>
                            <th>Dentist</th>
                            <th>Date & Time</th>
                            <th>Purpose</th>
                            <th>Status</th>
                            <th>Notes</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($row = $appointments->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['patientFName'] . ' ' . $row['patientLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['dentistFName'] . ' ' . $row['dentistLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['appointmentDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['purpose']); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                            <td><?php echo htmlspecialchars($row['notes']); ?></td>
                            <td class="actions">
                                <a href="appointments.php?edit=<?php echo $row['appointmentID']; ?>" class="button small outline">Edit</a>
                                <a href="appointments.php?delete=<?php echo $row['appointmentID']; ?>" onclick="return confirm('Delete this appointment?')" class="button small danger-action">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
