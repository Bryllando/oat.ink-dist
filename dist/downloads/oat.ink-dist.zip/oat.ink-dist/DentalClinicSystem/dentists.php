<?php
require_once 'db.php';
$conn = getConnection();

$message = '';
$type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $fname = trim($_POST['dentistFName']);
    $lname = trim($_POST['dentistLName']);
    $specialization = trim($_POST['specialization']);
    $contact = trim($_POST['contactNo']);

    if ($fname === '' || $lname === '' || $specialization === '' || $contact === '') {
        $message = 'Please fill in all fields.';
        $type = 'danger';
    } else {
        $id = intval($_POST['dentistID'] ?? 0);
        if ($id > 0) {
            $stmt = $conn->prepare('UPDATE dentists SET dentistFName=?, dentistLName=?, specialization=?, contactNo=? WHERE dentistID=?');
            $stmt->bind_param('ssssi', $fname, $lname, $specialization, $contact, $id);
            $stmt->execute();
            $message = 'Dentist updated successfully.';
        } else {
            $stmt = $conn->prepare('INSERT INTO dentists (dentistFName, dentistLName, specialization, contactNo) VALUES (?, ?, ?, ?)');
            $stmt->bind_param('ssss', $fname, $lname, $specialization, $contact);
            $stmt->execute();
            $message = 'Dentist added successfully.';
        }
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare('DELETE FROM dentists WHERE dentistID=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $message = 'Dentist deleted successfully.';
}

$edit = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $edit = $conn->query("SELECT * FROM dentists WHERE dentistID=$id")->fetch_assoc();
}

$search = trim($_GET['search'] ?? '');
$sql = 'SELECT * FROM dentists';
if ($search !== '') {
    $sql .= " WHERE dentistFName LIKE '%$search%' OR dentistLName LIKE '%$search%' OR specialization LIKE '%$search%'";
}
$sql .= ' ORDER BY dentistLName, dentistFName';
$dentists = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dentists</title>
    
    </head>
    <body>
        <nav class="app-nav">
            <a class="app-brand" href="index.php">Dental Clinic</a>
            <a href="index.php">Dashboard</a>
            <a class="active" href="dentists.php">Dentists</a>
            <a href="patients.php">Patients</a>
            <a href="appointments.php">Appointments</a>
            <a href="reports.php">Reports</a>
        </nav>

        <div class="container">
        <?php if ($message !== ''): ?>
            <div role="alert" class="notice notice-<?php echo htmlspecialchars($type); ?>"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

            <div class="card">
                <h1 class="page-title"><?php echo $edit ? 'Edit Dentist' : 'Add Dentist'; ?></h1>
                <form method="post" class="entry-form">
                    <input type="hidden" name="dentistID" value="<?php echo $edit ? (int) $edit['dentistID'] : 0; ?>">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-dentistFName">First Name</label>
                            <input type="text" name="dentistFName" value="<?php echo htmlspecialchars($edit['dentistFName'] ?? ''); ?>" required id="input-dentistFName">
                        </div>
                        <div class="form-group">
                            <label for="input-dentistLName">Last Name</label>
                            <input type="text" name="dentistLName" value="<?php echo htmlspecialchars($edit['dentistLName'] ?? ''); ?>" required id="input-dentistLName">
                        </div>
                        <div class="form-group">
                            <label for="input-specialization">Specialization</label>
                            <input type="text" name="specialization" value="<?php echo htmlspecialchars($edit['specialization'] ?? ''); ?>" required id="input-specialization">
                        </div>
                        <div class="form-group">
                            <label for="input-contactNo">Contact Number</label>
                            <input type="text" name="contactNo" value="<?php echo htmlspecialchars($edit['contactNo'] ?? ''); ?>" required id="input-contactNo">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="save">Save</button>
                <?php if ($edit): ?>
                        <a href="dentists.php" class="button outline">Cancel</a>
                <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Search Dentists</h2>
                <form method="get" class="filter-form">
                    <div class="form-group">
                        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by name or specialization">
                    </div>
                    <button type="submit">Search</button>
                    <a class="button outline" href="dentists.php">Clear</a>
                </form>
            </div>

            <div class="card">
                <h2>Dentist Records</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Specialization</th>
                            <th>Contact</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($row = $dentists->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['dentistFName'] . ' ' . $row['dentistLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['specialization']); ?></td>
                            <td><?php echo htmlspecialchars($row['contactNo']); ?></td>
                            <td class="actions">
                                <a href="dentists.php?edit=<?php echo $row['dentistID']; ?>" class="button small outline">Edit</a>
                                <a href="dentists.php?delete=<?php echo $row['dentistID']; ?>" onclick="return confirm('Delete this dentist?')" class="button small danger-action">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
