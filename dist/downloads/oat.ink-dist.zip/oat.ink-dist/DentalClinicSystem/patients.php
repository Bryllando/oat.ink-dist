<?php
require_once 'db.php';
$conn = getConnection();

$message = '';
$type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $fname = trim($_POST['patientFName']);
    $lname = trim($_POST['patientLName']);
    $birth = trim($_POST['birthDate']);
    $contact = trim($_POST['contactNo']);
    $address = trim($_POST['address']);

    if ($fname === '' || $lname === '' || $birth === '' || $contact === '' || $address === '') {
        $message = 'Please fill in all fields.';
        $type = 'danger';
    } else {
        $id = intval($_POST['patientID'] ?? 0);
        if ($id > 0) {
            $stmt = $conn->prepare('UPDATE patients SET patientFName=?, patientLName=?, birthDate=?, contactNo=?, address=? WHERE patientID=?');
            $stmt->bind_param('sssssi', $fname, $lname, $birth, $contact, $address, $id);
            $stmt->execute();
            $message = 'Patient updated successfully.';
        } else {
            $stmt = $conn->prepare('INSERT INTO patients (patientFName, patientLName, birthDate, contactNo, address) VALUES (?, ?, ?, ?, ?)');
            $stmt->bind_param('sssss', $fname, $lname, $birth, $contact, $address);
            $stmt->execute();
            $message = 'Patient added successfully.';
        }
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare('DELETE FROM patients WHERE patientID=?');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $message = 'Patient deleted successfully.';
}

$edit = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $edit = $conn->query("SELECT * FROM patients WHERE patientID=$id")->fetch_assoc();
}

$search = trim($_GET['search'] ?? '');
$sql = 'SELECT * FROM patients';
if ($search !== '') {
    $sql .= " WHERE patientFName LIKE '%$search%' OR patientLName LIKE '%$search%' OR address LIKE '%$search%'";
}
$sql .= ' ORDER BY patientLName, patientFName';
$patients = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Patients</title>
    
    </head>
    <body>
        <nav class="app-nav">
            <a class="app-brand" href="index.php">Dental Clinic</a>
            <a href="index.php">Dashboard</a>
            <a href="dentists.php">Dentists</a>
            <a class="active" href="patients.php">Patients</a>
            <a href="appointments.php">Appointments</a>
            <a href="reports.php">Reports</a>
        </nav>

        <div class="container">
        <?php if ($message !== ''): ?>
            <div role="alert" class="notice notice-<?php echo htmlspecialchars($type); ?>"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

            <div class="card">
                <h1 class="page-title"><?php echo $edit ? 'Edit Patient' : 'Add Patient'; ?></h1>
                <form method="post" class="entry-form">
                    <input type="hidden" name="patientID" value="<?php echo $edit ? (int) $edit['patientID'] : 0; ?>">
                    <div class="field-grid">
                        <div class="form-group">
                            <label for="input-patientFName">First Name</label>
                            <input type="text" name="patientFName" value="<?php echo htmlspecialchars($edit['patientFName'] ?? ''); ?>" required id="input-patientFName">
                        </div>
                        <div class="form-group">
                            <label for="input-patientLName">Last Name</label>
                            <input type="text" name="patientLName" value="<?php echo htmlspecialchars($edit['patientLName'] ?? ''); ?>" required id="input-patientLName">
                        </div>
                        <div class="form-group">
                            <label for="input-birthDate">Birth Date</label>
                            <input type="date" name="birthDate" value="<?php echo htmlspecialchars($edit['birthDate'] ?? ''); ?>" required id="input-birthDate">
                        </div>
                        <div class="form-group">
                            <label for="input-contactNo">Contact Number</label>
                            <input type="text" name="contactNo" value="<?php echo htmlspecialchars($edit['contactNo'] ?? ''); ?>" required id="input-contactNo">
                        </div>
                        <div class="form-group">
                            <label for="input-address">Address</label>
                            <textarea name="address" required id="input-address"><?php echo htmlspecialchars($edit['address'] ?? ''); ?></textarea>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="save">Save</button>
                <?php if ($edit): ?>
                        <a href="patients.php" class="button outline">Cancel</a>
                <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Search Patients</h2>
                <form method="get" class="filter-form">
                    <div class="form-group">
                        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by name or address">
                    </div>
                    <button type="submit">Search</button>
                    <a class="button outline" href="patients.php">Clear</a>
                </form>
            </div>

            <div class="card">
                <h2>Patient Records</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Birth Date</th>
                            <th>Contact</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($row = $patients->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['patientFName'] . ' ' . $row['patientLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['birthDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['contactNo']); ?></td>
                            <td><?php echo htmlspecialchars($row['address']); ?></td>
                            <td class="actions">
                                <a href="patients.php?edit=<?php echo $row['patientID']; ?>" class="button small outline">Edit</a>
                                <a href="patients.php?delete=<?php echo $row['patientID']; ?>" onclick="return confirm('Delete this patient?')" class="button small danger-action">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
