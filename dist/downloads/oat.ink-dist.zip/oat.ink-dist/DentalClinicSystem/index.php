<?php
require_once 'db.php';
$conn = getConnection();

$dentistsCount = $conn->query('SELECT COUNT(*) AS total FROM dentists')->fetch_assoc()['total'];
$patientsCount = $conn->query('SELECT COUNT(*) AS total FROM patients')->fetch_assoc()['total'];
$appointmentsCount = $conn->query('SELECT COUNT(*) AS total FROM appointments')->fetch_assoc()['total'];
$upcoming = $conn->query("SELECT a.appointmentID, p.patientFName, p.patientLName, d.dentistFName, d.dentistLName, a.appointmentDate, a.status
    FROM appointments a
    JOIN patients p ON p.patientID = a.patientID
    JOIN dentists d ON d.dentistID = a.dentistID
    ORDER BY a.appointmentDate DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dental Clinic Dashboard</title>
    
    </head>
    <body>
        <nav class="app-nav">
            <a class="app-brand" href="index.php">Dental Clinic</a>
            <a class="active" href="index.php">Dashboard</a>
            <a href="dentists.php">Dentists</a>
            <a href="patients.php">Patients</a>
            <a href="appointments.php">Appointments</a>
            <a href="reports.php">Reports</a>
        </nav>

        <div class="container">
            <div class="card">
                <h1 class="page-title">Dental Clinic Appointment System</h1>
                <p>Simple offline clinic management for XAMPP localhost.</p>
            </div>

            <div class="grid">
                <div class="stat-box">
                    <h3><?php echo $dentistsCount; ?></h3>
                    <p>Dentists</p>
                </div>
                <div class="stat-box">
                    <h3><?php echo $patientsCount; ?></h3>
                    <p>Patients</p>
                </div>
                <div class="stat-box">
                    <h3><?php echo $appointmentsCount; ?></h3>
                    <p>Appointments</p>
                </div>
            </div>

            <div class="card">
                <h2>Latest Appointments</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Patient</th>
                            <th>Dentist</th>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php while ($row = $upcoming->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['patientFName'] . ' ' . $row['patientLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['dentistFName'] . ' ' . $row['dentistLName']); ?></td>
                            <td><?php echo htmlspecialchars($row['appointmentDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>
