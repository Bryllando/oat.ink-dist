<?php
require 'db.php';
$conn = getConnection();

$dentistID = $_GET['dentistID'] ?? '';
$patientID = $_GET['patientID'] ?? '';
$from = $_GET['from'] ?? '';
$to = $_GET['to'] ?? '';

$where = [];
if ($dentistID !== '') $where[] = 'a.dentistID = ' . (int)$dentistID;
if ($patientID !== '') $where[] = 'a.patientID = ' . (int)$patientID;
if ($from !== '') $where[] = "a.appointmentDate >= '" . $conn->real_escape_string($from) . " 00:00:00'";
if ($to !== '') $where[] = "a.appointmentDate <= '" . $conn->real_escape_string($to) . " 23:59:59'";

$sql = "SELECT p.patientFName, p.patientLName, d.dentistFName, d.dentistLName, d.specialization, a.appointmentDate, a.purpose, a.status
FROM appointments a
JOIN patients p ON p.patientID = a.patientID
JOIN dentists d ON d.dentistID = a.dentistID";
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' ORDER BY a.appointmentDate DESC';

$rows = $conn->query($sql);
$dentists = $conn->query('SELECT dentistID, dentistFName, dentistLName FROM dentists ORDER BY dentistLName, dentistFName');
$patients = $conn->query('SELECT patientID, patientFName, patientLName FROM patients ORDER BY patientLName, patientFName');
$summary = $conn->query("SELECT COUNT(*) AS totalAppointments, SUM(status='Scheduled') AS scheduledAppointments, SUM(status='Completed') AS completedAppointments, SUM(status='Cancelled') AS cancelledAppointments FROM appointments");
$summaryRow = $summary->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="assets/css/oat.min.css">
        <link rel="stylesheet" href="assets/css/app.css">
        <script src="assets/js/oat.min.js" defer></script>
        <script src="assets/js/app.js" defer></script>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Reports</title>
  
    </head>
    <body>
        <nav class="app-nav">
            <a class="app-brand" href="index.php">Dental Clinic</a>
            <a href="index.php">Dashboard</a>
            <a href="dentists.php">Dentists</a>
            <a href="patients.php">Patients</a>
            <a href="appointments.php">Appointments</a>
            <a class="active" href="reports.php">Reports</a>
        </nav>
        <div class="container">
            <div class="card">
                <h1 class="page-title">Appointment Reports</h1>
                <form method="get" class="filter-form">
                    <div class="grid">
                        <div class="form-group"><label>Dentist</label><select name="dentistID"><option value="">All</option><?php while ($d = $dentists->fetch_assoc()): ?><option value="<?=$d['dentistID']?>" <?=($dentistID == $d['dentistID']) ? 'selected' : ''?>><?=htmlspecialchars($d['dentistFName'].' '.$d['dentistLName'])?></option><?php endwhile; ?></select></div>
                        <div class="form-group"><label>Patient</label><select name="patientID"><option value="">All</option><?php while ($p = $patients->fetch_assoc()): ?><option value="<?=$p['patientID']?>" <?=($patientID == $p['patientID']) ? 'selected' : ''?>><?=htmlspecialchars($p['patientFName'].' '.$p['patientLName'])?></option><?php endwhile; ?></select></div>
                        <div class="form-group"><label>From</label><input type="date" name="from" value="<?=htmlspecialchars($from)?>"></div>
                        <div class="form-group"><label>To</label><input type="date" name="to" value="<?=htmlspecialchars($to)?>"></div>
                    </div>
                    <button type="submit">Filter</button>
                    <a class="button outline" href="reports.php">Clear</a>
                </form>
            </div>
            <div class="grid">
                <div class="stat-box"><h3><?= (int)$summaryRow['totalAppointments'] ?></h3><p>Total</p></div>
                <div class="stat-box"><h3><?= (int)$summaryRow['scheduledAppointments'] ?></h3><p>Scheduled</p></div>
                <div class="stat-box"><h3><?= (int)$summaryRow['completedAppointments'] ?></h3><p>Completed</p></div>
                <div class="stat-box"><h3><?= (int)$summaryRow['cancelledAppointments'] ?></h3><p>Cancelled</p></div>
            </div>
            <div class="card">
                <h2>Results</h2>
                <table>
                    <thead><tr><th>Patient</th><th>Dentist</th><th>Specialization</th><th>Date</th><th>Purpose</th><th>Status</th></tr></thead>
                    <tbody><?php while ($r = $rows->fetch_assoc()): ?><tr><td><?=htmlspecialchars($r['patientFName'].' '.$r['patientLName'])?></td><td><?=htmlspecialchars($r['dentistFName'].' '.$r['dentistLName'])?></td><td><?=htmlspecialchars($r['specialization'])?></td><td><?=htmlspecialchars($r['appointmentDate'])?></td><td><?=htmlspecialchars($r['purpose'])?></td><td><?=htmlspecialchars($r['status'])?></td></tr><?php endwhile; ?></tbody>
                </table>
            </div>
        </div>
    </body>
</html>
