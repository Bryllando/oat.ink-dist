> **Current setup (Oat):** Copy this whole folder into XAMPP `htdocs`, start Apache and MySQL, and open its local URL. The active styles are `assets/css/oat.min.css` and `assets/css/app.css`; the scripts are in `assets/js`. Earlier scenario notes and code examples below are reference material and may describe the previous design.

# Dental Clinic Appointment System

This project is a simple offline Dental Clinic Appointment System built for XAMPP localhost.

## Features
- PHP procedural code with mysqli
- Local MySQL database: `dental_clinic`
- Local Oat UI assets only
- No OOP, no MVC, no AJAX, no Composer
- Simple CRUD modules for Dentists, Patients, Appointments, and Reports
- Beginner-friendly and easy to navigate
- Designed for a college skills test project

## Setup
1. Copy this folder to:

```text
C:\xampp\htdocs\DentalClinicSystem
Start Apache and MySQL in XAMPP.
Import the database file into phpMyAdmin or use CLI:
mysql -u root < "C:/xampp/htdocs/DentalClinicSystem/dental_clinic.sql"
Open the app in your browser:
http://localhost/DentalClinicSystem/index.php
Database Schema

The system uses a single database named:

dental_clinic
dentists
dentistID INT PRIMARY KEY
dentistFName VARCHAR
dentistLName VARCHAR
specialization VARCHAR
contactNo VARCHAR
patients
patientID INT PRIMARY KEY
patientFName VARCHAR
patientLName VARCHAR
birthDate DATE
contactNo VARCHAR
address VARCHAR
appointments
appointmentID INT PRIMARY KEY
patientID INT FOREIGN KEY → patients.patientID
dentistID INT FOREIGN KEY → dentists.dentistID
appointmentDate DATETIME
purpose VARCHAR
status VARCHAR
notes TEXT
Modules and Pages
Main Pages
index.php — Dashboard / homepage
dentists.php — Dentists CRUD
patients.php — Patients CRUD
appointments.php — Appointment transaction module
reports.php — Appointment inquiry and reports
db.php — Database connection
styles.css — Main stylesheet
dental_clinic.sql — Database schema and sample data
What is Implemented
Dentists Module
Add dentist record
Search dentist record
Edit dentist record
Delete dentist record
View dentist records
Patients Module
Add patient record
Search patient record
Edit patient record
Delete patient record
View patient records
Appointments Module
Create appointment
Select patient
Select dentist
Add appointment date and time
Add purpose or reason of visit
Add status:
Scheduled
Completed
Cancelled
View appointment records from latest to oldest
Edit appointment record
Delete appointment record
Reports Module
Filter appointments by:
Dentist specialization
Patient ID
Dentist ID
Date range
Display:
Patient full name
Dentist full name
Dentist specialization
Appointment date/time
Purpose
Status
Use aggregate function:
COUNT(*) for total appointments
Important SQL Aggregates
COUNT(*) AS totalAppointments

Optional status counts:

COUNT(CASE WHEN status = 'Scheduled' THEN 1 END) AS scheduledAppointments
COUNT(CASE WHEN status = 'Completed' THEN 1 END) AS completedAppointments
COUNT(CASE WHEN status = 'Cancelled' THEN 1 END) AS cancelledAppointments
Recommended Minimal Project Structure
DentalClinicSystem/
├── styles.css
├── db.php
├── index.php
├── dentists.php
├── patients.php
├── appointments.php
├── reports.php
└── dental_clinic.sql
Notes
This project is intentionally simple.
It is made for a college skills test.
It works offline using XAMPP.
It does not require internet connection.
It uses local Bootstrap files only if Bootstrap is included.
Keep the code procedural and beginner-friendly.
Do not use frameworks, Composer, MVC, AJAX, or OOP.
Verification Checklist
 Database created: dental_clinic
 Dentists table created
 Patients table created
 Appointments table created
 Dentists CRUD working
 Patients CRUD working
 Appointment transaction working
 Reports page with filters working
 COUNT aggregate working
 Local CSS used
 Offline ready for XAMPP 

 # 🎨 UI Style Guide

Use this style for ALL future PHP skills test projects.

## General

- Font: Arial, Helvetica, sans-serif
- Body: `#f4f6f9`
- Cards/Tables/Navbar: `#ffffff`
- Text: `#333333`
- Border: `1px solid #ddd`
- Border Radius: `4px`

## Colors

| Purpose | Color |
|---------|--------|
| Primary | `#007bff` |
| Success | `#28a745` |
| Warning | `#ffc107` |
| Danger | `#dc3545` |
| Gray | `#f1f1f1` |
| White | `#ffffff` |

## Buttons

| Class | Use |
|------|------|
| `btn btn-primary` | Save / Add |
| `btn btn-secondary` | Back / Cancel |
| `btn-action btn-edit` | Edit |
| `btn-action btn-delete` | Delete |

## Alerts

| Class | Use |
|------|------|
| `alert alert-success` | Success |
| `alert alert-warning` | Error / Not Found |

## Layout

Every page should have:

- Fixed Navbar
- Page Title
- Card Container
- Form
- Table
- Oat UI (local)

## Rules

- PHP Procedural mysqli only
- XAMPP localhost
- Bootstrap local CSS & JS only
- Offline ready
- No OOP
- No MVC
- No AJAX
- No Composer
- Beginner-friendly
- Flat folder structure
- Clean CRUD interface
- Focus on passing the college skills test