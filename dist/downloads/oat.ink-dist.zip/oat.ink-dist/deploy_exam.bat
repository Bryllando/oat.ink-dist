@echo off
setlocal
title Skilltest - Systems and Tools Deployer
color 0b
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy_exam.ps1" %*
set "deployExit=%ERRORLEVEL%"
echo.
pause
exit /b %deployExit%
