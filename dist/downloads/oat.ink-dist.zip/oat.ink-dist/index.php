<?php
$systems = array_map('dirname', glob(__DIR__ . '/*/database.sql'));
if (is_file(__DIR__ . '/SystemMorpher/index.php')) $systems[] = __DIR__ . '/SystemMorpher';
sort($systems);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Skills Test 2</title>
    <link rel="stylesheet" href="assets/css/oat.min.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <script src="assets/js/oat.min.js" defer></script>
    <script src="assets/js/app.js" defer></script>
</head>
<body>
    <main class="container">
        <div class="page-heading">
            <h1>Skills Test 2</h1>
            <p class="text-light">Select from <?= count($systems) ?> systems and tools.</p>
        </div>
        <ul class="simple-menu">
        <?php foreach ($systems as $system):
            $folder = basename($system);
            $title = preg_replace('/(?<=[a-z])(?=[A-Z])/', ' ', $folder);
            $title = str_replace(['Uc ', 'Ict '], ['UC ', 'ICT '], $title);
        ?>
            <li><a href="<?= rawurlencode($folder) ?>/index.php"><?= htmlspecialchars($title) ?></a></li>
        <?php endforeach; ?>
        </ul>
    </main>
</body>
</html>
